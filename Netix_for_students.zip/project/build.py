#!/usr/bin/env python3
"""Python port of build.mjs (Node is not installed on this machine).
Joins css + fonts + js + content fragments into ONE self-contained HTML file.
Run from project/:  python build.py
"""
import base64, json, os, re, sys

ROOT = os.path.dirname(os.path.abspath(__file__))
R = lambda *p: os.path.join(ROOT, *p)


def read(*p):
    with open(R(*p), encoding='utf-8') as f:
        return f.read()


def b64(*p):
    with open(R(*p), 'rb') as f:
        return base64.b64encode(f.read()).decode('ascii')


cfg = json.loads(read('src', 'config.json'))

LATIN = 'U+0000-00FF,U+0131,U+0152-0153,U+02BB-02BC,U+02C6,U+02DA,U+02DC,U+2000-206F,U+20AC,U+2122,U+2191,U+2193,U+2212,U+2215,U+FEFF,U+FFFD'
EXT = 'U+0100-0130,U+0132-02BA,U+02BD-02C5,U+02C7-02CC,U+02CE-02D7,U+02DD-02FF,U+0304,U+0308,U+0329,U+1E00-1E9F,U+1EF2-1EFF,U+2020,U+20A0-20AB,U+20AD-20C0,U+2113,U+2C60-2C7F,U+A720-A7FF'


def face(family, file, weight, stretch, ranges):
    st = 'font-stretch:%s;' % stretch if stretch else ''
    return ("@font-face{font-family:'%s';font-style:normal;font-weight:%s;%sfont-display:swap;"
            "src:url(data:font/woff2;base64,%s) format('woff2');unicode-range:%s;}"
            % (family, weight, st, b64('src', 'fonts', file), ranges))


font_css = '\n'.join([
    face('Archivo', 'archivo-latin-ext.woff2', '100 900', '62% 125%', EXT),
    face('Archivo', 'archivo-latin.woff2', '100 900', '62% 125%', LATIN),
    face('JetBrains Mono', 'jbmono-latin-ext-400.woff2', 400, None, EXT),
    face('JetBrains Mono', 'jbmono-latin-400.woff2', 400, None, LATIN),
    face('JetBrains Mono', 'jbmono-latin-ext-700.woff2', 700, None, EXT),
    face('JetBrains Mono', 'jbmono-latin-700.woff2', 700, None, LATIN),
])


def cat(dirpath, ext, sep, label_prefix=''):
    out = []
    for f in sorted(os.listdir(dirpath)):
        if f.endswith(ext):
            with open(os.path.join(dirpath, f), encoding='utf-8') as fh:
                out.append('/* %s%s */\n' % (label_prefix, f) + fh.read())
    return sep.join(out)


css = font_css + '\n' + cat(R('src', 'css'), '.css', '\n')
core_js = cat(R('src', 'js'), '.js', '\n;\n')

content_dir = R('src', 'content')
root_js = []
for f in sorted(os.listdir(content_dir)):
    if f.endswith('.js'):
        root_js.append('/* content/%s */\n' % f + read('src', 'content', f))

frags, topic_js, problems = {}, [], []
TAGS = ['div', 'details', 'summary', 'pre', 'ul', 'ol', 'li', 'table', 'tr', 'td', 'th', 'p', 'span', 'section', 'figure', 'svg', 'code']


def balance(name, html):
    for tag in TAGS:
        o = len(re.findall(r'<' + tag + r'(\s[^>]*)?>', html))
        c = len(re.findall(r'</' + tag + '>', html))
        if o != c:
            problems.append('%s: <%s> open=%d close=%d' % (name, tag, o, c))


def dirs(p):
    return sorted(d for d in os.listdir(p) if os.path.isdir(os.path.join(p, d)))


for part in dirs(content_dir):
    for topic in dirs(os.path.join(content_dir, part)):
        d = os.path.join(content_dir, part, topic)
        for f in sorted(os.listdir(d)):
            full = os.path.join(d, f)
            if f.endswith('.html'):
                key = '%s/%s/%s' % (part, topic, f[:-5])   # e.g. p1/t01/explain or p1/t01/explain.en
                with open(full, encoding='utf-8') as fh:
                    html = fh.read()
                balance(key, html)
                frags[key] = html
            elif f.endswith('.js'):
                with open(full, encoding='utf-8') as fh:
                    topic_js.append('/* content/%s/%s/%s */\n' % (part, topic, f) + fh.read())

if problems:
    sys.stderr.write('HTML balance problems:\n' + '\n'.join(problems) + '\n')
    sys.exit(1)

frag_js = 'PT.frag = ' + json.dumps(frags, ensure_ascii=False).replace('</', '<\\/') + ';'

FAVICON = ("data:image/svg+xml," + "%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 34 34'%3E%3Crect width='34' height='34' rx='8' fill='%23163a5f'/%3E"
           "%3Cpath d='M9.5 25V9l15 16V9' fill='none' stroke='white' stroke-width='2.6' stroke-linecap='round' stroke-linejoin='round'/%3E"
           "%3Ccircle cx='9.5' cy='25' r='2.8' fill='%2339c46b'/%3E%3Ccircle cx='9.5' cy='9' r='2.8' fill='%23f2b21c'/%3E"
           "%3Ccircle cx='24.5' cy='25' r='2.8' fill='%23f2b21c'/%3E%3Ccircle cx='24.5' cy='9' r='2.8' fill='%2339c46b'/%3E%3C/svg%3E")


def make_html(instructor):
    c = dict(cfg)
    c['instructor'] = bool(instructor)
    js = '\n;\n'.join(['window.PT = window.PT || {}; PT.config = ' + json.dumps(c, ensure_ascii=False) + ';',
                       core_js, frag_js] + root_js + topic_js + ['PT.boot && PT.boot();'])
    js = re.sub(r'</script', r'<\\/script', js, flags=re.I)
    title = cfg['title'] + (' (instructor)' if instructor else '')
    html = """<!doctype html>
<html lang="az" data-theme="light">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="color-scheme" content="light dark">
<title>%s</title>
<link rel="icon" href="%s">
<style>
%s
</style>
</head>
<body>
<div id="app"></div>
<noscript>Bu səhifənin işləməsi üçün JavaScript lazımdır. / This page needs JavaScript.</noscript>
<script>
%s
</script>
</body>
</html>
""" % (title, FAVICON, css, js)
    return html, js


import shutil
os.makedirs(R('dist'), exist_ok=True)
# two packages, each a folder with: the page, server.py and ONE launcher (.bat)
for instructor, folder, page, bat in ((False, 'Netix', 'Netix.html', 'Netix.bat'),
                                      (True, 'Netix_Instructor', 'Netix_Instructor.html', 'Netix_Instructor.bat')):
    html, js = make_html(instructor)
    pkg = R('dist', folder)
    if os.path.isdir(pkg):
        for fn in ('server.py', 'README.txt', bat, page):
            fp = os.path.join(pkg, fn)
            if os.path.exists(fp):
                os.remove(fp)
    os.makedirs(pkg, exist_ok=True)
    with open(os.path.join(pkg, page), 'w', encoding='utf-8', newline='\n') as f:
        f.write(html)
    shutil.copy(R('server', 'server.py'), os.path.join(pkg, 'server.py'))
    shutil.copy(R('server', 'README.txt'), os.path.join(pkg, 'README.txt'))
    with open(R('server', bat), encoding='utf-8') as f:
        bat_text = f.read()
    with open(os.path.join(pkg, bat), 'w', encoding='utf-8', newline='\r\n') as f:   # .bat wants Windows line endings
        f.write(bat_text.replace('\r\n', '\n'))
    print('built %s/%s  %d KB  (css %d KB, js %d KB, fragments %d)' % (folder, page, len(html.encode('utf-8')) // 1024, len(css) // 1024, len(js) // 1024, len(frags)))
