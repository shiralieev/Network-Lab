# NETIX project notes (v2, read this first; NOTES.md is the old v1 file)

Name: **Netix** (was "Packet Tracer Sifirdan Pesekara"). The source of truth is this folder (Desktop/Netix/project). The Downloads handoff is the old v1.

## Build and run
- Node is NOT installed on this machine. Build with `python build.py`. It makes `dist/Netix/` (student) and `dist/Netix_Instructor/` (every topic open, all lab and quiz answers shown).
- Run: double-click `Netix.bat` inside a folder that also holds `Netix.html` and `server.py` (ready copies: `Desktop/Netix/Netix` and `Desktop/Netix/Netix_Instructor`). It starts `server.py` on 127.0.0.1:47310 (instructor 47311) and opens the browser.
- Progress is stored in `Netix_data/state.json` next to the .bat (not in the browser). If the html is opened as a plain file, localStorage is only a fallback.
- Testing: start `python server.py --no-browser --port 47320` from `dist/Netix`, open it in a browser, delete the test `Netix_data` folder afterwards. Never kill all python processes (the user runs other Python apps).

## Writing style (user feedback 2026-11-05, applies to every topic)
- NO generic label paragraphs ("Qayda: ... Niyə: ... Burada necə tətbiq olunur: ..."). Use one `<h2>`/`<h3>` per idea that names what is explained, then plain prose.
- Technical tone, complete but plain informal sentences, no baby analogies. Order: what it is, why it exists, how it works, example, then checks.
- Stay inside the topic. No "you will see this in topic N". No numbered topic references at all (numbers change when topics move).
- No useless depth. Subnet mask is taught in small steps (parts of an IP, mask octets, prefix, mid-octet masks, network/broadcast, block method, same-network, subnetting). The AND operation lives in a `box-extra`.
- Non-required facts go in `<div class="box box-extra"><h4>Bilmək məcburi deyil: ...</h4>` and are never quizzed.
- Quiz and lab explanations (`why`) are plain prose too, no label prefixes.
- Quiz concept ids must equal an `<h2 id>` or `<h3 id>` in the topic's explain.html. Keep the correct option from being systematically the longest.
- Azerbaijani only until the user asks for English. The en files for p1t10 and p1t01 are OLD (stale) and the other topics have no en files (the az text is shown with a notice).

## Content structure
- UI text: `src/js/05_strings.js` (`PT.t('key')`). Inline text inside simulators: `PT.L('az', 'en')`. Topic content: `explain.html`, `cheat.html`, `topic.js` (az) and `*.en.*` (en). Glossary: `10_glossary.js`, `12_glossary_p2plus.js` (az), `11_glossary_en.js` (en).
- Lab step types (`src/js/50_lab.js`): info, choice, form, order, ptsteps, terminal, `spot` (click the faulty line, optional typed fix), `match` (pairs), `ticket` (staged helpdesk story). A form field with a `check` function must also set `show:` for the instructor copy.
- Terminal simulator (`70_terminal.js`, `75_host.js`) supports a Cisco switch/router basic CLI and a Windows-like host (ping, ipconfig, arp, tracert, getmac). It does NOT support routing, DHCP, NAT, VLAN, ACL commands, so Part 2-5 labs use spot/match/ticket/form/ptsteps instead of a terminal.
- Part 1 order: p1t10 (OSI) → p1t1 → p1t2 → p1t3 … p1t9 (outline order, ids are only names).

## Status (az)
- Part 1 (10 topics): rewritten in the new style. p1t2 (subnet mask) fully restructured, p1t3 and p1t4 slimmed, p1t7 hub/collision to box-extra, p1t5/p1t6 trimmed, p1t8/p1t9 forward references removed.
- Parts 2-5 (19 topics): written new in az (explain, cheat, lab 8-12 steps with spot/match/ticket, quiz 9-15 questions + generators): p2 router, packet path, DHCP, relay, DNS; p3 VLAN, trunk, router-on-a-stick, L3 switch, static routing, default route/LPM; p4 ACL, port security, DTP, VTP, DHCP attacks/snooping; p5 STP, NAT/PAT, OSPF.
- Checked automatically in the browser: all 29 topics x 4 views render with no JS error; every quiz concept is a heading; every choice question has exactly one correct option and an explanation for every option; generators run 60 times without error.

## Known follow-ups
- Quiz option length: balanced (correct option is the strictly longest in 64 of 307 choice questions, about 21%, chance is 25%). Re-check with the validator snippet in the notes of this session if new questions are added; some padded distractors end with generic tails ("və bu avtomatik baş verir"), which a teacher may want to reword.
- Older Part 1 lab form fields have `check` without `show` (instructor copy then prints the step solution text instead).
- Packet Tracer instructions in `ptsteps` and CLI output samples were written from general IOS knowledge and not run in Packet Tracer. Each says "versiyadan asılı ola bilər" where it matters. A teacher should run each lab once.
- English: p1t10 and p1t01 en files are stale, all others missing. Simulator strings in `82_sim_layers.js`, `83_sim_l2.js`, `84_sim_misc.js` are still az-only.
- Not tested: running `Netix.bat` itself (server.py was tested directly), the Playwright suite (needs Node), phone layout of the new lab step types.
