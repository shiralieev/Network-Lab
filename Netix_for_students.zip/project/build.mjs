// Build: joins css + fonts + js + content fragments into ONE self-contained HTML file.
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const root = path.dirname(fileURLToPath(import.meta.url));
const R = (...p) => path.join(root, ...p);
const read = (...p) => fs.readFileSync(R(...p), 'utf8');
const b64 = (...p) => fs.readFileSync(R(...p)).toString('base64');
const cfg = JSON.parse(read('src', 'config.json'));

// ---------- fonts ----------
const LATIN = 'U+0000-00FF,U+0131,U+0152-0153,U+02BB-02BC,U+02C6,U+02DA,U+02DC,U+2000-206F,U+20AC,U+2122,U+2191,U+2193,U+2212,U+2215,U+FEFF,U+FFFD';
const EXT = 'U+0100-0130,U+0132-02BA,U+02BD-02C5,U+02C7-02CC,U+02CE-02D7,U+02DD-02FF,U+0304,U+0308,U+0329,U+1E00-1E9F,U+1EF2-1EFF,U+2020,U+20A0-20AB,U+20AD-20C0,U+2113,U+2C60-2C7F,U+A720-A7FF';
const face = (family, file, weight, stretch, ranges) =>
  `@font-face{font-family:'${family}';font-style:normal;font-weight:${weight};${stretch ? `font-stretch:${stretch};` : ''}font-display:swap;` +
  `src:url(data:font/woff2;base64,${b64('src', 'fonts', file)}) format('woff2');unicode-range:${ranges};}`;
const fontCss = [
  face('Archivo', 'archivo-latin-ext.woff2', '100 900', '62% 125%', EXT),
  face('Archivo', 'archivo-latin.woff2', '100 900', '62% 125%', LATIN),
  face('JetBrains Mono', 'jbmono-latin-ext-400.woff2', 400, null, EXT),
  face('JetBrains Mono', 'jbmono-latin-400.woff2', 400, null, LATIN),
  face('JetBrains Mono', 'jbmono-latin-ext-700.woff2', 700, null, EXT),
  face('JetBrains Mono', 'jbmono-latin-700.woff2', 700, null, LATIN),
].join('\n');

// ---------- css ----------
const cssDir = R('src', 'css');
const css = fontCss + '\n' + fs.readdirSync(cssDir).filter(f => f.endsWith('.css')).sort()
  .map(f => `/* ${f} */\n` + fs.readFileSync(path.join(cssDir, f), 'utf8')).join('\n');

// ---------- js core ----------
const jsDir = R('src', 'js');
const coreJs = fs.readdirSync(jsDir).filter(f => f.endsWith('.js')).sort()
  .map(f => `/* ${f} */\n` + fs.readFileSync(path.join(jsDir, f), 'utf8')).join('\n;\n');

// ---------- content ----------
const contentDir = R('src', 'content');
const rootJs = fs.readdirSync(contentDir).filter(f => f.endsWith('.js')).sort()
  .map(f => `/* content/${f} */\n` + fs.readFileSync(path.join(contentDir, f), 'utf8'));
const frags = {};
const topicJs = [];
const problems = [];
function balance(name, html) {
  for (const tag of ['div', 'details', 'summary', 'pre', 'ul', 'ol', 'li', 'table', 'tr', 'td', 'th', 'p', 'span', 'section', 'figure', 'svg', 'code']) {
    const o = (html.match(new RegExp('<' + tag + '(\\s[^>]*)?>', 'g')) || []).length;
    const c = (html.match(new RegExp('</' + tag + '>', 'g')) || []).length;
    if (o !== c) problems.push(`${name}: <${tag}> open=${o} close=${c}`);
  }
}
for (const part of fs.readdirSync(contentDir).filter(d => fs.statSync(path.join(contentDir, d)).isDirectory()).sort()) {
  for (const topic of fs.readdirSync(path.join(contentDir, part)).filter(d => fs.statSync(path.join(contentDir, part, d)).isDirectory()).sort()) {
    const dir = path.join(contentDir, part, topic);
    for (const f of fs.readdirSync(dir).sort()) {
      const full = path.join(dir, f);
      if (f.endsWith('.html')) {
        const key = `${part}/${topic}/${f.replace(/\.html$/, '')}`;
        const html = fs.readFileSync(full, 'utf8');
        balance(key, html);
        frags[key] = html;
      } else if (f.endsWith('.js')) {
        topicJs.push(`/* content/${part}/${topic}/${f} */\n` + fs.readFileSync(full, 'utf8'));
      }
    }
  }
}
if (problems.length) {
  console.error('HTML balance problems:\n' + problems.join('\n'));
  process.exit(1);
}
const fragJs = 'PT.frag = ' + JSON.stringify(frags).replace(/<\//g, '<\\/') + ';';

const js = [
  'window.PT = window.PT || {}; PT.config = ' + JSON.stringify(cfg) + ';',
  coreJs, fragJs, ...rootJs, ...topicJs,
  'PT.boot && PT.boot();',
].join('\n;\n').replace(/<\/script/gi, '<\\/script');

const html = `<!doctype html>
<html lang="az" data-theme="light">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="color-scheme" content="light dark">
<title>${cfg.title}</title>
<style>
${css}
</style>
</head>
<body>
<div id="app"></div>
<noscript>Bu səhifənin işləməsi üçün JavaScript lazımdır.</noscript>
<script>
${js}
</script>
</body>
</html>
`;
fs.mkdirSync(R('dist'), { recursive: true });
const out = R('dist', cfg.outFile);
fs.writeFileSync(out, html);
console.log(`built ${path.basename(out)}  ${(html.length / 1024).toFixed(0)} KB  (css ${(css.length / 1024).toFixed(0)} KB, js ${(js.length / 1024).toFixed(0)} KB, fragments ${Object.keys(frags).length})`);
