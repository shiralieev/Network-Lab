@echo off
rem Netix launcher: starts the local server and opens the page in your browser.
cd /d "%~dp0"
title Netix
where py >nul 2>nul && (py -3 server.py & goto :end)
where python >nul 2>nul && (python server.py & goto :end)
echo.
echo Python 3 was not found on this computer.
echo Install it from https://www.python.org/downloads/ (tick "Add python.exe to PATH"), then run this file again.
echo.
pause
:end
