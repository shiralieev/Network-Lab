@echo off
rem Netix instructor copy: every topic open, all lab and quiz answers visible.
cd /d "%~dp0"
title Netix (instructor copy)
where py >nul 2>nul && (py -3 server.py --instructor & goto :end)
where python >nul 2>nul && (python server.py --instructor & goto :end)
echo.
echo Python 3 was not found on this computer.
echo Install it from https://www.python.org/downloads/ (tick "Add python.exe to PATH"), then run this file again.
echo.
pause
:end
