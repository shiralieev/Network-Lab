# Packet Tracer platform — project notes (read this first after any context loss)

Goal: ONE self-contained, offline, downloadable HTML file in Azerbaijani: a learning platform that takes students from absolute zero to advanced Cisco Packet Tracer work.
Output: dist/Packet_Tracer_Sifirdan_Pesekara.html   (build: `node build.mjs`)

## Decisions (user-approved)
- Language: Azerbaijani, spoken-teacher style (not academic). Technical keywords stay in English (frame, flood, MAC address table, default gateway, VLAN ...). NO non-technical analogies.
- 5 tabs = 5 parts, 28 topics. Harder topics at the very end. Part 1 = 9 topics (incl. Cisco CLI basics).
- Every topic: 1 Explanation (diagrams + predict-first sims + "Prove it in Packet Tracer" + "Stop and think") -> 2 Cheat sheet (short direct sentences + "Commands in this topic") -> 3 Interactive lab (exam style, tiered hints; PT build labs where needed) -> 4 Quiz (pass 80% to unlock next topic).
- Quiz quality bar (5 tests): job, reasoning, distractor (real misconceptions, each option explained), clarity (no trick wording), proof. Pool 8-10 strong questions/topic + generators. Option order shuffled every attempt; correct position must be uniform (tested).
- Every explanation states: the rule -> why the rule exists -> how it applies here. Wrong AND right options get explanations.
- Gating: after 2 fails -> targeted review; after 3 -> teacher unlock code (config in src/config.json, visible in source, fine for class). Gating is a learning aid, not security.
- Progress in localStorage (try/catch + memory fallback), export/import text. NO teacher progress codes, NO per-student personalization (user declined).
- Excluded: DNS attacks, device hardening/SSH, VLSM, in-page sandbox (stretch, later).
- Baseline devices: Catalyst 2960 switch, 3560 multilayer switch, 2911 router; standard IOS commands; PT 8.x/9.x.
- Teacher answer-key file + whole-file extras (weak-spot review, concept map, printable cheat sheets, part exams) = Milestone 2.

## Milestones
- M1: design system + shell + Part 1 complete (this).
- M2: Parts 2-5, then extras + teacher key.

## Design system ("patch panel")
- Memorable element: home page = patch panels; each topic is a port with a link LED (off=locked, amber=open, green=passed). Passing a quiz plugs a cable into the port (single orchestrated animation).
- Fonts: Archivo variable (wght+wdth axes) for UI/headings, JetBrains Mono for CLI. Embedded as base64 (latin + latin-ext; verified glyphs for ə ı ö ü ç ş ğ İ).
- Avoid: cream+serif+terracotta, black+acid green, all-caps eyebrows, middle-dot meta strings, arrows on buttons, identical rounded cards with soft shadows.
- Status never by color alone (icon + text). Check contrast in both themes (tests/contrast.py).

## Verified facts (sources)
- IOS modes/prompts/errors: cisco.com "Using the Command-Line Interface" (User EXEC `>`, Privileged `#` via `enable`, Global `(config)#` via `configure terminal`, Interface `(config-if)#`; `?`, Tab, unique-prefix abbreviation, `no` form; errors: % Ambiguous command / % Incomplete command. / % Invalid input detected at '^' marker.)
- PT Simulation Mode (tutorials.ptnetacad.net help): Simulation Panel, Add Simple PDU, Auto Capture/Play, Capture/Forward, Back, Play Speed slider, Reset Simulation, Event List (Visible, Time, Last Device, At Device, Type, Info), Edit Filters; switching Realtime<->Simulation restarts the simulation.
- Not verifiable by me: exact PT screenshots/layout of a specific version -> labeled "check in your version".

## Conventions
- src/content/<part>/<topic>/ : topic.js (registers topic), explain.html, cheat.html (fragments inlined by build.mjs as PT.frag[...]).
- JS modules are plain scripts on window.PT (no bundler). Files concatenated in filename order.
- Tests: tests/*.mjs (node) + tests/e2e.mjs (playwright) + tests/contrast.py.

## Progress (M1)
- Part 1 DONE: T1-T9 all have explain + cheat + lab + quiz. Verified: quizqa problems 0 (all 9), generators re-checked in Python (T7 180, T8 120, T9 180 records, 0 bad), e2e 0 errors / 0 external requests, contrast 0 problems.
- Glossary: src/content/10_glossary.js has ~75 Part 1 terms (first occurrence per page is underlined; skipped inside .m, pre, tables of commands, terminal).
- Teacher shortcut: `#/teacher/<teacherCode>` unlocks every topic that has content (code in src/config.json, default PT-UNLOCK).
- Quiz option-length rule: correct option must not be systematically longest/shortest. Check with `node tests/lens.mjs <id>` (rank 0 = longest; ties count as 0) and `node tests/quizqa.mjs <id>`. Rebalanced T3, T4, T5, T7, T8, T9.
- Last topic of a part: quiz pass shows "next part comes in a later version" + button to home when the next topic has no content.
- Test scripts used for T9 are in the session scratchpad only (t9term.mjs: goals via PT.mountTerminal with onChange; t9forms.mjs; lab9.mjs; quiz9.mjs). Quick pattern: mount terminal step from PT.topics.<id>.lab.steps, type commands with inp.type(), evaluate goal.test(dev) on each onChange (sticky flags live on dev.mark).

## Known limits to state at delivery
- Cannot run Packet Tracer. Practice terminal is IOS-like, not real IOS (first-word typos in User/Privileged EXEC print the DNS "Translating" message, like real IOS).
- PT-specific behaviours are worded cautiously ("çox vaxt", "öz versiyanda yoxla").
- Progress lives in the browser's localStorage per file path: moving the file loses it -> use export/import.

## Next (Milestone 2)
- Parts 2-5 (19 topics), teacher answer-key file, weak-spot review, concept map, printable cheat sheets, part exams, PT tips page, final break-and-fix.
