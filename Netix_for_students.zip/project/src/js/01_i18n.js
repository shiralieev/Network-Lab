/* i18n: two languages, 'az' (default) and 'en'.
   UI text lives in PT.S (see 05_strings.js) and is read with PT.t('key', {param: value}).
   Topic content has one registered version per language: PT.topic(def) for Azerbaijani,
   PT.topicEn(def) for English. If a topic has no English version yet, the Azerbaijani one is shown
   together with a small notice. */
(function () {
  const PT = window.PT;
  PT.S = { az: {}, en: {} };
  PT.lang = 'az';
  PT.LANGS = ['az', 'en'];

  // PT.t('key', {n: 3}) -> string for the current language ({n} placeholders are replaced)
  PT.t = function (key, params) {
    let s = PT.S[PT.lang][key];
    if (s == null) s = PT.S.az[key];
    if (s == null) return '[' + key + ']';
    if (params) s = s.replace(/\{(\w+)\}/g, (m, k) => (k in params ? params[k] : m));
    return s;
  };
  // register UI text: PT.addStrings('key', 'azərbaycanca', 'english')
  PT.addStrings = function (rows) { rows.forEach(r => { PT.S.az[r[0]] = r[1]; PT.S.en[r[0]] = r[2]; }); };

  // outline items (parts, topics) may carry an `en: {title, desc}` object
  PT.title = x => (PT.lang === 'en' && x.en && x.en.title) || x.title;
  PT.desc = x => (PT.lang === 'en' && x.en && x.en.desc) || x.desc;

  PT.setLang = function (l) {
    if (!PT.LANGS.includes(l)) return;
    PT.lang = l; document.documentElement.setAttribute('lang', l);
    if (PT.store) PT.store.set('lang', l);
  };
  PT.initLang = function () {
    const saved = PT.store && PT.store.get('lang', null);
    PT.setLang(saved === 'en' || saved === 'az' ? saved : 'az');
  };
  PT.otherLang = () => (PT.lang === 'az' ? 'en' : 'az');
  // inline text in the current language: PT.L('azərbaycanca', 'english')
  PT.L = (az, en) => (PT.lang === 'en' ? en : az);
})();
