window.PT = window.PT || {}; window.PT.sims = window.PT.sims || {};
(function () {
  const PT = window.PT;
  PT.$ = (s, r) => (r || document).querySelector(s);
  PT.$$ = (s, r) => Array.from((r || document).querySelectorAll(s));
  PT.esc = s => String(s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  PT.stripTags = h => String(h).replace(/<[^>]*>/g, ' ').replace(/&nbsp;/g, ' ').replace(/&amp;/g, '&').replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/\s+/g, ' ').trim();

  // tiny DOM builder: h('div', {class:'x', onclick:fn, html:'<b>..'}, child, child...)
  PT.h = function (tag, attrs, ...kids) {
    const el = document.createElement(tag);
    if (attrs) for (const k of Object.keys(attrs)) {
      const v = attrs[k];
      if (v == null || v === false) continue;
      if (k === 'class') el.className = v;
      else if (k === 'html') el.innerHTML = v;
      else if (k === 'dataset') Object.assign(el.dataset, v);
      else if (k.startsWith('on') && typeof v === 'function') el.addEventListener(k.slice(2), v);
      else el.setAttribute(k, v === true ? '' : v);
    }
    for (const kid of kids.flat(Infinity)) {
      if (kid == null || kid === false) continue;
      el.append(kid.nodeType ? kid : document.createTextNode(String(kid)));
    }
    return el;
  };
  const SVGNS = 'http://www.w3.org/2000/svg';
  PT.s = function (tag, attrs, ...kids) {
    const el = document.createElementNS(SVGNS, tag);
    if (attrs) for (const k of Object.keys(attrs)) { if (attrs[k] != null) el.setAttribute(k, attrs[k]); }
    for (const kid of kids.flat(Infinity)) { if (kid == null) continue; el.append(kid.nodeType ? kid : document.createTextNode(String(kid))); }
    return el;
  };

  // uniform random integer in [0, n)
  PT.randInt = function (n) {
    if (n <= 1) return 0;
    if (window.crypto && crypto.getRandomValues) {
      const lim = Math.floor(0x100000000 / n) * n; const a = new Uint32Array(1);
      do { crypto.getRandomValues(a); } while (a[0] >= lim);
      return a[0] % n;
    }
    return Math.floor(Math.random() * n);
  };
  PT.shuffle = function (arr) { const a = arr.slice(); for (let i = a.length - 1; i > 0; i--) { const j = PT.randInt(i + 1); [a[i], a[j]] = [a[j], a[i]]; } return a; };
  PT.pick = arr => arr[PT.randInt(arr.length)];
  PT.sample = (arr, n) => PT.shuffle(arr).slice(0, n);
  PT.clamp = (v, a, b) => Math.min(b, Math.max(a, v));
  PT.sleep = ms => new Promise(r => setTimeout(r, ms));
  PT.copy = async function (text) {
    try { await navigator.clipboard.writeText(text); return true; } catch (e) { }
    try {
      const t = PT.h('textarea', { style: 'position:fixed;opacity:0' }); t.value = text; document.body.append(t); t.select();
      const ok = document.execCommand('copy'); t.remove(); return ok;
    } catch (e) { return false; }
  };
  PT.letters = 'ABCDEFGH';
})();
