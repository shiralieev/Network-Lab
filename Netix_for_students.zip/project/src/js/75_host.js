/* PC command prompt emulator (Windows-style output): ipconfig, ping, arp, tracert, hostname.
   Works over a tiny network model given in cfg. Simplified: it is not Windows and not Packet Tracer's PC. */
(function () {
  const PT = window.PT; const h = PT.h;
  const ip2n = s => s.split('.').reduce((a, x) => a * 256 + (+x), 0);
  const isIp = s => /^\d{1,3}(\.\d{1,3}){3}$/.test(s) && s.split('.').every(x => +x <= 255);
  const winMac = m => m.replace(/\./g, '').match(/../g).join('-').toLowerCase();
  const pad = (s, n) => { s = String(s); return s.length >= n ? s : s + ' '.repeat(n - s.length); };
  const same = (a, b, mask) => ((ip2n(a) & ip2n(mask)) >>> 0) === ((ip2n(b) & ip2n(mask)) >>> 0);
  const WIN_STATICS = [['224.0.0.22', '01-00-5e-00-00-16'], ['224.0.0.251', '01-00-5e-00-00-fb'], ['239.255.255.250', '01-00-5e-7f-ff-fa'], ['255.255.255.255', 'ff-ff-ff-ff-ff-ff']];

  PT.mountHost = function (container, cfg) {
    cfg = cfg || {};
    const H = Object.assign({ name: 'PC1', ip: '192.168.1.10', mask: '255.255.255.0', gw: '192.168.1.1', mac: '0001.4321.AAAA' }, cfg.host || {});
    const peers = (cfg.peers || []).map(p => Object.assign({ up: true, ttl: 128 }, p));
    const remote = cfg.remote || [];
    const dev = { host: H, arp: [], history: [], pings: [], errCount: 0, has: re => dev.history.some(l => re.test(l)), cleared: 0, tracerts: [] };
    const bodyEl = h('div', { class: 'term-body', role: 'log', 'aria-live': 'polite', 'aria-label': PT.t('hostOutAria') });
    const inEl = h('input', { class: 'term-input', type: 'text', autocomplete: 'off', autocapitalize: 'off', spellcheck: 'false', 'aria-label': PT.t('cmdAria') });
    const promptEl = h('span', { class: 'term-prompt' }, 'C:\\>');
    const lineEl = h('div', { class: 'term-in' }, promptEl, inEl); bodyEl.append(lineEl);
    let hist = [], hi = 0;
    const print = (t, cls) => String(t).split('\n').forEach(x => bodyEl.insertBefore(h('div', { class: 'ln' + (cls ? ' ' + cls : '') }, x === '' ? '\u00a0' : x), lineEl));

    const arpAdd = (ip, mac) => { if (!dev.arp.some(a => a.ip === ip)) { dev.arp.push({ ip, mac }); dev.newArp = ip; } };
    const gwPeer = () => peers.find(p => p.ip === H.gw);

    // decide what happens to one echo
    function decide(ip) {
      if (ip === H.ip || ip === '127.0.0.1') return { r: 'ok', ttl: 128, self: true };
      if (same(ip, H.ip, H.mask)) {
        const p = peers.find(x => x.ip === ip);
        if (p && p.up) { arpAdd(p.ip, p.mac); return { r: 'ok', ttl: p.ttl }; }
        return { r: 'unreach-local' };
      }
      if (!H.gw) return { r: 'nogw' };
      const g = gwPeer(); if (!g || !g.up) return { r: 'unreach-local' };
      arpAdd(g.ip, g.mac);
      const rm = remote.find(x => x.ip === ip);
      if (cfg.reach) { const v = cfg.reach(ip, H, dev); if (v && v !== 'ok') return { r: v }; if (v === 'ok') return { r: 'ok', ttl: (rm && rm.ttl) || 127 }; }
      if (rm && rm.fail) return { r: rm.fail };
      if (rm) return { r: 'ok', ttl: rm.ttl || 127 };
      return { r: 'timeout' };
    }

    const cmds = {
      ipconfig(a) {
        const all = a.some(x => x.toLowerCase() === '/all');
        print('Windows IP Configuration'); print('');
        if (all) { print('   Host Name . . . . . . . . . . . . : ' + H.name); print('   Primary Dns Suffix  . . . . . . . : '); print('   Node Type . . . . . . . . . . . . : Hybrid'); print('   IP Routing Enabled. . . . . . . . : No'); print(''); }
        print('Ethernet adapter Ethernet:'); print('');
        print('   Connection-specific DNS Suffix  . : ');
        if (all) { print('   Description . . . . . . . . . . . : Intel(R) Ethernet Connection'); print('   Physical Address. . . . . . . . . : ' + winMac(H.mac).toUpperCase()); print('   DHCP Enabled. . . . . . . . . . . : ' + (H.dhcp ? 'Yes' : 'No')); print('   Autoconfiguration Enabled . . . . : Yes'); }
        print('   IPv4 Address. . . . . . . . . . . : ' + (H.ip || '0.0.0.0') + (all ? '(Preferred)' : ''));
        print('   Subnet Mask . . . . . . . . . . . : ' + (H.mask || '0.0.0.0'));
        print('   Default Gateway . . . . . . . . . : ' + (H.gw || ''));
      },
      getmac() { print('Physical Address    Transport Name'); print('=================== =========================================================='); print(pad(winMac(H.mac).toUpperCase(), 20) + '\\Device\\Tcpip_{...}'); },
      hostname() { print(H.name); },
      cls() { Array.from(bodyEl.querySelectorAll('.ln')).forEach(x => x.remove()); },
      arp(a) {
        const f = (a[0] || '').toLowerCase();
        if (f === '-d') { dev.arp = []; dev.cleared++; return; }
        if (f !== '-a') { print('Displays and modifies the IP-to-Physical address translation tables used by'); print('address resolution protocol (ARP).'); print(''); print('ARP -a [-N if_addr]    (this practice prompt supports: arp -a, arp -d)'); return; }
        const rows = dev.arp.map(x => [x.ip, winMac(x.mac), 'dynamic']);
        if (cfg.statics !== false) WIN_STATICS.forEach(s => rows.push([s[0], s[1], 'static']));
        if (!rows.length) { print('No ARP Entries Found.'); return; }
        print(''); print('Interface: ' + H.ip + ' --- 0x4'); print('  Internet Address      Physical Address      Type');
        rows.sort((x, y) => ip2n(x[0]) - ip2n(y[0])).forEach(r => print('  ' + pad(r[0], 22) + pad(r[1], 22) + r[2]));
      },
      ping(a) {
        let n = 4; const ni = a.findIndex(x => x === '-n'); if (ni >= 0) { n = Math.max(1, Math.min(10, parseInt(a[ni + 1], 10) || 4)); a = a.filter((x, i) => i !== ni && i !== ni + 1); }
        const ip = a[0];
        if (!ip) { print('Usage: ping [-n count] target_name'); return; }
        if (!isIp(ip)) { print('Ping request could not find host ' + ip + '. Please check the name and try again.'); dev.errCount++; return; }
        print(''); print('Pinging ' + ip + ' with 32 bytes of data:'); print('');
        let recv = 0; const d = decide(ip);
        for (let i = 0; i < n; i++) {
          if (d.r === 'ok') { recv++; print('Reply from ' + ip + ': bytes=32 time<1ms TTL=' + d.ttl); }
          else if (d.r === 'timeout') print('Request timed out.', 'err');
          else if (d.r === 'unreach-local') print('Reply from ' + H.ip + ': Destination host unreachable.', 'err');
          else if (d.r === 'unreach-gw') print('Reply from ' + H.gw + ': Destination host unreachable.', 'err');
          else if (d.r === 'ttl-exp') print('Reply from ' + (cfg.ttlFrom || H.gw) + ': TTL expired in transit.', 'err');
          else if (d.r === 'nogw') print('PING: transmit failed. General failure.', 'err');
          else print('Request timed out.', 'err');
        }
        print(''); print('Ping statistics for ' + ip + ':'); print('    Packets: Sent = ' + n + ', Received = ' + recv + ', Lost = ' + (n - recv) + ' (' + Math.round((n - recv) * 100 / n) + '% loss),');
        if (recv) { print('Approximate round trip times in milli-seconds:'); print('    Minimum = 0ms, Maximum = 0ms, Average = 0ms'); }
        dev.pings.push({ ip, result: d.r, received: recv, sent: n });
      },
      tracert(a) {
        const ip = a[0]; if (!ip || !isIp(ip)) { print('Usage: tracert target_ip'); return; }
        print(''); print('Tracing route to ' + ip + ' over a maximum of 30 hops'); print('');
        const d = decide(ip); const hops = (cfg.hops && cfg.hops[ip]) || (cfg.hops && cfg.hops['*']) || [];
        if (d.r === 'ok' && !d.self) {
          const route = hops.length ? hops : [H.gw, ip].filter(Boolean);
          route.forEach((hp, i) => print(pad(String(i + 1), 3) + '   <1 ms    <1 ms    <1 ms  ' + hp));
        } else if (d.self) print('  1    <1 ms    <1 ms    <1 ms  ' + ip);
        else if (cfg.broken && cfg.broken[ip]) {
          const ok = cfg.broken[ip]; ok.forEach((hp, i) => print(pad(String(i + 1), 3) + '   <1 ms    <1 ms    <1 ms  ' + hp));
          for (let i = ok.length + 1; i <= ok.length + 3; i++) print(pad(String(i), 3) + '    *        *        *     Request timed out.', 'err');
          print(PT.t('tracertMore'), 'dim');
        }
        else { for (let i = 1; i <= 3; i++) print(pad(String(i), 3) + '    *        *        *     Request timed out.', 'err'); }
        print(''); print('Trace complete.'); dev.tracerts.push(ip);
      },
      help() { print('Commands in this practice prompt: ipconfig, ipconfig /all, ping <ip>, ping -n 2 <ip>, arp -a, arp -d, tracert <ip>, hostname, getmac, cls'); },
    };
    cmds['?'] = cmds.help;

    function submit(raw) {
      print('C:\\>' + raw);
      const line = raw.trim(); const before = dev.arp.length; dev.newArp = null;
      if (line) {
        dev.history.push(line); hist.push(raw); hi = hist.length;
        const parts = line.split(/\s+/); const name = parts[0].toLowerCase();
        if (cmds[name] && name !== '?') cmds[name](parts.slice(1)); else if (name === '?') cmds.help(); else { dev.errCount++; print("'" + parts[0] + "' is not recognized as an internal or external command,", 'err'); print('operable program or batch file.', 'err'); }
      }
      bodyEl.scrollTop = bodyEl.scrollHeight; renderState(); if (cfg.onChange) cfg.onChange(dev);
    }
    inEl.addEventListener('keydown', e => {
      if (e.key === 'Enter') { e.preventDefault(); const v = inEl.value; inEl.value = ''; submit(v); }
      else if (e.key === 'ArrowUp') { e.preventDefault(); if (hi > 0) { hi--; inEl.value = hist[hi]; } }
      else if (e.key === 'ArrowDown') { e.preventDefault(); if (hi < hist.length - 1) { hi++; inEl.value = hist[hi]; } else { hi = hist.length; inEl.value = ''; } }
    });
    bodyEl.addEventListener('click', () => { if (!window.getSelection().toString()) inEl.focus(); });

    // state panel
    const stateBody = h('div', { class: 'state-body' });
    const panel = h('div', { class: 'state' }, h('div', { class: 'state-head' }, h('span', null, PT.t('hostState', { n: H.name })), h('span', { class: 'mode' }, 'PC')), stateBody);
    function renderState() {
      stateBody.innerHTML = '';
      const t = h('table');
      [['IP', H.ip], ['Mask', H.mask], ['Gateway', H.gw || '— (none)'], ['MAC', winMac(H.mac)]].forEach(r => t.append(h('tr', null, h('th', null, r[0]), h('td', { class: 'm' }, r[1]))));
      stateBody.append(h('div', null, h('h4', null, PT.t('hostSettings')), t));
      const at = h('table'); at.append(h('tr', null, h('th', null, 'IP'), h('th', null, 'MAC'), h('th', null, 'Type')));
      if (!dev.arp.length) at.append(h('tr', null, h('td', { colspan: 3, class: 'state-note' }, PT.t('arpEmpty'))));
      dev.arp.forEach(x => { const tr = h('tr', null, h('td', { class: 'm' }, x.ip), h('td', { class: 'm' }, winMac(x.mac)), h('td', null, 'dynamic')); if (dev.newArp === x.ip) tr.classList.add('flash'); at.append(tr); });
      stateBody.append(h('div', null, h('h4', null, PT.t('arpTitle')), at, h('div', { class: 'state-note' }, PT.t('arpNote'))));
    }
    const quick = h('div', { class: 'term-quick' });
    (cfg.quick || []).forEach(q => quick.append(h('button', { type: 'button', onclick: () => { inEl.value = q; inEl.focus(); } }, q)));
    quick.append(h('button', { type: 'button', style: 'background:var(--term-mark);color:var(--term-ink);border:1px solid #2d405a;border-radius:3px;padding:3px 10px;font-size:12.5px', onclick: () => { const v = inEl.value; inEl.value = ''; submit(v); inEl.focus(); } }, 'Enter'));
    const term = h('div', { class: 'term' },
      h('div', { class: 'term-bar' }, h('span', { class: 'tled' }), h('span', null, PT.t('hostBar', { n: H.name })), h('button', { class: 'tclr', type: 'button', onclick: () => cmds.cls() }, PT.t('clear'))),
      bodyEl, h('div', { class: 'term-hintbar', html: PT.t('hostHint') }), quick);
    container.innerHTML = ''; container.append(h('div', { class: 'tgrid' }, term, panel));
    print(cfg.welcome || PT.t('hostWelcome'), 'dim');
    renderState(); if (cfg.onChange) cfg.onChange(dev);
    const ctl = { dev, print, run: submit, focus: () => inEl.focus() }; container._term = ctl; return ctl;
  };
})();
