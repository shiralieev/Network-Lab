/* osilayers: predict how far up the 7 layers each kind of device reads. */
(function () {
  const PT = window.PT; const h = PT.h; const t = (k, p) => PT.t(k, p);
  const LAYERS = [[7, 'Application'], [6, 'Presentation'], [5, 'Session'], [4, 'Transport'], [3, 'Network'], [2, 'Data Link'], [1, 'Physical']];
  const DEVICES = [
    { id: 'switch', top: 2 }, { id: 'router', top: 3 }, { id: 'pc', top: 7 },
  ];
  const NAME = { hub: ['Hub (köhnə cihaz)', 'Hub (an old device)'], switch: ['Switch', 'Switch'], router: ['Router', 'Router'], pc: ['PC / server', 'PC / server'] };
  const WHY = {
    hub: ['Hub yalnız siqnalı təkrarlayır, heç nəyi oxumur: Layer 1.', 'A hub only repeats the signal and reads nothing: Layer 1.'],
    switch: ['Switch frame-in MAC ünvanına baxır: Layer 2-yə qədər.', 'A switch looks at the MAC address of the frame: up to Layer 2.'],
    router: ['Router IP ünvanına baxıb yol seçir: Layer 3-ə qədər. Port və proqram məlumatı ona lazım deyil.', 'A router looks at the IP address and picks the way: up to Layer 3. It does not need ports or app data.'],
    pc: ['Məlumatın sonunda proqram dayanır, ona görə PC hər 7 layer-i işlədir.', 'The data ends at a program, so a PC uses all 7 layers.'],
  };
  const L = i => PT.lang === 'en' ? 1 : 0;

  PT.sims.osilayers = function (el) {
    const body = PT.simFrame(el, t('osiSimTitle'), t('osiSimHint'));
    const stack = h('div', { class: 'osi-stack', style: 'display:grid;gap:4px;max-width:420px;margin:10px 0' });
    const rows = LAYERS.map(([n, name]) => { const r = h('div', { style: 'padding:7px 12px;border:1.5px solid var(--line);border-radius:5px;background:var(--panel);font-weight:600' }, n + '  ' + name); stack.append(r); return { n, r }; });
    const out = h('div', { class: 'fine', style: 'min-height:2.6em', role: 'status' });
    const picker = h('div', { class: 'sim-ctrl' });
    let cur = null;
    function show(dev, correct) {
      rows.forEach(({ n, r }) => { const on = n <= dev.top; r.style.background = on ? 'var(--yel-soft)' : 'var(--panel)'; r.style.borderColor = on ? 'var(--yel)' : 'var(--line)'; r.style.color = on ? 'var(--ink)' : 'var(--ink-3)'; });
      out.innerHTML = '<b>' + NAME[dev.id][L()] + ': Layer ' + dev.top + '.</b> ' + WHY[dev.id][L()];
    }
    function ask(dev) {
      cur = dev; rows.forEach(({ r }) => { r.style.background = 'var(--panel)'; r.style.borderColor = 'var(--line)'; r.style.color = 'var(--ink)'; });
      out.innerHTML = '';
      pbox.innerHTML = '';
      const opts = [2, 3, 4, 7].map(n => ({ t: 'Layer ' + n, ok: n === dev.top }));
      const p = PT.predict({ title: t('osiPredictTitle'), q: '<p>' + t('osiQ', { d: NAME[dev.id][L()] }) + '</p>', options: opts, why: WHY[dev.id][L()], onAnswer: () => show(dev) });
      pbox.append(p.el);
    }
    const pbox = h('div');
    DEVICES.forEach(d => picker.append(h('button', { class: 'btn btn-sm', type: 'button', onclick: () => ask(d) }, NAME[d.id][L()])));
    body.append(h('div', { class: 'fine' }, t('osiPick')), picker, pbox, stack, out);
  };
})();
