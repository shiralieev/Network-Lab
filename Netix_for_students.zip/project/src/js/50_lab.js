(function () {
  const PT = window.PT; const h = PT.h; const t = (k, p) => PT.t(k, p);

  /* Lab step types:
     info | choice | form | order | ptsteps | terminal      (original)
     spot   : a config or output; the student clicks the faulty line(s), optionally types the fix
     match  : pair items on the left with the right meaning (drop-down per row)
     ticket : a helpdesk story solved in stages (what to check, what the cause is, what to do) */

  function fixField(f, k, stepId) { return f; }

  /* ---------- instructor view: every step with the answer key, nothing to solve ---------- */
  function instructorStep(step, i) {
    const box = h('section', { class: 'lstep is-done', id: 'lab-' + step.id });
    box.append(h('div', { class: 'lstep-head' }, h('span', { class: 'lstep-no' }, String(i + 1)), h('span', { class: 'lstep-title' }, step.title + '  (' + step.type + ')')));
    const body = h('div', { class: 'lstep-body' }); box.append(body);
    if (step.body) body.append(h('div', { html: step.body }));
    if (step.table) body.append(h('div', { class: 'tbl-wrap addr-table', html: step.table }));
    if (step.pre) body.append(h('pre', { class: 'pre', html: step.pre }));
    if (step.cmds) step.cmds.forEach(c => body.append(PT.cmdLine(c)));
    if (step.sim && PT.sims[step.sim.name]) { const sh = h('div', { 'data-sim': step.sim.name }); body.append(sh); PT.sims[step.sim.name](sh, step.sim.opts || {}); }
    const key = h('div', { class: 'fb is-ok' }); key.append(h('div', { class: 'tag' }, t('instrKey')));
    const ul = h('ul'); const li = x => ul.append(h('li', { html: x }));
    switch (step.type) {
      case 'choice': step.options.forEach(o => li('<b>' + (o.ok ? t('tagRight') : t('tagWhy')) + '</b>' + o.t + ' — ' + (o.why || ''))); break;
      case 'form': step.fields.forEach(f => li('<b>' + f.label + ':</b> ' + ((f.answers && f.answers.join('  |  ')) || f.show || t('instrSeeSolution')) + (f.wrong ? ' <i>(' + f.wrong + ')</i>' : ''))); break;
      case 'order': step.items.forEach((it, k) => li((k + 1) + '. ' + it.t + ' — ' + (it.why || ''))); break;
      case 'ptsteps': step.checks.forEach(c => li(c.t + (c.cmd ? ' <code>' + [].concat(c.cmd).join('; ') + '</code>' : ''))); break;
      case 'terminal': (step.term.goals || []).forEach(g => li(g.text)); break;
      case 'spot': step.lines.forEach(l => { if (l.bad) li('<code>' + PT.esc(l.t) + '</code> — ' + (l.why || '')); }); if (step.fix) li('<b>' + t('spotFixLbl') + '</b> ' + ((step.fix.answers || []).join('  |  ') || step.fix.show || '')); break;
      case 'match': step.pairs.forEach(p => li(p.l + ' → ' + p.r + (p.why ? ' — ' + p.why : ''))); break;
      case 'ticket': step.stages.forEach((s, k) => { const ok = s.options.find(o => o.ok); li((k + 1) + '. ' + s.q + ' → <b>' + (ok ? ok.t : '') + '</b> — ' + (ok ? ok.why || '' : '')); }); break;
    }
    key.append(ul);
    if (step.hints && step.hints.length) key.append(h('div', { html: '<b>' + t('hint') + ':</b> ' + step.hints.map((x, k) => (k + 1) + ') ' + x).join('  ') }));
    if (step.solution) key.append(h('div', { html: '<b>' + t('solutionBold') + '</b> ' + step.solution }));
    if (step.after) key.append(h('div', { html: step.after }));
    box.append(key);
    return box;
  }

  PT.lab = {
    mount(container, topic) {
      const lab = topic.lab; const prog = PT.progress.topic(topic.id);
      container.innerHTML = '';
      const root = h('div', { class: 'lab' });
      container.append(root);
      const reopened = new Set();
      const instr = PT.instructor();
      const stepsDone = () => lab.steps.filter(s => prog.labSteps[s.id]).length;

      function head() {
        const dl = h('dl');
        dl.append(h('dt', null, t('labGoal')), h('dd', { html: lab.goal }));
        if (lab.why) dl.append(h('dt', null, t('labWhy')), h('dd', { html: lab.why }));
        if (lab.minutes) dl.append(h('dt', null, t('labTime')), h('dd', null, t('labMin', { n: lab.minutes })));
        if (instr) return h('div', { class: 'lab-head' }, h('h2', null, lab.title), dl);
        const pct = Math.round(stepsDone() * 100 / lab.steps.length);
        return h('div', { class: 'lab-head' }, h('h2', null, lab.title), dl,
          h('div', { class: 'lab-prog' }, h('div', { class: 'bar' }, h('i', { style: 'width:' + pct + '%' })), h('div', { class: 'bar-txt' }, t('labProg', { a: stepsDone(), b: lab.steps.length }))));
      }

      function refresh() {
        root.innerHTML = '';
        root.append(head());
        if (instr) { lab.steps.forEach((s, i) => root.append(instructorStep(s, i))); PT.glossify(root); return; }
        const firstOpen = lab.steps.findIndex(s => !prog.labSteps[s.id]);
        lab.steps.forEach((s, i) => root.append(renderStep(s, i, firstOpen)));
        if (firstOpen === -1) {
          if (!prog.labDone) { prog.labDone = true; PT.progress.save(); }
          root.append(h('div', { class: 'lab-done' }, h('h3', null, t('labDoneTitle')), h('p', { html: lab.finish || t('labDoneDef') }),
            h('button', { class: 'btn btn-primary', type: 'button', onclick: () => PT.go('/' + PT.meta(topic.id).part.id + '/' + topic.id + '/quiz') }, t('toQuiz'))));
        }
        PT.glossify(root);
      }

      function complete(step) { prog.labSteps[step.id] = true; PT.progress.save(); const y = window.scrollY; refresh(); window.scrollTo({ top: y }); }

      function renderStep(step, i, firstOpen) {
        const done = !!prog.labSteps[step.id]; const future = !done && i > firstOpen;
        const box = h('section', { class: 'lstep' + (done ? ' is-done' : '') + (future ? ' is-future' : ''), id: 'lab-' + step.id });
        box.append(h('div', { class: 'lstep-head' }, h('span', { class: 'lstep-no' }, done ? '✓' : String(i + 1)), h('span', { class: 'lstep-title' }, step.title)));
        if (future) { box.append(h('p', { class: 'fine', style: 'margin:0' }, t('stepFuture'))); return box; }
        if (done && !reopened.has(step.id)) {
          box.append(h('button', { class: 'btn btn-sm btn-quiet', type: 'button', onclick: () => { reopened.add(step.id); refresh(); } }, t('stepReview')));
          return box;
        }
        const body = h('div', { class: 'lstep-body' }); box.append(body);
        if (step.body) body.append(h('div', { html: step.body }));
        if (step.table) body.append(h('div', { class: 'tbl-wrap addr-table', html: step.table }));
        if (step.pre) body.append(h('pre', { class: 'pre', html: step.pre }));
        if (step.cmds) step.cmds.forEach(c => body.append(PT.cmdLine(c)));
        if (step.sim && PT.sims[step.sim.name]) { const sh = h('div', { 'data-sim': step.sim.name }); body.append(sh); PT.sims[step.sim.name](sh, step.sim.opts || {}); }
        const fbHost = h('div'); const hintHost = h('div');
        const contBtn = () => h('div', { class: 'hint-bar' }, h('button', { class: 'btn btn-primary', type: 'button', onclick: () => complete(step) }, t('cont')));
        const T = {
          info: () => { body.append(h('div', { class: 'hint-bar' }, h('button', { class: 'btn btn-primary', type: 'button', onclick: () => complete(step) }, step.button || t('infoBtn')))); },
          ptsteps: () => {
            const ul = h('ul', { class: 'chk' }); const boxes = [];
            step.checks.forEach((c, k) => { const cb = h('input', { type: 'checkbox', id: step.id + '-c' + k, 'aria-label': t('stepAria', { n: k + 1 }) }); boxes.push(cb); cb.addEventListener('change', () => btn.disabled = !boxes.every(b => b.checked)); ul.append(h('li', null, cb, h('label', { for: step.id + '-c' + k, html: c.t }))); if (c.cmd) { const li = ul.lastChild; (Array.isArray(c.cmd) ? c.cmd : [c.cmd]).forEach(x => { const cl = PT.cmdLine(x); cl.style.gridColumn = '2'; li.append(cl); }); } });
            const btn = h('button', { class: 'btn btn-primary', type: 'button', disabled: '', onclick: () => complete(step) }, step.button || t('allDone'));
            body.append(ul, h('div', { class: 'hint-bar' }, btn));
          },
          choice: () => {
            const opts = PT.shuffle(step.options); const list = h('div', { class: 'opts', role: 'group' });
            opts.forEach((o, k) => {
              const b = h('button', { type: 'button', class: 'opt' }, h('span', { class: 'opt-key' }, PT.letters[k]), h('span', { html: o.t }));
              b.addEventListener('click', () => {
                if (b.classList.contains('is-ok')) return;
                b.classList.remove('is-bad'); b.querySelectorAll('.opt-why').forEach(x => x.remove());
                b.classList.add(o.ok ? 'is-ok' : 'is-bad');
                b.append(h('span', { class: 'opt-why', html: '<span class="tag">' + (o.ok ? t('right') : t('wrong')) + ' </span>' + (o.why || '') }));
                if (o.ok) { list.querySelectorAll('.opt').forEach(x => x.disabled = true); fbHost.innerHTML = ''; if (step.after) fbHost.append(h('div', { class: 'fb is-ok', html: step.after })); fbHost.append(contBtn()); }
              });
              list.append(b);
            });
            body.append(list);
          },
          form: () => {
            const rows = []; const wrap = h('div', { style: 'display:grid;gap:10px;margin-top:6px' });
            step.fields.forEach((f, k) => {
              const inp = h('input', { type: 'text', autocomplete: 'off', autocapitalize: 'off', spellcheck: 'false', id: step.id + '-f' + k, placeholder: f.placeholder || '', style: 'min-height:42px;min-width:220px;padding:6px 12px;border:1.5px solid var(--line);border-radius:5px;background:var(--panel);font-family:var(--font-mono);font-size:15.5px' });
              const fb = h('span', { class: 'fine', 'aria-live': 'polite' });
              rows.push({ f, inp, fb });
              wrap.append(h('div', { style: 'display:flex;flex-wrap:wrap;gap:8px 12px;align-items:center' }, h('label', { for: step.id + '-f' + k, style: 'min-width:190px;font-weight:600', html: f.label }), inp, fb));
            });
            const btn = h('button', { class: 'btn btn-primary', type: 'button' }, t('check'));
            const okTxt = t('formRight');
            const run = () => {
              let all = true;
              rows.forEach(({ f, inp, fb }) => {
                if (inp.dataset.ok === '1') return;
                const raw = inp.value; let ok = false;
                if (f.check) { const r = f.check(raw); ok = typeof r === 'object' ? r.ok : !!r; if (!ok && typeof r === 'object' && r.note) fb.innerHTML = r.note; }
                else ok = (f.answers || []).some(a => PT.norm(a) === PT.norm(raw));
                if (ok) { inp.dataset.ok = '1'; inp.disabled = true; inp.style.borderColor = 'var(--ok)'; fb.innerHTML = '<b style="color:var(--ok)">' + okTxt + '</b>'; }
                else { all = false; inp.style.borderColor = 'var(--bad)'; if (!fb.innerHTML || fb.innerHTML.indexOf(okTxt) >= 0) fb.innerHTML = '<b style="color:var(--bad)">' + t('formWrong') + '</b>' + (f.wrong ? ': ' + f.wrong : ''); }
              });
              if (all) { btn.classList.add('hide'); fbHost.innerHTML = ''; fbHost.append(h('div', { class: 'fb is-ok', html: '<span class="tag">' + t('allRight') + '</span>' + (step.after || '') }), contBtn()); }
            };
            btn.addEventListener('click', run);
            wrap.addEventListener('keydown', e => { if (e.key === 'Enter') run(); });
            body.append(wrap, h('div', { class: 'hint-bar' }, btn));
          },
          order: () => {
            const q = { type: 'order', stem: '', items: step.items, why: step.after };
            const r = PT.renderQuestion(PT.quiz.prepare(q), ok => { if (ok) r.actions.append(h('button', { class: 'btn btn-primary', type: 'button', onclick: () => complete(step) }, t('cont'))); else r.actions.append(h('button', { class: 'btn', type: 'button', onclick: () => refresh() }, t('retryAgain'))); });
            body.append(r.el);
          },
          terminal: () => {
            const goals = step.term.goals || []; const ul = h('ul', { class: 'goals' }); const lis = goals.map(g => h('li', null, h('span', { class: 'gi' }), h('span', { html: g.text })));
            lis.forEach(l => ul.append(l)); let finished = false;
            const check = (dev) => {
              let all = true; goals.forEach((g, k) => { const ok = !!g.test(dev); lis[k].classList.toggle('is-met', ok); if (!ok) all = false; });
              if (all && !finished) { finished = true; fbHost.innerHTML = ''; fbHost.append(h('div', { class: 'fb is-ok', html: '<span class="tag">' + t('goalsAll') + '</span>' + (step.after || '') }), contBtn()); }
            };
            const host = h('div'); body.append(h('p', { style: 'margin:8px 0 0' }, h('b', null, t('goalsLbl'))), ul, host);
            const mount = step.term.kind === 'host' ? PT.mountHost : PT.mountTerminal;
            mount(host, Object.assign({}, step.term, { onChange: dev => check(dev) }));
          },

          /* spot: click the faulty line(s) in a config or output; optional `fix` = {label, answers|check, wrong} */
          spot: () => {
            const picked = new Set(); const list = h('div', { class: 'spot', role: 'group' });
            const btns = step.lines.map((l, k) => {
              const b = h('button', { type: 'button', class: 'spot-line', 'aria-pressed': 'false' }, h('span', { class: 'spot-no' }, String(k + 1)), h('code', null, l.t));
              b.addEventListener('click', () => { if (b.disabled) return; if (picked.has(k)) picked.delete(k); else picked.add(k); b.classList.toggle('is-pick', picked.has(k)); b.setAttribute('aria-pressed', picked.has(k) ? 'true' : 'false'); });
              list.append(b); return b;
            });
            const btn = h('button', { class: 'btn btn-primary', type: 'button' }, t('check'));
            const msg = h('div', { class: 'fine', role: 'status', style: 'margin-top:8px' });
            btn.addEventListener('click', () => {
              const badSet = new Set(step.lines.map((l, k) => l.bad ? k : -1).filter(k => k >= 0));
              const ok = badSet.size === picked.size && [...badSet].every(k => picked.has(k));
              if (!ok) {
                btns.forEach((b, k) => { b.classList.toggle('is-bad', picked.has(k) && !badSet.has(k)); });
                msg.innerHTML = '<b style="color:var(--bad)">' + t('spotWrong') + '</b>'; return;
              }
              btns.forEach((b, k) => { b.disabled = true; b.classList.remove('is-pick'); if (badSet.has(k)) { b.classList.add('is-ok'); b.append(h('span', { class: 'opt-why', html: step.lines[k].why || '' })); } });
              btn.classList.add('hide'); msg.innerHTML = '<b style="color:var(--ok)">' + t('spotRight') + '</b>';
              if (!step.fix) { fbHost.innerHTML = ''; if (step.after) fbHost.append(h('div', { class: 'fb is-ok', html: step.after })); fbHost.append(contBtn()); return; }
              const f = step.fix; const inp = h('input', { type: 'text', autocomplete: 'off', autocapitalize: 'off', spellcheck: 'false', placeholder: f.placeholder || '', style: 'min-height:42px;min-width:260px;padding:6px 12px;border:1.5px solid var(--line);border-radius:5px;background:var(--panel);font-family:var(--font-mono);font-size:15.5px' });
              const fb = h('span', { class: 'fine', 'aria-live': 'polite' }); const fbtn = h('button', { class: 'btn btn-primary', type: 'button' }, t('check'));
              const go = () => { const raw = inp.value; const r = f.check ? f.check(raw) : (f.answers || []).some(a => PT.norm(a) === PT.norm(raw)); const good = typeof r === 'object' ? r.ok : !!r;
                if (good) { inp.disabled = true; fbtn.classList.add('hide'); fb.innerHTML = '<b style="color:var(--ok)">' + t('formRight') + '</b>'; fbHost.innerHTML = ''; if (step.after) fbHost.append(h('div', { class: 'fb is-ok', html: step.after })); fbHost.append(contBtn()); }
                else { inp.style.borderColor = 'var(--bad)'; fb.innerHTML = '<b style="color:var(--bad)">' + t('formWrong') + '</b>' + (f.wrong ? ': ' + f.wrong : ''); } };
              fbtn.addEventListener('click', go); inp.addEventListener('keydown', e => { if (e.key === 'Enter') go(); });
              body.append(h('div', { style: 'margin-top:12px;display:flex;flex-wrap:wrap;gap:8px 12px;align-items:center' }, h('label', { style: 'font-weight:600' }, f.label || t('spotFixLbl')), inp, fbtn, fb));
            });
            body.append(h('p', { class: 'fine', style: 'margin:6px 0' }, t('spotPick')), list, h('div', { class: 'hint-bar' }, btn), msg);
          },

          /* match: pairs:[{l, r, why}] ; the right-hand side is a drop-down per row */
          match: () => {
            const rights = PT.shuffle([...new Set(step.pairs.map(p => p.r))]); const rows = [];
            const grid = h('div', { class: 'match' });
            step.pairs.forEach((p, k) => {
              const sel = h('select', { 'aria-label': p.l.replace(/<[^>]+>/g, '') }, h('option', { value: '' }, t('matchPick')), rights.map(r => h('option', { value: r }, r)));
              const why = h('div', { class: 'fine' });
              rows.push({ p, sel, why });
              grid.append(h('div', { class: 'match-row' }, h('div', { class: 'match-l', html: p.l }), sel, why));
            });
            const btn = h('button', { class: 'btn btn-primary', type: 'button' }, t('check')); const msg = h('div', { class: 'fine', role: 'status', style: 'margin-top:8px' });
            btn.addEventListener('click', () => {
              let all = true;
              rows.forEach(({ p, sel, why }) => { const ok = sel.value === p.r; sel.classList.toggle('is-ok', ok); sel.classList.toggle('is-bad', !ok); if (ok) { sel.disabled = true; why.textContent = p.why || ''; } else { all = false; why.textContent = ''; } });
              if (all) { btn.classList.add('hide'); msg.innerHTML = ''; fbHost.innerHTML = ''; fbHost.append(h('div', { class: 'fb is-ok', html: '<span class="tag">' + t('allRight') + '</span>' + (step.after || '') }), contBtn()); }
              else msg.innerHTML = '<b style="color:var(--bad)">' + t('matchSome') + '</b>';
            });
            body.append(h('p', { class: 'fine', style: 'margin:6px 0' }, t('matchHelp')), grid, h('div', { class: 'hint-bar' }, btn), msg);
          },

          /* ticket: stages:[{q, options:[{t, ok, why}]}] ; complaint is in step.body */
          ticket: () => {
            let cur = 0; const host = h('div'); body.append(host);
            const show = () => {
              host.innerHTML = '';
              const s = step.stages[cur];
              host.append(h('div', { class: 'fine', style: 'margin:10px 0 4px' }, t('ticketStage', { i: cur + 1, n: step.stages.length })), h('div', { class: 'q-stem', html: s.q }));
              const list = h('div', { class: 'opts', role: 'group' });
              PT.shuffle(s.options).forEach((o, k) => {
                const b = h('button', { type: 'button', class: 'opt' }, h('span', { class: 'opt-key' }, PT.letters[k]), h('span', { html: o.t }));
                b.addEventListener('click', () => {
                  if (b.classList.contains('is-ok')) return;
                  b.classList.remove('is-bad'); b.querySelectorAll('.opt-why').forEach(x => x.remove());
                  b.classList.add(o.ok ? 'is-ok' : 'is-bad');
                  b.append(h('span', { class: 'opt-why', html: '<span class="tag">' + (o.ok ? t('right') : t('wrong')) + ' </span>' + (o.why || '') }));
                  if (o.ok) {
                    list.querySelectorAll('.opt').forEach(x => x.disabled = true);
                    const last = cur === step.stages.length - 1;
                    host.append(h('div', { class: 'hint-bar' }, h('button', { class: 'btn btn-primary', type: 'button', onclick: () => { if (last) { fbHost.innerHTML = ''; fbHost.append(h('div', { class: 'fb is-ok', html: '<span class="tag">' + t('ticketDone') + '</span>' + (step.after || '') }), contBtn()); host.innerHTML = ''; } else { cur++; show(); } } }, last ? t('ticketDone') : t('ticketNext'))));
                  }
                });
                list.append(b);
              });
              host.append(list);
            };
            show();
          },
        };
        (T[step.type] || T.info)();
        box.append(fbHost);
        // hints (tiered): hint 1, hint 2, ..., then the worked answer
        if (step.hints && step.hints.length && step.type !== 'info' && step.type !== 'ptsteps') {
          let shown = 0; const bar = h('div', { class: 'hint-bar' });
          const btn = h('button', { class: 'btn btn-sm', type: 'button' }, t('hint'));
          btn.addEventListener('click', () => {
            if (shown < step.hints.length) {
              hintHost.append(h('div', { class: 'hint-box', html: '<b>' + t('hintN', { n: shown + 1 }) + '</b> ' + step.hints[shown] })); shown++;
              if (shown === step.hints.length) btn.textContent = step.solution ? t('showSolution') : t('noMoreHints');
              if (shown === step.hints.length && !step.solution) btn.disabled = true;
            } else if (step.solution) { hintHost.append(h('div', { class: 'hint-box', html: '<b>' + t('solutionBold') + '</b> ' + step.solution })); btn.disabled = true; }
          });
          bar.append(btn); box.append(bar, hintHost);
        }
        return box;
      }
      refresh();
    },
  };
})();
