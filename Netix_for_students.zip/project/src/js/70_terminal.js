/* IOS-like practice terminal: device model + command engine + terminal widget + state panel.
   It imitates the Cisco IOS command line (modes, ?, Tab, abbreviations, no, errors, save/reload).
   It is NOT real IOS. Commands/outputs are simplified; always test in Packet Tracer too. */
(function () {
  const PT = window.PT; const h = PT.h;

  const TYPES = [{ name: 'FastEthernet', abbr: 'Fa' }, { name: 'GigabitEthernet', abbr: 'Gi' }, { name: 'Vlan', abbr: 'Vlan' }];
  const clone = o => JSON.parse(JSON.stringify(o));
  const pad = (s, n) => { s = String(s); return s.length >= n ? s + ' ' : s + ' '.repeat(n - s.length); };
  const isIp = s => /^\d{1,3}(\.\d{1,3}){3}$/.test(s) && s.split('.').every(x => +x <= 255);
  const ip2n = s => s.split('.').reduce((a, x) => a * 256 + (+x), 0);
  const isMask = s => { if (!isIp(s)) return false; const n = ip2n(s); const inv = (~n) >>> 0; return ((inv + 1) & inv) === 0 && n !== 0; };
  const parseIf = txt => {
    const m = /^([a-zA-Z]+)\s*(\d+(?:\/\d+)*)$/.exec(String(txt).trim()); if (!m) return null;
    const t = m[1].toLowerCase(); const ty = TYPES.find(x => x.name.toLowerCase().startsWith(t)); if (!ty) return null;
    return ty.name + m[2];
  };
  const short = n => n.replace('FastEthernet', 'Fa').replace('GigabitEthernet', 'Gi');
  PT.ios = { parseIf, short, isIp, isMask };

  /* ------------------------------------------------------------ device model */
  function makeDevice(cfg) {
    const kind = cfg.kind || 'switch';
    const ports = (cfg.ports || (kind === 'switch' ? ['FastEthernet0/1', 'FastEthernet0/2', 'FastEthernet0/3', 'GigabitEthernet0/1'] : ['GigabitEthernet0/0', 'GigabitEthernet0/1'])).map(p => parseIf(p) || p);
    const cables = {};
    Object.keys(cfg.cables || {}).forEach(k => { const v = cfg.cables[k]; cables[parseIf(k) || k] = typeof v === 'string' ? { peer: v, up: true } : Object.assign({ up: true }, v); });
    const dev = { kind, ports, cables, mode: 'user', curIf: null, pending: null, history: [], errKinds: {}, errCount: 0, reloads: 0, macs: [], saves: 0, erased: 0 };
    dev.macs = (cfg.macs || []).map(m => Object.assign({ vlan: 1, type: 'DYNAMIC' }, m));

    function factory() {
      const st = { hostname: cfg.hostname || (kind === 'switch' ? 'Switch' : 'Router'), noLookup: false, defGw: null, ifs: {} };
      ports.forEach(p => { st.ifs[p] = { shut: kind === 'router', desc: '', ip: null, mask: null }; });
      if (kind === 'switch') st.ifs.Vlan1 = { shut: true, desc: '', ip: null, mask: null };
      return st;
    }
    function applyInitial(st, ini) {
      if (!ini) return st;
      if (ini.hostname) st.hostname = ini.hostname;
      if (ini.noLookup) st.noLookup = true;
      if (ini.defGw) st.defGw = ini.defGw;
      Object.keys(ini.ifs || {}).forEach(k => { const n = parseIf(k) || k; if (st.ifs[n]) Object.assign(st.ifs[n], ini.ifs[k]); });
      return st;
    }
    dev.factory = factory;
    dev.run = applyInitial(factory(), cfg.initial);
    const startMode = cfg.startup || (cfg.initial ? 'copy' : 'none');
    dev.start = startMode === 'copy' ? clone(dev.run) : null;

    dev.iface = function (name) {
      const full = parseIf(name) || name; const i = dev.run.ifs[full]; if (!i) return null;
      const l = dev.link(full);
      return Object.assign({ name: full, short: short(full), status: l.st, proto: l.pr }, i);
    };
    dev.link = function (name) {
      const i = dev.run.ifs[name];
      if (i.shut) return { st: 'administratively down', pr: 'down' };
      if (name.startsWith('Vlan')) { const any = ports.some(p => dev.link(p).pr === 'up'); return any ? { st: 'up', pr: 'up' } : { st: 'down', pr: 'down' }; }
      const c = cables[name]; if (c && c.up !== false) return { st: 'up', pr: 'up' };
      return { st: 'down', pr: 'down' };
    };
    dev.hostname = () => dev.run.hostname;
    dev.prompt = function () {
      if (dev.pending) return dev.pending.prompt;
      const n = dev.run.hostname;
      return n + ({ user: '>', priv: '#', config: '(config)#', if: '(config-if)#' }[dev.mode]);
    };
    dev.listIfs = () => Object.keys(dev.run.ifs);
    // config text -------------------------------------------------
    dev.cfgLines = function (st) {
      st = st || dev.run; const L = ['version 15.0', '!', 'hostname ' + st.hostname, '!'];
      if (st.noLookup) { L.push('no ip domain-lookup', '!'); }
      const names = Object.keys(st.ifs);
      names.forEach(n => {
        const i = st.ifs[n]; L.push('interface ' + n);
        if (i.desc) L.push(' description ' + i.desc);
        const l3 = kind === 'router' || n.startsWith('Vlan');
        if (l3) L.push(i.ip ? ' ip address ' + i.ip + ' ' + i.mask : ' no ip address');
        if (kind === 'router') L.push(' duplex auto', ' speed auto');
        if (i.shut) L.push(' shutdown');
        L.push('!');
      });
      if (st.defGw) L.push('ip default-gateway ' + st.defGw, '!');
      L.push('end');
      return L;
    };
    dev.runText = () => dev.cfgLines(dev.run).join('\n');
    dev.startText = () => (dev.start ? dev.cfgLines(dev.start).join('\n') : null);
    dev.unsaved = function () { const base = dev.start ? dev.cfgLines(dev.start) : dev.cfgLines(factory()); return base.join('\n') !== dev.cfgLines(dev.run).join('\n'); };
    dev.runHas = line => dev.cfgLines(dev.run).some(x => x.trim() === line);
    dev.startHas = line => !!dev.start && dev.cfgLines(dev.start).some(x => x.trim() === line);
    dev.hist = re => dev.history.some(l => re.test(l));
    dev.learn = function (mac, port, vlan) {
      if (!dev.macs.some(m => m.mac.toLowerCase() === mac.toLowerCase())) dev.macs.push({ vlan: vlan || 1, mac, type: 'DYNAMIC', port });
      else dev.macs.forEach(m => { if (m.mac.toLowerCase() === mac.toLowerCase()) m.port = port; });
    };
    dev.reachable = cfg.reach || null;
    return dev;
  }

  /* ------------------------------------------------------------ command tree */
  const K = (w, help, o) => Object.assign({ w, help }, o || {});
  const A = (id, help, test, o) => Object.assign({ arg: id, help, test }, o || {});
  const REST = (id, help, run) => ({ arg: id, help, test: () => true, rest: true, run });

  function buildTree(dev, api) {
    const isRouter = dev.kind === 'router';
    const ifArg = (run) => ({ arg: 'TYPE NUMBER', help: 'Interface, for example fa0/1 or gi0/0', test: () => true, rest: true, validate: v => !!parseIf(v), norm: v => parseIf(v), run });
    const showCmds = (priv) => {
      const L = [];
      L.push(K('interfaces', 'Interface status and configuration', { children: [ifArg(c => api.showIf(c)), ...(isRouter ? [] : [K('status', 'Interface line status', { run: c => api.showIfStatus(c) })])] }));
      L.push(K('ip', 'IP information', { children: [K('interface', 'IP interface status and configuration', { children: [K('brief', 'Brief summary of IP status and configuration', { run: c => api.showIpBrief(c) })] })] }));
      if (!isRouter) {
        L.push(K('mac', 'MAC configuration', { children: [K('address-table', 'MAC forwarding table', { run: c => api.showMac(c), children: [K('dynamic', 'dynamic entries only', { run: c => api.showMac(c) })] })] }));
      }
      if (priv) {
        L.push(K('running-config', 'Current operating configuration', { run: c => api.showRun(c) }));
        L.push(K('startup-config', 'Contents of startup configuration', { run: c => api.showStart(c) }));
      }
      return L;
    };
    const ping = K('ping', 'Send echo messages', { children: [A('WORD', 'Ping destination address or hostname', isIp, { run: (c) => api.ping(c) })] });
    const user = [
      K('enable', 'Turn on privileged commands', { run: c => { dev.mode = 'priv'; } }),
      K('exit', 'Exit from the EXEC', { run: c => { c.out(''); c.out(dev.run.hostname + ' con0 is now available'); c.out(''); c.out('Press RETURN to get started.', 'dim'); } }),
      ping,
      K('show', 'Show running system information', { children: showCmds(false) }),
    ];
    const priv = [
      K('clear', 'Reset functions', { children: isRouter ? [] : [K('mac', 'MAC forwarding table', { children: [K('address-table', 'MAC forwarding table', { children: [K('dynamic', 'dynamic entries only', { run: c => { dev.macs = dev.macs.filter(m => m.type !== 'DYNAMIC'); } })] })] })] }),
      K('configure', 'Enter configuration mode', { children: [K('terminal', 'Configure from the terminal', { run: c => { dev.mode = 'config'; c.out('Enter configuration commands, one per line.  End with CNTL/Z.'); } })] }),
      K('copy', 'Copy from one file to another', { children: [K('running-config', 'Copy from current system configuration', { children: [K('startup-config', 'Copy to startup configuration', { run: c => api.copyRunStart(c) })] })] }),
      K('disable', 'Turn off privileged commands', { run: c => { dev.mode = 'user'; } }),
      K('erase', 'Erase a filesystem', { children: [K('startup-config', 'Erase contents of configuration memory', { run: c => api.erase(c) })] }),
      K('exit', 'Exit from the EXEC', { run: c => { dev.mode = 'user'; c.out(''); c.out(dev.run.hostname + ' con0 is now available'); c.out(''); c.out('Press RETURN to get started.', 'dim'); } }),
      ping,
      K('reload', 'Halt and perform a cold restart', { run: c => api.reload(c) }),
      K('show', 'Show running system information', { children: showCmds(true) }),
      K('write', 'Write running configuration to memory', { run: c => api.writeMem(c), children: [K('memory', 'Write to NV memory', { run: c => api.writeMem(c) })] }),
    ];
    const doCmd = K('do', 'To run exec commands in config mode', { children: [REST('LINE', 'Exec command', c => api.doExec(c))] });
    const hostnameCmd = K('hostname', 'Set system\'s network name', { negOk: true, runNeg: c => { dev.run.hostname = dev.factory().hostname; }, children: [A('WORD', 'This system\'s network name', t => /^\S+$/.test(t), { run: c => { dev.run.hostname = c.args[0]; } })] });
    const ipGlobal = K('ip', 'Global IP configuration subcommands', {
      negOk: true,
      children: [
        K('domain-lookup', 'Enable IP Domain Name System hostname translation', { run: c => { dev.run.noLookup = !!c.neg; } }),
        ...(isRouter ? [] : [K('default-gateway', 'Specify default gateway (if not routing IP)', { children: [A('A.B.C.D', 'IP address of default gateway', isIp, { run: c => { dev.run.defGw = c.args[0]; } })], runNeg: c => { dev.run.defGw = null; } })]),
      ],
    });
    const intCmd = K('interface', 'Select an interface to configure', { children: [ifArg(c => { if (!dev.run.ifs[c.args[0]]) { c.errLine('% Invalid interface type and number'); return; } dev.curIf = c.args[0]; dev.mode = 'if'; })] });
    const no = K('no', 'Negate a command or set its defaults', { isNo: true });
    const config = [no, doCmd, hostnameCmd, ipGlobal, intCmd,
      K('exit', 'Exit from configure mode', { run: c => { dev.mode = 'priv'; c.out('%SYS-5-CONFIG_I: Configured from console by console', 'dim'); } }),
      K('end', 'Exit from configure mode', { run: c => { dev.mode = 'priv'; c.out('%SYS-5-CONFIG_I: Configured from console by console', 'dim'); } }),
    ];
    const ifCmds = [no, doCmd,
      K('description', 'Interface specific description', { negOk: true, runNeg: c => { dev.run.ifs[dev.curIf].desc = ''; }, children: [REST('LINE', 'Up to 240 characters describing this interface', c => { dev.run.ifs[dev.curIf].desc = c.args[0]; })] }),
      K('shutdown', 'Shutdown the selected interface', { negOk: true, run: c => { dev.run.ifs[dev.curIf].shut = !c.neg; api.linkMsg(c); } }),
      K('interface', 'Select an interface to configure', { children: [ifArg(c => { if (!dev.run.ifs[c.args[0]]) { c.errLine('% Invalid interface type and number'); return; } dev.curIf = c.args[0]; })] }),
      K('exit', 'Exit from interface configuration mode', { run: c => { dev.mode = 'config'; dev.curIf = null; } }),
      K('end', 'Exit from configure mode', { run: c => { dev.mode = 'priv'; dev.curIf = null; c.out('%SYS-5-CONFIG_I: Configured from console by console', 'dim'); } }),
    ];
    const ipIf = K('ip', 'Interface Internet Protocol config commands', {
      negOk: true,
      vis: () => isRouter || (dev.curIf && dev.curIf.startsWith('Vlan')),
      children: [K('address', 'Set the IP address of an interface', {
        runNeg: c => { const i = dev.run.ifs[dev.curIf]; i.ip = null; i.mask = null; },
        children: [A('A.B.C.D', 'IP address', isIp, { children: [A('A.B.C.D', 'IP subnet mask', isMask, { run: c => { const i = dev.run.ifs[dev.curIf]; i.ip = c.args[0]; i.mask = c.args[1]; } })] })],
      })],
    });
    ifCmds.splice(2, 0, ipIf);
    return { user, priv, config, if: ifCmds };
  }

  /* ------------------------------------------------------------ parser */
  function tokenize(line) { const toks = []; const re = /\S+/g; let m; while ((m = re.exec(line))) toks.push({ t: m[0], i: m.index }); return toks; }
  const kids = (list, ctx) => (typeof list === 'function' ? list(ctx) : (list || [])).filter(n => !n.vis || n.vis(ctx));

  function walk(tree, mode, line, toks, ctx) {
    const root = tree[mode];
    let level = root; let node = null;
    for (let k = 0; k < toks.length; k++) {
      const tk = toks[k]; const low = tk.t.toLowerCase(); const list = kids(level, ctx);
      const kw = list.filter(n => n.w);
      const exact = kw.find(n => n.w === low);
      const cand = exact ? [exact] : kw.filter(n => n.w.startsWith(low));
      if (cand.length > 1) return { err: 'ambiguous', k, node, level };
      let pick = cand[0];
      if (!pick) pick = list.find(n => n.arg && n.test(tk.t, ctx));
      if (!pick) return { err: 'invalid', k, node, level };
      if (pick.isNo) { ctx.neg = true; level = root.filter(n => n.negOk); node = pick; continue; }
      node = pick;
      if (pick.arg) {
        const v = pick.rest ? line.slice(tk.i).trim() : (pick.val ? pick.val(tk.t) : tk.t);
        if (pick.validate && !pick.validate(v)) return { err: 'invalid', k, node, level };
        ctx.args.push(pick.norm ? pick.norm(v) : v);
        if (pick.rest) { level = []; break; }
      }
      level = pick.children || [];
    }
    return { node, level };
  }

  function helpFor(tree, mode, line, ctx) {
    const trailing = /\s$/.test(line) || line === '';
    const toks = tokenize(line);
    if (!trailing && toks.length) {
      const last = toks.pop(); const w = walk(tree, mode, line, toks, ctx);
      if (w.err) return { err: true };
      const cand = kids(w.level, ctx).filter(n => n.w && n.w.startsWith(last.t.toLowerCase()));
      return cand.length ? { words: cand.map(n => n.w) } : { err: true, unrec: true };
    }
    const w = walk(tree, mode, line, toks, ctx);
    if (w.err) return { err: true };
    const rows = kids(w.level, ctx).map(n => n.w ? [n.w, n.help] : [n.arg === 'LINE' ? 'LINE' : (n.arg === 'WORD' ? 'WORD' : n.arg), n.help]);
    const fn = w.node ? (ctx.neg ? (w.node.runNeg || w.node.run) : w.node.run) : null;
    if (fn) rows.push(['<cr>', '']);
    if (ctx.neg && !w.node.arg && w.node.isNo) { /* only no-able list */ }
    return { rows };
  }

  /* ------------------------------------------------------------ widget */
  PT.mountTerminal = function (container, cfg) {
    cfg = cfg || {};
    const dev = makeDevice(cfg);
    const bodyEl = h('div', { class: 'term-body', role: 'log', 'aria-live': 'polite', 'aria-label': PT.t('termOutAria') });
    const inEl = h('input', { class: 'term-input', type: 'text', autocomplete: 'off', autocapitalize: 'off', spellcheck: 'false', 'aria-label': PT.t('cmdAria') });
    const promptEl = h('span', { class: 'term-prompt' });
    const lineEl = h('div', { class: 'term-in' }, promptEl, inEl);
    bodyEl.append(lineEl);
    let hist = [], hi = 0;

    function print(text, cls) {
      String(text).split('\n').forEach(t => { const d = h('div', { class: 'ln' + (cls ? ' ' + cls : '') }, t === '' ? ' ' : t); bodyEl.insertBefore(d, lineEl); });
    }
    function scroll() { bodyEl.scrollTop = bodyEl.scrollHeight; }
    function setPrompt() { promptEl.textContent = dev.prompt(); }

    /* ---- api used by commands ---- */
    const api = {};
    api.showIpBrief = c => {
      c.out(pad('Interface', 23) + pad('IP-Address', 16) + pad('OK?', 4) + pad('Method', 7) + pad('Status', 22) + 'Protocol');
      dev.listIfs().forEach(n => { const i = dev.run.ifs[n]; const l = dev.link(n); c.out(pad(n, 23) + pad(i.ip || 'unassigned', 16) + pad('YES', 4) + pad(i.ip ? 'manual' : 'unset', 7) + pad(l.st, 22) + l.pr); });
    };
    api.showIfStatus = c => {
      c.out(pad('Port', 10) + pad('Name', 19) + pad('Status', 13) + pad('Vlan', 11) + pad('Duplex', 8) + pad('Speed', 7) + 'Type');
      dev.ports.forEach(n => {
        const i = dev.run.ifs[n]; const l = dev.link(n); const st = i.shut ? 'disabled' : (l.pr === 'up' ? 'connected' : 'notconnect'); const up = st === 'connected';
        c.out(pad(short(n), 10) + pad((i.desc || '').slice(0, 18), 19) + pad(st, 13) + pad('1', 11) + pad(up ? 'a-full' : 'auto', 8) + pad(up ? (n.startsWith('Gi') ? 'a-1000' : 'a-100') : 'auto', 7) + (n.startsWith('Gi') ? '10/100/1000BaseTX' : '10/100BaseTX'));
      });
    };
    api.showIf = c => {
      const n = c.args[0]; const i = dev.run.ifs[n]; if (!i) { c.out('% Invalid interface type and number', 'err'); return; }
      const l = dev.link(n); const tag = dev.kind === 'switch' && !n.startsWith('Vlan') ? ' (' + (i.shut ? 'disabled' : (l.pr === 'up' ? 'connected' : 'notconnect')) + ')' : '';
      c.out(n + ' is ' + l.st + ', line protocol is ' + l.pr + tag);
      if (i.desc) c.out('  Description: ' + i.desc);
      if (i.ip) c.out('  Internet address is ' + i.ip + '/' + i.mask.split('.').reduce((a, x) => a + (+x).toString(2).replace(/0/g, '').length, 0));
      c.out('  MTU 1500 bytes, BW 100000 Kbit/sec');
      c.out('  [the remaining lines are not shown in this practice terminal]', 'dim');
    };
    api.showMac = c => {
      c.out('          Mac Address Table'); c.out('-------------------------------------------'); c.out('');
      c.out('Vlan    Mac Address       Type        Ports'); c.out('----    -----------       --------    -----');
      dev.macs.forEach(m => c.out(pad(String(m.vlan).padStart(4, ' '), 8) + pad(m.mac.toLowerCase(), 18) + pad(m.type, 12) + m.port));
      c.out('Total Mac Addresses for this criterion: ' + dev.macs.length);
    };
    api.showRun = c => {
      const L = dev.cfgLines(dev.run); c.out('Building configuration...'); c.out('');
      c.out('Current configuration : ' + (L.join('\n').length + 120) + ' bytes'); L.forEach(l => c.out(l));
    };
    api.showStart = c => {
      if (!dev.start) { c.out('startup-config is not present'); return; }
      c.out('Using ' + (dev.cfgLines(dev.start).join('\n').length + 120) + ' bytes'); dev.cfgLines(dev.start).forEach(l => c.out(l));
    };
    api.linkMsg = c => {
      const n = dev.curIf; const l = dev.link(n); const ifn = n;
      const before = c.prevLink; if (before && before.st === l.st && before.pr === l.pr) return;
      if (l.pr === 'up') { c.out('%LINK-3-UPDOWN: Interface ' + ifn + ', changed state to up', 'dim'); c.out('%LINEPROTO-5-UPDOWN: Line protocol on Interface ' + ifn + ', changed state to up', 'dim'); }
      else if (l.st === 'administratively down') { c.out('%LINK-5-CHANGED: Interface ' + ifn + ', changed state to administratively down', 'dim'); if (before && before.pr === 'up') c.out('%LINEPROTO-5-UPDOWN: Line protocol on Interface ' + ifn + ', changed state to down', 'dim'); }
    };
    api.ping = c => {
      const ip = c.args[0]; c.out('Type escape sequence to abort.'); c.out('Sending 5, 100-byte ICMP Echos to ' + ip + ', timeout is 2 seconds:');
      let ok = false;
      dev.listIfs().forEach(n => { const i = dev.run.ifs[n]; if (i.ip === ip && dev.link(n).pr === 'up') ok = true; });
      if (!ok && dev.reachable) ok = !!dev.reachable(dev, ip);
      if (ok) { c.out('!!!!!'); c.out('Success rate is 100 percent (5/5), round-trip min/avg/max = 1/1/2 ms'); }
      else { c.out('.....'); c.out('Success rate is 0 percent (0/5)'); }
    };
    api.copyRunStart = c => {
      dev.pending = { prompt: 'Destination filename [startup-config]? ', next: txt => { dev.start = clone(dev.run); dev.saves++; print('Building configuration...'); print('[OK]'); } };
    };
    api.writeMem = c => { dev.start = clone(dev.run); dev.saves++; c.out('Building configuration...'); c.out('[OK]'); };
    api.erase = c => {
      dev.pending = { prompt: 'Erasing the nvram filesystem will remove all configuration files! Continue? [confirm]', next: txt => { if (txt === '' || /^y/i.test(txt)) { dev.start = null; dev.erased++; print('[OK]'); print('Erase of nvram: complete'); print('%SYS-7-NV_BLOCK_INIT: Initialized the geometry of nvram', 'dim'); } } };
    };
    api.reload = c => {
      const doReload = () => {
        dev.pending = { prompt: 'Proceed with reload? [confirm]', next: txt => {
          if (txt === '' || /^y/i.test(txt)) {
            dev.run = dev.start ? clone(dev.start) : dev.factory(); dev.mode = 'user'; dev.curIf = null; dev.reloads++; dev.macs = dev.macs.filter(m => m.type !== 'DYNAMIC');
            print(''); print('Reload requested by console.', 'dim'); print('[Booting... the boot messages are omitted in this practice terminal]', 'dim'); print(''); print('Press RETURN to get started!');
          }
        } };
      };
      if (dev.unsaved()) {
        const ask = () => { dev.pending = { prompt: 'System configuration has been modified. Save? [yes/no]: ', next: txt => {
          if (/^y(es)?$/i.test(txt)) { dev.start = clone(dev.run); dev.saves++; print('Building configuration...'); print('[OK]'); doReload(); }
          else if (/^n(o)?$/i.test(txt)) doReload();
          else { print("Please answer 'yes' or 'no'."); ask(); }
        } }; };
        ask();
      } else doReload();
    };
    api.doExec = c => { runLine(c.args[0], 'priv', true, c); };

    /* ---- executing a line ---- */
    function runLine(line, mode, nested, parentCtx) {
      const tree = TREE; const out = parentCtx ? parentCtx.out : (t, cls) => print(t, cls);
      const ctx = { neg: false, args: [], dev, out, errLine: t => out(t, 'err'), prevLink: null };
      if (dev.curIf && dev.run.ifs[dev.curIf]) ctx.prevLink = dev.link(dev.curIf);
      const toks = tokenize(line);
      if (!toks.length) return;
      const promptLen = (nested ? '' : dev.prompt()).length;
      const w = walk(tree, mode, line, toks, ctx);
      const fail = kind => { dev.errCount++; dev.errKinds[kind] = (dev.errKinds[kind] || 0) + 1; };
      if (w.err === 'ambiguous') { fail('ambiguous'); out('% Ambiguous command:  "' + line.trim() + '"', 'err'); return; }
      if (w.err === 'invalid') {
        if (w.k === 0 && (mode === 'user' || mode === 'priv') && !dev.run.noLookup) { fail('unknown'); out('Translating "' + toks[0].t + '"', 'dim'); out('% Unknown command or computer name, or unable to find computer address', 'err'); return; }
        if (w.k === 0 && (mode === 'user' || mode === 'priv')) { fail('unknown'); out('% Unknown command or computer name, or unable to find computer address', 'err'); return; }
        fail('invalid'); out(' '.repeat(promptLen + toks[w.k].i) + '^', 'err'); out("% Invalid input detected at '^' marker.", 'err'); return;
      }
      const node = w.node;
      const fn = node ? (ctx.neg ? (node.runNeg || node.run) : node.run) : null;
      if (!fn) { fail('incomplete'); out('% Incomplete command.', 'err'); return; }
      fn(ctx);
    }

    function submit(raw) {
      const line = raw;
      print(dev.prompt() + line);
      const before = snapshot();
      if (dev.pending) {
        const p = dev.pending; dev.pending = null; p.next(line.trim());
      } else if (line.trim()) {
        dev.history.push(line.trim()); hist.push(line); hi = hist.length;
        const mode = dev.mode; runLine(line, mode, false, null);
      }
      setPrompt(); scroll(); renderState(before); if (cfg.onChange) cfg.onChange(dev);
    }

    /* ---- help / tab ---- */
    function showHelp() {
      const v = inEl.value; const mode = dev.mode;
      const ctx = { neg: false, args: [], dev, out: print };
      print(dev.prompt() + v + '?');
      const r = helpFor(TREE, mode, v, ctx);
      if (r.err) { print(r.unrec ? '% Unrecognized command' : '% Unrecognized command', 'err'); }
      else if (r.words) print(r.words.join('  '));
      else { const wd = Math.max(...r.rows.map(x => x[0].length)) + 2; r.rows.forEach(x => print('  ' + pad(x[0], wd) + x[1])); }
      dev.history.push(v + '?'); noteHelp(v); scroll(); if (cfg.onChange) cfg.onChange(dev);
    }
    function noteHelp() { dev.helpUsed = (dev.helpUsed || 0) + 1; }
    function tab() {
      const v = inEl.value; if (!v || /\s$/.test(v)) return;
      const toks = tokenize(v); const last = toks.pop(); const ctx = { neg: false, args: [], dev, out: print };
      const w = walk(TREE, dev.mode, v, toks, ctx); if (w.err) return;
      const cand = kids(w.level, ctx).filter(n => n.w && n.w.startsWith(last.t.toLowerCase()));
      if (cand.length === 1) { inEl.value = v.slice(0, last.i) + cand[0].w + ' '; dev.tabUsed = (dev.tabUsed || 0) + 1; }
    }

    inEl.addEventListener('keydown', e => {
      if (e.key === 'Enter') { e.preventDefault(); const v = inEl.value; inEl.value = ''; submit(v); }
      else if (e.key === '?' && !dev.pending) { e.preventDefault(); showHelp(); }
      else if (e.key === 'Tab') { e.preventDefault(); if (!dev.pending) tab(); }
      else if (e.key === 'ArrowUp') { e.preventDefault(); if (hi > 0) { hi--; inEl.value = hist[hi]; } }
      else if (e.key === 'ArrowDown') { e.preventDefault(); if (hi < hist.length - 1) { hi++; inEl.value = hist[hi]; } else { hi = hist.length; inEl.value = ''; } }
      else if (e.key.toLowerCase() === 'z' && e.ctrlKey) { e.preventDefault(); if (dev.mode === 'config' || dev.mode === 'if') { print(dev.prompt() + '^Z'); const b = snapshot(); dev.mode = 'priv'; dev.curIf = null; print('%SYS-5-CONFIG_I: Configured from console by console', 'dim'); setPrompt(); renderState(b); if (cfg.onChange) cfg.onChange(dev); scroll(); } }
    });
    bodyEl.addEventListener('click', () => { if (!window.getSelection().toString()) inEl.focus(); });

    /* ---- state panel ---- */
    const stateBody = h('div', { class: 'state-body' });
    const modeBadge = h('span', { class: 'mode' });
    const stateHead = h('div', { class: 'state-head' }, h('span', null, PT.t('devState')), modeBadge);
    const statePanel = h('div', { class: 'state' }, stateHead, stateBody);

    function snapshot() { const s = {}; dev.listIfs().forEach(n => { const i = dev.run.ifs[n]; const l = dev.link(n); s[n] = [i.shut, i.ip, i.mask, i.desc, l.st, l.pr].join('|'); }); s._host = dev.run.hostname; s._macs = dev.macs.length; return s; }

    function diff(a, b) {
      const n = a.length, m = b.length; const T = Array.from({ length: n + 1 }, () => new Array(m + 1).fill(0));
      for (let i = n - 1; i >= 0; i--) for (let j = m - 1; j >= 0; j--) T[i][j] = a[i] === b[j] ? T[i + 1][j + 1] + 1 : Math.max(T[i + 1][j], T[i][j + 1]);
      const out = []; let i = 0, j = 0;
      while (i < n && j < m) { if (a[i] === b[j]) { out.push({ t: 's', x: a[i] }); i++; j++; } else if (T[i + 1][j] >= T[i][j + 1]) { out.push({ t: 'd', x: a[i] }); i++; } else { out.push({ t: 'a', x: b[j] }); j++; } }
      while (i < n) out.push({ t: 'd', x: a[i++] }); while (j < m) out.push({ t: 'a', x: b[j++] });
      return out;
    }

    function renderState(before) {
      setPrompt();
      modeBadge.textContent = dev.pending ? PT.t('modePending') : ({ user: 'User EXEC', priv: 'Privileged EXEC', config: 'Global config', if: 'Interface config' }[dev.mode]);
      stateBody.innerHTML = '';
      const hn = h('div', null, h('b', null, 'Hostname: '), h('span', { style: 'font-family:var(--font-mono)' }, dev.run.hostname));
      stateBody.append(hn);
      // interfaces
      const t = h('table'); t.append(h('tr', null, h('th', null, 'Port'), h('th', null, 'IP'), h('th', null, 'Status'), h('th', null, 'Kabel')));
      const after = snapshot();
      dev.listIfs().forEach(n => {
        const i = dev.run.ifs[n]; const l = dev.link(n); const c = dev.cables[n];
        const cls = l.pr === 'up' ? 'up' : (i.shut ? 'admin' : 'down'); const txt = l.pr === 'up' ? 'up' : (i.shut ? 'admin down' : 'down');
        const tr = h('tr', null, h('td', { class: 'm' }, short(n)), h('td', { class: 'm' }, i.ip ? i.ip + (i.mask ? '/' + maskBits(i.mask) : '') : '—'), h('td', null, h('span', { class: 'badge ' + cls }, txt)), h('td', { class: 'm' }, c ? c.peer : '—'));
        if (before && before[n] !== undefined && before[n] !== after[n]) tr.classList.add('flash');
        t.append(tr);
      });
      stateBody.append(h('div', null, h('h4', null, PT.t('ifaces')), t, h('div', { class: 'state-note' }, PT.t('ifNote'))));
      if (dev.kind === 'switch' && (dev.macs.length || cfg.macPanel)) {
        const mt = h('table'); mt.append(h('tr', null, h('th', null, 'MAC'), h('th', null, 'Port')));
        dev.macs.forEach(m => mt.append(h('tr', null, h('td', { class: 'm' }, m.mac.toLowerCase()), h('td', { class: 'm' }, m.port))));
        stateBody.append(h('div', null, h('h4', null, 'MAC address table'), mt));
      }
      // config diff
      const base = dev.start ? dev.cfgLines(dev.start) : dev.cfgLines(dev.factory());
      const cur = dev.cfgLines(dev.run);
      const d = diff(base, cur).filter(x => x.t !== 's' || false);
      const un = dev.unsaved();
      const box = h('div', null, h('h4', null, 'Running-config ↔ startup-config'));
      box.append(h('div', { style: 'margin-bottom:6px' }, un ? h('span', { class: 'badge admin' }, PT.t('unsaved')) : h('span', { class: 'badge up' }, PT.t('runEqStart'))));
      if (un) { const pre = h('div', { class: 'cfg' }); d.forEach(x => pre.append(h('span', { class: x.t === 'a' ? 'add' : 'gone' }, (x.t === 'a' ? '+ ' : '- ') + x.x))); box.append(pre); box.append(h('div', { class: 'state-note' }, PT.t('cfgAddNote'))); }
      else box.append(h('div', { class: 'state-note' }, dev.start ? PT.t('startSame') : PT.t('noStart')));
      stateBody.append(box);
    }
    function maskBits(m) { return m.split('.').reduce((a, x) => a + (+x).toString(2).replace(/0/g, '').length, 0); }

    /* ---- assemble ---- */
    const TREE = buildTree(dev, api);
    const quick = h('div', { class: 'term-quick' });
    (cfg.quick || []).forEach(q => quick.append(h('button', { type: 'button', onclick: () => { inEl.value = q; inEl.focus(); } }, q)));
    (cfg.actions || []).forEach(a => quick.append(h('button', { type: 'button', style: 'border-color:var(--term-prompt)', onclick: () => { const b = snapshot(); a.run(dev, { print }); renderState(b); if (cfg.onChange) cfg.onChange(dev); } }, a.label)));
    const sendBtn = h('button', { type: 'button', style: 'background:var(--term-mark);color:var(--term-ink);border:1px solid #2d405a;border-radius:3px;padding:3px 10px;font-size:12.5px', onclick: () => { const v = inEl.value; inEl.value = ''; submit(v); inEl.focus(); } }, 'Enter');
    quick.append(sendBtn);
    const clr = h('button', { class: 'tclr', type: 'button', onclick: () => { Array.from(bodyEl.querySelectorAll('.ln')).forEach(x => x.remove()); } }, PT.t('clear'));
    const term = h('div', { class: 'term' },
      h('div', { class: 'term-bar' }, h('span', { class: 'tled' }), h('span', null, PT.t('termBar', { n: cfg.title || (dev.kind === 'switch' ? 'Switch' : 'Router') })), clr),
      bodyEl,
      h('div', { class: 'term-hintbar', html: PT.t('termHint') }),
      quick);
    const grid = h('div', { class: cfg.state === false ? '' : 'tgrid' }, term, cfg.state === false ? null : statePanel);
    container.innerHTML = ''; container.append(grid);
    (cfg.banner || []).forEach(l => print(l, 'dim'));
    print((cfg.welcome || PT.t('termWelcome')), 'dim');
    renderState(null);
    if (cfg.onChange) cfg.onChange(dev);
    const ctl = { dev, print, run: l => submit(l), focus: () => inEl.focus(), help: v => { inEl.value = v; showHelp(); inEl.value = ''; }, tab: v => { inEl.value = v; tab(); const r = inEl.value; inEl.value = ''; return r; } };
    container._term = ctl;
    return ctl;
  };
})();
