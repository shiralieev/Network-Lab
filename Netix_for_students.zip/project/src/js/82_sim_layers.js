/* encapsulation builder, who-reads-what, hex dump decoder, cast types */
(function () {
  const PT = window.PT; const h = PT.h; const A = PT.addr;

  /* ====================== frame bytes (shared by hexdump and tests) ====================== */
  const mac = s => s.split(':').map(x => parseInt(x, 16));
  const ipb = s => s.split('.').map(Number);
  const csum = bytes => { let s = 0; for (let i = 0; i < bytes.length; i += 2) s += (bytes[i] << 8) + (bytes[i + 1] || 0); while (s >> 16) s = (s & 0xFFFF) + (s >> 16); return (~s) & 0xFFFF; };
  PT.frames = {};
  PT.frames.arp = function () {
    const b = [...mac('ff:ff:ff:ff:ff:ff'), ...mac('00:01:43:21:aa:aa'), 0x08, 0x06, 0, 1, 0x08, 0, 6, 4, 0, 1, ...mac('00:01:43:21:aa:aa'), ...ipb('192.168.1.10'), ...mac('00:00:00:00:00:00'), ...ipb('192.168.1.20')];
    return { bytes: b, fields: [
      { n: 'Destination MAC', a: 0, z: 5, v: 'ff:ff:ff:ff:ff:ff', d: 'Hamısı 1: broadcast. ARP request hamıya gedir, çünki PC-A cavab verənin MAC-ini hələ bilmir.', layer: 'Ethernet' },
      { n: 'Source MAC', a: 6, z: 11, v: '00:01:43:21:aa:aa', d: 'Göndərənin (PC-A) öz MAC ünvanı. Switch bunu MAC address table-a öyrənir.', layer: 'Ethernet' },
      { n: 'EtherType', a: 12, z: 13, v: '0x0806', d: '0x0806 = payload ARP-dır. (0x0800 olsaydı IPv4 olardı.) Qəbul edən cihaz bu sahəyə baxıb bilir ki, içəridəki məlumatı hansı protokola verməlidir.', layer: 'Ethernet' },
      { n: 'Hardware type', a: 14, z: 15, v: '1', d: '1 = Ethernet. ARP başqa L2 texnologiyaları üçün də istifadə oluna bilər, bu sahə hansı olduğunu deyir.', layer: 'ARP' },
      { n: 'Protocol type', a: 16, z: 17, v: '0x0800', d: 'Hansı L3 protokolun ünvanı soruşulur: 0x0800 = IPv4.', layer: 'ARP' },
      { n: 'Hardware size', a: 18, z: 18, v: '6', d: 'MAC ünvanı 6 bayt uzunluğundadır.', layer: 'ARP' },
      { n: 'Protocol size', a: 19, z: 19, v: '4', d: 'IPv4 ünvanı 4 bayt uzunluğundadır.', layer: 'ARP' },
      { n: 'Opcode', a: 20, z: 21, v: '1 (request)', d: '1 = sorğu (request), 2 = cavab (reply).', layer: 'ARP' },
      { n: 'Sender MAC', a: 22, z: 27, v: '00:01:43:21:aa:aa', d: 'Sorğunu göndərənin MAC ünvanı. Cavab verən bunu öz ARP cache-inə yazır.', layer: 'ARP' },
      { n: 'Sender IP', a: 28, z: 31, v: '192.168.1.10', d: 'Sorğunu göndərənin IP ünvanı (c0 a8 01 0a = 192.168.1.10).', layer: 'ARP' },
      { n: 'Target MAC', a: 32, z: 37, v: '00:00:00:00:00:00', d: 'Bilinmir, çünki məhz bunu soruşuruq. Ona görə sıfırlarla doldurulub.', layer: 'ARP' },
      { n: 'Target IP', a: 38, z: 41, v: '192.168.1.20', d: 'MAC-i soruşulan IP ünvanı: "192.168.1.20 kimdir? MAC-ini mənə de."', layer: 'ARP' },
    ], note: 'FCS (4 bayt) və Ethernet minimum ölçüyə çatmaq üçün əlavə padding bu siyahıda göstərilmir; NIC onları avtomatik əlavə edir.' };
  };
  PT.frames.icmp = function () {
    const data = 'abcdefghijklmnopqrstuvwabcdefghi'.split('').map(c => c.charCodeAt(0));
    const icmp = [8, 0, 0, 0, 0, 1, 0, 1, ...data]; const c1 = csum(icmp); icmp[2] = c1 >> 8; icmp[3] = c1 & 255;
    const ip = [0x45, 0, 0, 60, 0, 1, 0, 0, 128, 1, 0, 0, ...ipb('192.168.1.10'), ...ipb('192.168.1.20')]; const c2 = csum(ip); ip[10] = c2 >> 8; ip[11] = c2 & 255;
    const b = [...mac('00:01:43:21:bb:bb'), ...mac('00:01:43:21:aa:aa'), 0x08, 0x00, ...ip, ...icmp];
    const x = (n) => '0x' + A.hex(n, 4);
    return { bytes: b, checksums: { ip: c2, icmp: c1 }, fields: [
      { n: 'Destination MAC', a: 0, z: 5, v: '00:01:43:21:bb:bb', d: 'Növbəti cihazın MAC ünvanı. Burada hədəf PC eyni network-dədir, ona görə hədəfin öz MAC-idir (ARP ilə tapılıb). Hədəf başqa network-də olsaydı, burada router-in MAC-i olardı.', layer: 'Ethernet' },
      { n: 'Source MAC', a: 6, z: 11, v: '00:01:43:21:aa:aa', d: 'Göndərənin MAC-i.', layer: 'Ethernet' },
      { n: 'EtherType', a: 12, z: 13, v: '0x0800', d: '0x0800 = içəridə IPv4 paketi var.', layer: 'Ethernet' },
      { n: 'Version + IHL', a: 14, z: 14, v: '0x45', d: 'Birinci rəqəm 4 = IPv4. İkinci rəqəm 5 = başlıq 5 × 4 = 20 bayt uzunluğundadır.', layer: 'IPv4' },
      { n: 'DSCP / ECN', a: 15, z: 15, v: '0x00', d: 'Trafikin prioritet etiketi (QoS). Burada standart, yəni 0.', layer: 'IPv4' },
      { n: 'Total length', a: 16, z: 17, v: '60', d: 'IP başlığı + içindəki hər şey: 20 (IP) + 8 (ICMP başlığı) + 32 (data) = 60 bayt.', layer: 'IPv4' },
      { n: 'Identification', a: 18, z: 19, v: '1', d: 'Paket bölünərsə (fragmentation), hissələri birləşdirmək üçün eyni nömrə istifadə olunur.', layer: 'IPv4' },
      { n: 'Flags + Fragment offset', a: 20, z: 21, v: '0x0000', d: 'Fragmentation üçün sahələr. Burada paket bölünməyib.', layer: 'IPv4' },
      { n: 'TTL', a: 22, z: 22, v: '128', d: 'Time To Live. Hər router paketi ötürəndə bunu 1 azaldır. 0 olanda paket atılır. Bu, paketlərin şəbəkədə sonsuz dolaşmasının qarşısını alır. 128 Windows-un standart başlanğıc dəyəridir.', layer: 'IPv4' },
      { n: 'Protocol', a: 23, z: 23, v: '1 (ICMP)', d: 'İçəridəki məlumat hansı protokoldur: 1 = ICMP, 6 = TCP, 17 = UDP.', layer: 'IPv4' },
      { n: 'Header checksum', a: 24, z: 25, v: x(c2), d: 'Yalnız IP başlığının yoxlama cəmi. Router TTL-i dəyişəndə bunu yenidən hesablayır.', layer: 'IPv4' },
      { n: 'Source IP', a: 26, z: 29, v: '192.168.1.10', d: 'c0 a8 01 0a = 192.168.1.10. Router-lərdən keçəndə də dəyişmir (NAT olmasa).', layer: 'IPv4' },
      { n: 'Destination IP', a: 30, z: 33, v: '192.168.1.20', d: 'Paketin son hədəfi. Router bu ünvana baxıb routing table-dan növbəti hop-u seçir.', layer: 'IPv4' },
      { n: 'ICMP type', a: 34, z: 34, v: '8 (echo request)', d: '8 = ping sorğusu. Cavab 0 (echo reply) olacaq.', layer: 'ICMP' },
      { n: 'ICMP code', a: 35, z: 35, v: '0', d: 'Echo üçün əlavə kod yoxdur.', layer: 'ICMP' },
      { n: 'ICMP checksum', a: 36, z: 37, v: x(c1), d: 'ICMP mesajının yoxlama cəmi.', layer: 'ICMP' },
      { n: 'Identifier', a: 38, z: 39, v: '1', d: 'Hansı ping prosesinə aid olduğunu göstərir.', layer: 'ICMP' },
      { n: 'Sequence number', a: 40, z: 41, v: '1', d: 'Hər ping sorğusunda 1 artır. Cavabı sorğu ilə uyğunlaşdırmaq üçündür.', layer: 'ICMP' },
      { n: 'Data', a: 42, z: 73, v: '"abcdefghijklmnopqrstuvwabcdefghi"', d: 'Ping-in məlumatı: 32 bayt. Windows hərfləri a-dan w-yə qədər, sonra yenidən a-dan başlayaraq doldurur. Hex-də 61 62 63 ... (61 = "a").', layer: 'ICMP' },
    ], note: 'Ethernet FCS (4 bayt) göstərilmir. Real şəbəkədə NIC onu əlavə edir.' };
  };

  /* ====================== hexdump ====================== */
  PT.sims.hexdump = function (el, o) {
    o = Object.assign({ frame: 'icmp', title: 'Hex dump decoder' }, o);
    const body = PT.simFrame(el, o.title, 'Baytın üstünə klik et. Tapşırıq: istənilən sahəni tap.');
    let cur = o.frame; let sel = -1;
    const tabs = h('div', { class: 'fields' }); const dump = h('div', { class: 'hex' }); const info = h('div', { class: 'sim-log' }); const fl = h('div', { class: 'fields' }); const task = h('div', { class: 'predict' });
    const names = { icmp: 'Ethernet + IPv4 + ICMP (ping)', arp: 'Ethernet + ARP' };
    if (Array.isArray(o.modes)) Object.keys(names).forEach(k => { if (o.modes.indexOf(k) < 0) delete names[k]; });
    Object.keys(names).forEach(k => { const b = h('button', { type: 'button', class: 'chip' + (k === cur ? ' is-on' : '') }, names[k]); b.addEventListener('click', () => { cur = k; sel = -1; Array.from(tabs.children).forEach((c, i) => c.classList.toggle('is-on', Object.keys(names)[i] === k)); draw(); newTask(); }); tabs.append(b); });
    let target = null, tmsg = h('div', { class: 'fine', role: 'status', style: 'margin-top:6px' });
    function F() { return PT.frames[cur](); }
    function draw() {
      const fr = F(); dump.innerHTML = ''; fl.innerHTML = '';
      for (let r = 0; r < fr.bytes.length; r += 16) {
        dump.append(h('div', { class: 'off' }, A.hex(r, 4)));
        const bx = h('div', { class: 'bytes' });
        for (let i = r; i < Math.min(r + 16, fr.bytes.length); i++) {
          const fi = fr.fields.findIndex(f => i >= f.a && i <= f.z);
          const b = h('span', { class: 'hb' + (sel >= 0 && fr.fields[sel].a <= i && i <= fr.fields[sel].z ? ' sel' : ''), 'data-i': i, 'data-f': fi, tabindex: '0', role: 'button', 'aria-label': 'Bayt ' + i + ': ' + A.hex(fr.bytes[i]) }, A.hex(fr.bytes[i]));
          const act = () => pickField(fi); b.addEventListener('click', act); b.addEventListener('keydown', e => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); act(); } });
          bx.append(b);
        }
        dump.append(bx);
      }
      fr.fields.forEach((f, i) => { const c = h('button', { type: 'button', class: 'chip' + (i === sel ? ' is-on' : '') }, f.n); c.addEventListener('click', () => pickField(i)); fl.append(c); });
    }
    function pickField(i) {
      const fr = F(); const f = fr.fields[i];
      if (target !== null && !target.done) { if (i === target.i) { target.done = true; tmsg.innerHTML = '<b style="color:var(--ok)">Düzdür.</b> Bu "' + f.n + '" sahəsidir.'; } else tmsg.innerHTML = '<b style="color:var(--bad)">Bu "' + f.n + '" sahəsidir.</b> Axtarılan: <b>' + fr.fields[target.i].n + '</b>. Başqa baytlara bax.'; }
      sel = i; draw();
      info.innerHTML = '<b>' + f.layer + ' · ' + f.n + '</b> (bayt ' + f.a + (f.z > f.a ? '–' + f.z : '') + ', ' + (f.z - f.a + 1) + ' bayt)<br>Dəyər: <b class="m">' + f.v + '</b><br>' + f.d;
    }
    function newTask() {
      const fr = F(); const pool = fr.fields.filter(f => !/Data|Target MAC/.test(f.n)); const f = PT.pick(pool); target = { i: fr.fields.indexOf(f), done: false };
      task.innerHTML = ''; task.append(h('h4', null, 'Tapşırıq'), h('div', null, 'Dump-da ', h('b', null, '"' + f.n + '"'), ' sahəsini tap və baytlarına klik et.'), tmsg); tmsg.textContent = '';
      const nb = h('button', { type: 'button', class: 'btn btn-sm', style: 'margin-top:8px', onclick: newTask }, 'Başqa sahə ver'); task.append(nb);
    }
    body.append(tabs, dump, h('div', { class: 'fine', style: 'margin:8px 0 4px' }, 'Hər iki rəqəm bir baytdır (hex). Sahələr:'), fl, info, task);
    info.textContent = 'Bir bayta və ya sahə adına klik et, burada izahı görünəcək.';
    draw(); newTask();
  };

  /* ====================== encapsulation builder ====================== */
  const ENC = {
    web: {
      name: 'Veb sorğusu (TCP)', data: 'GET / HTTP/1.1\nHost: 192.168.1.20', pdu4: 'Segment', proto: '6 (TCP)', l4: 'TCP',
      l4fields: [['Source port', '51514', 'Göndərən proqramın müvəqqəti portu'], ['Destination port', '80', 'HTTP serverin portu'], ['Sequence number', '1', 'Baytların sırasını izləmək üçün'], ['Acknowledgment', '1', 'Qarşı tərəfdən hansı bayta qədər aldığını bildirir'], ['Flags', 'PSH, ACK', 'Bağlantı vəziyyəti bayraqları'], ['Window', '64240', 'Qəbul edən tərəfin hazırda qəbul edə biləcəyi bayt sayı']],
    },
    ping: {
      name: 'Ping (ICMP)', data: 'abcdefghijklmnopqrstuvwabcdefghi', pdu4: null, proto: '1 (ICMP)', l4: 'ICMP',
      l4fields: [['Type', '8', 'Echo request (ping sorğusu)'], ['Code', '0', 'Əlavə kod yoxdur'], ['Checksum', '0x4d5a', 'Mesajın yoxlama cəmi'], ['Identifier', '1', 'Ping prosesinin nömrəsi'], ['Sequence', '1', 'Sorğunun sıra nömrəsi']],
    },
  };
  ENC.ping.l4fields[2][1] = '0x' + A.hex(PT.frames.icmp().checksums.icmp, 4);
  PT.sims.encap = function (el, o) {
    const body = PT.simFrame(el, 'Encapsulation: məlumat necə sarılır', 'Əvvəl təxmin et, sonra addım-addım bax.');
    let sc = 'web', step = 0, who = null;
    const tabs = h('div', { class: 'fields' }); const stage = h('div'); const info = h('div', { class: 'sim-log' }); const nav = h('div', { class: 'sim-ctrl' }); const whoBar = h('div', { class: 'fields' });
    Object.keys(ENC).forEach(k => { const b = h('button', { type: 'button', class: 'chip' + (k === sc ? ' is-on' : '') }, ENC[k].name); b.addEventListener('click', () => { sc = k; step = 0; Array.from(tabs.children).forEach((c, i) => c.classList.toggle('is-on', Object.keys(ENC)[i] === k)); draw(); }); tabs.append(b); });
    const prev = h('button', { type: 'button', class: 'btn btn-sm', onclick: () => { if (step > 0) { step--; draw(); } } }, 'Geri');
    const next = h('button', { type: 'button', class: 'btn btn-sm btn-primary', onclick: () => { if (step < 4) { step++; draw(); } } }, 'Növbəti layer');
    const rst = h('button', { type: 'button', class: 'btn btn-sm btn-quiet', onclick: () => { step = 0; who = null; draw(); } }, 'Başa qaytar');
    nav.append(prev, next, rst);
    ['PC', 'Switch', 'Router'].forEach(w => { const b = h('button', { type: 'button', class: 'chip' }, w + ' nəyə baxır?'); b.addEventListener('click', () => { who = who === w ? null : w; Array.from(whoBar.children).forEach((c, i) => c.classList.toggle('is-on', ['PC', 'Switch', 'Router'][i] === who)); draw(); }); whoBar.append(b); });

    function block(cls, title, sub, key) {
      const b = h('div', { class: 'enc-blk ' + cls, 'data-key': key, tabindex: '0', role: 'button' }, h('b', null, title), h('span', null, sub));
      const read = who && ((who === 'PC') || (who === 'Switch' && key === 'eth') || (who === 'Router' && (key === 'eth' || key === 'ip')));
      const rewrite = who === 'Router' && (key === 'eth' || key === 'ip');
      if (who) { b.style.opacity = read ? 1 : 0.35; if (read) b.style.outline = '3px solid var(--btn)'; }
      b.addEventListener('click', () => showFields(key)); b.addEventListener('keydown', e => { if (e.key === 'Enter') showFields(key); });
      return b;
    }
    let shown = 'data';
    function showFields(key) { shown = key; renderInfo(); }
    function renderInfo() {
      const E = ENC[sc]; info.innerHTML = '';
      const tbl = (title, rows) => info.append(PT.fieldsTable(title, rows.map(r => [r[0], r[1]])), h('div', { class: 'fine', style: 'margin-top:6px' }, rows.map(r => r[0] + ': ' + r[2]).join(' · ')));
      if (shown === 'data') info.append(h('div', null, h('b', null, 'Application data. '), 'Proqramın göndərmək istədiyi məlumat. Hələ heç bir ünvan və port yoxdur; bunları aşağıdakı layer-lər əlavə edir.'));
      else if (shown === 'l4') { info.append(h('div', null, h('b', null, E.l4 + ' header. '), sc === 'web' ? 'Transport layer: portlar hansı proqrama çatdırılacağını, sıra nömrələri isə etibarlı çatdırılmanı idarə edir.' : 'ICMP IP-nin köməkçi protokoludur: o, IP paketinin içində gedir, port yoxdur. Layer baxımından Network layer-ə aiddir.')); tbl(E.l4 + ' sahələri', E.l4fields); }
      else if (shown === 'ip') { info.append(h('div', null, h('b', null, 'IPv4 header. '), 'Network layer: məntiqi ünvanlar (IP) və TTL burada olur. Router məhz bu başlığa baxıb qərar verir.')); tbl('IPv4 sahələri', [['Version / IHL', '4 / 5', 'IPv4, başlıq 20 bayt'], ['TTL', '128', 'Hər router 1 azaldır'], ['Protocol', E.proto, 'İçəridə hansı protokol var'], ['Source IP', '192.168.1.10', 'Göndərənin IP-si'], ['Destination IP', '192.168.1.20', 'Hədəfin IP-si']]); }
      else if (shown === 'eth') { info.append(h('div', null, h('b', null, 'Ethernet header + FCS. '), 'Data link layer: MAC ünvanları yalnız bir link üçün keçərlidir. Switch yalnız bu başlığa baxır.')); tbl('Ethernet sahələri', [['Destination MAC', '00:01:43:21:bb:bb', 'Bu link-də növbəti cihaz'], ['Source MAC', '00:01:43:21:aa:aa', 'Bu link-də göndərən'], ['EtherType', '0x0800', 'İçəridə IPv4 var'], ['FCS (sonda)', '4 bayt', 'Kadrın sağlamlığını yoxlayır']]); }
      else if (shown === 'bits') info.append(h('div', null, h('b', null, 'Physical layer. '), 'Kadr bitlərə çevrilir və kabeldə elektrik siqnalı (mis), işıq (optik) və ya radio dalğası kimi göndərilir. Bu, əvvəlki layer-lərin heç birinə aid deyil: onlar yalnız bitlərin düzgün sırası və mənası ilə maraqlanır.'));
      if (who === 'Switch') info.append(h('p', { style: 'margin:8px 0 0' }, h('b', null, 'Switch: '), 'yalnız Ethernet başlığını oxuyur (Destination və Source MAC). IP və port onun üçün sadəcə "içəridəki məlumat"dır. Kadrı dəyişdirmir, olduğu kimi ötürür.'));
      if (who === 'Router') info.append(h('p', { style: 'margin:8px 0 0' }, h('b', null, 'Router: '), 'kadrı qəbul edib Ethernet başlığını silir, IP başlığını oxuyur (Destination IP-ə görə routing table-a baxır), TTL-i 1 azaldır (checksum yenidən hesablanır), sonra çıxış interface-i üçün YENİ Ethernet başlığı (yeni MAC-lər) yaradır. Source/Destination IP dəyişməz qalır.'));
      if (who === 'PC') info.append(h('p', { style: 'margin:8px 0 0' }, h('b', null, 'Hədəf PC: '), 'bütün layer-ləri aşağıdan yuxarı açır: Ethernet → IP → TCP/ICMP → proqram.'));
    }
    function draw() {
      const E = ENC[sc]; stage.innerHTML = ''; shown = ['data', 'l4', 'ip', 'eth', 'bits'][step];
      const names = ['1. Application data', '2. ' + (sc === 'web' ? 'Transport: TCP' : 'ICMP mesajı'), '3. Network: IP', '4. Data link: Ethernet', '5. Physical: bitlər'];
      const pdu = ['Data', sc === 'web' ? 'Segment' : 'ICMP mesajı', 'Packet', 'Frame', 'Bits'][step];
      stage.append(h('div', { class: 'fields' }, names.map((n, i) => h('span', { class: 'chip' + (i === step ? ' is-on' : ''), style: 'cursor:default;opacity:' + (i <= step ? 1 : 0.5) }, n))));
      const row = h('div', { class: 'enc-row' });
      if (step === 4) row.append(h('div', { class: 'enc-bits', 'data-key': 'bits' }, '10101100 00011000 01010011 11001010 00110101 …'));
      else {
        if (step >= 3) row.append(block('eth', 'Ethernet', 'MAC dst, MAC src, type', 'eth'));
        if (step >= 2) row.append(block('ip', 'IP header', 'IP src, IP dst, TTL', 'ip'));
        if (step >= 1) row.append(block('l4', E.l4 + ' header', sc === 'web' ? 'port src, port dst' : 'type 8, code 0', 'l4'));
        row.append(block('data', 'Data', E.data.split('\n')[0], 'data'));
        if (step >= 3) row.append(block('eth', 'FCS', '4 bayt', 'eth'));
      }
      stage.append(row, h('div', { class: 'enc-pdu' }, 'PDU adı: ', h('b', null, pdu), step >= 1 && step <= 3 ? '  (' + ['', 'Transport layer', 'Network layer', 'Data link layer'][step] + ')' : ''));
      prev.disabled = step === 0; next.disabled = step === 4;
      renderInfo();
    }
    const pb = PT.predict({ q: 'Məlumat göndərilərkən layer-lər yuxarıdan aşağı başlıq əlavə edir. Sonda <b>ən xaricdə</b> hansı başlıq olacaq?', options: [{ t: 'Ethernet (Data link)', ok: true, why: 'Hər layer yuxarıdan aldığını sarıyır. Data link ən aşağıdakı software layer-dir, ona görə onun başlığı ən xaricdə, yəni kadrın ən başındadır. Switch də məhz buna baxdığı üçün əvvəl onu oxuyur.' }, { t: 'IP', why: 'IP başlığı Ethernet-in İÇİNDƏDİR. Əvvəl IP başlığı əlavə olunur, sonra Data link onu da sarıyır.' }, { t: 'TCP', why: 'TCP başlığı ən içdədir (data-ya ən yaxın). Ən xaricdə olan sonuncu əlavə olunan başlıqdır.' }] });
    body.append(pb.el, tabs, nav, stage, h('div', { class: 'fine', style: 'margin:10px 0 4px' }, 'Cihaz seç: hansı başlığa baxır və nəyi dəyişir?'), whoBar, info); draw();
  };

  /* ====================== cast types ====================== */
  PT.sims.cast = function (el, o) {
    const body = PT.simFrame(el, 'Cast növləri: kim qəbul edir?', 'Növü seç, təxmin et, göndər.');
    o = o || {}; const showSnoop = o.snoop !== false;
    let mode = 'unicast', snoop = !showSnoop, busy = false;
    const tabs = h('div', { class: 'fields' }); const stageHost = h('div', { class: 'sim-stage' }); const log = h('div', { class: 'sim-log' }); const ctrl = h('div', { class: 'sim-ctrl' }); const predHost = h('div'); const insp = h('div');
    const names = { unicast: 'Unicast', broadcast: 'Broadcast', multicast: 'Multicast', anycast: 'Anycast' };
    Object.keys(names).forEach(k => { const b = h('button', { type: 'button', class: 'chip' + (k === mode ? ' is-on' : '') }, names[k]); b.addEventListener('click', () => { mode = k; Array.from(tabs.children).forEach((c, i) => c.classList.toggle('is-on', Object.keys(names)[i] === k)); init(); }); tabs.append(b); });
    let T, sendBtn, snoopCb, failCb, answered = false;
    const MACS = { PC1: '00:01:43:21:aa:01', PC2: '00:01:43:21:aa:02', PC3: '00:01:43:21:aa:03', PC4: '00:01:43:21:aa:04' };
    const IPS = { PC1: '192.168.1.1', PC2: '192.168.1.2', PC3: '192.168.1.3', PC4: '192.168.1.4' };

    function lanNodes() { return [{ id: 'PC1', label: 'PC1', x: 70, y: 150, kind: 'pc', sub: 'göndərən' }, { id: 'SW', label: 'Switch', x: 300, y: 150, kind: 'switch' }, { id: 'PC2', label: 'PC2', x: 540, y: 50, kind: 'pc' }, { id: 'PC3', label: 'PC3', x: 540, y: 150, kind: 'pc' }, { id: 'PC4', label: 'PC4', x: 540, y: 250, kind: 'pc' }]; }
    function init() {
      busy = false; answered = false; stageHost.innerHTML = ''; log.textContent = 'Əvvəl təxmin et, sonra "Göndər" düyməsinə bas.'; ctrl.innerHTML = ''; predHost.innerHTML = ''; insp.innerHTML = '';
      if (mode === 'anycast') {
        T = PT.topo([{ id: 'C', label: 'Client', x: 70, y: 200, kind: 'pc' }, { id: 'S1', label: 'Server A', x: 540, y: 70, kind: 'server', sub: '203.0.113.53\n2 hop' }, { id: 'S2', label: 'Server B', x: 540, y: 200, kind: 'server', sub: '203.0.113.53\n6 hop' }, { id: 'S3', label: 'Server C', x: 540, y: 330, kind: 'server', sub: '203.0.113.53\n9 hop' }, { id: 'R', label: 'Internet', x: 300, y: 200, kind: 'router' }], [['C', 'R'], ['R', 'S1'], ['R', 'S2'], ['R', 'S3']], { w: 640, h: 420 });
        failCb = h('input', { type: 'checkbox', id: 'any-fail' }); failCb.addEventListener('change', () => { T.clearMarks(); T.badge('S1', ''); log.textContent = failCb.checked ? 'Server A kənarlaşdırıldı (söndü). Göndərəndə routing növbəti ən yaxın serveri seçəcək.' : 'Bütün serverlər işləyir.'; });
        sendBtn = h('button', { type: 'button', class: 'btn btn-primary btn-sm', onclick: send }, 'Göndər');
        ctrl.append(sendBtn, h('label', { for: 'any-fail', style: 'display:flex;gap:6px;align-items:center' }, failCb, 'Ən yaxın server (A) sönüb'));
        predHost.append(PT.predict({ q: 'Üç serverin hamısında <b>eyni IP ünvanı</b> var (203.0.113.53). Client bu IP-yə paket göndərəndə hansı server cavab verəcək?', options: [{ t: 'Routing baxımından ən yaxın olan (Server A)', ok: true, why: 'Anycast-da eyni IP bir neçə yerdən elan olunur. Router-lər paketi ən qısa (ən aşağı metric-li) yola göndərir; bu da Server A-dır. Heç bir "seçim" mexanizmi yoxdur, routing özü seçir.' }, { t: 'Hər üçü eyni vaxtda', why: 'Bu multicast olardı. Anycast-da paket yalnız BİR serverə çatır.' }, { t: 'Təsadüfi biri', why: 'Təsadüfi deyil: routing həmişə ən yaxın yolu seçir. Yalnız yaxınlıq dəyişəndə (məsələn, server sönəndə) hədəf dəyişir.' }] }).el);
      } else {
        T = PT.topo(lanNodes(), [['PC1', 'SW'], ['SW', 'PC2'], ['SW', 'PC3'], ['SW', 'PC4']], { w: 640, h: 310 });
        sendBtn = h('button', { type: 'button', class: 'btn btn-primary btn-sm', onclick: send }, 'Göndər');
        ctrl.append(sendBtn);
        if (mode === 'unicast') {
          predHost.append(PT.predict({ q: 'PC1 → PC3 unicast kadr göndərir. PC3-ün MAC ünvanı switch-in MAC table-ında artıq var. Kadrı <b>hansı PC-lər</b> alacaq?', options: [{ t: 'Yalnız PC3', ok: true, why: 'Switch destination MAC-a baxır, cədvəldə onu PC3-ün portunda tapır və kadrı yalnız həmin portdan göndərir (forward). PC2 və PC4 kadrı heç görmür.' }, { t: 'PC2, PC3 və PC4 (hamısı)', why: 'Hamıya göndərmək flood-dur. Switch yalnız hədəf MAC-i cədvəldə TAPMADIQDA flood edir. Burada tapılıb, ona görə flood yoxdur.' }, { t: 'PC3 və PC2', why: 'Switch bilinən unicast kadrı yalnız bir porta ötürür, "yaxın" portlar anlayışı yoxdur.' }] }).el);
        } else if (mode === 'broadcast') {
          predHost.append(PT.predict({ q: 'PC1 destination MAC <b>FF:FF:FF:FF:FF:FF</b> olan kadr göndərir. Switch bunu necə edəcək?', options: [{ t: 'Gələn port istisna olmaqla bütün portlara göndərəcək (flood)', ok: true, why: 'Switch-in MAC table-ında FF:FF:FF:FF:FF:FF heç vaxt olmur (bu MAC heç bir cihazın source ünvanı ola bilməz), ona görə həmişə flood olunur. Gələn porta geri göndərilmir.' }, { t: 'Yalnız cədvəldə olan cihazlara', why: 'Broadcast ünvanı cədvələ düşmür. Switch qərar vermir, sadəcə bütün portlara yayır.' }, { t: 'Atacaq, çünki cədvəldə yoxdur', why: 'Bilinməyən UNICAST ünvan flood olunur, atılmır. Broadcast isə qəsdən hamıya yayılır.' }] }).el);
        } else {
          if (showSnoop) { snoopCb = h('input', { type: 'checkbox', id: 'cast-snoop' }); snoopCb.addEventListener('change', () => { snoop = snoopCb.checked; T.clearMarks(); });
          ctrl.append(h('label', { for: 'cast-snoop', style: 'display:flex;gap:6px;align-items:center' }, snoopCb, 'Switch-də IGMP snooping aktivdir')); }
          if (!showSnoop) predHost.append(PT.predict({ q: 'Group <b>239.1.1.1</b>-ə yalnız PC2 və PC4 qoşulub. PC1 bu group-a multicast frame göndərir. Frame-i <b>kimlər</b> qəbul edəcək?', options: [{ t: 'Yalnız group-a üzv olan PC2 və PC4', ok: true, why: 'Multicast frame yalnız group-a qoşulmuş cihazlara çatdırılır. PC3 üzv deyil, onun üçün frame emal olunmur.' }, { t: 'Network-dəki bütün cihazlar (PC2, PC3, PC4)', why: 'Bu broadcast olardı. Multicast-ın məqsədi məhz hamıya yox, yalnız üzvlərə çatdırmaqdır.' }, { t: 'Yalnız PC2', why: 'PC4 də group-a qoşulub, ona görə o da qəbul edir. Group-a qoşulmuş bütün cihazlar frame alır.' }] }).el);
          else predHost.append(PT.predict({ q: 'Group <b>239.1.1.1</b>-ə yalnız PC2 və PC4 qoşulub. IGMP snooping <b>söndürülüb</b> (sadə switch). Kadr hansı <b>portlara</b> göndəriləcək?', options: [{ t: 'Bütün portlara (flood), amma PC3-ün NIC-i onu atacaq', ok: true, why: 'Sadə switch multicast MAC-i (01:00:5E...) öyrənə bilmir, çünki heç kim bu ünvanı source kimi istifadə etmir; ona görə unknown kimi flood edir. PC3-ün NIC-i isə kadrın destination MAC-nin ona aid olmadığını görüb aparat səviyyəsində atır.' }, { t: 'Yalnız PC2 və PC4 portlarına', why: 'Bunu yalnız IGMP snooping aktiv olanda edə bilər: switch IGMP mesajlarını dinləyib qrup üzvlərini öyrənir. Sadə switch bunu bilmir.' }, { t: 'Heç bir porta', why: 'Multicast kadrlar atılmır; bilinməyən kimi flood olunur.' }] }).el);
        }
      }
      stageHost.append(T.svg); drawInsp(null);
    }
    function dstFor() {
      if (mode === 'unicast') return { mac: MACS.PC3, ip: IPS.PC3, note: 'Destination MAC = PC3-ün MAC-i, Destination IP = PC3-ün IP-si' };
      if (mode === 'broadcast') return { mac: 'ff:ff:ff:ff:ff:ff', ip: '255.255.255.255', note: 'Destination MAC hamısı 1. IP tərəfdə 255.255.255.255 (limited broadcast) və ya 192.168.1.255 (bu network-ün broadcast-ı) ola bilər.' };
      if (mode === 'multicast') return { mac: '01:00:5e:01:01:01', ip: '239.1.1.1', note: 'Group IP 239.1.1.1 → MAC: 01:00:5E + IP-nin son 23 biti (01.01.01)' };
      return { mac: '(router-in MAC-i)', ip: '203.0.113.53', note: 'Eyni IP bir neçə serverdədir. MAC isə yalnız ilk hop-a (router-ə) aiddir.' };
    }
    function drawInsp(d) {
      insp.innerHTML = ''; const x = d || dstFor();
      insp.append(PT.fieldsTable('Göndərilən paketdə (nümunə)', [['Source MAC', MACS.PC1], ['Destination MAC', x.mac], ['Source IP', IPS.PC1], ['Destination IP', x.ip]]), h('p', { class: 'fine' }, x.note));
    }
    async function send() {
      if (busy) return; busy = true; sendBtn.disabled = true; T.clearMarks(); ['PC1', 'PC2', 'PC3', 'PC4', 'C', 'S1', 'S2', 'S3'].forEach(i => { if (T.nodeEls[i]) T.badge(i, ''); });
      if (mode === 'anycast') {
        const alive = failCb.checked ? ['S2', 'S3'] : ['S1', 'S2', 'S3']; const dst = alive[0];
        await T.move('C', 'R'); T.lit('C', 'R'); await T.move('R', dst); T.lit('R', dst, 'var(--ok)'); T.mark(dst, 'fill-ok'); T.badge(dst, 'cavab verir', 'fill-ok');
        ['S1', 'S2', 'S3'].filter(s => s !== dst).forEach(s => { if (failCb.checked && s === 'S1') T.badge(s, 'söndü', 'fill-bad'); else T.badge(s, 'görmür'); });
        log.innerHTML = '<b>Nəticə:</b> paket yalnız <b>' + T.byId[dst].label + '</b> serverinə çatdı (' + T.byId[dst].sub.split('\n')[1] + ' məsafədə). Hamısında eyni IP olduğu üçün Client fərq görmür; routing ən yaxını seçdi.';
        drawInsp(); busy = false; sendBtn.disabled = false; T.hideDot(); return;
      }
      await T.move('PC1', 'SW'); T.lit('PC1', 'SW');
      let recv = [], dropped = [], none = [];
      if (mode === 'unicast') { recv = ['PC3']; none = ['PC2', 'PC4']; }
      else if (mode === 'broadcast') { recv = ['PC2', 'PC3', 'PC4']; }
      else if (snoop) { recv = ['PC2', 'PC4']; none = ['PC3']; } else { recv = ['PC2', 'PC4']; dropped = ['PC3']; }
      const outs = recv.concat(dropped);
      for (const id of outs) { await T.move('SW', id); T.lit('SW', id, dropped.includes(id) ? 'var(--warn)' : 'var(--ok)'); }
      recv.forEach(id => { T.mark(id, 'fill-ok'); T.badge(id, mode === 'broadcast' ? 'qəbul etdi' : (mode === 'multicast' ? 'üzvdür: qəbul' : 'qəbul etdi'), 'fill-ok'); });
      dropped.forEach(id => { T.mark(id, 'fill-bad'); T.badge(id, 'NIC atdı', 'fill-bad'); });
      none.forEach(id => T.badge(id, 'görmədi'));
      const msgs = { unicast: '<b>Unicast:</b> switch hədəf MAC-i cədvəldə tapdı və yalnız PC3-ə göndərdi. Digərləri kadrı görmədi.', broadcast: '<b>Broadcast:</b> switch kadrı gələn port istisna olmaqla bütün portlara flood etdi. Hər üç PC kadrı qəbul etdi və yuxarı layer-ə ötürdü. Broadcast domain: bu bütün cihazlar bir-birinin broadcast-ını alır.', multicast: snoop ? '<b>Multicast + IGMP snooping:</b> switch IGMP mesajlarından qrup üzvlərini (PC2, PC4) öyrənib kadrı yalnız onların portlarına göndərdi. PC3 heç nə almadı.' : '<b>Multicast, snooping yoxdur:</b> switch kadrı flood etdi. PC2 və PC4 qrupa üzv olduğu üçün qəbul etdi; PC3-ün NIC-i kadrı gördü, amma destination MAC onun siyahısında olmadığı üçün aparat səviyyəsində atdı (CPU-ya çatmadı). Yəni kadr PC3-ə çatdı, amma işlənmədi.' };
      log.innerHTML = msgs[mode]; drawInsp(); T.hideDot(); busy = false; sendBtn.disabled = false;
    }
    body.append(tabs, predHost, ctrl, stageHost, log, insp); init();
  };
})();
