/* ptui (annotated Packet Tracer window), pingttl, anat (command anatomy), climodes */
(function () {
  const PT = window.PT; const h = PT.h;

  /* ====================== Packet Tracer interface ====================== */
  const REG = {
    menu: { n: 'Menu Bar', area: 'menu', d: 'File, Edit, Options, View, Tools, Extensions, Window, Help menyuları. Layihəni saxlamaq (File → Save), açmaq və tənzimləmələr (Options → Preferences) buradadır.', use: 'Layihəni .pkt faylı kimi saxla. Preferences-də məsələn "Show Device Name Labels" kimi görünüş seçimləri var.' },
    tool: { n: 'Main Tool Bar', area: 'tool', d: 'Ən çox işlənən fəaliyyətlər üçün qısa düymələr: New, Open, Save, Print, Copy, Paste, Undo, Redo, Zoom.', use: 'Tez Save etmək, Undo ilə səhvi geri qaytarmaq.' },
    work: { n: 'Logical Workspace', area: 'work', d: 'Əsas iş sahəsi. Cihazları buraya qoyur, kabellərlə birləşdirir və topologiyanı qurursan. Yuxarıdakı Logical / Physical nişanları iki görünüş arasında keçid edir.', use: 'Topologiyanın qurulması. Cihaza klik edəndə onun konfiqurasiya pəncərəsi (Physical, Config, CLI, Desktop) açılır.' },
    common: { n: 'Common Tools Bar', area: 'common', d: 'Sağdakı alətlər: Select, Move Layout, Place Note, Delete, Inspect, Resize Shape, Add Simple PDU (zərf ikonu), Add Complex PDU.', use: 'Delete ilə cihaz/kabel silmək; Add Simple PDU ilə iki cihaz arasında bir test paketi göndərmək; Inspect ilə cihazın cədvəllərinə (ARP table, MAC table, routing table) baxmaq.' },
    rts: { n: 'Realtime / Simulation Bar', area: 'rts', d: 'İki rejim: Realtime (şəbəkə real vaxtda işləyir, ping dərhal nəticə verir) və Simulation (paketlərin hər addımını görürsən, dayandırıb baxa bilərsən).', use: 'Paketin yolunu addım-addım izləmək üçün Simulation rejiminə keç. Rejimi dəyişəndə simulyasiya yenidən başlayır.' },
    types: { n: 'Device-Type Selection Box', area: 'types', d: 'Sol altda cihaz kateqoriyaları: Network Devices (router, switch...), End Devices (PC, server...), Components, Connections (kabellər), Miscellaneous, Multiuser. Kateqoriyanı seçəndikdə yanındakı qutu dəyişir.', use: 'Switch əlavə etmək üçün əvvəl Network Devices → Switches seç.' },
    devs: { n: 'Device-Specific Selection Box', area: 'devs', d: 'Seçdiyin kateqoriyaya aid konkret modellər (məsələn 2911 router, 2960 switch, PC, Server). Modeli workspace-ə sürüklə.', use: 'Konkret model seç: məsələn Switches → 2960. Connections-da kabel növləri olur (Copper Straight-Through, Console...).' },
    pdu: { n: 'User Created Packet Window', area: 'pdu', d: 'Sağ altda: Add Simple PDU ilə göndərdiyin test paketlərinin siyahısı, hər birinin vəziyyəti (Successful / Failed) və ssenari idarəsi.', use: 'Ping-in uğurlu olub-olmadığına bu pəncərədən də baxa bilərsən (Last Status sütunu).' },
  };
  const TASKS = [
    { q: 'Layihəni fayl kimi saxlamaq istəyirsən. Hansı hissədən başlayırsan?', a: 'menu', why: 'Save əmri File menyusundadır (Menu Bar). Main Tool Bar-dakı disket ikonu da eyni işi görür, amma menyu əsas yoldur.' },
    { q: 'Switch əlavə etmək istəyirsən. Əvvəl hansı qutuda kateqoriya seçirsən?', a: 'types', why: 'Əvvəl Device-Type Selection Box-da Network Devices → Switches seçilir, sonra Device-Specific qutuda model götürülür.' },
    { q: 'Paketin hər addımını ayrıca görmək istəyirsən. Hansı hissədə rejimi dəyişirsən?', a: 'rts', why: 'Realtime/Simulation Bar-da Simulation nişanına keçirsən. Realtime-da paket dərhal çatır, görməyə vaxt qalmır.' },
    { q: 'Cihazı və ya kabeli silmək istəyirsən. Alət hansı bardadır?', a: 'common', why: 'Delete aləti sağdakı Common Tools Bar-dadır (X ikonu). Əvvəl onu seç, sonra silinəcək obyektə klik et.' },
    { q: 'Hazırda topologiyanın qurulduğu əsas sahə hansıdır?', a: 'work', why: 'Cihazlar və kabellər Logical Workspace-də qurulur.' },
    { q: 'Add Simple PDU ilə göndərdiyin paketin Successful/Failed nəticəsinə harada baxırsan?', a: 'pdu', why: 'User Created Packet Window hər test paketinin sonuncu vəziyyətini (Last Status) göstərir.' },
  ];
  PT.sims.ptui = function (el, o) {
    const body = PT.simFrame(el, 'Packet Tracer pəncərəsi (sxematik)', 'Hissənin üstünə klik et. Aşağıda tapşırıqlar var.');
    const win = h('div', { class: 'ptwin' });
    const mk = (k, cls, text) => { const r = REG[k]; const b = h('button', { type: 'button', class: 'ptreg ' + cls, 'data-reg': k, 'aria-label': r.n }, text === undefined ? r.n : text); b.addEventListener('click', () => select(k)); return b; };
    const work = mk('work', 'r-work', null); work.append(h('div', { class: 'ptw-tabs' }, h('span', null, 'Logical'), h('span', null, 'Physical')), h('div', { class: 'ptw-canvas' }, h('span', { class: 'ptw-dev' }, 'PC'), h('span', { class: 'ptw-line' }), h('span', { class: 'ptw-dev sw' }, 'SW')), h('div', { class: 'ptw-lbl' }, 'Logical Workspace'));
    win.append(mk('menu', 'r-menu', 'Menu Bar:  File  Edit  Options  View  Tools  Extensions  Window  Help'), mk('tool', 'r-tool', 'Main Tool Bar'), h('div', { class: 'ptw-mid' }, work, mk('common', 'r-common', 'Common Tools Bar\nSelect · Move · Note · Delete · Inspect · Resize · Simple PDU')),
      h('div', { class: 'ptw-bot' }, mk('types', 'r-types', 'Device-Type\nSelection Box'), mk('devs', 'r-devs', 'Device-Specific\nSelection Box'), h('div', { class: 'ptw-right' }, mk('rts', 'r-rts', 'Realtime | Simulation'), mk('pdu', 'r-pdu', 'User Created\nPacket Window'))));
    const info = h('div', { class: 'sim-log' }, 'Bir hissəyə klik et.'); const task = h('div'); let cur = null, tIdx = 0;
    function select(k) {
      win.querySelectorAll('.ptreg').forEach(x => x.classList.toggle('is-on', x.dataset.reg === k));
      const r = REG[k]; info.innerHTML = '<b>' + r.n + '</b><br>' + r.d + '<br><b>Nə üçün lazımdır:</b> ' + r.use;
      if (cur && !cur.done) { if (k === cur.t.a) { cur.done = true; cur.msg.innerHTML = '<b style="color:var(--ok)">Düzdür.</b> ' + cur.t.why; } else cur.msg.innerHTML = '<b style="color:var(--bad)">Bu "' + r.n + '" hissəsidir, axtarılan deyil.</b> Başqa hissəni yoxla.'; }
    }
    function newTask() {
      const t = TASKS[tIdx % TASKS.length]; tIdx++; const msg = h('div', { class: 'fine', role: 'status', style: 'margin-top:6px' }); cur = { t, done: false, msg };
      task.innerHTML = ''; task.append(h('div', { class: 'predict' }, h('h4', null, 'Tapşırıq ' + tIdx), h('div', null, t.q + ' (sxemdə düzgün hissəyə klik et)'), msg, h('button', { type: 'button', class: 'btn btn-sm', style: 'margin-top:8px', onclick: newTask }, 'Növbəti tapşırıq')));
    }
    body.append(win, info, task, h('p', { class: 'fine' }, 'Bu sxematik şəkildir. Düymələrin dəqiq görünüşü və adları Packet Tracer versiyasına görə bir qədər fərqlənə bilər: öz versiyanda yoxla.')); newTask();
  };

  /* ====================== ping / TTL / traceroute ====================== */
  PT.sims.pingttl = function (el, o) {
    const body = PT.simFrame(el, 'TTL: paket haradan keçir, harada ölür?', 'TTL seç, göndər. Sonra tracert rejimini sına.');
    const nodes = [{ id: 'PC', label: 'PC', x: 50, y: 120, kind: 'pc', sub: '192.168.1.10' }, { id: 'R1', label: 'R1', x: 200, y: 120, kind: 'router', sub: '192.168.1.1' }, { id: 'R2', label: 'R2', x: 350, y: 120, kind: 'router', sub: '10.0.12.2' }, { id: 'R3', label: 'R3', x: 500, y: 120, kind: 'router', sub: '10.0.23.3' }, { id: 'SRV', label: 'Server', x: 640, y: 120, kind: 'server', sub: '172.16.0.10' }];
    const T = PT.topo(nodes, [['PC', 'R1'], ['R1', 'R2'], ['R2', 'R3'], ['R3', 'SRV']], { w: 700, h: 210 });
    const stage = h('div', { class: 'sim-stage' }, T.svg); const log = h('div', { class: 'sim-log' }); const out = h('div'); const predHost = h('div');
    const ttl = h('input', { type: 'range', min: 1, max: 6, value: 3, 'aria-label': 'TTL' }); const ttlOut = h('b', { style: 'font-family:var(--font-mono)' }, '3');
    ttl.addEventListener('input', () => { ttlOut.textContent = ttl.value; });
    const chain = ['PC', 'R1', 'R2', 'R3', 'SRV']; const ips = { R1: '192.168.1.1', R2: '10.0.12.2', R3: '10.0.23.3', SRV: '172.16.0.10' };
    let busy = false;
    async function sendOne(t, quiet) {
      T.clearMarks(); chain.forEach(c => T.badge(c, ''));
      let cur = t; T.badge('PC', 'TTL=' + cur, 'fill-yel');
      for (let k = 1; k < chain.length; k++) {
        if (!quiet) await T.move(chain[k - 1], chain[k], 380); else T.lit(chain[k - 1], chain[k]);
        if (chain[k] === 'SRV') { if (!quiet) { T.lit(chain[k - 1], 'SRV', 'var(--ok)'); T.mark('SRV', 'fill-ok'); T.badge('SRV', 'TTL=' + cur, 'fill-ok'); } return { reached: true, at: 'SRV', ttl: cur }; }
        cur -= 1;
        if (cur <= 0) { if (!quiet) { T.mark(chain[k], 'fill-bad'); T.badge(chain[k], 'TTL=0: atdı', 'fill-bad'); } return { reached: false, at: chain[k], ttl: 0 }; }
        if (!quiet) T.badge(chain[k], 'TTL=' + cur, 'fill-yel');
      }
    }
    const send = h('button', { type: 'button', class: 'btn btn-primary btn-sm' }, 'Göndər'); const tr = h('button', { type: 'button', class: 'btn btn-sm' }, 'tracert rejimi (TTL 1, 2, 3 ...)');
    send.addEventListener('click', async () => {
      if (busy) return; busy = true; send.disabled = tr.disabled = true; out.innerHTML = '';
      const t = +ttl.value; const r = await sendOne(t);
      if (r.reached) log.innerHTML = '<b>Paket serverə çatdı</b> (qalan TTL = ' + r.ttl + '). Server cavab göndərir: <span class="m">Reply from 172.16.0.10: bytes=32 time=1ms TTL=' + (128 - 3) + '</span>.';
      else log.innerHTML = '<b>Paket ' + T.byId[r.at].label + ' router-də öldü.</b> Router TTL-i 1 azaltdı, nəticə 0 oldu və paketi atdı. Sonra ' + ips[r.at] + ' ünvanından PC-yə ICMP <b>Time Exceeded</b> mesajı göndərdi. PC ekranında: <span class="m">Reply from ' + ips[r.at] + ': TTL expired in transit.</span>';
      T.hideDot(); busy = false; send.disabled = tr.disabled = false;
    });
    tr.addEventListener('click', async () => {
      if (busy) return; busy = true; send.disabled = tr.disabled = true; out.innerHTML = ''; log.textContent = 'tracert hər dəfə TTL-i 1 artırır: 1, 2, 3 ... Hər atan router özünü bildirir.';
      const t = h('table', { class: 'tbl' }); t.append(h('tr', null, h('th', null, 'Hop'), h('th', null, 'Göndərilən TTL'), h('th', null, 'Kim cavab verdi'), h('th', null, 'Niyə'))); out.append(h('div', { class: 'tbl-wrap' }, t));
      for (let n = 1; n <= 5; n++) {
        const r = await sendOne(n, false); const who = r.at; t.append(h('tr', null, h('td', null, String(n)), h('td', { class: 'm' }, String(n)), h('td', { class: 'm' }, ips[who]), h('td', null, r.reached ? 'Hədəfə çatdı: echo reply' : 'TTL 0 oldu: Time Exceeded')));
        if (r.reached) break;
      }
      log.innerHTML = '<b>tracert belə işləyir:</b> yeni bir şey göndərmir, sadəcə TTL-i 1-dən başlayıb artırır. TTL=1 olan paket ilk router-də ölür və o, öz ünvanını göndərir; TTL=2 olan paket ikinci router-də ölür və s. Beləliklə paketin keçdiyi router-lərin siyahısı alınır.';
      T.hideDot(); busy = false; send.disabled = tr.disabled = false;
    });
    predHost.append(PT.predict({ q: 'PC-dən <b>TTL = 3</b> olan paket göndərilir. Yolda 3 router var (R1, R2, R3), sonra server. Paket <b>harada</b> atılacaq?', options: [{ t: 'R3-də', ok: true, why: 'TTL 3: R1 onu 2-yə endirir, R2 1-ə endirir, R3 isə 0-a endirir və atır. Paketin serverə çatması üçün TTL ən azı 4 olmalıdır (üç router 3 azaldır, 1 qalır).' }, { t: 'R1-də', why: 'R1 TTL-i 3-dən 2-yə endirir, bu hələ sıfır deyil, paket ötürülür. Paket yalnız TTL 0 olanda atılır.' }, { t: 'Serverə çatır', why: 'Serverə çatması üçün TTL router sayından (3) böyük olmalıdır. TTL 3 olanda sonuncu router (R3) onu 0 edir.' }, { t: 'R2-də', why: 'R2 TTL-i 2-dən 1-ə endirir; hələ sıfır deyil. Sıfıra ancaq R3 endirir.' }] }).el);
    body.append(predHost, h('div', { class: 'sim-ctrl' }, h('label', null, 'TTL:'), ttl, ttlOut, send, tr), stage, log, out);
  };

  /* ====================== command anatomy ====================== */
  PT.sims.anat = function (el, o) {
    const body = PT.simFrame(el, o.title || 'Əmrin anatomiyası', 'Hissənin üstünə klik et.');
    const row = h('div', { class: 'anat-row' }); const info = h('div', { class: 'sim-log' }, 'Əmrin bir hissəsinə klik et: nə etdiyini görəcəksən.');
    const col = { kw: 'is-kw', arg: 'is-arg', no: 'is-no', mode: 'is-mode' }; const kindName = { kw: 'keyword (əmrin sabit sözü)', arg: 'argument (sən yazdığın dəyər)', no: 'no (əmri ləğv edir)', mode: 'prompt' };
    (o.parts || []).forEach((p, i) => { const b = h('button', { type: 'button', class: 'anat-tok ' + col[p.k] }, h('span', { class: 'anat-t' }, p.t), h('span', { class: 'anat-k' }, p.k === 'kw' ? 'keyword' : (p.k === 'arg' ? 'argument' : p.k))); b.addEventListener('click', () => { row.querySelectorAll('.anat-tok').forEach(x => x.classList.remove('sel')); b.classList.add('sel'); info.innerHTML = '<b>' + p.t + '</b> — ' + kindName[p.k] + '<br>' + p.d; }); row.append(b); });
    const meta = h('div', { class: 'res-grid' });
    [['Hansı rejimdə yazılır', o.mode], ['Nə dəyişir', o.effect], ['Yoxlama əmri (proof)', o.proof], ['Geri qaytarmaq', o.undo]].forEach(r => { if (r[1]) meta.append(h('div', { class: 'res' }, h('small', null, r[0]), h('b', { style: 'font-family:var(--font-ui);font-weight:600;word-break:normal' }, r[1]))); });
    body.append(row, info, meta);
  };

  /* ====================== CLI modes ====================== */
  const MODES = [
    { id: 'user', n: 'User EXEC', p: 'Switch>', d: 'Giriş rejimi. Yalnız baxmaq və sadə yoxlamalar: ping, bəzi show əmrləri. Konfiqurasiyanı görə və dəyişə bilməzsən.', go: 'enable', back: '(çıxış: exit)' },
    { id: 'priv', n: 'Privileged EXEC', p: 'Switch#', d: 'Tam baxış rejimi: show running-config, copy, reload, erase burada işləyir. Konfiqurasiya etmək üçün keçid məntəqəsidir.', go: 'configure terminal', back: 'disable' },
    { id: 'config', n: 'Global configuration', p: 'Switch(config)#', d: 'Cihazın ümumi ayarları burada dəyişir: hostname, və başqa rejimlərə keçid üçün (interface ... ) əmrləri.', go: 'interface fa0/1', back: 'exit və ya end (Ctrl+Z)' },
    { id: 'if', n: 'Interface configuration', p: 'Switch(config-if)#', d: 'Seçilmiş bir interface-in ayarları: description, shutdown / no shutdown, ip address (router-də).', go: '', back: 'exit (config-ə), end (priv-ə)' },
  ];
  PT.sims.climodes = function (el, o) {
    const body = PT.simFrame(el, 'IOS rejimləri', 'Rejimə klik et. Sonra prompt-a baxıb rejimi tap.');
    const chain = h('div', { class: 'modes' }); const info = h('div', { class: 'sim-log' }, 'Rejimə klik et.'); const quiz = h('div');
    MODES.forEach((m, i) => {
      const b = h('button', { type: 'button', class: 'mode-card', 'data-mode': m.id }, h('b', null, m.n), h('span', { class: 'm' }, m.p));
      b.addEventListener('click', () => { chain.querySelectorAll('.mode-card').forEach(x => x.classList.toggle('is-on', x === b)); info.innerHTML = '<b>' + m.n + '</b> — prompt: <span class="m">' + m.p + '</span><br>' + m.d + (m.go ? '<br><b>Növbəti rejimə:</b> <span class="m">' + m.go + '</span>' : '') + '<br><b>Geri:</b> <span class="m">' + m.back + '</span>'; });
      chain.append(b); if (i < MODES.length - 1) chain.append(h('div', { class: 'mode-arrow' }, h('span', { class: 'm' }, MODES[i].go), h('span', { class: 'fine' }, ' ↓    ' + MODES[i + 1].back.split(' ')[0] + ' ↑')));
    });
    const P = [['Router#', 'priv'], ['SW1(config)#', 'config'], ['Core-SW(config-if)#', 'if'], ['Switch>', 'user'], ['R1>', 'user'], ['HQ-Router(config)#', 'config'], ['Access1#', 'priv'], ['SW2(config-if)#', 'if']];
    let n = 0;
    function newQ() {
      const [pr, id] = P[n % P.length]; n++; quiz.innerHTML = '';
      const msg = h('div', { class: 'fine', role: 'status', style: 'margin-top:6px' });
      const box = h('div', { class: 'predict' }, h('h4', null, 'Hansı rejimdəsən?'), h('div', null, 'Terminalda bu prompt görünür: ', h('b', { class: 'm' }, pr)));
      const opts = h('div', { class: 'opts' }); let done = false;
      MODES.forEach(m => { const c = h('button', { type: 'button', class: 'chip' }, m.n); c.addEventListener('click', () => { if (done) return; if (m.id === id) { done = true; c.classList.add('is-ok'); msg.innerHTML = '<b>Düzdür.</b> Hostname-dən sonra: <span class="m">&gt;</span> = User EXEC, <span class="m">#</span> = Privileged EXEC, <span class="m">(config)#</span> = Global config, <span class="m">(config-if)#</span> = Interface config. Hostname (Router, SW1...) rejimi göstərmir, yalnız cihazın adıdır.'; } else { c.classList.add('is-bad'); msg.innerHTML = '<b>Düz deyil.</b> Prompt-un hostname-dən sonrakı hissəsinə (&gt;, #, (config)#, (config-if)#) bax.'; } }); opts.append(c); });
      box.append(opts, msg, h('button', { type: 'button', class: 'btn btn-sm', style: 'margin-top:8px', onclick: newQ }, 'Başqa prompt')); quiz.append(box);
    }
    body.append(chain, info, quiz); newQ();
  };
})();
