(function () {
  const PT = window.PT; const h = PT.h; const t = (k, p) => PT.t(k, p);

  /* ---------- theme ---------- */
  PT.theme = {
    init() {
      let v = PT.store.get('theme', null);
      if (!v) v = (window.matchMedia && matchMedia('(prefers-color-scheme: dark)').matches) ? 'dark' : 'light';
      this.set(v, false);
    },
    set(v, save = true) { document.documentElement.setAttribute('data-theme', v); if (save) PT.store.set('theme', v); },
    toggle() { this.set(document.documentElement.getAttribute('data-theme') === 'dark' ? 'light' : 'dark'); },
    current: () => document.documentElement.getAttribute('data-theme'),
  };

  /* ---------- toast ---------- */
  let toastEl = null, toastT = 0;
  PT.toast = function (msg, ms = 3200) {
    if (toastEl) toastEl.remove(); clearTimeout(toastT);
    toastEl = h('div', { class: 'toast', role: 'status' }, msg); document.body.append(toastEl);
    toastT = setTimeout(() => { if (toastEl) toastEl.remove(); toastEl = null; }, ms);
  };

  /* ---------- dialog ---------- */
  PT.dialog = function (title, bodyNode) {
    const dlg = h('dialog', { class: 'dlg', 'aria-label': title });
    const close = h('button', { class: 'btn btn-sm btn-quiet', type: 'button', onclick: () => dlg.close() }, t('close'));
    dlg.append(h('div', { class: 'dlg-head' }, h('h2', null, title), close), h('div', { class: 'dlg-body' }, bodyNode));
    dlg.addEventListener('close', () => dlg.remove());
    dlg.addEventListener('click', e => { if (e.target === dlg) dlg.close(); });
    document.body.append(dlg);
    if (dlg.showModal) dlg.showModal(); else dlg.setAttribute('open', '');
    return dlg;
  };

  /* ---------- glossary tooltip ---------- */
  let tipEl = null;
  function showTip(target) {
    hideTip();
    const g = PT.gloss().find(x => x.t === target.dataset.term); if (!g) return;
    tipEl = h('div', { class: 'tip', role: 'tooltip' }, h('b', null, g.t), g.d);
    document.body.append(tipEl);
    const r = target.getBoundingClientRect(); const tr = tipEl.getBoundingClientRect();
    let x = Math.min(window.innerWidth - tr.width - 10, Math.max(10, r.left)); let y = r.bottom + 8;
    if (y + tr.height > window.innerHeight - 8) y = Math.max(8, r.top - tr.height - 8);
    tipEl.style.left = x + 'px'; tipEl.style.top = y + 'px';
  }
  function hideTip() { if (tipEl) { tipEl.remove(); tipEl = null; } }
  document.addEventListener('mouseover', e => { const el = e.target.closest && e.target.closest('.gl'); if (el) showTip(el); });
  document.addEventListener('mouseout', e => { if (e.target.closest && e.target.closest('.gl')) hideTip(); });
  document.addEventListener('focusin', e => { const el = e.target.closest && e.target.closest('.gl'); if (el) showTip(el); });
  document.addEventListener('focusout', hideTip);
  document.addEventListener('click', e => {
    const el = e.target.closest && e.target.closest('.gl');
    if (el) { if (tipEl && tipEl.dataset.for === el.dataset.term) hideTip(); else { showTip(el); if (tipEl) tipEl.dataset.for = el.dataset.term; } } else hideTip();
  });
  window.addEventListener('scroll', hideTip, { passive: true });

  // wraps the FIRST occurrence of each glossary term inside root (not in code, pre, links, buttons, headings)
  PT.glossify = function (root) {
    const terms = PT.gloss().slice().sort((a, b) => Math.max(...b.k.map(x => x.length)) - Math.max(...a.k.map(x => x.length)));
    if (!terms.length) return;
    const done = new Set();
    const skip = 'CODE,PRE,A,BUTTON,SUMMARY,H1,H2,H3,H4,H5,TEXTAREA,INPUT,SELECT,SVG,SCRIPT,STYLE,.GL,DFN,KBD,TH'.split(',');
    const skipNode = n => { for (let p = n.parentNode; p && p !== root; p = p.parentNode) { if (p.nodeType === 1 && (skip.includes(p.tagName.toUpperCase()) || p.classList.contains('gl') || p.classList.contains('no-gl') || p.hasAttribute('data-sim') || (typeof p.className === 'string' && /(^|\s)(m|where|cmd-table|cmd-line|term[\w-]*|state[\w-]*|goals|pre)(\s|$)/.test(p.className)))) return true; } return false; };
    for (const g of terms) {
      if (done.has(g.t)) continue;
      const alts = g.k.map(k => k.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')).join('|');
      const re = new RegExp('(^|[^\\p{L}\\p{N}_])(' + alts + ')(?![\\p{L}\\p{N}_]|\\.\\d)', 'iu');
      const walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT);
      let node;
      while ((node = walker.nextNode())) {
        if (!node.nodeValue.trim() || skipNode(node)) continue;
        const m = re.exec(node.nodeValue); if (!m) continue;
        const start = m.index + m[1].length; const word = m[2];
        const after = node.splitText(start); const rest = after.splitText(word.length);
        const span = h('span', { class: 'gl', tabindex: '0', dataset: { term: g.t } }, word);
        after.replaceWith(span); done.add(g.t); void rest; break;
      }
    }
  };

  /* ---------- copy buttons ---------- */
  PT.cmdLine = function (text) {
    const b = h('button', { type: 'button', 'aria-label': t('copyCmdAria') }, t('copy'));
    b.addEventListener('click', async () => { const ok = await PT.copy(text); b.textContent = ok ? t('copied') : t('copyFail'); setTimeout(() => b.textContent = t('copy'), 1400); });
    return h('div', { class: 'cmd-line' }, h('code', null, text), b);
  };

  /* ---------- search ---------- */
  function textOf(id) {
    const d = PT.T(id); if (!d) return '';
    return PT.stripTags((d.explain || '') + ' ' + (d.cheat || ''));
  }
  PT.openSearch = function () {
    const input = h('input', { type: 'search', placeholder: t('searchPh'), 'aria-label': t('search') });
    const res = h('ul', { class: 'srch-res' });
    const body = h('div', null, input, res);
    const dlg = PT.dialog(t('searchTitle'), body);
    const items = [];
    for (const p of PT.outline.parts) for (const tp of p.topics) items.push({ id: tp.id, title: PT.title(tp), part: p, text: textOf(tp.id) });
    function run() {
      const q = input.value.trim().toLowerCase(); res.innerHTML = '';
      if (q.length < 2) return;
      const out = [];
      for (const it of items) {
        let score = 0; const tl = it.title.toLowerCase();
        if (tl.includes(q)) score += 10;
        const idx = it.text.toLowerCase().indexOf(q); if (idx >= 0) score += 3;
        if (score) out.push({ it, score, idx });
      }
      for (const g of PT.gloss()) {
        if (g.t.toLowerCase().includes(q) || g.k.some(k => k.toLowerCase().includes(q))) out.push({ g, score: 6 });
      }
      out.sort((a, b) => b.score - a.score);
      if (!out.length) { res.append(h('li', { class: 'fine', style: 'padding:10px 6px' }, t('nothing'))); return; }
      for (const o of out.slice(0, 14)) {
        if (o.g) { res.append(h('li', null, h('button', { type: 'button', onclick: () => { dlg.close(); PT.openGlossary(o.g.t); } }, h('span', { class: 'st' }, o.g.t), h('span', { class: 'sn' }, o.g.d)))); continue; }
        const snip = o.idx >= 0 ? '…' + o.it.text.slice(Math.max(0, o.idx - 40), o.idx + 90) + '…' : t('part', { n: o.it.part.n }) + ': ' + PT.title(o.it.part);
        res.append(h('li', null, h('button', { type: 'button', onclick: () => { dlg.close(); PT.go('/' + o.it.part.id + '/' + o.it.id + '/explain'); } }, h('span', { class: 'st' }, o.it.title), h('span', { class: 'sn' }, snip))));
      }
    }
    input.addEventListener('input', run); setTimeout(() => input.focus(), 50);
  };

  PT.openGlossary = function (focusTerm) {
    const dl = h('dl', { class: 'gl-list' });
    for (const g of PT.gloss().slice().sort((a, b) => a.t.localeCompare(b.t))) {
      dl.append(h('dt', { id: 'gl-' + g.t.replace(/\W+/g, '_') }, g.t), h('dd', null, g.d));
    }
    const dlg = PT.dialog(t('glossary'), dl);
    if (focusTerm) { const el = dlg.querySelector('#gl-' + focusTerm.replace(/\W+/g, '_')); if (el) el.scrollIntoView({ block: 'center' }); }
  };

  /* ---------- export / import progress (a backup you can carry to another computer) ---------- */
  PT.openProgress = function () {
    const ta = h('textarea', { readonly: '', 'aria-label': t('progCodeAria') }); ta.value = PT.progress.exportText();
    const imp = h('textarea', { placeholder: t('progPaste'), 'aria-label': t('progPasteAria') });
    const msg = h('p', { class: 'fine', role: 'status' });
    const body = h('div', null,
      h('p', null, t('progInfo')),
      h('h3', { style: 'font-size:16px;margin:14px 0 6px' }, t('getCode')), ta,
      h('div', { class: 'sim-ctrl' },
        h('button', { class: 'btn btn-sm', type: 'button', onclick: async () => { const ok = await PT.copy(ta.value); msg.textContent = ok ? t('codeCopied') : t('codeCopyFail'); } }, t('copy'))),
      h('h3', { style: 'font-size:16px;margin:18px 0 6px' }, t('loadCode')), imp,
      h('div', { class: 'sim-ctrl' },
        h('button', { class: 'btn btn-sm btn-primary', type: 'button', onclick: () => { try { PT.progress.importText(imp.value); msg.textContent = t('loaded'); setTimeout(() => PT.render(), 400); } catch (e) { msg.textContent = e.message; } } }, t('load')),
        h('button', { class: 'btn btn-sm btn-quiet', type: 'button', onclick: () => { if (confirm(t('confirmReset'))) { PT.progress.reset(); PT.render(); msg.textContent = t('resetDone'); } } }, t('resetAll'))),
      msg);
    PT.dialog(t('progTitle'), body);
  };
})();
