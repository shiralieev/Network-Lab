/* Shared helpers for simulators: frame, predict box, addressing math, topology drawing. */
(function () {
  const PT = window.PT; const h = PT.h; const S = PT.s;

  PT.fast = false;       // tests set this to skip animations
  PT.reduced = () => PT.fast || (window.matchMedia && matchMedia('(prefers-reduced-motion: reduce)').matches);

  /* ---------- frame ---------- */
  PT.simFrame = function (el, title, hint) {
    el.classList.add('sim'); el.innerHTML = '';
    const body = h('div', { class: 'sim-body' });
    el.append(h('div', { class: 'sim-head' }, h('span', { class: 'sim-title' }, title), hint ? h('span', { class: 'sim-hint' }, hint) : null), body);
    return body;
  };

  /* ---------- predict box: returns {el, reset()} ---------- */
  PT.predict = function (o) {
    const box = h('div', { class: 'predict' });
    box.append(h('h4', null, o.title || PT.t('tryFirst')), h('div', { html: o.q }));
    const opts = h('div', { class: 'opts' }); const fb = h('div', { class: 'fine', style: 'margin-top:8px', role: 'status' });
    let done = false;
    const order = PT.shuffle(o.options.map((op, i) => i));   // options are shown in random order
    const chips = order.map((i) => {
      const op = o.options[i];
      const c = h('button', { type: 'button', class: 'chip' }, op.t);
      c.addEventListener('click', () => {
        if (done) return; done = true;
        chips.forEach((x, j) => { x.disabled = true; if (o.options[order[j]].ok) x.classList.add('is-ok'); else if (order[j] === i) x.classList.add('is-bad'); });
        fb.innerHTML = '<b>' + (op.ok ? PT.t('right') + ' ' : PT.t('formWrong') + '. ') + '</b>' + (op.why || o.why || '');
        if (o.onAnswer) o.onAnswer(!!op.ok, i);
      });
      return c;
    });
    chips.forEach(c => opts.append(c)); box.append(opts, fb);
    return { el: box, reset() { done = false; fb.innerHTML = ''; chips.forEach(c => { c.disabled = false; c.className = 'chip'; }); } };
  };

  /* ---------- addressing math ---------- */
  const A = PT.addr = {};
  A.isIp = s => /^\d{1,3}(\.\d{1,3}){3}$/.test(String(s).trim()) && String(s).trim().split('.').every(x => +x <= 255);
  A.toN = s => s.trim().split('.').reduce((a, x) => a * 256 + (+x), 0) >>> 0;
  A.toS = n => [n >>> 24, (n >>> 16) & 255, (n >>> 8) & 255, n & 255].join('.');
  A.maskN = p => p === 0 ? 0 : ((0xFFFFFFFF << (32 - p)) >>> 0);
  A.maskS = p => A.toS(A.maskN(p));
  A.bits = n => { const a = []; for (let i = 31; i >= 0; i--) a.push((n >>> i) & 1); return a; };
  A.fromBits = b => b.reduce((a, x) => ((a << 1) | x) >>> 0, 0) >>> 0;
  A.prefixOf = m => A.toN(m).toString(2).replace(/0/g, '').length;
  A.net = (ip, p) => (A.toN(ip) & A.maskN(p)) >>> 0;
  A.bcast = (ip, p) => (A.net(ip, p) | (~A.maskN(p) >>> 0)) >>> 0;
  A.info = function (ip, p) {
    const n = A.net(ip, p), b = A.bcast(ip, p); const total = Math.pow(2, 32 - p);
    return { net: A.toS(n), bc: A.toS(b), first: p >= 31 ? '—' : A.toS(n + 1), last: p >= 31 ? '—' : A.toS(b - 1), hosts: p >= 31 ? (p === 31 ? 2 : 1) : total - 2, mask: A.maskS(p), total };
  };
  A.macParse = s => { const x = String(s).replace(/[^0-9a-fA-F]/g, ''); return x.length === 12 ? x.toLowerCase().match(/../g) : null; };
  A.macFmt = (o, style) => style === 'cisco' ? [o.slice(0, 2).join(''), o.slice(2, 4).join(''), o.slice(4, 6).join('')].join('.') : o.join(style === 'win' ? '-' : ':');
  A.hex = (n, w) => n.toString(16).padStart(w || 2, '0');

  /* ---------- topology drawing ---------- */
  // nodes: [{id, label, x, y, kind, sub}], links: [[a,b]]
  PT.topo = function (nodes, links, o) {
    o = Object.assign({ w: 640, h: 300 }, o);
    const svg = S('svg', { viewBox: '0 0 ' + o.w + ' ' + o.h, role: 'img', 'aria-label': o.label || 'Topologiya' });
    const byId = {}; nodes.forEach(n => { byId[n.id] = n; });
    const g = S('g'); svg.append(g);
    links.forEach(([a, b]) => { const A_ = byId[a], B_ = byId[b]; const ln = S('line', { x1: A_.x, y1: A_.y, x2: B_.x, y2: B_.y, class: 'ln', 'data-link': a + '-' + b }); g.append(ln); });
    const nodeEls = {};
    nodes.forEach(n => {
      const gr = S('g', { 'data-node': n.id, transform: 'translate(' + n.x + ',' + n.y + ')' });
      const kind = n.kind || 'pc';
      if (kind === 'pc') { gr.append(S('rect', { x: -24, y: -20, width: 48, height: 32, rx: 3, class: 'box-s dev' }), S('rect', { x: -17, y: -14, width: 34, height: 20, rx: 1, fill: 'var(--panel)', stroke: 'var(--ink-3)', 'stroke-width': 1 }), S('rect', { x: -10, y: 12, width: 20, height: 5, class: 'box-s' })); }
      else if (kind === 'switch') { gr.append(S('rect', { x: -38, y: -13, width: 76, height: 26, rx: 3, class: 'fill-blue dev' })); for (let i = 0; i < 6; i++) gr.append(S('rect', { x: -30 + i * 11, y: -4, width: 7, height: 8, rx: 1, fill: 'var(--panel)', stroke: 'var(--btn)', 'stroke-width': 1 })); }
      else if (kind === 'router') { gr.append(S('circle', { r: 22, class: 'fill-yel dev' }), S('path', { d: 'M-12 0H12M-12 0l5-4M-12 0l5 4M12 0l-5-4M12 0l-5 4M0 -12V12M0 -12l-4 5M0 -12l4 5M0 12l-4 -5M0 12l4 -5', stroke: 'var(--ink)', 'stroke-width': 1.6, fill: 'none' })); }
      else if (kind === 'server') { for (let i = 0; i < 3; i++) gr.append(S('rect', { x: -22, y: -22 + i * 15, width: 44, height: 12, rx: 2, class: 'box-s dev' }), S('circle', { cx: 14, cy: -16 + i * 15, r: 2, fill: 'var(--ok)' })); }
      gr.append(S('text', { x: 0, y: kind === 'router' ? 40 : 34, 'text-anchor': 'middle', 'font-size': 14, 'font-weight': 700 }, n.label));
      if (n.sub) n.sub.split('\n').forEach((t, i) => gr.append(S('text', { x: 0, y: (kind === 'router' ? 54 : 48) + i * 13, 'text-anchor': 'middle', 'font-size': 11, class: 't-m t-dim' }, t)));
      g.append(gr); nodeEls[n.id] = gr;
    });
    const dot = S('circle', { r: 7, fill: 'var(--yel)', stroke: 'var(--ink)', 'stroke-width': 1.5, cx: -50, cy: -50, opacity: 0 }); svg.append(dot);
    const api = {
      svg, nodeEls, byId,
      mark(id, cls) { const e = nodeEls[id]; if (!e) return; const d = e.querySelector('.dev'); if (!d) return; d.classList.remove('fill-ok', 'fill-bad', 'fill-yel2'); if (cls) d.classList.add(cls); },
      clearMarks() { nodes.forEach(n => { const d = nodeEls[n.id].querySelector('.dev'); if (d) d.classList.remove('fill-ok', 'fill-bad'); }); svg.querySelectorAll('line.ln').forEach(l => { l.style.stroke = ''; l.style.strokeWidth = ''; }); },
      lit(a, b, color) { const l = svg.querySelector('[data-link="' + a + '-' + b + '"],[data-link="' + b + '-' + a + '"]'); if (l) { l.style.stroke = color || 'var(--btn)'; l.style.strokeWidth = 4; } },
      badge(id, text, cls) { const e = nodeEls[id]; const old = e.querySelector('.bdg'); if (old) old.remove(); if (!text) return; const t = S('g', { class: 'bdg' }, S('rect', { x: -30, y: -46, width: 60, height: 18, rx: 3, class: cls || 'fill-yel' }), S('text', { x: 0, y: -33, 'text-anchor': 'middle', 'font-size': 11, 'font-weight': 700 }, text)); e.append(t); },
      async move(a, b, ms) {
        const A_ = byId[a], B_ = byId[b]; dot.setAttribute('opacity', 1);
        if (PT.reduced()) { dot.setAttribute('cx', B_.x); dot.setAttribute('cy', B_.y); return; }
        const t0 = performance.now(); ms = ms || 520;
        await new Promise(res => { const step = t => { const k = Math.min(1, (t - t0) / ms); dot.setAttribute('cx', A_.x + (B_.x - A_.x) * k); dot.setAttribute('cy', A_.y + (B_.y - A_.y) * k); if (k < 1) requestAnimationFrame(step); else res(); }; requestAnimationFrame(step); });
      },
      hideDot() { dot.setAttribute('opacity', 0); },
    };
    return api;
  };

  /* key-value table for a packet inspector */
  PT.fieldsTable = function (title, rows) {
    const t = h('table', { class: 'tbl' }); if (title) t.append(h('tr', null, h('th', { colspan: 2 }, title)));
    rows.forEach(r => t.append(h('tr', null, h('td', { class: 'm', style: 'white-space:nowrap' }, r[0]), h('td', { class: 'm', style: 'font-weight:600' }, r[1]))));
    return h('div', { class: 'tbl-wrap', style: 'margin:0' }, t);
  };
})();
