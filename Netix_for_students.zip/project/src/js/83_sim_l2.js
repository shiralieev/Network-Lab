/* ARP step simulator and switch learn/flood/forward/filter simulator */
(function () {
  const PT = window.PT; const h = PT.h;
  const M = { PC1: '00:01:43:21:aa:aa', PC2: '00:01:43:21:bb:bb', PC3: '00:01:43:21:cc:cc', R1: '00:01:43:21:dd:dd' };

  /* ====================== ARP ====================== */
  PT.sims.arpsim = function (el, o) {
    const body = PT.simFrame(el, 'ARP addım-addım', 'Hər addımda nə baş verdiyini oxu və təxminləri cavabla.');
    let scn = 'same', i = 0, blocked = false, busy = false;
    const tabs = h('div', { class: 'fields' }); const stageHost = h('div', { class: 'sim-stage' }); const log = h('div', { class: 'sim-log' }); const nav = h('div', { class: 'sim-ctrl' });
    const predHost = h('div'); const caches = h('div', { class: 'res-grid' }); const swT = h('div'); const insp = h('div');
    const names = { same: 'Eyni network: ping 192.168.1.20', other: 'Başqa network: ping 10.0.0.5' };
    Object.keys(names).forEach(k => { const b = h('button', { type: 'button', class: 'chip' + (k === scn ? ' is-on' : '') }, names[k]); b.addEventListener('click', () => { scn = k; Array.from(tabs.children).forEach((c, j) => c.classList.toggle('is-on', Object.keys(names)[j] === k)); i = 0; render(true); }); tabs.append(b); });
    const T = PT.topo([{ id: 'PC1', label: 'PC1', x: 70, y: 150, kind: 'pc', sub: '192.168.1.10\n…aa:aa' }, { id: 'SW', label: 'Switch', x: 300, y: 150, kind: 'switch' }, { id: 'PC2', label: 'PC2', x: 540, y: 50, kind: 'pc', sub: '192.168.1.20\n…bb:bb' }, { id: 'PC3', label: 'PC3', x: 540, y: 150, kind: 'pc', sub: '192.168.1.30\n…cc:cc' }, { id: 'R1', label: 'R1 (gateway)', x: 540, y: 250, kind: 'router', sub: '192.168.1.1\n…dd:dd' }], [['PC1', 'SW'], ['SW', 'PC2'], ['SW', 'PC3'], ['SW', 'R1']], { w: 640, h: 330 });
    stageHost.append(T.svg);
    const eth = (dst, src, type) => [['Destination MAC', dst], ['Source MAC', src], ['EtherType', type]];
    const arpF = (op, sm, si, tm, ti) => [['ARP opcode', op], ['Sender MAC', sm], ['Sender IP', si], ['Target MAC', tm], ['Target IP', ti]];
    const SAME = [
      { t: '<b>1. Qərar.</b> PC1 <b>192.168.1.20</b>-yə ping atmaq istəyir. Əvvəl öz mask-ı ilə yoxlayır: 192.168.1.10 AND 255.255.255.0 = 192.168.1.0, hədəf də 192.168.1.0. <b>Eyni network</b>, yəni paketi router olmadan, birbaşa PC2-yə göndərəcək. IP paketi hazırdır, amma Ethernet kadrı üçün <b>PC2-nin MAC-i</b> lazımdır.', c: {}, sw: [] },
      { t: '<b>2. ARP cache.</b> PC1 öz ARP cache-ində 192.168.1.20 axtarır: <b>giriş yoxdur</b> (cache miss). MAC-i bilmədən kadr qura bilməz, ona görə əvvəl ARP request göndərəcək. Ping paketi bu müddətdə gözləyir.', c: {}, sw: [] },
      { t: '<b>3. ARP request yaradılır.</b> PC1 "192.168.1.20 kimdir? MAC-ini mənə de" sualını yazır. Cavab verənin MAC-ini bilmir, ona görə Ethernet <b>destination MAC = FF:FF:FF:FF:FF:FF (broadcast)</b> olur. Target MAC sahəsi isə bilinmədiyi üçün 00:00:00:00:00:00-dır.', from: ['PC1', 'SW'], c: {}, sw: [], f: ['ARP request kadrı', eth('ff:ff:ff:ff:ff:ff', M.PC1, '0x0806 (ARP)').concat(arpF('1 (request)', M.PC1, '192.168.1.10', '00:00:00:00:00:00', '192.168.1.20'))],
        pred: { q: 'Bu ARP request kadrında <b>Destination MAC</b> nə olmalıdır?', options: [{ t: 'FF:FF:FF:FF:FF:FF (broadcast)', ok: true, why: 'PC1 cavab verənin MAC-ini bilmir, ona görə bütün network-ə yayır. Hamı alır, amma yalnız target IP-si öz IP-si olan cavab verir.' }, { t: 'PC2-nin MAC-i', why: 'Bunu PC1 bilsəydi ARP-a ehtiyac olmazdı. ARP-ın məqsədi məhz bu MAC-i tapmaqdır.' }, { t: '00:00:00:00:00:00', why: 'Bu, ARP-ın içindəki Target MAC sahəsidir (bilinmir). Ethernet başlığında isə broadcast MAC yazılır, çünki switch kadrı hamıya yaymalıdır.' }] } },
      { t: '<b>4. Switch flood edir.</b> Switch əvvəl <b>source MAC-i öyrənir</b>: aa:aa Fa0/1 portundadır. Sonra destination broadcast olduğu üçün kadrı gələn port istisna olmaqla <b>bütün portlara</b> yayır (flood): Fa0/2 (PC2), Fa0/3 (PC3), Fa0/4 (R1).', tos: ['PC2', 'PC3', 'R1'], c: {}, sw: [[M.PC1, 'Fa0/1']] },
      { t: '<b>5. Kim cavab verir?</b> Üçü də kadrı alır və ARP-ın <b>Target IP</b> sahəsinə baxır. PC3 və R1: "192.168.1.20 mənim IP-m deyil" → kadrı atır. <b>PC2</b>: "bu mənəm" → cavab hazırlayır. Eyni zamanda PC2 sorğudakı Sender IP/MAC-dən PC1-i öz ARP cache-inə yazır (çünki tezliklə ona cavab göndərməlidir).', c: { PC2: [['192.168.1.10', M.PC1]] }, sw: [[M.PC1, 'Fa0/1']], marks: { PC2: 'ok', PC3: 'bad', R1: 'bad' } },
      { t: '<b>6. ARP reply.</b> Artıq PC2 PC1-in MAC-ini bilir, ona görə cavab <b>unicast</b>-dır: destination MAC = PC1-in MAC-i. Cavabda PC2 öz MAC-ini deyir: "192.168.1.20 mənəm, MAC-im bb:bb". Switch bb:bb-ni Fa0/2-də öyrənir və kadrı cədvəldə tapdığı Fa0/1 portuna <b>yalnız oraya</b> ötürür.', from: ['PC2', 'SW'], then: ['SW', 'PC1'], c: { PC2: [['192.168.1.10', M.PC1]] }, sw: [[M.PC1, 'Fa0/1'], [M.PC2, 'Fa0/2']], f: ['ARP reply kadrı', eth(M.PC1, M.PC2, '0x0806 (ARP)').concat(arpF('2 (reply)', M.PC2, '192.168.1.20', M.PC1, '192.168.1.10'))] },
      { t: '<b>7. Cache yenilənir.</b> PC1 cavabı alıb ARP cache-inə yazır: <b>192.168.1.20 → bb:bb</b>. İndi Ethernet kadrı üçün lazım olan MAC məlumdur. Gözləyən ICMP echo request nəhayət göndərilir: destination MAC = PC2-nin MAC-i, destination IP = 192.168.1.20.', from: ['PC1', 'SW'], then: ['SW', 'PC2'], c: { PC1: [['192.168.1.20', M.PC2]], PC2: [['192.168.1.10', M.PC1]] }, sw: [[M.PC1, 'Fa0/1'], [M.PC2, 'Fa0/2']], f: ['ICMP echo request kadrı', eth(M.PC2, M.PC1, '0x0800 (IPv4)').concat([['Source IP', '192.168.1.10'], ['Destination IP', '192.168.1.20'], ['Protocol', '1 (ICMP), type 8']])], flash: 'PC1' },
      { t: '<b>8. Nəticə.</b> PC2 echo reply göndərir (artıq PC1-in MAC-ini bilir, ARP lazım deyil). Növbəti ping-lər ARP-ı <b>təkrarlamır</b>: PC1 cache-dən istifadə edir (giriş bir müddət sonra silinir). Packet Tracer-də ilk ping-in tez-tez bir "Request timed out" ilə başlamasının səbəbi də budur: ilk paket ARP gözləyərkən itə bilir.', from: ['PC2', 'SW'], then: ['SW', 'PC1'], c: { PC1: [['192.168.1.20', M.PC2]], PC2: [['192.168.1.10', M.PC1]] }, sw: [[M.PC1, 'Fa0/1'], [M.PC2, 'Fa0/2']], f: ['ICMP echo reply kadrı', eth(M.PC1, M.PC2, '0x0800 (IPv4)').concat([['Source IP', '192.168.1.20'], ['Destination IP', '192.168.1.10'], ['Protocol', '1 (ICMP), type 0']])] },
    ];
    const OTHER = [
      { t: '<b>1. Qərar.</b> PC1 <b>10.0.0.5</b>-ə ping atır. 192.168.1.10 AND 255.255.255.0 = 192.168.1.0, hədəf isə 10.0.0.0 şəbəkəsindədir. <b>Fərqli network</b>, deməli PC1 paketi birbaşa göndərə bilməz və onu <b>default gateway-ə</b> (192.168.1.1) verməlidir.', c: {}, sw: [] },
      { t: '<b>2. Hansı MAC lazımdır?</b> Burada çox vacib məqam: kadrın destination MAC-i 10.0.0.5-in MAC-i <b>olmayacaq</b> (o başqa network-dədir, PC1 onun MAC-ini heç vaxt öyrənə bilməz). MAC ünvanı yalnız bir link üçün keçərlidir; bu link-də növbəti cihaz <b>gateway-dir</b>. PC1 ARP cache-də <b>192.168.1.1</b> axtarır: giriş yoxdur.', c: {}, sw: [],
        pred: { q: 'PC1 ARP ilə kimin MAC-ini soruşacaq?', options: [{ t: 'Gateway-in (192.168.1.1)', ok: true, why: 'Kadr gateway-ə gedir, ona görə gateway-in MAC-i lazımdır. Hədəf IP (10.0.0.5) paketin içində qalır, MAC isə növbəti hop-a aiddir.' }, { t: '10.0.0.5-in', why: 'ARP yalnız eyni broadcast domain-də işləyir; 10.0.0.5 başqa network-dədir və PC1-in ARP sorğusu router-dən keçmir.' }, { t: 'Switch-in', why: 'Switch kadrı sadəcə ötürür, trafikin ünvanı deyil; PC onun MAC-ini soruşmur.' }] } },
      { t: '<b>3. ARP request.</b> PC1 broadcast ARP göndərir: "<b>192.168.1.1</b> kimdir?" (hədəf IP-nin yox, gateway-in IP-si soruşulur).', from: ['PC1', 'SW'], c: {}, sw: [], f: ['ARP request kadrı', eth('ff:ff:ff:ff:ff:ff', M.PC1, '0x0806 (ARP)').concat(arpF('1 (request)', M.PC1, '192.168.1.10', '00:00:00:00:00:00', '192.168.1.1'))] },
      { t: '<b>4. Flood.</b> Switch aa:aa-nı Fa0/1-də öyrənir və broadcast-ı bütün digər portlara göndərir. PC2 və PC3 "192.168.1.1 mənim deyil" deyib atır.', tos: ['PC2', 'PC3', 'R1'], c: {}, sw: [[M.PC1, 'Fa0/1']], marks: { PC2: 'bad', PC3: 'bad', R1: 'ok' } },
      { t: '<b>5. R1 cavab verir.</b> R1 unicast ARP reply göndərir: "192.168.1.1 mənəm, MAC-im dd:dd". PC1 cache-inə yazır: <b>192.168.1.1 → dd:dd</b>.', from: ['R1', 'SW'], then: ['SW', 'PC1'], c: { PC1: [['192.168.1.1', M.R1]] }, sw: [[M.PC1, 'Fa0/1'], [M.R1, 'Fa0/4']], f: ['ARP reply kadrı', eth(M.PC1, M.R1, '0x0806 (ARP)').concat(arpF('2 (reply)', M.R1, '192.168.1.1', M.PC1, '192.168.1.10'))], flash: 'PC1' },
      { t: '<b>6. İki fərqli ünvan bir kadrda.</b> İndi ICMP echo göndərilir. Kadrın <b>destination MAC-i = R1-in MAC-i</b> (növbəti hop), amma paketin <b>destination IP-si = 10.0.0.5</b> (son hədəf). MAC ünvanı "növbəti hop kimdir?", IP ünvanı isə "sonda kim?" sualının cavabıdır.', from: ['PC1', 'SW'], then: ['SW', 'R1'], c: { PC1: [['192.168.1.1', M.R1]] }, sw: [[M.PC1, 'Fa0/1'], [M.R1, 'Fa0/4']], f: ['ICMP echo request kadrı', eth(M.R1, M.PC1, '0x0800 (IPv4)').concat([['Source IP', '192.168.1.10'], ['Destination IP', '10.0.0.5'], ['Protocol', '1 (ICMP), type 8']])], marks: { R1: 'ok' } },
      { t: '<b>7. Sonra nə olur?</b> R1 kadrı alır, Ethernet başlığını silir, IP başlığındakı 10.0.0.5-ə baxıb routing table-dan çıxış interface-ini seçir və <b>yeni Ethernet başlığı</b> ilə (yeni MAC-lər) göndərir. Bu hissəni (Part 2) ətraflı görəcəksən. Qayda: <b>IP ünvanları son-a-son dəyişmir, MAC ünvanları hər link-də dəyişir.</b>', c: { PC1: [['192.168.1.1', M.R1]] }, sw: [[M.PC1, 'Fa0/1'], [M.R1, 'Fa0/4']] },
    ];
    const prev = h('button', { type: 'button', class: 'btn btn-sm', onclick: () => { if (i > 0) { i--; render(false); } } }, 'Geri');
    const next = h('button', { type: 'button', class: 'btn btn-sm btn-primary', onclick: () => { const S = scn === 'same' ? SAME : OTHER; if (i < S.length - 1) { i++; render(true); } } }, 'Növbəti addım');
    nav.append(prev, next);
    async function render(animate) {
      const S = scn === 'same' ? SAME : OTHER; const st = S[i]; T.clearMarks(); ['PC1', 'PC2', 'PC3', 'R1'].forEach(id => T.badge(id, ''));
      log.innerHTML = '<span class="fine">Addım ' + (i + 1) + ' / ' + S.length + '</span><br>' + st.t;
      insp.innerHTML = ''; if (st.f) insp.append(PT.fieldsTable(st.f[0], st.f[1]));
      // caches
      caches.innerHTML = '';
      ['PC1', 'PC2'].forEach(id => { const rows = (st.c && st.c[id]) || []; const t = h('table', { class: 'tbl' }); t.append(h('tr', null, h('th', { colspan: 2 }, id + ' — ARP cache'))); if (!rows.length) t.append(h('tr', null, h('td', { colspan: 2, class: 'fine' }, 'boşdur'))); rows.forEach(r => { const tr = h('tr', null, h('td', { class: 'm' }, r[0]), h('td', { class: 'm' }, r[1].slice(-5))); if (st.flash === id) tr.style.background = 'var(--yel-soft)'; t.append(tr); }); caches.append(h('div', { class: 'tbl-wrap', style: 'margin:0' }, t)); });
      const stt = h('table', { class: 'tbl' }); stt.append(h('tr', null, h('th', { colspan: 2 }, 'Switch — MAC address table'))); if (!st.sw.length) stt.append(h('tr', null, h('td', { colspan: 2, class: 'fine' }, 'boşdur'))); st.sw.forEach(r => stt.append(h('tr', null, h('td', { class: 'm' }, r[0].slice(-5)), h('td', { class: 'm' }, r[1])))); caches.append(h('div', { class: 'tbl-wrap', style: 'margin:0' }, stt));
      // predict
      predHost.innerHTML = ''; blocked = false;
      if (st.pred && animate) { blocked = true; const pb = PT.predict({ q: st.pred.q, options: st.pred.options, onAnswer: () => { blocked = false; sync(); } }); predHost.append(pb.el); }
      sync();
      if (animate && !busy) { busy = true; const mv = []; if (st.from) mv.push(st.from); if (st.then) mv.push(st.then); if (st.tos) st.tos.forEach(t => mv.push(['SW', t]));
        for (const [a, b] of mv) { await T.move(a, b, 450); T.lit(a, b); } T.hideDot(); busy = false; }
      if (st.marks) Object.keys(st.marks).forEach(id => { T.mark(id, st.marks[id] === 'ok' ? 'fill-ok' : 'fill-bad'); T.badge(id, st.marks[id] === 'ok' ? 'cavab verir' : 'atır', st.marks[id] === 'ok' ? 'fill-ok' : 'fill-bad'); });
    }
    function sync() { const S = scn === 'same' ? SAME : OTHER; prev.disabled = i === 0; next.disabled = blocked || i === S.length - 1; }
    body.append(tabs, nav, predHost, stageHost, log, insp, h('div', { style: 'margin-top:12px' }, caches)); render(true);
  };

  /* ====================== switch learn / flood / forward / filter ====================== */
  PT.sims.switchsim = function (el, o) {
    const body = PT.simFrame(el, 'Switch necə qərar verir?', 'Göndərən və hədəf seç. Switch-in qərarını əvvəl təxmin et.');
    const MAC = { A: '00:01:43:21:aa:aa', B: '00:01:43:21:bb:bb', C: '00:01:43:21:cc:cc', D: '00:01:43:21:dd:dd', X: '00:01:43:21:ee:ee' };
    let hub = false, table = [], busy = false, score = [0, 0], flashMac = null;
    const portOf = p => ({ A: 'Fa0/1', B: 'Fa0/2', C: 'Fa0/3', D: hub ? 'Fa0/3' : 'Fa0/4' }[p]);
    const srcSel = h('select', { 'aria-label': 'Göndərən' }); ['A', 'B', 'C', 'D'].forEach(x => srcSel.append(h('option', { value: x }, 'PC-' + x)));
    const dstSel = h('select', { 'aria-label': 'Hədəf' }); [['A', 'PC-A'], ['B', 'PC-B'], ['C', 'PC-C'], ['D', 'PC-D'], ['X', 'Bilinməyən MAC (şəbəkədə yoxdur)'], ['BC', 'Broadcast (FF:FF:FF:FF:FF:FF)']].forEach(x => dstSel.append(h('option', { value: x[0] }, x[1]))); dstSel.value = 'B';
    const hubCb = h('input', { type: 'checkbox', id: 'sw-hub' }); hubCb.addEventListener('change', () => { hub = hubCb.checked; table = []; buildTopo(); renderTable(); log.textContent = hub ? 'PC-C və PC-D indi bir hub-ın arxasındadır və switch-in eyni portuna (Fa0/3) qoşulub.' : 'Hub götürüldü: hər PC öz portundadır.'; });
    const sendBtn = h('button', { type: 'button', class: 'btn btn-primary btn-sm' }, 'Göndər'); const agBtn = h('button', { type: 'button', class: 'btn btn-sm', onclick: () => { table = []; renderTable(); log.textContent = 'Aging: entry-lər müəyyən müddət (default 300 saniyə) istifadə olunmayanda silinir. Cədvəl təmizləndi, switch hər şeyi yenidən öyrənəcək.'; } }, '300 saniyə keçdi (aging)'); const rst = h('button', { type: 'button', class: 'btn btn-sm btn-quiet', onclick: () => { table = []; score = [0, 0]; scoreEl.textContent = ''; renderTable(); log.textContent = 'Sıfırlandı.'; T.clearMarks(); } }, 'Hamısını sıfırla');
    const scoreEl = h('span', { class: 'fine', role: 'status' });
    const ctrl = h('div', { class: 'sim-ctrl' }, h('label', null, 'Kimdən:'), srcSel, h('label', null, 'Kimə:'), dstSel, sendBtn, agBtn, rst);
    const ctrl2 = h('div', { class: 'sim-ctrl' }, h('label', { for: 'sw-hub', style: 'display:flex;gap:6px;align-items:center' }, hubCb, 'PC-C və PC-D bir hub-ın arxasında olsun (eyni port)'), scoreEl);
    const stage = h('div', { class: 'sim-stage' }); const log = h('div', { class: 'sim-log' }); const tableHost = h('div'); const insp = h('div'); const predHost = h('div'); let T;
    function buildTopo() {
      const nodes = [{ id: 'SW', label: 'Switch', x: 310, y: 150, kind: 'switch' }, { id: 'A', label: 'PC-A', x: 80, y: 50, kind: 'pc', sub: 'Fa0/1' }, { id: 'B', label: 'PC-B', x: 80, y: 250, kind: 'pc', sub: 'Fa0/2' }];
      const links = [['SW', 'A'], ['SW', 'B']];
      if (hub) { nodes.push({ id: 'HUB', label: 'Hub', x: 470, y: 150, kind: 'switch', sub: 'Fa0/3-ə qoşulub' }, { id: 'C', label: 'PC-C', x: 570, y: 60, kind: 'pc' }, { id: 'D', label: 'PC-D', x: 570, y: 245, kind: 'pc' }); links.push(['SW', 'HUB'], ['HUB', 'C'], ['HUB', 'D']); }
      else { nodes.push({ id: 'C', label: 'PC-C', x: 540, y: 80, kind: 'pc', sub: 'Fa0/3' }, { id: 'D', label: 'PC-D', x: 540, y: 230, kind: 'pc', sub: 'Fa0/4' }); links.push(['SW', 'C'], ['SW', 'D']); }
      T = PT.topo(nodes, links, { w: 660, h: 320 }); stage.innerHTML = ''; stage.append(T.svg);
    }
    function renderTable() {
      const t = h('table', { class: 'tbl' }); t.append(h('tr', null, h('th', { colspan: 3 }, 'MAC address table (switch-in yaddaşı)'))); t.append(h('tr', null, h('th', null, 'Vlan'), h('th', null, 'MAC'), h('th', null, 'Port')));
      if (!table.length) t.append(h('tr', null, h('td', { colspan: 3, class: 'fine' }, 'boşdur: switch hələ heç kimi tanımır')));
      table.forEach(e => { const tr = h('tr', null, h('td', { class: 'm' }, '1'), h('td', { class: 'm' }, e.mac), h('td', { class: 'm' }, e.port)); if (e.mac === flashMac) tr.style.background = 'var(--yel-soft)'; t.append(tr); });
      tableHost.innerHTML = ''; tableHost.append(h('div', { class: 'tbl-wrap', style: 'margin:0' }, t));
    }
    // compute the decision (pure) -> {learn, decision, outs, steps}
    function decide(src, dst) {
      const inPort = portOf(src); const srcMac = MAC[src]; const steps = [];
      const ex = table.find(e => e.mac === srcMac); let learn;
      if (!ex) { learn = 'new'; } else if (ex.port !== inPort) { learn = 'moved'; } else learn = 'refresh';
      steps.push('Kadr <b>' + inPort + '</b> portundan gəldi. Switch əvvəl <b>source MAC-ə</b> baxır: ' + srcMac.slice(-5) + (learn === 'new' ? ' cədvəldə yoxdur → <b>öyrənir</b> (learn): bu MAC ' + inPort + ' portundadır.' : (learn === 'moved' ? ' başqa portda idi → entry yenilənir.' : ' artıq cədvəldədir → yalnız aging sayğacı yenilənir.')));
      const allPorts = hub ? ['A', 'B', 'HUBP'] : ['A', 'B', 'C', 'D'];
      let decision, outs = [];
      if (dst === 'BC') { decision = 'flood'; steps.push('Destination MAC <b>FF:FF:FF:FF:FF:FF</b> (broadcast) heç vaxt cədvəldə olmur → həmişə <b>flood</b>.'); }
      else {
        const dm = MAC[dst]; const d = table.find(e => e.mac === dm) || (learn === 'new' && dm === srcMac ? { port: inPort } : null);
        if (!d) { decision = 'flood'; steps.push('Destination MAC ' + dm.slice(-5) + ' cədvəldə <b>yoxdur</b> (unknown unicast) → hara getdiyini bilmir, ona görə <b>flood</b>: gələn port istisna olmaqla hamıya göndərir.'); }
        else if (d.port === inPort) { decision = 'filter'; steps.push('Destination MAC ' + dm.slice(-5) + ' cədvəldə <b>' + d.port + '</b> portunda göstərilib; kadr da elə bu portdan gəlib → hədəf artıq göndərənlə eyni seqmentdədir (hub-ın arxasında). Kadrı başqa yerə ötürmək lazım deyil → <b>filter</b> (atır).'); }
        else { decision = 'forward'; steps.push('Destination MAC ' + dm.slice(-5) + ' cədvəldə <b>' + d.port + '</b> portunda → kadr <b>yalnız bu porta</b> göndərilir (forward).'); }
      }
      return { inPort, srcMac, learn, decision, steps };
    }
    function topoTargets(src, decision, dst) {
      // which devices get a copy of the frame, and which ones accept it
      const all = ['A', 'B', 'C', 'D'].filter(x => x !== src);
      let seg = []; // devices on the same port as src (behind hub)
      if (hub && (src === 'C' || src === 'D')) seg = [src === 'C' ? 'D' : 'C'];
      let got = [];
      if (decision === 'flood') got = all.filter(x => !(hub && seg.includes(x)) ).concat(seg);
      else if (decision === 'forward') got = [dst].concat(seg);
      else got = seg;
      if (hub) { const behind = ['C', 'D'].filter(x => x !== src); if (got.some(x => x === 'C' || x === 'D')) behind.forEach(x => { if (!got.includes(x)) got.push(x); }); }
      return Array.from(new Set(got));
    }
    async function run(userGuess) {
      if (busy) return; busy = true; sendBtn.disabled = true; T.clearMarks(); ['A', 'B', 'C', 'D'].forEach(x => T.badge(x, ''));
      const src = srcSel.value, dst = dstSel.value;
      if (dst === src) { log.textContent = 'Göndərən və hədəf eyni ola bilməz.'; busy = false; sendBtn.disabled = false; return; }
      const r = decide(src, dst);
      // apply learning
      const ex = table.find(e => e.mac === r.srcMac); if (!ex) table.push({ mac: r.srcMac, port: r.inPort }); else ex.port = r.inPort; flashMac = r.srcMac;
      await T.move(src, hub && (src === 'C' || src === 'D') ? 'HUB' : 'SW', 380); if (hub && (src === 'C' || src === 'D')) { T.lit(src, 'HUB'); await T.move('HUB', 'SW', 380); T.lit('HUB', 'SW'); } else T.lit(src, 'SW');
      renderTable();
      const got = topoTargets(src, r.decision, dst);
      let hubDone = false;
      for (const id of got) {
        if (hub && (id === 'C' || id === 'D')) { if (!(src === 'C' || src === 'D') && !hubDone) { await T.move('SW', 'HUB', 360); T.lit('SW', 'HUB', 'var(--ok)'); hubDone = true; } await T.move('HUB', id, 360); T.lit('HUB', id, 'var(--ok)'); }
        else { await T.move('SW', id, 380); T.lit('SW', id, 'var(--ok)'); }
      }
      const accept = id => dst === 'BC' || (dst !== 'X' && id === dst);
      got.forEach(id => { const ok = accept(id); T.mark(id, ok ? 'fill-ok' : 'fill-bad'); T.badge(id, ok ? 'qəbul etdi' : 'NIC atdı', ok ? 'fill-ok' : 'fill-bad'); });
      const notGot = ['A', 'B', 'C', 'D'].filter(x => x !== src && !got.includes(x)); notGot.forEach(id => T.badge(id, 'görmədi'));
      const names = { flood: 'FLOOD', forward: 'FORWARD', filter: 'FILTER' };
      log.innerHTML = '<b>Qərar: ' + names[r.decision] + '.</b><br>' + r.steps.join('<br>') + (r.decision === 'flood' && dst !== 'BC' ? '<br>Flood edilmiş unicast kadrı hamıya çatır, amma yalnız MAC-i uyğun gələn cihaz (varsa) onu qəbul edir; digərlərinin NIC-i atır.' : '');
      insp.innerHTML = ''; insp.append(PT.fieldsTable('Kadr', [['Source MAC', r.srcMac], ['Destination MAC', dst === 'BC' ? 'ff:ff:ff:ff:ff:ff' : MAC[dst]], ['Gəldiyi port', r.inPort]]));
      T.hideDot(); busy = false; sendBtn.disabled = false;
      if (userGuess) { score[1]++; if (userGuess === r.decision) score[0]++; scoreEl.textContent = 'Təxminlərin: ' + score[0] + ' / ' + score[1] + ' düzgün'; }
    }
    sendBtn.addEventListener('click', () => {
      if (busy) return; const src = srcSel.value, dst = dstSel.value; if (src === dst) { log.textContent = 'Göndərən və hədəf eyni ola bilməz.'; return; }
      const r = decide(src, dst); predHost.innerHTML = '';
      const opts = [['flood', 'Flood (hamıya, gələn port istisna)'], ['forward', 'Forward (yalnız bir porta)'], ['filter', 'Filter (atır, heç yerə göndərmir)']];
      sendBtn.disabled = true;
      const pb = PT.predict({ title: 'Təxmin et: switch nə edəcək?', q: 'Cədvəl hazırda göstərildiyi kimidir. Bu kadr üçün qərar nədir?', options: opts.map(x => ({ t: x[1], ok: x[0] === r.decision, why: r.steps.slice(1).join(' ') })), onAnswer: (ok, idx) => { const g = opts[idx][0]; run(g); sendBtn.disabled = false; } });
      predHost.append(pb.el);
    });
    body.append(ctrl, ctrl2, predHost, stage, log, insp, h('div', { style: 'margin-top:12px' }, tableHost)); buildTopo(); renderTable(); log.textContent = 'Başla: PC-A-dan PC-B-yə kadr göndər, switch-in cədvəlinin necə dolduğuna bax.';
  };
})();
