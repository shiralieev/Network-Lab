/* Addressing simulators: bitgrid, samenet, splitnet, macview */
(function () {
  const PT = window.PT; const h = PT.h; const A = PT.addr;

  /* ---------- bitgrid: IP bits + mask bits + AND ---------- */
  PT.sims.bitgrid = function (el, o) {
    o = Object.assign({ ip: '192.168.1.10', prefix: 24, title: PT.L('Bit grid: IP ünvanı bitlərlə', 'Bit grid: an IP address in bits'), showMask: true, showResult: true, editPrefix: true }, o);
    const body = PT.simFrame(el, o.title, PT.L('Bitin üstünə klik et. Prefix sürüşdürgəcini dəyiş.', 'Click a bit. Move the prefix slider.'));
    let bits = A.bits(A.toN(o.ip)); let prefix = o.prefix;
    const gridHost = h('div'); const resHost = h('div');
    const ipIn = h('input', { type: 'text', value: o.ip, 'aria-label': PT.L('IP ünvanı', 'IP address'), style: 'width:150px;font-family:var(--font-mono)' });
    const pr = h('input', { type: 'range', min: 0, max: 32, value: prefix, 'aria-label': PT.L('Prefix uzunluğu', 'Prefix length') });
    const prOut = h('b', { style: 'font-family:var(--font-mono)' }, '/' + prefix);
    const msg = h('span', { class: 'fine', role: 'status' });

    function oct(row, label, bitsArr, clickable, kind) {
      const wrap = h('div', null, h('div', { class: 'fine', style: 'margin:6px 0 2px;font-weight:600' }, label));
      const bs = h('div', { class: 'bits' });
      for (let k = 0; k < 4; k++) {
        const ob = h('div', { class: 'oct-bits' });
        for (let j = 0; j < 8; j++) {
          const idx = k * 8 + j; const v = bitsArr[idx]; const isNet = idx < prefix;
          const cls = 'bit ' + (kind === 'ip' || kind === 'and' ? (isNet ? 'net' : 'host') : (isNet ? 'net' : 'host'));
          if (clickable) { const b = h('button', { type: 'button', class: cls, 'aria-label': 'Bit ' + (idx + 1) + ': ' + v }, String(v)); b.addEventListener('click', () => { bits[idx] ^= 1; sync(); }); ob.append(b); }
          else ob.append(h('span', { class: cls + ' static', style: 'display:grid;place-items:center' }, String(v)));
        }
        const dec = bitsArr.slice(k * 8, k * 8 + 8).reduce((a, x) => a * 2 + x, 0);
        bs.append(h('div', { class: 'oct' }, ob, h('div', { class: 'oct-dec' }, String(dec))));
      }
      wrap.append(bs); return wrap;
    }
    function weights() { const w = h('div', { class: 'bits', style: 'margin-bottom:0' }); for (let k = 0; k < 4; k++) { const r = h('div', { class: 'oct-wt' }); [128, 64, 32, 16, 8, 4, 2, 1].forEach(x => r.append(h('span', null, String(x)))); w.append(r); } return w; }

    function draw() {
      gridHost.innerHTML = ''; prOut.textContent = '/' + prefix;
      gridHost.append(weights());
      gridHost.append(oct(0, PT.L('IP ünvanı (bitə klik et)', 'IP address (click a bit)'), bits, true, 'ip'));
      if (o.showMask) gridHost.append(oct(1, PT.L('Subnet mask (1 = network hissəsi, 0 = host hissəsi)', 'Subnet mask (1 = network part, 0 = host part)'), A.bits(A.maskN(prefix)), false, 'mask'));
      if (o.showResult) gridHost.append(oct(2, PT.L('Network ünvanı (host bitləri sıfırlanır)', 'IP AND mask = network address (the host bits become 0)'), A.bits(A.net(A.toS(A.fromBits(bits)), prefix)), false, 'and'));
      gridHost.append(h('div', { class: 'bit-legend' }, h('span', null, h('i', { style: 'background:var(--blue-soft);border:1.5px solid var(--btn)' }), PT.L('network bitləri (maskın 1-ləri)', 'network bits (the 1s of the mask)')), h('span', null, h('i', { style: 'background:var(--yel-soft);border:1.5px solid var(--yel)' }), PT.L('host bitləri (maskın 0-ları)', 'host bits (the 0s of the mask)'))));
      const ipS = A.toS(A.fromBits(bits)); ipIn.value = ipS; const i = A.info(ipS, prefix);
      resHost.innerHTML = ''; const rg = h('div', { class: 'res-grid' });
      [['Mask', i.mask + ' (/' + prefix + ')'], ['Network address', i.net], ['Broadcast address', i.bc], [PT.L('İlk host', 'First host'), i.first], [PT.L('Son host', 'Last host'), i.last], [PT.L('İstifadə olunan host sayı', 'Usable hosts'), String(i.hosts)]].forEach(r => rg.append(h('div', { class: 'res' }, h('small', null, r[0]), h('b', null, r[1]))));
      resHost.append(rg);
    }
    function sync() { draw(); }
    ipIn.addEventListener('change', () => { if (A.isIp(ipIn.value)) { bits = A.bits(A.toN(ipIn.value)); msg.textContent = ''; draw(); } else msg.textContent = PT.L('IP ünvanı düzgün deyil (məs. 192.168.1.10).', 'That is not a valid IP address (for example 192.168.1.10).'); });
    pr.addEventListener('input', () => { prefix = +pr.value; draw(); });
    const ctrl = h('div', { class: 'sim-ctrl' }, h('label', { for: 'x' }, 'IP:'), ipIn, o.editPrefix ? h('label', null, 'Prefix:') : null, o.editPrefix ? pr : null, o.editPrefix ? prOut : null, msg);
    body.append(ctrl, gridHost, resHost); draw();
  };

  /* ---------- samenet: same network or not ---------- */
  const SAMENET = [
    { a: '192.168.1.10', b: '192.168.1.200', p: 24, why: 'Maskın 255.255.255.0 olması ilk 3 oktetin network hissəsi olduğunu göstərir. İkisində də 192.168.1 eynidir.' },
    { a: '192.168.1.10', b: '192.168.2.20', p: 24, why: 'Üçüncü oktet fərqlidir (1 və 2). /24 maskada üçüncü oktet də network hissəsidir, deməli network-lər fərqlidir.' },
    { a: '192.168.1.10', b: '192.168.1.200', p: 25, why: 'Bu tələdir: son oktet host hissəsi kimi görünür, amma /25 maskada son oktetin ilk biti də network bitidir. .10 bu bitdə 0-dır, .200 isə 1-dir, ona görə network-lər fərqlidir (…1.0 və …1.128).' },
    { a: '10.0.5.10', b: '10.0.9.20', p: 16, why: '/16 maskada yalnız ilk iki oktet network hissəsidir. İkisində də 10.0 eynidir, üçüncü oktet host hissəsinə aiddir.' },
    { a: '172.16.5.10', b: '172.16.20.20', p: 20, why: '/20 maskada üçüncü oktetin ilk 4 biti network hissəsidir. 5 = 00000101, 20 = 00010100. İlk 4 bit 0000 və 0001 fərqlidir, deməli network-lər fərqlidir (172.16.0.0 və 172.16.16.0).' },
  ];
  PT.sims.samenet = function (el, o) {
    const body = PT.simFrame(el, 'Eyni network-dürmü?', 'Əvvəl təxmin et, sonra bitlərə bax.');
    const pick = h('div', { class: 'fields' }); const stage = h('div');
    let cur = 0;
    SAMENET.forEach((ex, i) => { const b = h('button', { type: 'button', class: 'chip' + (i === 0 ? ' is-on' : '') }, 'Nümunə ' + (i + 1)); b.addEventListener('click', () => { cur = i; Array.from(pick.children).forEach((c, j) => c.classList.toggle('is-on', j === i)); show(); }); pick.append(b); });
    function show() {
      const ex = SAMENET[cur]; stage.innerHTML = '';
      stage.append(h('p', { style: 'margin:0 0 8px' }, 'PC-A: ', h('b', { class: 'm' }, ex.a), '   PC-B: ', h('b', { class: 'm' }, ex.b), '   Mask: ', h('b', { class: 'm' }, A.maskS(ex.p) + ' (/' + ex.p + ')')));
      const out = h('div');
      const same = A.net(ex.a, ex.p) === A.net(ex.b, ex.p);
      const pb2 = PT.predict({
        q: 'PC-A PC-B ilə <b>router olmadan</b> birbaşa danışa bilərmi (eyni network-dədirlər)?', options: [{ t: 'Bəli, eyni network', ok: same, why: ex.why }, { t: 'Xeyr, fərqli network-lər', ok: !same, why: ex.why }],
        onAnswer: () => { out.innerHTML = ''; out.append(reveal(ex)); },
      });
      stage.append(pb2.el, out);
    }
    function reveal(ex) {
      const w = h('div'); const nb = A.bits(A.net(ex.a, ex.p)), na = A.bits(A.net(ex.b, ex.p)); const m = A.bits(A.maskN(ex.p));
      const row = (label, bits) => h('div', null, h('div', { class: 'fine', style: 'font-weight:600;margin-top:6px' }, label), (() => { const bs = h('div', { class: 'bits' }); for (let k = 0; k < 4; k++) { const ob = h('div', { class: 'oct-bits' }); for (let j = 0; j < 8; j++) ob.append(h('span', { class: 'bit static ' + (k * 8 + j < ex.p ? 'net' : 'host'), style: 'display:grid;place-items:center' }, String(bits[k * 8 + j]))); bs.append(h('div', { class: 'oct' }, ob, h('div', { class: 'oct-dec' }, String(bits.slice(k * 8, k * 8 + 8).reduce((a, x) => a * 2 + x, 0))))); } return bs; })());
      w.append(row('PC-A: network hissəsi (host bitləri 0)', A.bits(A.net(ex.a, ex.p))), row('PC-B: network hissəsi (host bitləri 0)', A.bits(A.net(ex.b, ex.p))));
      const same = A.net(ex.a, ex.p) === A.net(ex.b, ex.p);
      w.append(h('div', { class: 'sim-log' }, h('b', null, 'PC-A network: ' + A.toS(A.net(ex.a, ex.p)) + '/' + ex.p + '   PC-B network: ' + A.toS(A.net(ex.b, ex.p)) + '/' + ex.p), h('br'),
        same ? 'Network ünvanları eynidir. PC-A paketi birbaşa PC-B-yə göndərir (əvvəl ARP ilə PC-B-nin MAC ünvanını tapır).' : 'Network ünvanları fərqlidir. PC-A paketi PC-B-yə birbaşa göndərə bilməz; onu default gateway-ə (router-ə) verir.'));
      return w;
    }
    body.append(pick, stage); show();
  };

  /* ---------- splitnet: split a /24 into equal subnets (fixed-length only) ---------- */
  PT.sims.splitnet = function (el, o) {
    o = Object.assign({ base: '192.168.10.0' }, o);
    const body = PT.simFrame(el, '/24 network-ü bərabər hissələrə bölmək', 'Neçə subnet lazımdır?');
    const sel = h('select', { 'aria-label': 'Subnet sayı' }); [2, 4, 8, 16].forEach(n => sel.append(h('option', { value: n }, n + ' subnet')));
    sel.value = '4'; const out = h('div');
    function draw() {
      const n = +sel.value; const bitsB = Math.log2(n); const p = 24 + bitsB; const size = 256 / n; const b = o.base.split('.').slice(0, 3).join('.');
      out.innerHTML = '';
      const cells = h('div', { class: 'bits', style: 'margin:10px 0' });
      const ob = h('div', { class: 'oct-bits' }); for (let j = 0; j < 8; j++) ob.append(h('span', { class: 'bit static ' + (j < bitsB ? 'host' : 'net'), style: 'display:grid;place-items:center;' + (j < bitsB ? 'background:var(--yel-soft);border-color:var(--yel)' : '') }, j < bitsB ? 'S' : 'H'));
      cells.append(h('div', { class: 'oct' }, ob, h('div', { class: 'oct-dec' }, 'son oktet')));
      out.append(h('p', null, 'Son oktetin ', h('b', null, bitsB + ' biti'), ' host hissəsindən götürülüb və subnet nömrəsi üçün istifadə olunur (S). Qalan ', h('b', null, (8 - bitsB) + ' bit'), ' host hissəsidir (H). Yeni prefix: ', h('b', { class: 'm' }, '/' + p), ', mask: ', h('b', { class: 'm' }, A.maskS(p)), ', blok ölçüsü: ', h('b', null, String(size)), '.'), cells);
      const t = h('table', { class: 'tbl' }); t.append(h('tr', null, ['№', 'Network', 'İlk host', 'Son host', 'Broadcast'].map(x => h('th', null, x))));
      for (let i = 0; i < n; i++) { const s = i * size; t.append(h('tr', null, h('td', null, String(i + 1)), h('td', { class: 'm' }, b + '.' + s + '/' + p), h('td', { class: 'm' }, b + '.' + (s + 1)), h('td', { class: 'm' }, b + '.' + (s + size - 2)), h('td', { class: 'm' }, b + '.' + (s + size - 1)))); }
      out.append(h('div', { class: 'tbl-wrap' }, t), h('p', { class: 'fine' }, 'Hər subnet-də ' + (size - 2) + ' istifadə olunan host ünvanı var (network və broadcast ayrılıb). Bu bərabər bölmədir (fixed-length). Bu kursda VLSM yoxdur.'));
    }
    sel.addEventListener('change', draw);
    body.append(h('div', { class: 'sim-ctrl' }, h('label', null, 'Bölünmə:'), sel), out); draw();
  };

  /* ---------- macview ---------- */
  const MACS = [['00:1A:2B:3C:4D:5E', 'Adi unicast MAC (NIC-in öz ünvanı)'], ['FF:FF:FF:FF:FF:FF', 'Broadcast MAC'], ['01:00:5E:00:00:05', 'IPv4 multicast MAC'], ['02:AA:BB:CC:DD:EE', 'Əllə təyin olunmuş (locally administered)'], ['00:01:43:21:AA:AA', 'Packet Tracer cihazlarının tipik MAC-i']];
  PT.sims.macview = function (el, o) {
    const body = PT.simFrame(el, 'MAC ünvanının quruluşu', 'MAC yaz və ya nümunə seç.');
    const inp = h('input', { type: 'text', value: MACS[0][0], 'aria-label': 'MAC ünvanı', style: 'width:200px;font-family:var(--font-mono)' });
    const chips = h('div', { class: 'fields' }); const out = h('div'); const msg = h('span', { class: 'fine', role: 'status' });
    MACS.forEach(m => { const c = h('button', { type: 'button', class: 'chip', title: m[1] }, m[1]); c.addEventListener('click', () => { inp.value = m[0]; draw(); }); chips.append(c); });
    function draw() {
      const o_ = A.macParse(inp.value); out.innerHTML = '';
      if (!o_) { msg.textContent = 'MAC 12 hex rəqəmdən ibarət olmalıdır (məs. 00:1A:2B:3C:4D:5E).'; return; } msg.textContent = '';
      const f = parseInt(o_[0], 16); const bin = f.toString(2).padStart(8, '0'); const ig = f & 1, ul = (f >> 1) & 1;
      const row = h('div', { class: 'fields' });
      o_.forEach((x, i) => row.append(h('span', { class: 'chip ' + (i < 3 ? 'is-ok' : ''), style: 'font-family:var(--font-mono);font-weight:700;cursor:default' }, x.toUpperCase())));
      out.append(h('p', { class: 'fine', style: 'margin:8px 0 2px' }, 'İlk 3 bayt (yaşıl) OUI, yəni istehsalçı kodu. Son 3 bayt NIC hissəsidir, istehsalçı hər karta unikal verir.'), row);
      const bits = h('div', { class: 'oct-bits', style: 'margin:6px 0' });
      bin.split('').forEach((b, i) => { const hi = i >= 6; bits.append(h('span', { class: 'bit static ' + (hi ? 'host' : ''), style: 'display:grid;place-items:center' }, b)); });
      out.append(h('p', { class: 'fine', style: 'margin:8px 0 2px' }, 'İlk baytın bitləri (' + o_[0].toUpperCase() + ' = ' + bin + '). Sağdan ilk iki bit (sarı) xüsusi məna daşıyır:'), bits);
      const all = o_.every(x => x === 'ff'); const kind = all ? 'Broadcast (hamıya)' : (ig ? 'Group (multicast)' : 'Unicast (bir cihaz)');
      const ul_ = h('ul', { style: 'margin:6px 0 0;padding-left:20px' });
      ul_.append(h('li', null, h('b', null, 'Sağdan 1-ci bit (I/G): ' + ig), ' → ' + kind + '. 0 olsa unicast, 1 olsa group ünvanıdır. Broadcast da group ünvanının xüsusi halıdır (hamısı 1).'));
      ul_.append(h('li', null, h('b', null, 'Sağdan 2-ci bit (U/L): ' + ul), ' → ' + (ul ? 'locally administered: ünvanı istehsalçı yox, administrator və ya proqram təyin edib.' : 'universal: ünvanı istehsalçı təyin edib (OUI ilə uyğundur).')));
      out.append(ul_);
      out.append(h('div', { class: 'res-grid' }, [['Cisco formatı', A.macFmt(o_, 'cisco')], ['Windows formatı', A.macFmt(o_, 'win')], ['Linux/standart', A.macFmt(o_, 'colon')]].map(r => h('div', { class: 'res' }, h('small', null, r[0]), h('b', null, r[1])))));
    }
    inp.addEventListener('input', draw);
    body.append(chips, h('div', { class: 'sim-ctrl' }, h('label', null, 'MAC:'), inp, msg), out); draw();
  };
})();
