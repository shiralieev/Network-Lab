(function () {
  const PT = window.PT;
  /* Where data lives:
     1. 'server'  : the page was opened from the Netix Python server (http://127.0.0.1:port). Everything is
                    saved in Netix_data/state.json next to server.py, so it does not depend on the browser.
     2. 'local'   : the HTML file was opened directly (file://). Falls back to the browser's localStorage.
     3. 'mem'     : localStorage is blocked too. Data lives until the page closes. */
  const PREFIX = 'netix.v1.';
  const mem = {};
  let mode = 'mem';
  let timer = 0; const dirty = {};

  function localOk() { try { localStorage.setItem(PREFIX + '_t', '1'); localStorage.removeItem(PREFIX + '_t'); return true; } catch (e) { return false; } }

  function flush(useBeacon) {
    clearTimeout(timer); timer = 0;
    const keys = Object.keys(dirty); if (!keys.length) return;
    const payload = {}; keys.forEach(k => { payload[k] = mem[k]; delete dirty[k]; });
    const body = JSON.stringify(payload);
    if (useBeacon && navigator.sendBeacon) { navigator.sendBeacon('/api/state', new Blob([body], { type: 'application/json' })); return; }
    fetch('/api/state', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body, keepalive: true }).catch(() => { keys.forEach(k => { dirty[k] = 1; }); });
  }
  window.addEventListener('pagehide', () => flush(true));
  document.addEventListener('visibilitychange', () => { if (document.visibilityState === 'hidden') flush(true); });

  PT.store = {
    mode: () => mode,
    blocked: () => mode === 'mem',
    // resolves when saved data has been loaded; always resolves
    init() {
      if (location.protocol === 'http:' || location.protocol === 'https:') {
        return fetch('/api/state', { cache: 'no-store' }).then(r => { if (!r.ok) throw new Error('state'); return r.json(); })
          .then(obj => { Object.assign(mem, obj || {}); mode = 'server'; })
          .catch(() => { mode = localOk() ? 'local' : 'mem'; });
      }
      mode = localOk() ? 'local' : 'mem';
      return Promise.resolve();
    },
    get(k, d) {
      if (k in mem) return mem[k];
      if (mode === 'local') { try { const v = localStorage.getItem(PREFIX + k); return v == null ? d : JSON.parse(v); } catch (e) { return d; } }
      return d;
    },
    set(k, v) {
      mem[k] = v;
      if (mode === 'server') { dirty[k] = 1; if (!timer) timer = setTimeout(() => flush(false), 200); }
      else if (mode === 'local') { try { localStorage.setItem(PREFIX + k, JSON.stringify(v)); } catch (e) { mode = 'mem'; } }
    },
  };

  PT.progress = {
    data: null,
    load() {
      const d = PT.store.get('progress', null);
      this.data = (d && d.topics) ? d : { v: 1, topics: {}, wrong: {}, unlocked: {} };
      this.data.wrong = this.data.wrong || {}; this.data.unlocked = this.data.unlocked || {};
    },
    save() { PT.store.set('progress', this.data); },
    topic(id) {
      const t = this.data.topics;
      if (!t[id]) t[id] = { passed: false, best: 0, attempts: 0, fails: 0, seen: {}, labSteps: {}, labDone: false };
      return t[id];
    },
    markSeen(id, what) { const t = this.topic(id); if (!t.seen[what]) { t.seen[what] = true; this.save(); } },
    recordWrong(qid) { const w = this.data.wrong; w[qid] = (w[qid] || 0) + 1; },
    clearWrong(qid) { delete this.data.wrong[qid]; },
    reset() { this.data = { v: 1, topics: {}, wrong: {}, unlocked: {} }; this.save(); },
    exportText() { return 'PTP1:' + btoa(unescape(encodeURIComponent(JSON.stringify(this.data)))); },
    // merge: keeps the better of the two states, so importing never loses progress
    importText(text) {
      const m = String(text || '').trim();
      if (!m.startsWith('PTP1:')) throw new Error(PT.t('errPrefix'));
      let inc;
      try { inc = JSON.parse(decodeURIComponent(escape(atob(m.slice(5))))); } catch (e) { throw new Error(PT.t('errRead')); }
      if (!inc || typeof inc !== 'object' || !inc.topics) throw new Error(PT.t('errNoData'));
      for (const id of Object.keys(inc.topics)) {
        const a = this.topic(id), b = inc.topics[id] || {};
        a.passed = a.passed || !!b.passed; a.best = Math.max(a.best || 0, b.best || 0);
        a.attempts = Math.max(a.attempts || 0, b.attempts || 0); a.fails = a.passed ? 0 : Math.max(a.fails || 0, b.fails || 0);
        a.labDone = a.labDone || !!b.labDone;
        Object.assign(a.labSteps, b.labSteps || {}); Object.assign(a.seen, b.seen || {});
      }
      Object.assign(this.data.unlocked, inc.unlocked || {});
      for (const q of Object.keys(inc.wrong || {})) this.data.wrong[q] = Math.max(this.data.wrong[q] || 0, inc.wrong[q]);
      this.save();
    },
  };
})();
