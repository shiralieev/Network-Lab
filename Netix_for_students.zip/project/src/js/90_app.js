(function () {
  const PT = window.PT; const h = PT.h; const $ = PT.$; const t = (k, p) => PT.t(k, p);

  const ICON = {
    search: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" aria-hidden="true"><circle cx="11" cy="11" r="6.5"/><path d="M16 16l4.5 4.5"/></svg>',
    book: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linejoin="round" aria-hidden="true"><path d="M5 4h10a4 4 0 0 1 4 4v12H9a4 4 0 0 1-4-4V4z"/><path d="M5 16a4 4 0 0 1 4-4h10"/></svg>',
    save: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M12 4v10M8 10l4 4 4-4M5 19h14"/></svg>',
    moon: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linejoin="round" aria-hidden="true"><path d="M20 14.5A8 8 0 1 1 9.5 4a6.5 6.5 0 0 0 10.5 10.5z"/></svg>',
    sun: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" aria-hidden="true"><circle cx="12" cy="12" r="4"/><path d="M12 2v3M12 19v3M2 12h3M19 12h3M4.9 4.9l2.1 2.1M17 17l2.1 2.1M4.9 19.1L7 17M17 7l2.1-2.1"/></svg>',
    lang: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" aria-hidden="true"><circle cx="12" cy="12" r="9"/><path d="M3 12h18M12 3c3 3.2 3 14.8 0 18M12 3c-3 3.2-3 14.8 0 18"/></svg>',
    lock: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect x="5" y="11" width="14" height="9" rx="2"/><path d="M8 11V8a4 4 0 0 1 8 0v3"/></svg>',
  };
  /* Netix logo: the letter N drawn as a cable run between four network nodes */
  const BRAND = '<svg class="brand-mark" viewBox="0 0 34 34" aria-hidden="true"><rect x="1.5" y="1.5" width="31" height="31" rx="7" fill="none" stroke="currentColor" stroke-width="2"/><path d="M9.5 25V9l15 16V9" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"/><circle cx="9.5" cy="25" r="2.6" fill="var(--ok)"/><circle cx="9.5" cy="9" r="2.6" fill="var(--yel)"/><circle cx="24.5" cy="25" r="2.6" fill="var(--yel)"/><circle cx="24.5" cy="9" r="2.6" fill="var(--ok)"/></svg>';

  /* ---------- routing ---------- */
  function parse() {
    const raw = (location.hash || '#/home').replace(/^#/, '');
    const [path, anchor] = raw.split('@');
    const seg = path.split('/').filter(Boolean);
    return { seg, anchor: anchor || null, page: seg[0] || 'home', part: seg[0] && /^p\d$/.test(seg[0]) ? seg[0] : null, topic: seg[1] || null, step: seg[2] || 'explain' };
  }
  PT.go = function (path) {
    const target = '#' + path;
    if (location.hash === target) PT.render(); else location.hash = target;
  };

  /* ---------- chrome ---------- */
  function topbar() {
    const dark = PT.theme.current() === 'dark';
    const btn = (icon, label, fn, aria) => h('button', { class: 'icon-btn', type: 'button', 'aria-label': aria || label, onclick: fn, html: icon + '<span class="lbl">' + label + '</span>' });
    return h('header', { class: 'topbar' },
      h('button', { class: 'brand', type: 'button', onclick: () => PT.go('/home'), 'aria-label': t('brandAria'), html: BRAND + '<span class="brand-txt"><span class="brand-name">Netix</span><span class="brand-sub">' + (PT.instructor() ? t('brandInstructor') : t('brandSub')) + '</span></span>' }),
      h('div', { class: 'tb-actions' },
        btn(ICON.search, t('search'), () => PT.openSearch()),
        btn(ICON.book, t('glossary'), () => PT.openGlossary()),
        btn(ICON.save, t('progress'), () => PT.openProgress(), t('progressAria')),
        btn(ICON.lang, t('langBtn'), () => { PT.setLang(PT.otherLang()); PT.render(); }, t('langAria')),
        btn(dark ? ICON.sun : ICON.moon, dark ? t('themeLight') : t('themeDark'), () => { PT.theme.toggle(); PT.render(); }, t('themeAria'))));
  }
  function tabs(r) {
    const nav = h('nav', { class: 'rack-tabs', 'aria-label': t('partsNav') });
    nav.append(h('button', { class: 'rack-tab' + (r.page === 'home' ? ' is-active' : ''), type: 'button', onclick: () => PT.go('/home') }, h('span', { class: 'rt-label' }, t('home')), h('span', { class: 'rt-sub' }, t('wholePath'))));
    PT.outline.parts.forEach(p => {
      const pr = PT.partProgress(p);
      const dots = h('span', { class: 'rt-dots', 'aria-hidden': 'true' }, p.topics.map(tp => h('i', { class: 'dot ' + (PT.isPassed(tp.id) ? 'd-pass' : (!PT.hasContent(tp.id) ? 'd-soon' : (PT.isUnlocked(tp.id) ? 'd-open' : ''))) })));
      nav.append(h('button', { class: 'rack-tab' + (r.part === p.id ? ' is-active' : ''), type: 'button', onclick: () => PT.go('/' + p.id), 'aria-label': t('partAria', { n: p.n, title: PT.title(p), a: pr.passed, b: pr.total }) },
        h('span', { class: 'rt-label' }, t('part', { n: p.n })), h('span', { class: 'rt-sub' }, PT.title(p) + ' (' + pr.passed + '/' + pr.total + ')'), dots));
    });
    return nav;
  }

  /* ---------- home ---------- */
  function statusText(id) { return !PT.hasContent(id) ? t('soon') : ({ pass: t('stPass'), open: t('stOpen'), locked: t('stLocked') })[PT.status(id)]; }
  function port(tp) {
    const st = PT.status(tp.id); const soon = !PT.hasContent(tp.id); const cls = soon ? 'locked' : st;
    const idx = PT.meta(tp.id).part.topics.findIndex(x => x.id === tp.id) + 1;
    const b = h('button', { class: 'port is-' + cls, type: 'button', 'aria-label': idx + '. ' + PT.title(tp) + ': ' + statusText(tp.id), onclick: () => openTopic(tp.id) },
      h('span', { class: 'port-led' }),
      h('span', { class: 'port-jack' }, st === 'pass' ? h('span', { class: 'plug' }) : null, cls === 'locked' ? h('span', { class: 'port-lock', html: ICON.lock }) : null),
      h('span', { class: 'port-name' }, idx + '. ' + PT.title(tp)),
      h('span', { class: 'port-status' }, statusText(tp.id)));
    return b;
  }
  function openTopic(id) {
    const m = PT.meta(id);
    if (!PT.hasContent(id)) { PT.toast(t('toastSoon')); return; }
    if (!PT.isUnlocked(id)) { const prev = PT.order()[PT.order().indexOf(id) - 1]; PT.toast(t('toastLocked', { t: PT.title(PT.meta(prev)) })); return; }
    PT.go('/' + m.part.id + '/' + id + '/explain');
  }
  function homeView() {
    const total = PT.order().length; const passed = PT.order().filter(PT.isPassed).length; const next = PT.nextOpen();
    const left = h('div', null,
      h('h1', { class: 'hero-title' }, t('heroTitle')),
      h('p', { class: 'hero-sub' }, t('heroSub', { n: total })),
      h('div', { class: 'hero-cta' },
        next ? h('button', { class: 'btn btn-primary', type: 'button', onclick: () => openTopic(next) }, (passed ? t('continue', { t: PT.title(PT.meta(next)) }) : t('start', { t: PT.title(PT.meta(next)) }))) : null,
        h('button', { class: 'btn', type: 'button', onclick: () => PT.go('/p1') }, t('seePart1'))),
      PT.instructor() ? null : h('p', { class: 'hero-meta' }, t('heroMeta', { a: passed, b: total })),
      h('div', { class: 'legend', 'aria-label': t('legend') },
        h('span', null, h('i', { class: 'dot', style: 'background:var(--led-off)' }), t('lgLocked')),
        h('span', null, h('i', { class: 'dot', style: 'background:var(--yel)' }), t('lgOpen')),
        h('span', null, h('i', { class: 'dot', style: 'background:var(--ok)' }), t('lgPass'))));
    const rack = h('div', { class: 'rack' });
    PT.outline.parts.forEach(p => {
      const pr = PT.partProgress(p);
      rack.append(h('section', { class: 'panel-unit', 'aria-label': t('part', { n: p.n }) },
        h('div', { class: 'pu-head' }, h('span', { class: 'pu-num' }, t('part', { n: p.n })), h('span', { class: 'pu-title' }, PT.title(p)), h('span', { class: 'pu-count' }, pr.passed + ' / ' + pr.total)),
        h('div', { class: 'pu-ports' }, p.topics.map(port))));
    });
    return h('div', { class: 'home-hero' }, left, rack);
  }

  /* ---------- part pages ---------- */
  function side(part, activeId) {
    const pr = PT.partProgress(part);
    const list = h('ul', { class: 'tlist' });
    part.topics.forEach((tp, i) => {
      const st = PT.hasContent(tp.id) ? PT.status(tp.id) : 'locked'; const tpg = PT.progress.data.topics[tp.id];
      const meta = !PT.hasContent(tp.id) ? t('soon') : (st === 'pass' ? t('sidePass', { p: tpg ? tpg.best : 0 }) : (st === 'open' ? t('sideOpen', { m: tp.min }) : t('stLocked')));
      list.append(h('li', null, h('button', { class: 'titem is-' + st + (activeId === tp.id ? ' is-active' : ''), type: 'button', 'aria-current': activeId === tp.id ? 'page' : null, onclick: () => openTopic(tp.id) },
        h('span', { class: 'titem-led' }), h('span', null, h('span', { class: 'titem-title' }, (i + 1) + '. ' + PT.title(tp)), h('span', { class: 'titem-meta', style: 'display:block' }, meta)))));
    });
    const el = h('aside', { class: 'side' },
      h('div', { class: 'side-head' }, h('div', { class: 'side-title' }, t('part', { n: part.n }) + ': ' + PT.title(part)), h('p', { class: 'side-desc' }, PT.desc(part)), h('div', { class: 'bar' }, h('i', { style: 'width:' + pr.pct + '%' })), h('div', { class: 'bar-txt' }, t('sideBar', { a: pr.passed, b: pr.total }))),
      h('button', { class: 'btn btn-quiet side-toggle', type: 'button', style: 'border-radius:0;border-width:1px 0 0 0', onclick: () => el.classList.toggle('is-open') }, t('topicList')), list);
    if (activeId === null) el.classList.add('is-open');
    return el;
  }
  function partOverview(part) {
    const any = part.topics.some(tp => PT.hasContent(tp.id));
    const main = h('div', { class: 'main' });
    if (!any) {
      main.append(h('div', { class: 'soon' }, h('h2', null, t('part', { n: part.n }) + ': ' + PT.title(part)), h('p', null, t('partSoon')), h('ul', null, part.topics.map(tp => h('li', null, PT.title(tp))))));
    } else {
      const next = part.topics.find(tp => PT.hasContent(tp.id) && !PT.isPassed(tp.id) && PT.isUnlocked(tp.id));
      main.append(h('div', { class: 't-head' }, h('h1', { class: 't-title' }, t('part', { n: part.n }) + ': ' + PT.title(part)), h('p', { class: 't-sub' }, PT.desc(part))),
        next ? h('p', null, h('button', { class: 'btn btn-primary', type: 'button', onclick: () => openTopic(next.id) }, (PT.progress.data.topics[next.id] ? t('continue', { t: PT.title(next) }) : t('start', { t: PT.title(next) })))) : h('p', null, h('b', null, t('partDone'))),
        h('div', { class: 'soon', style: 'max-width:760px;margin-top:14px' }, h('h2', null, t('fourSteps')), h('ul', null,
          h('li', null, t('fs1')), h('li', null, t('fs2')), h('li', null, t('fs3')), h('li', null, t('fs4')))));
    }
    return h('div', { class: 'part' }, side(part, null), main);
  }

  /* ---------- topic page ---------- */
  function topicView(part, id, step, anchor) {
    const meta = PT.meta(id); const idx = part.topics.findIndex(tp => tp.id === id) + 1;
    const main = h('div', { class: 'main' });
    if (!PT.hasContent(id)) { main.append(h('div', { class: 'soon' }, h('h2', null, PT.title(meta)), h('p', null, t('toastSoon')))); return h('div', { class: 'part' }, side(part, id), main); }
    if (!PT.isUnlocked(id)) {
      const prev = PT.order()[PT.order().indexOf(id) - 1];
      main.append(h('div', { class: 'soon' }, h('h2', null, t('lockedTitle')), h('p', null, t('lockedText', { t: PT.title(PT.meta(prev)) })), h('button', { class: 'btn btn-primary', type: 'button', onclick: () => openTopic(prev) }, t('goPrev'))));
      return h('div', { class: 'part' }, side(part, id), main);
    }
    const T = PT.T(id); const prog = PT.progress.topic(id);
    if (!['explain', 'cheat', 'lab', 'quiz'].includes(step)) step = 'explain';
    main.append(h('div', { class: 't-head' }, h('h1', { class: 't-title' }, PT.title(meta)), h('p', { class: 't-sub' }, t('topicSub', { n: part.n, i: idx, m: part.topics.length, min: meta.min }))));
    if (!PT.isTranslated(id)) main.append(h('div', { class: 'banner', role: 'status' }, t('notTranslated')));
    if (step === 'explain' && T.objectives) main.append(h('div', { class: 'objectives' }, h('h2', null, t('objectives')), h('ul', null, T.objectives.map(o => h('li', { html: o })))));
    const STEPS = [
      { k: 'explain', n: t('stExplain'), note: t('stExplainNote'), done: !!prog.seen.explain },
      { k: 'cheat', n: t('stCheat'), note: t('stCheatNote'), done: !!prog.seen.cheat },
      { k: 'lab', n: t('stLab'), note: prog.labDone ? t('stLabDone') : t('stLabTodo'), done: prog.labDone },
      { k: 'quiz', n: t('stQuiz'), note: prog.passed ? t('sidePass', { p: prog.best }) : t('stQuizTodo'), done: prog.passed },
    ];
    main.append(h('nav', { class: 'stepper', 'aria-label': t('stepsAria') }, STEPS.map((s, i) => h('button', { class: 'st' + (step === s.k ? ' is-active' : '') + (s.done ? ' is-done' : ''), type: 'button', 'aria-current': step === s.k ? 'step' : null, onclick: () => PT.go('/' + part.id + '/' + id + '/' + s.k) },
      h('span', { class: 'st-led' }), h('span', { class: 'st-txt' }, h('span', { class: 'st-name' }, (i + 1) + '. ' + s.n), h('span', { class: 'st-note' }, s.note))))));
    const body = h('div', { class: 'step-body' }); main.append(body);
    const nav = (prevK, nextK) => h('div', { class: 'step-nav' },
      prevK ? h('button', { class: 'btn', type: 'button', onclick: () => PT.go('/' + part.id + '/' + id + '/' + prevK) }, t('back', { s: STEPS.find(s => s.k === prevK).n })) : h('span'),
      nextK ? h('button', { class: 'btn btn-primary', type: 'button', onclick: () => PT.go('/' + part.id + '/' + id + '/' + nextK) }, t('next', { s: STEPS.find(s => s.k === nextK).n })) : h('span'));
    if (step === 'explain') {
      const el = h('article', { class: 'prose', html: T.explain }); body.append(el);
      PT.$$('[data-sim]', el).forEach(n => { const fn = PT.sims[n.dataset.sim]; if (fn) fn(n, n.dataset.opts ? JSON.parse(n.dataset.opts) : {}); else n.textContent = t('simMissing', { n: n.dataset.sim }); });
      PT.glossify(el); PT.progress.markSeen(id, 'explain'); body.append(nav(null, 'cheat'));
      if (anchor) setTimeout(() => { const a = el.querySelector('#' + CSS.escape(anchor)); if (a) a.scrollIntoView({ block: 'start' }); }, 30);
    } else if (step === 'cheat') {
      const el = h('div', { class: 'cheat-wrap', html: T.cheat }); body.append(el);
      body.append(h('div', { class: 'sim-ctrl', style: 'margin-top:18px' }, h('button', { class: 'btn btn-sm', type: 'button', onclick: () => window.print() }, t('print'))));
      PT.glossify(el); PT.progress.markSeen(id, 'cheat'); body.append(nav('explain', 'lab'));
    } else if (step === 'lab') {
      const el = h('div'); body.append(el); PT.lab.mount(el, T); body.append(nav('cheat', 'quiz'));
    } else {
      const el = h('div'); body.append(el); PT.quiz.mount(el, T); body.append(nav('lab', null));
    }
    return h('div', { class: 'part' }, side(part, id), main);
  }

  /* ---------- render ---------- */
  PT.render = function () {
    document.querySelectorAll('dialog.dlg').forEach(d => d.remove());
    /* teacher link: #/teacher/<code> opens every topic (a learning aid, not security) */
    { const q = parse(); if (q.page === 'teacher') {
      const ok = q.seg[1] && decodeURIComponent(q.seg[1]) === PT.config.teacherCode;
      if (ok) { PT.order().forEach(id => { if (PT.hasContent(id)) PT.progress.data.unlocked[id] = true; }); PT.progress.save(); }
      location.replace('#/p1'); return; } }
    const app = $('#app'); const r = parse(); app.innerHTML = '';
    app.append(topbar(), tabs(r));
    if (PT.instructor()) app.append(h('div', { class: 'banner', role: 'status' }, t('instrBanner')));
    if (PT.store.blocked()) app.append(h('div', { class: 'banner', role: 'alert' }, t('bannerBlocked')));
    let view;
    if (r.part) {
      const part = PT.outline.parts.find(p => p.id === r.part);
      if (r.topic && PT.meta(r.topic)) { view = topicView(part, r.topic, r.step, r.anchor); document.title = PT.title(PT.meta(r.topic)) + ' | ' + PT.config.title; }
      else { view = partOverview(part); document.title = t('part', { n: part.n }) + ': ' + PT.title(part) + ' | ' + PT.config.title; }
    } else { view = homeView(); document.title = PT.config.title; }
    const stage = h('main', { class: 'stage' }, view); app.append(stage);
    app.append(h('footer', { class: 'footer' }, t('footer')));
    if (!r.anchor) window.scrollTo({ top: 0 });
  };

  PT.boot = function () {
    PT.store.init().then(() => {
      PT.initLang(); PT.theme.init(); PT.progress.load();
      window.addEventListener('hashchange', () => PT.render());
      if (!location.hash) location.hash = '#/home';
      PT.render();
    });
  };
})();
