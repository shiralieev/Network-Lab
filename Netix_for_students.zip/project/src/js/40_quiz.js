(function () {
  const PT = window.PT; const h = PT.h; const t = (k, p) => PT.t(k, p);

  PT.norm = s => String(s == null ? '' : s).trim().toLowerCase().replace(/\s+/g, ' ').replace(/[.,;]+$/, '');

  /* ---------- building an attempt ---------- */
  function fromGen(g) { const q = g(); q._gen = true; return q; }
  PT.quiz = {
    build(topic) {
      const Q = topic.quiz; const draw = Q.draw || PT.config.quizDraw;
      const gens = (Q.gens || []).map(fromGen);
      const rest = PT.sample(Q.pool || [], Math.max(0, draw - gens.length));
      return PT.shuffle(gens.concat(rest)).slice(0, draw);
    },
    // fresh copy with the option order shuffled for this attempt
    prepare(q) {
      const c = Object.assign({}, q);
      if (q.type === 'order') { c.items = PT.shuffle(q.items.map((it, i) => Object.assign({ idx: i }, it))); if (c.items.every((it, i) => it.idx === i)) c.items.reverse(); }
      else if (!q.type || q.type === 'mc') c.options = PT.shuffle(q.options);
      return c;
    },
  };

  /* ---------- rendering one question (shared by quiz and labs) ---------- */
  // returns {el, actions, isAnswered}
  PT.renderQuestion = function (q, onAnswered, opts) {
    opts = opts || {};
    const root = h('div', { class: 'qbody' });
    const stem = h('div', { class: 'q-stem', html: q.stem });
    root.append(stem);
    let answered = false;
    const actions = h('div', { class: 'q-actions' });
    const verdict = h('div', { class: 'verdict hide', role: 'status' });

    function finish(ok, extraHtml) {
      answered = true;
      verdict.classList.remove('hide'); verdict.classList.add(ok ? 'is-ok' : 'is-bad');
      verdict.innerHTML = '<div class="head">' + (ok ? t('right') : t('wrong')) + '</div>' + (extraHtml || '');
      onAnswered(ok);
    }

    if (!q.type || q.type === 'mc') {
      const list = h('div', { class: 'opts', role: 'group' });
      let picked = null; const btns = [];
      q.options.forEach((o, i) => {
        const b = h('button', { type: 'button', class: 'opt', 'aria-pressed': 'false' }, h('span', { class: 'opt-key' }, PT.letters[i]), h('span', { html: o.t }));
        b.addEventListener('click', () => {
          if (answered) return; picked = i; btns.forEach((x, j) => { x.classList.toggle('is-pick', j === i); x.setAttribute('aria-pressed', j === i ? 'true' : 'false'); }); check.disabled = false;
        });
        btns.push(b); list.append(b);
      });
      const check = h('button', { type: 'button', class: 'btn btn-primary', disabled: '' }, t('check'));
      check.addEventListener('click', () => {
        if (answered || picked == null) return;
        const ok = !!q.options[picked].ok; check.classList.add('hide');
        btns.forEach((b, i) => {
          b.disabled = true; b.classList.remove('is-pick'); const o = q.options[i];
          if (o.ok) b.classList.add('is-ok'); else if (i === picked) b.classList.add('is-bad');
          const tag = o.ok ? t('tagRight') : (i === picked ? t('tagPicked') : t('tagWhy'));
          b.append(h('span', { class: 'opt-why', html: '<span class="tag">' + tag + '</span>' + (o.why || '') }));
        });
        finish(ok, q.why ? '<div>' + q.why + '</div>' : '');
      });
      actions.append(check); root.append(list);
    } else if (q.type === 'num') {
      const input = h('input', { type: 'text', autocomplete: 'off', autocapitalize: 'off', spellcheck: 'false', 'aria-label': t('answerAria'), placeholder: q.placeholder || t('answerPh') });
      const check = h('button', { type: 'button', class: 'btn btn-primary' }, t('check'));
      const go = () => {
        if (answered || !input.value.trim()) return;
        const r = q.check(input.value); const ok = typeof r === 'object' ? r.ok : !!r;
        input.disabled = true; check.classList.add('hide');
        finish(ok, '<div>' + (typeof r === 'object' && r.note ? r.note + ' ' : '') + '</div><div style="margin-top:8px"><b>' + t('solutionLbl') + '</b> ' + q.solution + '</div>');
      };
      check.addEventListener('click', go); input.addEventListener('keydown', e => { if (e.key === 'Enter') go(); });
      root.append(h('div', { class: 'num-in' }, input)); actions.append(check);
    } else if (q.type === 'order') {
      let items = q.items.slice(); const ul = h('ul', { class: 'order-list' });
      const draw = () => {
        ul.innerHTML = '';
        items.forEach((it, i) => {
          const up = h('button', { type: 'button', class: 'btn btn-sm', 'aria-label': t('up') }, t('up')); const dn = h('button', { type: 'button', class: 'btn btn-sm', 'aria-label': t('down') }, t('down'));
          up.disabled = answered || i === 0; dn.disabled = answered || i === items.length - 1;
          up.addEventListener('click', () => { [items[i - 1], items[i]] = [items[i], items[i - 1]]; draw(); });
          dn.addEventListener('click', () => { [items[i + 1], items[i]] = [items[i], items[i + 1]]; draw(); });
          const li = h('li', null, h('span', { html: it.t }), answered ? null : h('span', { class: 'mv' }, up, dn));
          if (answered) { const good = it.idx === i; li.classList.add(good ? 'is-ok' : 'is-bad'); li.append(h('div', { class: 'order-why', html: '<b>' + (good ? t('rightSpot') : t('wrongSpot', { n: it.idx + 1 })) + '</b>' + (it.why || '') })); }
          ul.append(li);
        });
      };
      draw();
      const check = h('button', { type: 'button', class: 'btn btn-primary' }, t('checkOrder'));
      check.addEventListener('click', () => {
        if (answered) return; const ok = items.every((it, i) => it.idx === i);
        check.classList.add('hide'); answered = true; draw(); answered = false; finish(ok, q.why ? '<div>' + q.why + '</div>' : '');
      });
      root.append(ul); actions.append(check);
    }
    root.append(verdict, actions);
    return { el: root, actions, isAnswered: () => answered };
  };

  /* ---------- instructor view: every question with all answers, nothing to solve ---------- */
  function staticQuestion(q, label) {
    const box = h('div', { class: 'qcard', style: 'margin-bottom:14px' });
    box.append(h('div', { class: 'fine', style: 'margin-bottom:6px' }, label), h('div', { class: 'q-stem', html: q.stem }));
    if (!q.type || q.type === 'mc') {
      const list = h('div', { class: 'opts' });
      q.options.forEach((o, i) => list.append(h('div', { class: 'opt ' + (o.ok ? 'is-ok' : '') , style: 'cursor:default' }, h('span', { class: 'opt-key' }, PT.letters[i]), h('span', { html: o.t }),
        h('span', { class: 'opt-why', html: '<span class="tag">' + (o.ok ? t('tagRight') : t('tagWhy')) + '</span>' + (o.why || '') }))));
      box.append(list);
    } else if (q.type === 'num') {
      box.append(h('div', { class: 'verdict is-ok', html: '<div class="head">' + t('solutionLbl') + '</div>' + q.solution }));
    } else if (q.type === 'order') {
      const ul = h('ol', { class: 'order-list' });
      q.items.forEach(it => ul.append(h('li', { class: 'is-ok' }, h('span', { html: it.t }), h('div', { class: 'order-why', html: it.why || '' }))));
      box.append(ul);
    }
    return box;
  }

  /* ---------- quiz screen ---------- */
  PT.quiz.mount = function (container, topic) {
    container.innerHTML = '';
    if (PT.instructor()) {
      const Q = topic.quiz; const wrap = h('div', { class: 'qwrap' });
      wrap.append(h('div', { class: 'result' }, h('h2', null, t('quiz')), h('p', null, t('instrQuizInfo', { n: (Q.pool || []).length, g: (Q.gens || []).length }))));
      (Q.pool || []).forEach((q, i) => wrap.append(staticQuestion(q, (q.id || '') + '  |  ' + (q.concept || ''))));
      (Q.gens || []).forEach((g, i) => { for (let k = 0; k < 2; k++) { const q = g(); wrap.append(staticQuestion(q, t('instrGenSample', { k: k + 1 }) + '  |  ' + (q.id || ''))); } });
      container.append(wrap); return;
    }
    const meta = PT.meta(topic.id); const prog = PT.progress.topic(topic.id);
    const need = Math.ceil(PT.config.passPercent / 100 * (topic.quiz.draw || PT.config.quizDraw));

    function intro() {
      container.innerHTML = '';
      const wrap = h('div', { class: 'qwrap' });
      wrap.append(h('div', { class: 'result' },
        h('h2', null, t('quiz')),
        h('p', null, t('quizIntro1', { d: topic.quiz.draw || PT.config.quizDraw, n: need, p: PT.config.passPercent })),
        h('p', null, t('quizIntro2')),
        prog.passed ? h('p', null, h('b', null, t('alreadyPassed')), t('bestScore', { p: prog.best })) : null,
        h('div', { class: 'q-actions' }, h('button', { class: 'btn btn-primary', type: 'button', onclick: () => run() }, prog.passed ? t('retry') : t('startQuiz')))));
      container.append(wrap);
    }

    function run() {
      const qs = PT.quiz.build(topic).map(PT.quiz.prepare); let i = 0, right = 0; const missed = [];
      const wrap = h('div', { class: 'qwrap' }); container.innerHTML = ''; container.append(wrap);
      const step = () => {
        wrap.innerHTML = '';
        const q = qs[i];
        wrap.append(h('div', { class: 'q-progress' }, h('span', null, t('qProg', { i: i + 1, n: qs.length })), h('div', { class: 'bar' }, h('i', { style: 'width:' + Math.round(i * 100 / qs.length) + '%' }))));
        const card = h('div', { class: 'qcard' }); wrap.append(card);
        const r = PT.renderQuestion(q, ok => {
          if (ok) { right++; if (q.id) PT.progress.clearWrong(q.id); } else { missed.push(q); if (q.id) PT.progress.recordWrong(q.id); }
          PT.progress.save();
          const last = i === qs.length - 1;
          r.actions.append(h('button', { class: 'btn btn-primary', type: 'button', onclick: () => { if (last) done(); else { i++; step(); window.scrollTo({ top: 0 }); } } }, last ? t('seeResult') : t('nextQ')));
        });
        card.append(r.el);
      };
      const done = () => {
        const pct = Math.round(right * 100 / qs.length); const pass = right >= need;
        prog.attempts++; prog.best = Math.max(prog.best, pct);
        if (pass) { prog.passed = true; prog.fails = 0; } else prog.fails++;
        PT.progress.save(); wrap.innerHTML = '';
        const res = h('div', { class: 'result' });
        res.append(h('h2', null, pass ? t('passTitle') : t('failTitle')), h('div', { class: 'score' }, t('score', { r: right, n: qs.length, p: pct, need })));
        if (pass) {
          res.append(h('div', { class: 'plug-anim', html: '<svg viewBox="0 0 200 74" aria-hidden="true"><rect x="108" y="14" width="80" height="46" rx="4" fill="var(--jack)" stroke="var(--jack-edge)" stroke-width="3"/><rect x="118" y="22" width="60" height="12" fill="none" stroke="var(--jack-edge)" stroke-width="3" stroke-dasharray="3 4"/><circle class="led" cx="148" cy="8" r="5" fill="var(--led-off)"/><g class="cable"><rect x="62" y="22" width="48" height="30" rx="3" fill="var(--btn)"/><rect x="2" y="32" width="62" height="10" rx="4" fill="var(--btn)"/></g></svg>' },
            h('div', null, h('b', null, t('portDone')), (PT.nextTopic(topic.id) && PT.hasContent(PT.nextTopic(topic.id))) ? t('nextOpened') : t('endOfPart'))));
        }
        if (!pass && missed.length) {
          res.append(h('p', null, h('b', null, t('missedTopics'))));
          const ul = h('ul', { class: 'review-list' });
          const seen = new Set();
          missed.forEach(q => { const key = q.concept || q.obj || t('general'); if (seen.has(key)) return; seen.add(key); ul.append(h('li', null, q.obj || key, q.concept ? [' ', h('button', { class: 'btn btn-sm', type: 'button', onclick: () => PT.go('/' + meta.part.id + '/' + topic.id + '/explain@' + q.concept) }, t('reread'))] : null)); });
          res.append(ul);
        }
        if (!pass && prog.fails >= PT.config.failsBeforeReview) res.append(h('p', { class: 'fine' }, t('failHint')));
        if (!pass && prog.fails >= PT.config.failsBeforeTeacherCode && PT.nextTopic(topic.id) && !PT.isUnlocked(PT.nextTopic(topic.id))) {
          const inp = h('input', { type: 'text', placeholder: t('teacherPh'), 'aria-label': t('teacherPh') }); const m = h('span', { class: 'fine', role: 'status' });
          res.append(h('div', { class: 'unlock' }, h('p', { style: 'margin:0 0 8px' }, t('teacherP')), inp,
            h('button', { class: 'btn btn-sm', type: 'button', onclick: () => { if (PT.unlockWithTeacher(topic.id, inp.value)) { m.textContent = t('nextOpened'); PT.toast(t('nextOpened')); } else m.textContent = t('badCode'); } }, t('open')), ' ', m));
        }
        const acts = h('div', { class: 'q-actions' });
        acts.append(h('button', { class: 'btn' + (pass ? '' : ' btn-primary'), type: 'button', onclick: run }, pass ? t('retry') : t('retryAgain')));
        const nx = PT.nextTopic(topic.id);
        if (pass && nx && PT.hasContent(nx)) acts.append(h('button', { class: 'btn btn-primary', type: 'button', onclick: () => { const m2 = PT.meta(nx); PT.go('/' + m2.part.id + '/' + nx + '/explain'); } }, t('nextTopicBtn')));
        else if (pass) acts.append(h('button', { class: 'btn btn-primary', type: 'button', onclick: () => PT.go('/home') }, t('backHome')));
        res.append(acts); wrap.append(res); window.scrollTo({ top: 0 });
      };
      step();
    }
    intro();
  };
})();
