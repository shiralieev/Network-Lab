(function () {
  const PT = window.PT;
  PT.topics = {};          // id -> Azerbaijani topic definition (only topics that have content)
  PT.topicsEn = {};        // id -> English topic definition (added topic by topic)
  PT.topic = function (def) { PT.topics[def.id] = def; };
  PT.topicEn = function (def) { PT.topicsEn[def.id] = def; };
  // the definition to show in the current language; falls back to Azerbaijani when no English version exists yet
  PT.T = id => (PT.lang === 'en' && PT.topicsEn[id]) || PT.topics[id] || PT.topicsEn[id];
  PT.isTranslated = id => PT.lang !== 'en' || !!PT.topicsEn[id];

  PT.instructor = () => !!(PT.config && PT.config.instructor);

  PT.order = function () { return PT.outline.parts.flatMap(p => p.topics.map(t => t.id)); };
  PT.meta = function (id) {
    for (const p of PT.outline.parts) for (const t of p.topics) if (t.id === id) return Object.assign({ part: p }, t);
    return null;
  };
  PT.hasContent = id => !!PT.topics[id] || !!PT.topicsEn[id];
  PT.isPassed = id => !!PT.progress.data.topics[id] && PT.progress.data.topics[id].passed;
  PT.isUnlocked = function (id) {
    if (PT.instructor()) return true;
    const ord = PT.order(); const i = ord.indexOf(id);
    if (i <= 0) return i === 0;
    if (PT.progress.data.unlocked[id]) return true;
    return PT.isPassed(ord[i - 1]);
  };
  PT.status = function (id) { return PT.isPassed(id) ? 'pass' : (PT.isUnlocked(id) ? 'open' : 'locked'); };
  PT.nextOpen = function () {
    for (const id of PT.order()) { if (PT.hasContent(id) && !PT.isPassed(id) && PT.isUnlocked(id)) return id; }
    return null;
  };
  PT.nextTopic = function (id) { const o = PT.order(); const n = o[o.indexOf(id) + 1]; return n || null; };
  PT.partProgress = function (part) {
    const total = part.topics.length; const passed = part.topics.filter(t => PT.isPassed(t.id)).length;
    return { total, passed, pct: total ? Math.round(passed * 100 / total) : 0 };
  };
  PT.unlockWithTeacher = function (id, code) {
    if (String(code).trim() === PT.config.teacherCode) { PT.progress.data.unlocked[PT.nextTopic(id)] = true; PT.progress.save(); return true; }
    return false;
  };
  PT.gloss = () => (PT.lang === 'en' && PT.glossaryEn) ? PT.glossaryEn : (PT.glossary || []);
})();
