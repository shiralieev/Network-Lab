(function () {
  const pick = PT.pick; const R = PT.randInt; const shuffle = PT.shuffle;
  const rnd = (lo, hi) => lo + R(hi - lo + 1);
  const macOk = r => { const t = String(r).trim(); if (!/^[0-9a-f]{2}([-:][0-9a-f]{2}){5}$/i.test(t) && !/^[0-9a-f]{4}(\.[0-9a-f]{4}){2}$/i.test(t)) return false; const x = t.replace(/[^0-9a-f]/gi, '').toLowerCase(); return x !== '000000000000' && x !== 'ffffffffffff'; };
  const macKey = r => String(r).replace(/[^0-9a-f]/gi, '').toLowerCase();

  PT.topic({
    id: 'p1t8',
    objectives: [
      'Packet Tracer pəncərəsinin hissələrini tanımaq, cihaz qoyub düzgün kabellə birləşdirmək',
      'Link işıqlarını oxumaq və PC ilə switch/router üçün düzgün pəncərəni (Desktop, CLI) seçmək',
      'Realtime və Simulation rejimlərini fərqləndirmək, Event List-də ARP və ICMP paketlərini izləmək',
      'Inspect aləti ilə ARP və MAC cədvəllərinə baxıb nəticəni əvvəlki proqnozla müqayisə etmək',
    ],
    explain: PT.frag['p1/t08/explain'], cheat: PT.frag['p1/t08/cheat'],

    lab: {
      title: 'Lab 8: İlk topologiyanı qur və paketi izlə',
      goal: 'Packet Tracer-də üç PC və bir switch qurmaq, IP vermək, əvvəl proqnoz verib sonra Simulation rejimində ARP və ICMP paketlərini izləmək, Inspect ilə cədvəllərə baxmaq.',
      why: 'Bu andan sonra hər yeni qaydanı Packet Tracer-də sübut edəcəksən. Cihazı tez qurmaq, paketi izləmək və cədvəldən nəticə oxumaq həm öyrənmədə, həm də real şəbəkədə problem tapmaqda əsas bacarıqdır.',
      minutes: 40,
      finish: 'Topologiyanı qurdun, paketi addım-addım izlədin və cədvəldən nəticə çıxardın. Növbəti mövzuda switch-in əmr xəttinə (CLI) girib əmrlərin necə işlədiyini öyrənəcəksən: bu mövzudakı topologiyanı orada da işlədə bilərsən.',
      steps: [
        { id: 's1', title: 'Plan', type: 'info', button: 'Başlayaq',
          body: '<p>Bu labda <b>Packet Tracer lazımdır</b> (8.x və ya 9.x). Packet Tracer-də öz kompüterində işləyirsən, bu səhifə sənə addımları verir və cavabları yoxlayır. Addımlar:</p><ol><li>Düzgün kabeli seç və qurma sırasını düz.</li><li>Üç PC və bir switch qur, IP ver.</li><li>PC-nin MAC ünvanını oxu.</li><li>Nəticəni əvvəl <b>proqnozlaşdır</b>, sonra Simulation rejimində yoxla.</li><li>Inspect ilə cədvəllərə bax.</li><li>İki ticket və bir ad səhvi.</li></ol><p>Proqnozu əvvəl sən verirsən: Packet Tracer cavabı yoxlamaq üçündür, tapmaq üçün yox.</p>' },

        { id: 's2', title: 'Hansı kabel?', type: 'choice',
          body: '<p>PC-ni switch-in Ethernet portuna (<span class="m">FastEthernet0/1</span>) qoşmaq istəyirsən. Klassik qaydaya görə hansı kabeli seçirsən?</p>',
          options: [
            { t: 'Copper Straight-Through: PC və switch fərqli növ cihazlardır.', ok: true, why: 'Klassik qayda: fərqli növ cihazlar (PC–switch, switch–router) straight-through ilə, eyni növ cihazlar (PC–PC, switch–switch) cross-over ilə birləşir. PC ilə switch fərqlidir.' },
            { t: 'Copper Cross-Over: PC ilə switch iki ayrı cihazdır, ona görə cross-over lazımdır.', why: 'Cross-over eyni növ cihazlar üçündür. "İki ayrı cihaz" fərqli növ demək deyil: hər ikisi son-istifadəçi və ya şəbəkə cihazı olur.' },
            { t: 'Console: bu PC-ni switch-ə birləşdirən ən sadə kabeldir.', why: 'Console kabeli idarəetmə üçündür, məlumat (kadr) daşımır. PC-nin trafikini switch-ə çatdırmaq üçün Ethernet kabeli lazımdır.' },
            { t: 'Serial DCE: bu, bütün cihazları birləşdirən universal kabeldir.', why: 'Serial kabellər router-lər arasında WAN linkləri üçündür. Switch Ethernet portuna qoşulmur.' },
          ],
          hints: ['PC və switch eyni növ cihazdır, yoxsa fərqli?'],
          after: '<p>Yenə də bu klassik qaydadır. Yeni cihazlar Auto-MDI/X ilə kabeli özü tanıya bilir və Packet Tracer-də səhv kabel çox vaxt qırmızı link verir. Əmin olmayanda klassik qaydadan başla.</p>' },

        { id: 's3', title: 'Qurma sırası', type: 'order',
          body: '<p>İlk linki qurursan: PC ilə switch. Addımları düzgün sırayla düz (ilk iş yuxarıda).</p>',
          items: [
            { t: 'Sol altda cihaz kateqoriyasını seçirsən (Network Devices, End Devices)', why: 'Hər şey kateqoriyadan başlayır: onsuz konkret model qutusu açılmır.' },
            { t: 'Modeli seçib iş sahəsinə qoyursan (switch və PC)', why: 'Kabeli çəkmək üçün əvvəl iki ucda cihaz olmalıdır.' },
            { t: 'Connections kateqoriyasında kabel növünü seçirsən', why: 'Kabel növü cihazlar qoyulandan sonra seçilir: ona görə ki, hansı portlara birləşdirəcəyini bilirsən.' },
            { t: 'İki cihazın portlarını seçirsən (məsələn PC FastEthernet0 və switch FastEthernet0/1)', why: 'Kabelin bir ucunu birinci cihaza, o birini ikinciyə qoşursan: hər dəfə port seçirsən.' },
            { t: 'Link işıqlarının yaşıl olmasını gözləyirsən (Fast Forward Time)', why: 'Yoxlama axırda olur: işıq yaşıldırsa link hazırdır, qırmızıdırsa kabeli və portu yoxlayırsan.' },
          ],
          hints: ['Kabeli çəkməzdən əvvəl hər iki ucda nə olmalıdır?'],
          after: '<p>Bu sıra hər layihədə təkrarlanır: <b>kateqoriya, model, kabel, portlar, yoxlama</b>.</p>' },

        { id: 's4', title: 'Packet Tracer-də qur: topologiya', type: 'ptsteps',
          body: '<p>Packet Tracer-i aç və aşağıdakıları et. Hər addımı edəndə qutunu işarələ.</p>',
          checks: [
            { t: '<i>End Devices</i> kateqoriyasından iş sahəsinə <b>üç PC</b> qoy.' },
            { t: '<i>Network Devices → Switches</i> kateqoriyasından bir <b>2960</b> switch qoy.' },
            { t: '<i>Connections</i> kateqoriyasında <b>Copper Straight-Through</b> kabel seç. PC-nin <span class="m">FastEthernet0</span> portunu switch-in <span class="m">FastEthernet0/1</span> portuna qoş.' },
            { t: 'Eyni kabellə ikinci PC-ni <span class="m">FastEthernet0/2</span>-yə, üçüncü PC-ni <span class="m">FastEthernet0/3</span>-ə qoş.' },
            { t: 'Hər cihazın üstünə klik et, <i>Config</i> nişanında <b>Display Name</b>-i dəyiş: <b>PC-A</b> (Fa0/1), <b>PC-B</b> (Fa0/2), <b>PC-C</b> (Fa0/3) və <b>SW1</b>. Bu adlardan sonra istifadə edəcəyik.' },
            { t: 'Bütün üç linkin işığının yaşıl olmasını gözlə. Narıncıdırsa, <b>Fast Forward Time</b> düyməsini bas.' },
          ],
          button: 'Hamısını etdim' },

        { id: 's5', title: 'IP ünvanlarını ver', type: 'ptsteps',
          body: '<p>Hər PC-yə IP ver: PC-nin üstünə klik et, <i>Desktop → IP Configuration</i> aç, <b>Static</b> seç.</p>',
          checks: [
            { t: '<b>PC-A</b>: IP Address <span class="m">192.168.1.10</span>, Subnet Mask <span class="m">255.255.255.0</span>.' },
            { t: '<b>PC-B</b>: IP Address <span class="m">192.168.1.11</span>, Subnet Mask <span class="m">255.255.255.0</span>.' },
            { t: '<b>PC-C</b>: IP Address <span class="m">192.168.1.12</span>, Subnet Mask <span class="m">255.255.255.0</span>.' },
            { t: 'Default Gateway boş qala bilər: üç PC eyni network-dədir və bir-biri ilə birbaşa danışır.' },
          ],
          button: 'IP-ləri verdim' },

        { id: 's6', title: 'MAC ünvanını oxu', type: 'form',
          body: '<p>PC-A-nın üstünə klik et, <i>Desktop → Command Prompt</i> aç və yaz:</p><pre class="pre"><span class="p">C:\\&gt;</span>ipconfig /all</pre><p><b>Physical Address</b> sətrindəki ünvanı bura yaz. Sonra eyni əmri PC-B-də işlət və onun MAC-ini də yaz. Packet Tracer MAC-i nöqtəli (<span class="m">0001.C7A1.5D32</span>), real Windows isə tire ilə göstərir: hər ikisi qəbul olunur.</p>',
          fields: [
            { label: 'PC-A-nın MAC-i', placeholder: '0001.xxxx.xxxx', check: r => { if (!macOk(r)) return { ok: false, note: '<b style="color:var(--bad)">Düz deyil</b>: Physical Address sətrini olduğu kimi köçür (12 hex rəqəm: 3 qrup nöqtə ilə və ya 6 qrup tire ilə).' }; const o = document.getElementById('s6-f1'); if (o && macKey(o.value) === macKey(r)) return { ok: false, note: '<b style="color:var(--bad)">Düz deyil</b>: bu PC-B ilə eynidir. Hər PC-nin öz MAC-i var: PC-A-da əmri ayrıca işlət.' }; return true; } },
            { label: 'PC-B-nin MAC-i', placeholder: '0001.xxxx.xxxx', check: r => { if (!macOk(r)) return { ok: false, note: '<b style="color:var(--bad)">Düz deyil</b>: Physical Address sətrini olduğu kimi köçür.' }; const a = document.getElementById('s6-f0'); if (a && macKey(a.value) === macKey(r)) return { ok: false, note: '<b style="color:var(--bad)">Düz deyil</b>: bu PC-A ilə eynidir. Hər PC-nin öz MAC-i var: PC-B-də əmri ayrıca işlət.' }; return true; } },
          ],
          hints: ['Command Prompt PC-nin Desktop nişanındadır. Switch-də Command Prompt yoxdur.', '<span class="m">ipconfig</span> yalnız IP göstərir. MAC üçün <span class="m">ipconfig /all</span> lazımdır.'],
          solution: 'PC-A → Desktop → Command Prompt → <span class="m">ipconfig /all</span> → Physical Address sətri. Eyni işi PC-B-də et. İki MAC fərqli olmalıdır.',
          after: '<p>Bu MAC-lər (Layer 2) və yazdığın IP-lər (Layer 3) cihazın iki ünvanıdır. Simulation-da paketdə ikisini də görəcəksən.</p>' },

        { id: 's7', title: 'Əvvəl proqnoz ver', type: 'form',
          body: '<p>Hələ heç bir ping atmamısan: switch-in MAC cədvəli və bütün ARP cache-lər boşdur. PC-A <b>PC-B-yə</b> ilk dəfə ping atacaq. Packet Tracer-də yoxlamazdan əvvəl <b>təxmin et</b>. Say: switch-dən (hər çıxış portu 1 nüsxə) neçə kadr nüsxəsi çıxır.</p>',
          fields: [
            { label: 'ARP request: switch-dən neçə nüsxə çıxır?', placeholder: 'rəqəm', check: r => r.trim() === '2', wrong: 'ARP request broadcast-dır. Gələn port istisna olmaqla hansı portlara flood olunur? Üç PC var.' },
            { label: 'ARP reply: switch-dən neçə nüsxə çıxır?', placeholder: 'rəqəm', check: r => r.trim() === '1', wrong: 'ARP reply unicast-dır. PC-A artıq switch-in cədvəlindədir (öz ARP request-i ilə öyrənilib).' },
            { label: 'ICMP echo request: switch-dən neçə nüsxə çıxır?', placeholder: 'rəqəm', check: r => r.trim() === '1', wrong: 'İndi PC-B-nin MAC-i switch-dədir (ARP reply-dan öyrənilib). Unicast kadr neçə porta gedir?' },
            { label: 'Ping bitəndən sonra switch-in MAC cədvəlində neçə giriş olacaq?', placeholder: 'rəqəm', check: r => r.trim() === '2', wrong: 'Switch yalnız kadr <b>göndərənlərdən</b> öyrənir. Kim göndərdi: PC-A, PC-B və ya PC-C?' },
            { label: 'PC-A-nın ARP cədvəlində neçə giriş olacaq?', placeholder: 'rəqəm', check: r => r.trim() === '1', wrong: 'PC-A ARP ilə neçə cihazın MAC-ini soruşdu?' },
          ],
          hints: ['Hər kadr üçün iki sual ver: broadcast-dırmı və ya unicast, Destination MAC switch-in cədvəlindədirmi?', 'ARP request: broadcast, cədvəl nə olursa olsun flood. ARP reply, echo request, echo reply: unicast, hədəf artıq cədvəldədir.'],
          solution: 'ARP request: broadcast, gələn port istisna 2 port (PC-B və PC-C) = 2. ARP reply: unicast PC-A-ya = 1. Echo request: unicast PC-B-yə = 1. Cədvəldə yalnız göndərənlər: PC-A və PC-B = 2 giriş (PC-C heç nə göndərmədi). PC-A-nın ARP cədvəli: yalnız PC-B = 1.',
          after: '<p>Bu ARP, ping və switch davranışının birgə nəticəsidir: ARP broadcast flood olur, qalan kadrlar unicast. İndi proqnozu Packet Tracer-də yoxlayaq.</p>' },

        { id: 's8', title: 'Simulation-da yoxla', type: 'ptsteps',
          body: '<p>Proqnozunun düzgün olub-olmadığını Packet Tracer-də yoxla.</p>',
          checks: [
            { t: 'Əgər əvvəl ping atmısansa, ARP cache-i silmək üçün PC-A-nın Command Prompt-unda <span class="m">arp -d</span> yaz və switch-in <i>CLI</i> nişanında <span class="m">enable</span>, sonra <span class="m">clear mac address-table dynamic</span> işlət. (Hələ ping atmamısansa, bu addımı keç.)' },
            { t: 'Sağ altda <b>Simulation</b> rejiminə keç.' },
            { t: '<b>Edit Filters</b> aç: əvvəl hamısını söndür, sonra yalnız <b>ARP</b> və <b>ICMP</b> işarələ.' },
            { t: 'Sağdakı <b>Add Simple PDU</b> alətini (zərf) seç. Əvvəl <b>PC-A</b>-ya, sonra <b>PC-B</b>-yə klik et.' },
            { t: '<b>Capture / Forward</b> düyməsini bas və hər addımda zərfin harada olduğuna bax. ARP request switch-dən çıxanda neçə zərf var? Proqnozunla müqayisə et.' },
            { t: 'Dörd paket tamamlanana qədər get: ARP request, ARP reply, ICMP echo request, ICMP echo reply. Sağ alt <b>User Created Packet Window</b>-da PDU-nun statusunun <b>Successful</b> olduğunu yoxla.' },
          ],
          button: 'Simulation-da izlədim' },

        { id: 's9', title: 'Zərfin içinə bax', type: 'form',
          body: '<p>Event List-də və ya iş sahəsində <b>ARP request</b> zərfinin üstünə klik et: <b>PDU Information</b> açılır. <i>Outbound PDU Details</i> nişanına keç və Layer 2 (Ethernet) sahələrinə bax. Sonra eyni işi ARP reply və ICMP echo request üçün et.</p>',
          fields: [
            { label: 'ARP request-in Layer 2 Destination MAC-i', placeholder: 'ünvan', check: r => macKey(r) === 'ffffffffffff', wrong: 'Hədəfin MAC-i hələ məlum deyil, ARP broadcast göndərilir. Broadcast MAC nədir?' },
            { label: 'ARP reply-ın Destination MAC-i kimin MAC-idir? (PC-A, PC-B və ya PC-C)', placeholder: 'cihaz adı', check: r => /^(pc[\s-]?)?a$/i.test(r.trim()), wrong: 'ARP reply unicast-dır: soruşana qayıdır. ARP request-i kim göndərmişdi?' },
            { label: 'Echo request-in Destination MAC-i broadcast idi? (bəli / xeyr)', placeholder: 'bəli / xeyr', answers: ['xeyr', 'yox', 'no', 'xeyir'], wrong: 'Bu nöqtədə PC-A, PC-B-nin MAC-ini artıq bilir (ARP reply-dan). Ona görə kadr kimə ünvanlanır?' },
          ],
          hints: ['PDU Information-da <b>Outbound PDU Details</b> hissəsində Ethernet başlığının "DEST ADDR" sahəsinə bax.', 'Packet Tracer-in versiyasında sahə adı bir qədər fərqli ola bilər: Layer 2 / Ethernet II başlığını tap.'],
          solution: 'ARP request: FFFF.FFFF.FFFF (broadcast). ARP reply: PC-A-nın MAC-i (unicast, ARP request-i PC-A göndərmişdi). Echo request: PC-B-nin MAC-i (unicast), broadcast deyil.',
          after: '<p>Sən nəzəriyyədə öyrəndiyin qaydanı paketin içində gördün: ARP broadcast ilə başlayır, qalanı unicast olur.</p>' },

        { id: 's10', title: 'Inspect ilə cədvəllərə bax', type: 'form',
          body: '<p>Ping tamamlandıqdan sonra cədvəllərə bax. <b>Inspect</b> alətini (böyüdücü) seç və PC-A-ya klik edib <i>ARP Table</i>, switch-ə klik edib <i>MAC Table</i> aç. Əmrlə də baxa bilərsən: PC-A-da <span class="m">arp -a</span>, switch CLI-da <span class="m">show mac address-table</span>.</p>',
          fields: [
            { label: 'Switch-in MAC cədvəlində neçə giriş var?', placeholder: 'rəqəm', check: r => r.trim() === '2', wrong: 'Kim kadr göndərdi? Əgər başqa rəqəm görürsənsə, əvvəl başqa ping atmış ola bilərsən: cədvəli silib təkrar et.' },
            { label: 'PC-A-nın ARP cədvəlində neçə giriş var?', placeholder: 'rəqəm', check: r => r.trim() === '1', wrong: 'PC-A kimin MAC-ini soruşdu? Başqa rəqəm görürsənsə, başqa PC-yə də ping atmış ola bilərsən.' },
            { label: 'PC-C switch-in MAC cədvəlindədir? (bəli / xeyr)', placeholder: 'bəli / xeyr', answers: ['xeyr', 'yox', 'no', 'xeyir'], wrong: 'Switch yalnız kadr göndərənlərdən öyrənir. PC-C kadr göndərdimi? (O, ARP request-i yalnız aldı.)' },
          ],
          hints: ['Switch yalnız <b>Source MAC</b>-dən öyrənir.', 'ARP cədvəli yalnız PC-nin özünün soruşduğu (və ya aldığı sorğuya cavab verdiyi) cihazları saxlayır.'],
          solution: 'Switch-in cədvəli: PC-A və PC-B (2 giriş). PC-A-nın ARP cədvəli: yalnız PC-B (1 giriş). PC-C heç nə göndərmədi, ona görə switch-də yoxdur.',
          after: '<p>Cədvəl <b>sübutdur</b>. "PC-C cədvəldə yoxdur" xəta deyil, nəticədir: switch onu hələ "eşitməyib". Cədvəl hadisədən sonra dəyişir, ona görə hər dəfə əvvəl və sonra bax.</p>' },

        { id: 's11', title: 'Ticket 1: heç nə hərəkət etmir', type: 'choice',
          body: '<p>Tələbə Simulation rejimindədir. <b>Add Simple PDU</b> ilə PC-A-dan PC-B-yə PDU yaradıb. İş sahəsində PC-A-nın üstündə zərf görünür, amma on dəqiqədir heç nə hərəkət etmir, Event List isə yalnız bir sətirdir. Tələbə şikayət edir: "Packet Tracer donub". Əvvəl nəyi yoxlayırsan?</p>',
          options: [
            { t: 'Capture / Forward basılıb? Simulyasiya sənin addımını gözləyir.', ok: true, why: 'Simulation rejimində zərf özü getmir: simulyasiya hər addımı sənin əmrinlə icra edir. Capture / Forward bir addım, Auto Capture / Play isə davamlı irəli aparır. Packet Tracer donmayıb, gözləyir.' },
            { t: 'PC-B-nin IP ünvanını dəyiş, çünki zərf səhv IP-yə görə dayanıb və getmir.', why: 'Səhv IP olsa belə zərf hərəkət edərdi (və sonra uğursuz olardı). Zərfin yerindən tərpənməməsi IP ilə yox, simulyasiyanın gözləməsi ilə bağlıdır.' },
            { t: 'Switch-in portlarını yoxla, çünki zərf link olmadığı üçün başlamayıb və dayanıb.', why: 'Link olmasa zərf hərəkət edər, amma yolda itər. Burada zərf heç başlamayıb: simulyasiya addım gözləyir.' },
            { t: 'Proqramı bağla və yenidən aç, çünki Simulation rejimi donub və cavab vermir.', why: 'Packet Tracer-i bağlamaq həll deyil və işi itirə bilərsən. Əvvəl simulyasiya düymələrini yoxla.' },
          ],
          hints: ['Simulation rejimində vaxtı kim idarə edir?'],
          after: '<p>Realtime-da hər şey öz-özünə gedir. Simulation-da isə <b>sən</b> irəli aparırsan. Bu fərqi bilməmək ən çox qarşılaşılan "yeni başlayan" problemidir.</p>' },

        { id: 's12', title: 'Ticket 2: yeni linkdə ilk ping itdi', type: 'choice',
          body: '<p>Tələbə yeni PC-ni switch-ə qoşdu və saniyələr sonra ilk ping-i atdı: <span class="m">Request timed out</span>. Bax: switch tərəfdəki link işığı <b>narıncıdır</b>. Ən məntiqli hərəkət nədir?</p>',
          options: [
            { t: 'Fast Forward Time bas və ya yarım dəqiqə gözlə, işıq yaşıl olandan sonra yenidən ping at.', ok: true, why: 'Narıncı switch portunun hələ kadr ötürmədiyini göstərir: port əvvəl loop yoxlaması aparır. Gözləyəndən sonra link yaşıl olur və ping işləyir. Kabel və IP ilə bağlı heç nə etməyə ehtiyac yoxdur.' },
            { t: 'Kabeli çıxarıb yenisini qoş, çünki narıncı kabelin xarab olduğunu göstərir.', why: 'Xarab kabel qırmızı link verir. Narıncı müvəqqətidir, kabelin nasazlığı yox, portun hazırlıq mərhələsidir.' },
            { t: 'PC-nin IP-sini dəyişir və yenidən ping atırsan, çünki link rəngi IP-yə bağlıdır.', why: 'Link işığı Layer 1 haqqındadır, IP Layer 3-dür. IP-nin dəyişməsi link rəngini dəyişməz.' },
            { t: 'Switch-i silib yenisini qoyursan, çünki yeni port işləmir.', why: 'Port işləyir, sadəcə hazır olmayıb. Yeni switch qoysan da yeni port yenə eyni gözləmədən keçəcək.' },
          ],
          hints: ['Narıncı "qırıq" demək deyil. Qırmızı nə demək idi?'],
          after: '<p>Metod: <b>əvvəl link işığına bax</b>. Qırmızı: Layer 1 problemi. Narıncı: gözlə. Yaşıl: Layer 1 hazırdır, ping alınmırsa daha yuxarı layer-ə (IP, mask) keç.</p>' },

        { id: 's13', title: 'Ad səhvi: Display Name və hostname', type: 'choice',
          body: '<p>Tələbə switch-in Display Name-ini <b>SW1</b> etdi (Config nişanı). Sonra <i>CLI</i> nişanını açdı və görür ki, prompt hələ də <span class="m">Switch&gt;</span>-dir. Tələbə deyir: "Ad saxlanmayıb". Nə baş verir?</p>',
          options: [
            { t: 'Display Name yalnız etiketdir. Prompt-dakı ad hostname-dir və CLI-da ayrıca dəyişir.', ok: true, why: 'İki ayrı ad var: iş sahəsində görünən Display Name (Packet Tracer etiketi) və cihazın öz konfiqurasiyasındakı hostname (CLI prompt-u). Biri digərini avtomatik dəyişmir. Hostname CLI-da dəyişir.' },
            { t: 'Ad saxlanmayıb: Packet Tracer faylını bağlayıb yenidən açmaq lazımdır, ad yenilənəcək.', why: 'Display Name saxlanıb: iş sahəsində SW1 görünür. Prompt başqa addır, fayl yenidən açılsa da dəyişməyəcək.' },
            { t: 'Switch yenidən yüklənməlidir ki, yeni ad prompt-a keçsin və cihaz yeniləsin.', why: 'Reload hostname-i dəyişmir. Hostname-i yalnız konfiqurasiyada dəyişdirsən (hostname əmri) prompt dəyişir.' },
            { t: 'Switch-lərin adı dəyişdirilə bilməz, prompt həmişə Switch qalır və dəyişməz.', why: 'Hostname dəyişdirilə bilər, bu cihazın adının standart təyin olunma üsuludur. Sadəcə bunu Config tabından yox, CLI-dan edirsən.' },
          ],
          hints: ['Config tabındakı ad ilə CLI prompt-undakı ad eyni yerdə saxlanır?'],
          after: '<p>İş yerində ad çox vacibdir: monitoring, log və xəbərdarlıqlar cihazı <b>hostname</b> ilə göstərir, qrafik etiketlə yox. Ona görə hostname-i həmişə CLI-da düzgün qur.</p>' },
      ],
    },

    quiz: {
      draw: 8,
      gens: [
        // flood copy count with some links down, or a known unicast
        () => {
          const L = ['A', 'B', 'C', 'D', 'E', 'F']; const n = rnd(4, 6); const hosts = L.slice(0, n).map(x => 'PC-' + x);
          const kind = pick(['arp', 'aged', 'known']);
          const src = hosts[R(n)]; let dst; do { dst = hosts[R(n)]; } while (dst === src);
          const others = hosts.filter(h => h !== src && h !== dst); const dn = kind === 'known' ? 0 : R(3);
          const down = shuffle(others).slice(0, Math.min(dn, others.length));
          const up = n - down.length; const ans = kind === 'known' ? 1 : up - 1;
          const downTxt = down.length ? ' ' + down.join(' və ') + (down.length > 1 ? ' PC-lərinin kabelləri çıxarılıb' : ' PC-sinin kabeli çıxarılıb') + ' (linklər qırmızıdır).' : ' Bütün linklər yaşıldır.';
          const head = '<p>Switch-ə ' + n + ' PC qoşulub: ' + hosts.join(', ') + '.' + downTxt + '</p>';
          let ctx, q, sol;
          if (kind === 'arp') {
            ctx = '<p>Switch-in MAC cədvəli və ARP cache-lər boşdur. <b>' + src + '</b> ilk dəfə <b>' + dst + '</b>-yə ping atır və ARP request göndərir.</p>';
            q = 'ARP request switch-dən neçə nüsxə çıxır (hər çıxış portu 1 nüsxə)?';
            sol = 'ARP request broadcast-dır, ona görə switch onu <b>flood</b> edir: gələn port istisna, linki işləyən bütün portlara. Linki işləyən PC sayı ' + up + ', onlardan göndərən ' + src + ' çıxılır: ' + up + ' − 1 = <b>' + ans + '</b>.' + (down.length ? ' Kabeli çıxarılan PC-lərin portu down olduğu üçün oraya nüsxə getmir.' : '');
          } else if (kind === 'aged') {
            ctx = '<p><b>' + src + '</b>-in ARP cache-ində <b>' + dst + '</b> var, amma switch-in cədvəlində <b>' + dst + '</b>-in girişi aging səbəbindən silinib (' + src + '-in özünün girişi var). ' + src + ' ' + dst + '-ə ICMP echo request göndərir.</p>';
            q = 'Echo request switch-dən neçə nüsxə çıxır (hər çıxış portu 1 nüsxə)?';
            sol = 'Destination MAC (' + dst + ') cədvəldə yoxdur: unknown unicast, switch <b>flood</b> edir. Linki işləyən ' + up + ' port, göndərən çıxılır: ' + up + ' − 1 = <b>' + ans + '</b>.' + (down.length ? ' Down portlara nüsxə getmir.' : '');
          } else {
            ctx = '<p>Switch-in MAC cədvəlində bütün PC-lərin girişi var. <b>' + src + '</b> <b>' + dst + '</b>-ə ICMP echo request göndərir.</p>';
            q = 'Echo request switch-dən neçə nüsxə çıxır (hər çıxış portu 1 nüsxə)?';
            sol = 'Destination MAC (' + dst + ') cədvəldə var və başqa portdadır: <b>forward</b>, yalnız həmin porta. Cavab: <b>1</b>, PC sayından asılı deyil.';
          }
          return { id: 'p1t8-g-flood-' + kind, concept: 'sim-read', obj: 'Switch-dən çıxan nüsxələr', type: 'num', _meta: { kind, n, up, ans, src, dst, down }, stem: head + ctx + '<p>' + q + '</p>', placeholder: 'rəqəm', check: r => r.trim() === String(ans), solution: sol };
        },
        // total frame copies across a ping sequence
        () => {
          const L = ['A', 'B', 'C', 'D', 'E']; const n = rnd(4, 5); const hosts = L.slice(0, n).map(x => 'PC-' + x);
          const nPairs = rnd(2, 3); const used = []; const pairs = [];
          let guard = 0;
          while (pairs.length < nPairs && guard++ < 200) {
            const a = hosts[R(n)]; const b = hosts[R(n)]; if (a === b) continue;
            const key = [a, b].sort().join('|'); if (used.includes(key)) continue; used.push(key); pairs.push([a, b]);
          }
          const seq = pairs.map(p => p.slice()); const repeat = R(2) === 0 ? 1 : 0;
          if (repeat) { const pi = R(pairs.length); const at = rnd(pi + 1, seq.length); seq.splice(at, 0, pairs[pi].slice()); }
          const ans = pairs.length * (n + 2) + repeat * 2;
          const lines = seq.map((p, i) => (i + 1) + '.  ' + p[0] + ' → ' + p[1]).join('\n');
          return { id: 'p1t8-g-seq', concept: 'sim-read', obj: 'Ping ardıcıllığında kadr nüsxələri', type: 'num', _meta: { n, seq, ans, pairs: pairs.length, repeat }, placeholder: 'rəqəm',
            stem: '<p>Switch-ə ' + n + ' PC qoşulub: ' + hosts.join(', ') + '. Hamısının linki yaşıldır. Switch-in MAC cədvəli və bütün ARP cache-lər <b>boşdur</b>. Aşağıdakı ping-lər ardıcıllıqla atılır və hər biri uğurla bitir:</p><pre class="pre">' + lines + '</pre><p>Başqa trafik yoxdur. Bütün ping-lər bitəndən sonra switch-dən çıxan kadr nüsxələrinin <b>cəmi</b> neçədir? ARP request, ARP reply, echo request və echo reply say. Hər çıxış portu 1 nüsxə sayılır.</p>',
            check: r => r.trim() === String(ans),
            solution: 'Hər <b>yeni</b> cüt (cüt = kim kimə) üçün: ARP request flood olur (' + (n - 1) + ' nüsxə), ARP reply unicast (1), echo request (1), echo reply (1) = ' + (n + 2) + '. Yeni cüt sayı: ' + pairs.length + ' → ' + pairs.length + ' × ' + (n + 2) + ' = ' + pairs.length * (n + 2) + '.' + (repeat ? ' Təkrar ping: ARP cache və switch cədvəli artıq doludur, yalnız echo request və reply = 2 nüsxə.' : '') + ' Cəmi <b>' + ans + '</b>.' };
        },
      ],
      pool: [
        { id: 'p1t8-q1', concept: 'modes', obj: 'Realtime və Simulation',
          stem: '<p>ARP request-in switch-dən hansı portlara çıxdığını addım-addım görmək istəyirsən. Hansı rejimdə işləyirsən?</p>',
          options: [
            { t: 'Simulation: paketlər addım-addım gedir, hər zərfə baxırsan.', ok: true, why: 'Paketin yolunu və hər cihazda nə baş verdiyini yalnız Simulation-da, Capture / Forward ilə addım-addım görürsən.' },
            { t: 'Realtime: şəbəkə real vaxtda işlədiyi üçün hər paketi görürsən.', why: 'Realtime-da paket dərhal çatır və yalnız nəticə görünür (məsələn ping cavabı). Aralıq addımlar və zərflər görünmür.' },
            { t: 'Realtime, amma Fast Forward Time ilə sürəti azaldırsan.', why: 'Fast Forward Time simulyasiya vaxtını sürətləndirir, yavaşlatmır. Üstəlik Realtime-da zərflər yoxdur.' },
            { t: 'Hər iki rejim eyni şeyi göstərir, fərq yalnız düymələrin yerindədir.', why: 'Fərq mahiyyətlidir: Realtime nəticəni, Simulation isə paketin yolunu göstərir.' },
          ] },
        { id: 'p1t8-q2', concept: 'cables', obj: 'Kabel növü',
          stem: '<p>İki PC-ni switch olmadan birbaşa Ethernet kabeli ilə birləşdirirsən. Klassik qaydaya görə hansı kabel düzgündür?</p>',
          options: [
            { t: 'Copper Cross-Over: eyni növ cihazlar (PC–PC) bu kabellə birləşir.', ok: true, why: 'Klassik qayda: eyni növ cihazlar cross-over ilə, fərqli növlər straight-through ilə birləşir. İki PC eyni növdür.' },
            { t: 'Copper Straight-Through, çünki hər halda Ethernet kabeli straight-through olur.', why: 'Straight-through fərqli növ cihazlar üçündür (PC–switch). Eyni növ cihazlarda klassik qayda cross-over-dir.' },
            { t: 'Console: iki cihazı birləşdirən kabeldir.', why: 'Console idarəetmə kabelidir, Ethernet linki yaratmır və məlumat kadrı daşımır.' },
            { t: 'Heç biri: iki PC switch olmadan birləşə bilməz.', why: 'Birləşə bilər: iki cihaz arasında birbaşa link mümkündür. Switch lazım deyil. (Müasir cihazlarda Auto-MDI/X kabelin növünü özü uyğunlaşdıra bilir.)' },
          ] },
        { id: 'p1t8-q3', concept: 'lights', obj: 'Link işığı',
          stem: '<p>Yeni switch-ə PC qoşdun. 5 saniyə sonra switch tərəfdəki link işığı <b>narıncıdır</b>. Ən məntiqli hərəkət nədir?</p>',
          options: [
            { t: 'Fast Forward Time bas və ya gözlə, sonra işığa yenidən bax.', ok: true, why: 'Narıncı portun hələ kadr ötürmədiyini göstərir: port əvvəl loop yoxlaması aparır. Gözləyəndən sonra yaşıl olur.' },
            { t: 'Kabeli dərhal dəyişirsən, çünki narıncı kabelin qırıq olduğunu göstərir.', why: 'Qırıq kabel qırmızı link verir. Narıncı müvəqqətidir və portun hazırlıq mərhələsini göstərir.' },
            { t: 'PC-nin IP ünvanını yoxlayırsan, çünki link işığı IP ilə bağlıdır.', why: 'Link işığı Layer 1 haqqındadır, IP isə Layer 3-dür. IP düzgün və ya səhv olsa belə link rəngi dəyişməz.' },
            { t: 'Switch-i silib yenisini qoyursan.', why: 'Port nasaz deyil, sadəcə hazır olmayıb. Yeni switch-in yeni portu eyni gözləmədən keçəcək.' },
          ] },
        { id: 'p1t8-q4', concept: 'access', obj: 'Pəncərə seçimi',
          stem: '<p>PC-A-dan PC-B-yə <span class="m">ping</span> atmaq istəyirsən. Hansı pəncərəni açırsan?</p>',
          options: [
            { t: 'PC-A → Desktop → Command Prompt: ping orada yazılır.', ok: true, why: 'PC-lərin əmr xətti Desktop nişanındakı Command Prompt-dur: ping, ipconfig, arp, tracert orada işləyir.' },
            { t: 'PC-A → CLI: bütün Cisco əmrləri, o cümlədən ping, orada yazılır.', why: 'PC-lərdə CLI nişanı yoxdur. CLI switch və router-dədir.' },
            { t: 'PC-A → Config: ping orada qrafik düymə ilə atılır.', why: 'Config nişanı ayarlar formasıdır (ad, IP, gateway). Ping əmri Command Prompt-dadır.' },
            { t: 'Switch → CLI: ping oradan PC-A adına atılır.', why: 'Switch CLI-ında yazılan əmr switch-in özündən çıxır, PC-A-dan yox. PC-A-dan ping üçün PC-A-nın öz pəncərəsi lazımdır.' },
          ] },
        { id: 'p1t8-q5', concept: 'access', obj: 'Display Name və hostname',
          stem: '<p>Switch-in Display Name-ini SW1 etdin. CLI-ı açanda prompt hələ də <span class="m">Switch&gt;</span> göstərir. Niyə?</p>',
          options: [
            { t: 'Display Name yalnız etiketdir. Prompt-dakı ad hostname-dir və CLI-da ayrıca dəyişir.', ok: true, why: 'İki ayrı ad var: iş sahəsində görünən Display Name və cihazın öz konfiqurasiyasındakı hostname. Biri digərini dəyişmir.' },
            { t: 'Packet Tracer ad dəyişikliyini yadda saxlamayıb, fayl yenidən açılmalıdır.', why: 'Ad saxlanıb: iş sahəsində SW1 görünür. Sadəcə iki ad iki ayrı yerdədir.' },
            { t: 'Prompt həmişə Switch olaraq qalır, hostname dəyişdirilə bilməz.', why: 'Hostname dəyişdirilir: CLI-da hostname əmri ilə.' },
            { t: 'Switch yenidən yüklənməlidir ki, ad prompt-a keçsin.', why: 'Reload Display Name-i hostname-ə çevirmir, bunlar ayrı ayarlardır.' },
          ] },
        { id: 'p1t8-q6', concept: 'sim-read', obj: 'Flood və down port',
          stem: '<p>Switch-ə dörd PC qoşulub (A, B, C, D). D-nin kabeli çıxarılıb, linki qırmızıdır. Switch-in MAC cədvəli boşdur. A ARP request göndərir. Switch-dən neçə nüsxə çıxır?</p>',
          options: [
            { t: '2 nüsxə: B və C portlarına.', ok: true, why: 'ARP request broadcast-dır: switch gələn port istisna, linki işləyən bütün portlara göndərir. B və C. D-nin portu down olduğu üçün oraya çıxış yoxdur.' },
            { t: '3 nüsxə: B, C və D portlarına.', why: 'D-nin kabeli çıxarılıb, port down-dır. Kadr link olmayan porta göndərilə bilməz.' },
            { t: '1 nüsxə: yalnız hədəf PC-yə.', why: 'Cədvəl boşdur, hədəfin yeri bilinmir. Üstəlik ARP request broadcast-dır, unicast kimi göndərilmir.' },
            { t: '0 nüsxə: cədvəl boşdur, switch hara göndərəcəyini bilmir və kadrı atır.', why: 'Bilməmək atmaq demək deyil: switch bilinməyən və broadcast kadrı flood edir. Atmaq yalnız filter halında olur.' },
          ] },
        { id: 'p1t8-q7', concept: 'modes', obj: 'İlk ping və ARP',
          stem: '<p>Realtime rejimində yeni qurulmuş şəbəkədə PC-A PC-B-yə ilk dəfə <span class="m">ping</span> atır. Nəticə: birinci paket <span class="m">Request timed out</span>, qalan üç paket uğurlu. Ən ehtimal səbəb nədir?</p>',
          options: [
            { t: 'İlk paket ARP-ı gözləyir: PC-B-nin MAC-i hələ öyrənilməyib.', ok: true, why: 'Echo request üçün Destination MAC lazımdır. İlk ping-də PC-A bunu ARP ilə öyrənir və bu vaxt itir. MAC ARP cache-ə düşəndən sonra sonrakı paketlər dərhal gedir.' },
            { t: 'Kabel qırıqdır, ona görə bəzi paketlər yolda itir və yenidən gəlmir.', why: 'Qırıq kabel bütün paketləri itirərdi. Sonrakı üç paketin uğurlu olması kabelin sağlam olduğunu göstərir.' },
            { t: 'Subnet mask səhvdir, ona görə PC-B şəbəkədən kənarda görünür.', why: 'Səhv mask paketlərin hamısına eyni cür təsir edərdi, yalnız birinciyə yox.' },
            { t: 'TTL birinci paketdə bitir, çünki switch-lər TTL-i azaldır.', why: 'TTL router-lərdə azalır, bu şəbəkədə yalnız switch var. Üstəlik hər paket eyni TTL ilə başlayır.' },
          ] },
        { id: 'p1t8-q8', concept: 'inspect', obj: 'Cədvəldən nəticə',
          stem: '<p>PC-A PC-B-yə ping atdı və ping uğurlu oldu. Inspect ilə switch-in MAC Table-ına baxırsan: PC-A və PC-B var, <b>PC-C yoxdur</b>. PC-C eyni switch-ə qoşulub, linki yaşıldır. Bu nəyi göstərir?</p>',
          options: [
            { t: 'Normaldır: PC-C hələ heç nə göndərməyib, switch isə yalnız göndərənlərdən öyrənir.', ok: true, why: 'Switch Source MAC-dən öyrənir. PC-C ARP request-in nüsxəsini aldı, amma cavab vermədi və heç nə göndərmədi. Göndərməyənin girişi olmur.' },
            { t: 'PC-C-nin kabeli və ya portu xarabdır, çünki cədvəldə yoxdur.', why: 'Linki yaşıldır, Layer 1 sağlamdır. Cədvəldə yoxluq xəta yox, PC-C-nin susması nəticəsidir.' },
            { t: 'Switch broadcast kadrdan öyrənmir, PC-C isə yalnız broadcast aldığı üçün cədvəldə yoxdur.', why: 'Switch broadcast kadrın Source MAC-indən də öyrənir (məsələn PC-A ARP request ilə öyrənildi). PC-C-nin yoxluğu onun heç nə göndərməməsindəndir.' },
            { t: 'Switch-in cədvəli doldu və PC-C üçün yer qalmadı.', why: 'Cədvəl minlərlə giriş saxlayır, iki giriş onu doldurmaz.' },
          ] },
        { id: 'p1t8-q9', concept: 'sim-read', obj: 'Simulation gözləyir',
          stem: '<p>Simulation rejimində Add Simple PDU ilə paket yaratdın. Zərf PC-A-nın üstündə görünür, amma heç nə hərəkət etmir. Ən ehtimal izah nədir?</p>',
          options: [
            { t: 'Simulyasiya addım gözləyir: Capture / Forward və ya Auto Capture / Play bas.', ok: true, why: 'Simulation rejimində zərf özü getmir. Vaxtı sən idarə edirsən: Capture / Forward bir addım, Auto Capture / Play davamlı irəli aparır.' },
            { t: 'PC-lərdən birinin IP-si və ya mask-ı səhvdir, ona görə paket çıxmır.', why: 'Səhv IP olsa belə zərf hərəkət edərdi, sonra uğursuz olardı. Zərfin yerindən tərpənməməsi rejimin gözləməsidir.' },
            { t: 'Switch-in portlarından biri qırmızıdır və kadr oradan keçə bilmir.', why: 'Qırmızı link zərfin hərəkət etməsinə mane olmaz: zərf başlayardı, yolda itərdi.' },
            { t: 'Packet Tracer donub, proqramı bağlayıb yenidən açmaq lazımdır, rejim işləmir.', why: 'Proqram donmayıb, gözləyir. Bağlamaq işi itirə bilər: əvvəl simulyasiya düymələrini yoxla.' },
          ] },
        { id: 'p1t8-q10', concept: 'what-pt', obj: 'Real və simulyator',
          stem: '<p>Packet Tracer-də bir əmr gözlədiyin nəticəni verdi. Real Cisco cihazında eyni olacağına nə dərəcədə əmin ola bilərsən?</p>',
          options: [
            { t: 'Mexanizmi başa düşmüsən, amma əmin deyilsən: PT IOS-u təqlid edir, real cihazda yoxla.', ok: true, why: 'Əsas mexanizmlər (ARP, switching, routing məntiqi) eynidir, amma bəzi əmrlər və çıxışlar Packet Tracer-də fərqlənir və ya yoxdur. Əmin olmaq üçün rəsmi sənəd və ya real cihaz lazımdır.' },
            { t: 'Tam əminsən: Packet Tracer-də real cihazda işləyən eyni IOS işləyir, fərq yoxdur.', why: 'Packet Tracer real IOS imici deyil, onun təqlididir. Bəzi əmrlər və çıxışlar fərqlənir.' },
            { t: 'Heç əmin deyilsən: Packet Tracer-də öyrəndiyin heç bir şey real şəbəkəyə aid deyil.', why: 'Mexanizmlər real həyatdakı kimidir. Fərq detallardadır, ona görə Packet Tracer öyrənmək üçün yaxşı vasitədir.' },
            { t: 'Yalnız switch əmrləri real cihazla eynidir, router əmrləri isə tamam fərqlidir.', why: 'Belə bölgü yoxdur: hər cihaz növündə fərqlənən fərdi əmrlər ola bilər.' },
          ] },
        { id: 'p1t8-q11', concept: 'sim-read', obj: 'ARP request Layer 2',
          stem: '<p>Simulation-da ARP request zərfini açdın və <i>Outbound PDU Details</i>-ə baxırsan. Ethernet başlığında <b>Destination MAC</b> nə olmalıdır?</p>',
          options: [
            { t: 'FFFF.FFFF.FFFF: ARP request broadcast-dır, hədəfin MAC-i hələ məlum deyil.', ok: true, why: 'ARP-ın məqsədi MAC-i tapmaqdır. MAC hələ məlum olmadığı üçün kadr broadcast ünvana (hamıya) göndərilir.' },
            { t: 'PC-B-nin MAC-i: ARP request kadrı birbaşa hədəfə ünvanlanmalıdır.', why: 'PC-A PC-B-nin MAC-ini bilsəydi, ARP lazım olmazdı. Məhz bilmədiyi üçün sorğu göndərir.' },
            { t: 'Switch-in MAC-i: kadr əvvəl switch-ə ünvanlanır, sonra o ötürür.', why: 'Switch kadrı ötürür, ona ünvanlanmır. Kadr switch-dən keçəndə Destination MAC dəyişmir.' },
            { t: '0000.0000.0000: hədəf ünvan hələ məlum olmadığı üçün sıfırdır.', why: 'ARP başlığının daxilində Target MAC sahəsi sıfırlarla doldurulur, amma Ethernet başlığının Destination MAC-i broadcast-dır: kadr onunla göndərilir.' },
          ] },
      ],
    },
  });
})();
