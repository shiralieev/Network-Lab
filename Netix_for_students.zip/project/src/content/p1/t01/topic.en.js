(function () {
  const A = PT.addr; const bin8 = n => n.toString(2).padStart(8, '0');
  const MAC_OK = raw => !!A.macParse(raw);
  const strip = raw => String(raw).toLowerCase().replace(/[^0-9a-f]/g, '');

  PT.topicEn({
    id: 'p1t1',
    objectives: [
      'Explain what a MAC address and an IP address each do, and why a device needs both',
      'Read a MAC address: find the OUI (the manufacturer) and recognize the three formats',
      'Convert an IPv4 address from decimal to binary and back',
      'Recognize private, loopback and APIPA addresses and read the output of ipconfig /all',
    ],
    explain: PT.frag['p1/t01/explain.en'], cheat: PT.frag['p1/t01/cheat.en'],

    lab: {
      title: 'Lab 2: Find, read and convert addresses',
      goal: 'Find the MAC and IP address on your own computer, convert addresses to binary and read the ipconfig output.',
      why: 'In helpdesk and SOC work, every investigation starts with finding a device by its IP and MAC address. You need to read these addresses fast.',
      minutes: 30,
      finish: 'You can find and read addresses. On to the quiz: every question is picked fresh, and you see why the wrong options are wrong too.',
      steps: [
        { id: 's1', title: 'Get ready: open the command prompt', type: 'info', button: 'I opened it, continue',
          body: '<p>You start this lab on your own computer. <b>Windows</b>: press <span class="m">Win + R</span>, type <span class="m">cmd</span>, press Enter. <b>macOS</b>: the Terminal app. <b>Linux</b>: a terminal.</p><p>Type <span class="m">ipconfig /all</span> on Windows, <span class="m">ifconfig</span> on macOS, <span class="m">ip addr</span> on Linux. In the output, find the <b>MAC</b>, <b>IPv4</b>, <b>mask</b> and <b>gateway</b> lines.</p>' },
        { id: 's2', title: 'Find the addresses on your own computer', type: 'form',
          body: '<p>Run the command and type the values of the active network adapter (Ethernet or Wi-Fi) below. Skip VPN and virtual adapters: they are not your main connection.</p>',
          fields: [
            { label: 'Your MAC address (Physical Address)', placeholder: 'e.g. 3C-52-82-AA-10-5B', check: MAC_OK, wrong: 'It has to be 12 hex digits (with dashes, colons or dots).' },
            { label: 'Your IPv4 address', placeholder: 'e.g. 192.168.1.37', check: raw => A.isIp(raw), wrong: '4 octets, each from 0 to 255 (e.g. 192.168.1.37).' },
            { label: 'Subnet mask', placeholder: 'e.g. 255.255.255.0', check: raw => PT.ios.isMask(raw.trim()), wrong: 'A mask is a row of 1s followed by 0s (e.g. 255.255.255.0).' },
            { label: 'Default gateway', placeholder: 'e.g. 192.168.1.1', check: raw => A.isIp(raw), wrong: 'The gateway is an IPv4 address too. Sometimes it is empty, but at home or in an office it should be filled in.' },
          ],
          hints: ['On Windows type <span class="m">ipconfig /all</span> and scroll down. There can be many adapters; look under "Ethernet adapter" or "Wireless LAN adapter Wi-Fi".', 'The MAC is on the "Physical Address" line. The IPv4 line may end with "(Preferred)": do not type that, only the numbers.'],
          after: '<p>These four values are the raw material of the next topics. Check: is your IP address in a <b>private</b> range (192.168.x.x, 10.x.x.x or 172.16–31.x.x)? Compare it with a "what is my IP" website: the address shown there is your <b>public</b> address, and it is different. You learn why in a later part.</p>' },
        { id: 's3', title: 'Decimal to binary', type: 'form',
          body: '<p>Bit weights: <span class="m">128 64 32 16 8 4 2 1</span>. Convert every octet of <b>172.16.5.130</b> to binary and type the whole address in groups of 8 (with dots or spaces).</p>',
          fields: [{ label: '172.16.5.130 in binary', placeholder: '________.________.________.________', check: raw => raw.replace(/[\s.]/g, '') === '10101100000100000000010110000010', wrong: 'Every octet has to be exactly 8 bits. 172 = 128+32+8+4, 16 = 16, 5 = 4+1, 130 = 128+2.' }],
          hints: ['172: 128 fits (1), 44 left. 64 does not fit (0). 32 fits (1), 12 left. 16 does not fit (0). 8 fits (1), 4 left. 4 fits (1). 2 and 1 do not fit.', 'Write 8 bits for every octet. 16 = 00010000, 5 = 00000101.'],
          solution: '172 = 10101100, 16 = 00010000, 5 = 00000101, 130 = 10000010. Whole address: 10101100.00010000.00000101.10000010',
          after: '<p>The method: for every weight you ask "does it fit into what is left?". If it does, you write 1 and subtract.</p>' },
        { id: 's4', title: 'Binary to decimal', type: 'form',
          body: '<p>Convert this binary address to decimal form: <span class="m">11000000.10101000.00001010.00000001</span></p>',
          fields: [{ label: 'Decimal address', placeholder: 'a.b.c.d', check: raw => raw.trim() === '192.168.10.1', wrong: 'In every octet, add up the weights of the bits that are 1.' }],
          hints: ['First octet 11000000: only the 128 and 64 bits are 1.', 'Second octet 10101000 = 128 + 32 + 8 = 168.'],
          solution: '11000000 = 128+64 = 192; 10101000 = 128+32+8 = 168; 00001010 = 8+2 = 10; 00000001 = 1. Answer: 192.168.10.1' },
        { id: 's5', title: 'Which "private" address is really public?', type: 'spot',
          body: '<p>A colleague wrote a list of the company\'s internal servers and called all of them "private". <b>One address is outside the private ranges.</b> Find it.</p>',
          lines: [
            { t: 'File server      10.20.5.14' },
            { t: 'Printer          192.168.40.7' },
            { t: 'Mail server      172.32.10.5', bad: true, why: 'The private range is 172.16.0.0 to 172.31.255.255. 172.32 is outside it, so it is a public address.' },
            { t: 'Backup server    172.20.1.1' },
            { t: 'Test PC          10.200.30.40' },
          ],
          hints: ['Recall the three private ranges: 10.x.x.x, 172.16-31.x.x, 192.168.x.x.', 'For addresses that start with 172, look at the second octet.'],
          after: '<p>The trap: "all 172.x.x.x addresses are private" is wrong. At work, calling a public address internal by mistake can become a security problem.</p>' },
        { id: 's6', title: 'Read the ipconfig output of another PC', type: 'form',
          pre: 'Ethernet adapter Ethernet:\n\n   Physical Address. . . . . . . . . : 00-1A-2B-3C-4D-5E\n   DHCP Enabled. . . . . . . . . . . : No\n   IPv4 Address. . . . . . . . . . . : 10.20.30.40\n   Subnet Mask . . . . . . . . . . . : 255.255.255.0\n   Default Gateway . . . . . . . . . : 10.20.30.1',
          body: '<p>A colleague sent you this output. Answer the questions.</p>',
          fields: [
            { label: 'The MAC address in Cisco format (xxxx.xxxx.xxxx)', placeholder: 'xxxx.xxxx.xxxx', check: raw => /^[0-9a-f]{4}\.[0-9a-f]{4}\.[0-9a-f]{4}$/i.test(raw.trim()) && strip(raw) === '001a2b3c4d5e', wrong: 'Keep the hex digits, only change the separator: 00-1A-2B-3C-4D-5E → a dot after every 4 digits.' },
            { label: 'Is the IP address private? (yes / no)', answers: ['yes', 'yes.', 'y'], wrong: 'The range 10.0.0.0 – 10.255.255.255 is private.' },
            { label: 'How was the address set? (static / dhcp)', answers: ['static'], wrong: 'Look at the DHCP Enabled line: No means somebody typed the address by hand.' },
          ],
          hints: ['Cisco format: 3 groups, each with 4 hex digits, with dots between them.'], solution: '001a.2b3c.4d5e · yes (10.x.x.x is private) · static (DHCP Enabled: No)' },
        { id: 's7', title: 'Use commands on a PC command prompt', type: 'terminal',
          body: '<p>The practice PC below works like a Windows command prompt. Type the commands yourself (the buttons below only type the text, you press Enter yourself).</p>',
          term: { kind: 'host', host: { name: 'PC1', ip: '192.168.1.10', mask: '255.255.255.0', gw: '192.168.1.1', mac: '0001.4321.AAAA' }, peers: [{ name: 'R1', ip: '192.168.1.1', mac: '0001.4321.DDDD' }], quick: ['ipconfig', 'ipconfig /all', 'getmac'],
            goals: [{ text: 'Run the <span class="m">ipconfig /all</span> command', test: d => d.has(/^ipconfig\s+\/all$/i) }, { text: 'Run the <span class="m">getmac</span> command', test: d => d.has(/^getmac$/i) }] },
          hints: ['Type the command and press Enter: <span class="m">ipconfig /all</span>', 'The second command: <span class="m">getmac</span>'] },
        { id: 's8', title: 'Split the MAC address from the output', type: 'form',
          body: '<p>Look at the MAC address of the practice PC from the last step (Physical Address in <span class="m">ipconfig /all</span>). Cut it into two parts.</p>',
          fields: [
            { label: 'OUI (the first 3 bytes)', placeholder: 'xx-xx-xx', check: raw => strip(raw) === '000143', wrong: 'The first 6 hex digits: 00-01-43.' },
            { label: 'NIC part (the last 3 bytes)', placeholder: 'xx-xx-xx', check: raw => strip(raw) === '21aaaa', wrong: 'The last 6 hex digits: 21-AA-AA.' },
          ],
          hints: ['The MAC of PC1 is 0001.4321.AAAA. In Cisco format the dots are only separators: 000143 21AAAA.'], solution: 'OUI = 00-01-43, NIC part = 21-AA-AA' },
        { id: 's9', title: 'Ticket: "There is no internet"', type: 'ticket',
          body: '<p><b>A user calls:</b> "The internet is not working." You run <span class="m">ipconfig</span> and the PC\'s IP is <b>169.254.8.3</b>. The other PCs in the same office work fine.</p>',
          stages: [
            { q: '<p>What does a 169.254.x.x address mean?</p>', options: [
              { t: 'The PC could not get an address from DHCP, so it gave itself a link-local (APIPA) address.', ok: true, why: 'Rule: when DHCP does not answer, Windows picks an address from 169.254.0.0/16 itself. Why: so it can at least talk to the other devices on the same link. Here: the problem is that no address was received.' },
              { t: 'The internet provider gave this address and the connection is fine.', why: 'An APIPA address only works inside the same link, and a router does not forward it. A provider does not hand out addresses from this range.' },
              { t: 'The administrator typed this address by hand.', why: 'This range is not normally typed by hand. The address itself is a sign that DHCP failed.' },
              { t: 'It is the address of the router.', why: 'A router usually uses a private address (192.168.x.x, 10.x.x.x). 169.254 shows up when the device picks it itself.' },
            ] },
            { q: '<p>The other PCs work fine, but this one has no address. What should your first step be?</p>', options: [
              { t: 'Check the cable and the port light of this PC, then try to get the address again.', ok: true, why: 'The others work, so the DHCP server most likely works. Look at this PC\'s connection first (Layer 1), then ask for the address again.' },
              { t: 'Restart the DHCP server.', why: 'The other PCs get addresses, so the server works. Stopping it would cut everybody off.' },
              { t: 'Reinstall the browser.', why: 'The address was not received at the operating system level. The browser is not the problem.' },
              { t: 'Type the gateway by hand as 169.254.0.1.', why: '169.254.0.0/16 only works inside the same link. Typing a gateway by hand does not solve the problem.' },
            ] },
          ],
          after: '<p>The way of thinking: <b>check the address first</b>, then the services above it (DNS, the program). Without an address, nothing above works.</p>' },
      ],
    },

    quiz: {
      draw: 8,
      gens: [
        () => {
          const toBin = PT.randInt(2) === 0;
          if (toBin) {
            const n = PT.pick([37, 77, 100, 130, 172, 200, 214, 225, 241, 250, 19, 66]); const b = bin8(n);
            const parts = []; let rest = n; [128, 64, 32, 16, 8, 4, 2, 1].forEach(w => { if (rest >= w) { parts.push(w); rest -= w; } });
            return { id: 'p1t1-g-bin', concept: 'convert', obj: 'Convert decimal to binary', type: 'num', stem: '<p>One octet of an IP address has the decimal value <b>' + n + '</b>. What is its 8-bit binary form?</p>', placeholder: '8 digits (0 and 1)',
              check: raw => { const v = raw.replace(/\s/g, ''); if (!/^[01]+$/.test(v)) return { ok: false, note: 'Type only 0 and 1.' }; if (v.length !== 8) return { ok: false, note: 'An octet has to be exactly 8 bits (do not forget the zeros on the left).' }; return v === b; },
              solution: 'The weights are 128 64 32 16 8 4 2 1. ' + n + ' = ' + parts.join(' + ') + ', so the bits of these weights are 1 and the others are 0: <span class="m">' + b + '</span>.' };
          }
          const n = PT.pick([29, 64, 99, 128, 146, 192, 208, 224, 240, 252, 5, 170]); const b = bin8(n);
          const parts = []; b.split('').forEach((x, i) => { if (x === '1') parts.push([128, 64, 32, 16, 8, 4, 2, 1][i]); });
          return { id: 'p1t1-g-dec', concept: 'convert', obj: 'Convert binary to decimal', type: 'num', stem: '<p>One octet of an IP address has the binary value <span class="m">' + b + '</span>. What is its decimal value?</p>', placeholder: 'decimal number',
            check: raw => parseInt(raw.trim(), 10) === n && /^\d+$/.test(raw.trim()),
            solution: 'Add up the weights of the bits that are 1: ' + parts.join(' + ') + ' = <b>' + n + '</b>.' };
        },
      ],
      pool: [
        { id: 'p1t1-q1', concept: 'why-addresses', obj: 'Why a router routes by IP',
          stem: '<p>On the internet, packets are forwarded by the IP address, not the MAC address. What is the main reason?</p>',
          options: [
            { t: 'An IP address has a network part, so a router keeps one entry per network. A MAC has no such structure.', ok: true, why: 'Rule: the forwarding decision is made on the network part of the address. Why: if a router had to remember every device, its table would grow as big as the number of devices in the world. Here: the network part of an IP covers millions of hosts with one entry.' },
            { t: 'A MAC address is shorter than an IP address, so a router cannot build a routing table with it.', why: 'It is the other way round: a MAC is 48 bits and IPv4 is 32 bits. Length is not the reason; the reason is whether the address has structure or not.' },
            { t: 'A MAC address cannot be changed by software, but an IP can, so an IP is the one to use for routing.', why: 'A MAC address can be changed by software (spoofing). And being changeable does not explain the choice. The real point is that a MAC has no network part.' },
            { t: 'A MAC address only works on Wi-Fi and is not used on cabled networks, so it is no use on the internet.', why: 'A MAC address is used the same way on Ethernet and Wi-Fi. This is a wrong idea that has nothing to do with the topic.' },
          ] },
        { id: 'p1t1-q2', concept: 'why-addresses', obj: 'The addresses in an Ethernet header',
          stem: '<p>PC1 (192.168.1.10) pings PC2 (192.168.1.20), which is on the same switch. Which addresses are in the <b>Ethernet header</b> of the frame?</p>',
          options: [
            { t: 'Source MAC (the MAC of PC1) and Destination MAC (the MAC of PC2).', ok: true, why: 'Rule: the Ethernet header only carries MAC addresses. Why: Ethernet is Layer 2 and a switch only looks at this header. Here: the IP addresses are one layer higher, in the IP header.' },
            { t: 'Source IP (192.168.1.10) and Destination IP (192.168.1.20).', why: 'IP addresses are in the IP header, not in the Ethernet header. A switch does not read the IP header.' },
            { t: 'Source MAC (the MAC of PC1) and Destination IP (192.168.1.20).', why: 'The address types are mixed up: the Ethernet header has MACs, the IP header has IPs. Every header carries the address of its own layer.' },
            { t: 'Source MAC is the MAC of PC1, and Destination MAC is always FF:FF:FF:FF:FF:FF.', why: 'The broadcast MAC is only in frames meant for everybody (for example an ARP request). In a normal ping, the exact MAC of PC2 is written.' },
          ] },
        { id: 'p1t1-q3', concept: 'mac-parts', obj: 'What the OUI is',
          stem: '<p>In the MAC address <span class="m">00:1A:2B:3C:4D:5E</span>, what does the part <span class="m">00:1A:2B</span> show?</p>',
          options: [
            { t: 'The manufacturer of the card (the OUI).', ok: true, why: 'Rule: the first 24 bits are the OUI, and IEEE gives it to the manufacturer. Why: so each manufacturer can number the last 24 bits itself, and addresses of different manufacturers never clash. Here: the first 3 bytes are the manufacturer, the last 3 bytes are the number of the card.' },
            { t: 'The number of the network the device is in.', why: 'A MAC address has no network part: that is exactly why a router does not route by MAC. The network part only exists in the IP address.' },
            { t: 'The serial number of the card (like the last 3 bytes).', why: 'The number of the card is the last 3 bytes. The first 3 bytes are the same for all the cards of that manufacturer.' },
            { t: 'The VLAN number.', why: 'A VLAN is not in the MAC address. It is shown in a separate VLAN tag (802.1Q), which you meet in Part 3.' },
          ] },
        { id: 'p1t1-q4', concept: 'mac', obj: 'Length of a MAC',
          stem: '<p>How many bits is a MAC address, and with how many hex digits is it written?</p>',
          options: [
            { t: '48 bits, 12 hex digits.', ok: true, why: 'Rule: one hex digit is 4 bits. 48 / 4 = 12 digits. That is 2 digits per byte, 6 bytes in total (00:1A:2B:3C:4D:5E: 6 groups, 2 digits in each).' },
            { t: '48 bits, 6 hex digits.', why: 'The number of bytes (6) is mixed up with the number of hex digits. There are 6 bytes, but every byte is 2 hex digits, so 12 digits in total.' },
            { t: '32 bits, 8 hex digits.', why: '32 bits is the length of an IPv4 address. A MAC is 48 bits.' },
            { t: '64 bits, 16 hex digits.', why: '64 bits belongs to the EUI-64 format (used in IPv6). A classic Ethernet MAC address is 48 bits.' },
          ] },
        { id: 'p1t1-q6', concept: 'ip-binary', obj: 'The biggest value of an octet',
          stem: '<p>Why can each octet of an IPv4 address be at most 255?</p>',
          options: [
            { t: 'An octet is 8 bits, and the biggest value of 8 bits is 11111111 = 255.', ok: true, why: 'Rule: with n bits you can write 2^n values (from 0 to 2^n - 1). For 8 bits that is 256 values, so 0 to 255. Here: writing 192.168.1.300 is impossible.' },
            { t: '255 is reserved for broadcast and cannot be used in a normal address.', why: 'An octet of 255 is not forbidden. For example 10.255.1.1 is a normal address. A broadcast address is defined by all the host bits being 1, not by one octet being 255.' },
            { t: 'The standard picked this number at random.', why: 'The limit is not random, it comes from the number of bits. 8 bits = 256 combinations.' },
            { t: 'An IP address has 4 parts, and every part is divided up to 64.', why: 'Having 4 parts is not the reason for the limit. The limit depends on how many bits each part has.' },
          ] },
        { id: 'p1t1-q7', concept: 'special', obj: 'What an APIPA address means',
          stem: '<p>A PC shows <b>169.254.12.7</b> in <span class="m">ipconfig</span>. What does this mean?</p>',
          options: [
            { t: 'The PC could not find a DHCP server and gave itself a link-local address.', ok: true, why: 'Rule: when DHCP does not answer, Windows picks an address from 169.254.0.0/16 itself (APIPA). Why: so the PC can at least talk to the other devices on the same link. Here: the main problem is that no address came: the connection or DHCP.' },
            { t: 'The administrator typed this address by hand so the PC only works in the local network.', why: 'This range is not normally typed by hand. The address itself is a sign of a DHCP failure.' },
            { t: 'It is the LAN-side address of the router, and the PCs see it as their gateway.', why: 'A router\'s address usually ends with .1 or .254 and is private (192.168.x.x, 10.x.x.x). The 169.254 range shows up when the device picks it itself.' },
            { t: 'The PC is on the internet and everything works, because the provider gave the address.', why: 'An APIPA address only works inside the local link and a router does not route it, so there is no way out to the internet.' },
          ] },
        { id: 'p1t1-q8', concept: 'special', obj: 'The loopback test',
          stem: '<p><span class="m">ping 127.0.0.1</span> was successful. What does it prove?</p>',
          options: [
            { t: 'The PC\'s own TCP/IP software works. The packet did not leave through the cable.', ok: true, why: 'Rule: 127.0.0.1 is the loopback address, and the packet turns around inside the operating system. Why: it answers even without a network card or a cable. Here: it only checks the local software.' },
            { t: 'The default gateway is reachable and the router answers.', why: 'A loopback packet never goes to the gateway. To check the gateway, you have to ping its own IP.' },
            { t: 'The network card and the cable are fine, and the signal reaches the switch.', why: 'A loopback packet does not reach the card, so it says nothing about the card or the cable. It succeeds even with the cable pulled out.' },
            { t: 'The internet works and packets reach outside servers.', why: 'This ping does not leave the PC, so it tells you nothing about the internet.' },
          ] },
        { id: 'p1t1-q9', concept: 'special', obj: 'The private ranges',
          stem: '<p>Which of these addresses is <b>not private</b> (is routed on the internet)?</p>',
          options: [
            { t: '172.32.10.5', ok: true, why: 'The private range is 172.16.0.0 to 172.31.255.255. 172.32 is outside the range, so it is public. The trap: "all of 172.x.x.x is private" is wrong.' },
            { t: '172.20.1.1', why: '172.20 is inside the range (172.16–172.31), so it is private.' },
            { t: '10.200.30.40', why: 'The whole of 10.0.0.0/8 is private, whatever the second octet is.' },
            { t: '192.168.100.5', why: '192.168.0.0/16 is private (192.168.0.0–192.168.255.255).' },
          ] },
        { id: 'p1t1-q10', concept: 'ipconfig', obj: 'Physical Address in ipconfig',
          stem: '<p>In the <span class="m">ipconfig /all</span> output, which address does the <b>Physical Address</b> line show?</p>',
          options: [
            { t: 'The MAC address of this PC\'s network card.', ok: true, why: '"Physical Address" is the name Windows uses for the MAC address, because the MAC belongs to the physical card. The IP address is on its own "IPv4 Address" line.' },
            { t: 'The MAC address of the default gateway (the router).', why: 'This line is only about this PC\'s own adapter. You see the MAC of the gateway in the ARP cache (arp -a), which comes in later topics.' },
            { t: 'The IPv4 address and the mask of the PC together.', why: 'The IPv4 address is on the "IPv4 Address" line. The word "Physical" points to Layer 1/2 information.' },
            { t: 'The address of the internet provider (the device on the ISP side).', why: 'The address of the provider is not shown in this output. "Physical Address" is about the local adapter.' },
          ] },
      ],
    },
  });
})();
