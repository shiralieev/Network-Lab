(function () {
  const A = PT.addr; const bin8 = n => n.toString(2).padStart(8, '0');
  const MAC_OK = raw => !!A.macParse(raw);
  const strip = raw => String(raw).toLowerCase().replace(/[^0-9a-f]/g, '');

  PT.topic({
    id: 'p1t1',
    objectives: [
      'MAC və IP ünvanının hansı işi gördüyünü və niyə ikisinə də ehtiyac olduğunu izah etmək',
      'MAC ünvanını oxumaq: OUI-ni (istehsalçı) tapmaq və üç formatı tanımaq',
      'IPv4 ünvanını onluqdan ikiliyə və geriyə çevirmək',
      'Private, loopback və APIPA ünvanlarını tanımaq və ipconfig /all çıxışını oxumaq',
    ],
    explain: PT.frag['p1/t01/explain'], cheat: PT.frag['p1/t01/cheat'],

    lab: {
      title: 'Lab 2: Ünvanları tap, oxu və çevir',
      goal: 'Öz kompüterindəki MAC və IP ünvanını tapmaq, ünvanları ikiliyə çevirmək və ipconfig çıxışını oxumaq.',
      why: 'Helpdesk və SOC-da hər araşdırma bir cihazı onun IP və MAC ünvanı ilə tapmaqla başlayır. Bu ünvanları sürətlə oxumaq lazımdır.',
      minutes: 25,
      finish: 'Ünvanları tapıb oxuya bilirsən. İndi quizə keç: hər sual yeni seçilir və səhv variantların da niyə səhv olduğu izah olunur.',
      steps: [
        { id: 's1', title: 'Hazırlıq: komanda sətrini aç', type: 'info', button: 'Açdım, davam et',
          body: '<p>Bu laba öz kompüterində başlayırsan. <b>Windows</b>: <span class="m">Win + R</span> bas, <span class="m">cmd</span> yaz, Enter. <b>macOS</b>: Terminal tətbiqi. <b>Linux</b>: terminal.</p><p>Windows-da <span class="m">ipconfig /all</span>, macOS-da <span class="m">ifconfig</span>, Linux-da <span class="m">ip addr</span> yaz. Çıxışda <b>MAC</b>, <b>IPv4</b>, <b>mask</b> və <b>gateway</b> sətirlərini tapmalısan.</p>' },
        { id: 's2', title: 'Öz kompüterində ünvanları tap', type: 'form',
          body: '<p>Komanda sətrində əmri işlət və aktiv şəbəkə adapterinin (Ethernet və ya Wi-Fi) dəyərlərini aşağıya yaz. VPN və virtual adapterləri keç: onlar sənin əsas bağlantın deyil.</p>',
          fields: [
            { label: 'MAC ünvanın (Physical Address)', placeholder: 'məs. 3C-52-82-AA-10-5B', check: MAC_OK, wrong: '12 hex rəqəm olmalıdır (tire, iki nöqtə və ya nöqtə ilə).' },
            { label: 'IPv4 ünvanın', placeholder: 'məs. 192.168.1.37', check: raw => A.isIp(raw), wrong: '4 oktet, hər biri 0–255 (məs. 192.168.1.37).' },
            { label: 'Subnet mask', placeholder: 'məs. 255.255.255.0', check: raw => PT.ios.isMask(raw.trim()), wrong: 'Mask ardıcıl 1-lər və sonra 0-lardan ibarət olmalıdır (məs. 255.255.255.0).' },
            { label: 'Default gateway', placeholder: 'məs. 192.168.1.1', check: raw => A.isIp(raw), wrong: 'Gateway də IPv4 ünvanıdır. Bəzən boş olur, amma evdə/ofisdə olmalıdır.' },
          ],
          hints: ['Windows-da <span class="m">ipconfig /all</span> yaz və aşağı sürüşdür. Çox adapter ola bilər; "Ethernet adapter" və ya "Wireless LAN adapter Wi-Fi" başlığının altına bax.', 'MAC "Physical Address" sətrindədir. IPv4 sətrinin sonunda "(Preferred)" yazıla bilər: onu yazma, yalnız rəqəmləri yaz.'],
          after: '<p>Bu dörd dəyər növbəti mövzuların xammalıdır. Diqqət et: IP ünvanın <b>private</b> aralıqdadır (192.168.x.x, 10.x.x.x və ya 172.16–31.x.x)? Bunu internetdə "what is my IP" saytına baxıb müqayisə et: orada görünən ünvan sənin <b>public</b> ünvanındır və fərqlidir. Bu fərqi NAT izah edir (Part 5).</p>' },
        { id: 's3', title: 'Onluqdan ikiliyə çevir', type: 'form',
          body: '<p>Bit çəkiləri: <span class="m">128 64 32 16 8 4 2 1</span>. <b>172.16.5.130</b> ünvanının hər oktetini ikiliyə çevir və tam ünvanı 8-lik qruplarla yaz (nöqtə ilə və ya boşluqla).</p>',
          fields: [{ label: '172.16.5.130 ikilikdə', placeholder: '________.________.________.________', check: raw => raw.replace(/[\s.]/g, '') === '10101100000100000000010110000010', wrong: 'Hər oktet düz 8 bit olmalıdır. 172 = 128+32+8+4, 16 = 16, 5 = 4+1, 130 = 128+2.' }],
          hints: ['172: 128 sığır (1), qalan 44. 64 sığmır (0). 32 sığır (1), qalan 12. 16 sığmır (0). 8 sığır (1), qalan 4. 4 sığır (1). 2 və 1 sığmır.', 'Hər oktet üçün 8 bit yaz. 16 = 00010000, 5 = 00000101.'],
          solution: '172 = 10101100, 16 = 00010000, 5 = 00000101, 130 = 10000010. Tam: 10101100.00010000.00000101.10000010',
          after: '<p>Metod: hər çəki üçün "qalana sığırmı?" soruşursan. Sığırsa 1 yazıb çıxırsan.</p>' },
        { id: 's4', title: 'İkilikdən onluğa çevir', type: 'form',
          body: '<p>Bu ikilik ünvanı onluq formaya çevir: <span class="m">11000000.10101000.00001010.00000001</span></p>',
          fields: [{ label: 'Onluq ünvan', placeholder: 'a.b.c.d', check: raw => raw.trim() === '192.168.10.1', wrong: '1 olan bitlərin çəkilərini hər oktet üçün topla.' }],
          hints: ['Birinci oktet 11000000: yalnız 128 və 64 bitləri 1-dir.', 'İkinci oktet 10101000 = 128 + 32 + 8 = 168.'],
          solution: '11000000 = 128+64 = 192; 10101000 = 128+32+8 = 168; 00001010 = 8+2 = 10; 00000001 = 1. Cavab: 192.168.10.1' },
        { id: 's5', title: 'Hansı "private" ünvan əslində public-dir?', type: 'spot',
          body: '<p>Bir kolleqa şirkətin daxili serverlərinin siyahısını yazıb və hamısını "private" sayıb. <b>Bir ünvan private aralığın xaricindədir.</b> Onu tap.</p>',
          lines: [
            { t: 'Fayl server      10.20.5.14' },
            { t: 'Printer          192.168.40.7' },
            { t: 'Mail server      172.32.10.5', bad: true, why: 'Private aralıq 172.16.0.0-dan 172.31.255.255-ə qədərdir. 172.32 bu aralığın xaricindədir, yəni public ünvandır.' },
            { t: 'Backup server    172.20.1.1' },
            { t: 'Test PC          10.200.30.40' },
          ],
          hints: ['Üç private aralığı yada sal: 10.x.x.x, 172.16-31.x.x, 192.168.x.x.', '172-lə başlayan ünvanlarda ikinci oktetə diqqət et.'],
          after: '<p>Tələ: "172.x.x.x hamısı private-dir" fikri yanlışdır. İşdə ünvanı public sayıb səhvən daxili adlandırmaq təhlükəsizlik problemi yarada bilər.</p>' },
        { id: 's6', title: 'Başqa PC-nin ipconfig çıxışını oxu', type: 'form',
          pre: 'Ethernet adapter Ethernet:\n\n   Physical Address. . . . . . . . . : 00-1A-2B-3C-4D-5E\n   DHCP Enabled. . . . . . . . . . . : No\n   IPv4 Address. . . . . . . . . . . : 10.20.30.40\n   Subnet Mask . . . . . . . . . . . : 255.255.255.0\n   Default Gateway . . . . . . . . . : 10.20.30.1',
          body: '<p>Bir həmkarın bu çıxışı göndərib. Suallara cavab ver.</p>',
          fields: [
            { label: 'MAC ünvanı Cisco formatında (xxxx.xxxx.xxxx)', placeholder: 'xxxx.xxxx.xxxx', check: raw => /^[0-9a-f]{4}\.[0-9a-f]{4}\.[0-9a-f]{4}$/i.test(raw.trim()) && strip(raw) === '001a2b3c4d5e', wrong: 'Hex rəqəmləri saxla, yalnız ayırıcını dəyiş: 00-1A-2B-3C-4D-5E → hər 4 rəqəmdən sonra nöqtə.' },
            { label: 'IP ünvanı private-dir? (bəli / xeyr)', answers: ['bəli', 'beli', 'yes', 'bəli.'], wrong: '10.0.0.0 – 10.255.255.255 aralığı private-dir.' },
            { label: 'Ünvan necə verilib? (statik / dhcp)', answers: ['statik', 'static'], wrong: 'DHCP Enabled sətrinə bax: No deməkdir ki, ünvan əllə yazılıb.' },
          ],
          hints: ['Cisco formatı: 3 qrup, hər qrup 4 hex rəqəm, aralarında nöqtə.'], solution: '001a.2b3c.4d5e · bəli (10.x.x.x private) · statik (DHCP Enabled: No)' },
        { id: 's7', title: 'PC komanda sətrində əmr işlət', type: 'terminal',
          body: '<p>Aşağıdakı praktika PC-si Windows komanda sətrinə bənzəyir. Əmrləri özün yaz (aşağıdakı düymələr yalnız mətni yazır, Enter-i özün bas).</p>',
          term: { kind: 'host', host: { name: 'PC1', ip: '192.168.1.10', mask: '255.255.255.0', gw: '192.168.1.1', mac: '0001.4321.AAAA' }, peers: [{ name: 'R1', ip: '192.168.1.1', mac: '0001.4321.DDDD' }], quick: ['ipconfig', 'ipconfig /all', 'getmac'],
            goals: [{ text: '<span class="m">ipconfig /all</span> əmrini işlət', test: d => d.has(/^ipconfig\s+\/all$/i) }, { text: '<span class="m">getmac</span> əmrini işlət', test: d => d.has(/^getmac$/i) }] },
          hints: ['Əmri yaz və Enter bas: <span class="m">ipconfig /all</span>', 'İkinci əmr: <span class="m">getmac</span>'] },
        { id: 's8', title: 'Çıxışdan MAC hissələrini ayır', type: 'form',
          body: '<p>Əvvəlki praktika PC-nin MAC ünvanına bax (<span class="m">ipconfig /all</span>-da Physical Address). Onu iki hissəyə böl.</p>',
          fields: [
            { label: 'OUI (ilk 3 bayt)', placeholder: 'xx-xx-xx', check: raw => strip(raw) === '000143', wrong: 'İlk 6 hex rəqəm: 00-01-43.' },
            { label: 'NIC hissəsi (son 3 bayt)', placeholder: 'xx-xx-xx', check: raw => strip(raw) === '21aaaa', wrong: 'Son 6 hex rəqəm: 21-AA-AA.' },
          ],
          hints: ['PC1-in MAC-i 0001.4321.AAAA. Cisco formatında nöqtələr sadəcə ayırıcıdır: 000143 21AAAA.'], solution: 'OUI = 00-01-43, NIC hissəsi = 21-AA-AA' },
        { id: 's9', title: 'Ticket: "İnternet yoxdur"', type: 'ticket',
          body: '<p><b>İstifadəçi zəng edib:</b> "İnternet işləmir." <span class="m">ipconfig</span> baxanda PC-nin IP-si <b>169.254.8.3</b> görünür. Eyni ofisdəki digər PC-lər normal işləyir.</p>',
          stages: [
            { q: '<p>169.254.x.x ünvanı nə deməkdir?</p>', options: [
              { t: 'PC DHCP-dən ünvan ala bilməyib və özünə link-local (APIPA) ünvan verib.', ok: true, why: 'Qayda: DHCP cavab verməyəndə Windows 169.254.0.0/16 aralığından özü ünvan seçir. Heç olmasa eyni link-dəki cihazlarla danışa bilsin. Problem ünvan almamaqdır.' },
              { t: 'İnternet provayderi bu ünvanı verib və bağlantı normaldır.', why: 'APIPA ünvanı yalnız eyni link daxilində işləyir və router onu yönləndirmir. Provayder bu aralıqdan ünvan vermir.' },
              { t: 'Administrator bu ünvanı əllə yazıb.', why: 'Bu aralıq adətən əllə verilmir. Ünvanın özü DHCP uğursuzluğunun əlamətidir.' },
              { t: 'Bu, router-in ünvanıdır.', why: 'Router adətən private ünvan işlədir (192.168.x.x, 10.x.x.x). 169.254 cihaz özü seçəndə görünür.' },
            ] },
            { q: '<p>Digər PC-lər normal işləyir, bu PC-də isə ünvan yoxdur. İlk addımın nə olmalıdır?</p>', options: [
              { t: 'Bu PC-nin kabelini və port işığını yoxlayıb, sonra ünvanı yenidən almağa çalışmaq.', ok: true, why: 'Digərləri işlədiyi üçün DHCP server çox güman ki işləyir. Əvvəl bu PC-nin bağlantısına (Layer 1) bax, sonra ünvanı yenidən al.' },
              { t: 'DHCP server-i yenidən başlatmaq.', why: 'Digər PC-lər ünvan alır, yəni server işləyir. Server-i dayandırmaq hamını kəsər.' },
              { t: 'Brauzeri yenidən quraşdırmaq.', why: 'Ünvan əməliyyat sistemi səviyyəsində alınmayıb, brauzer problem deyil.' },
              { t: 'Gateway-i əllə 169.254.0.1 etmək.', why: '169.254.0.0/16 yalnız eyni link daxilində işləyir. Əllə gateway yazmaq problemi həll etməz.' },
            ] },
          ],
          after: '<p>Düşüncə modeli: <b>əvvəl ünvanı yoxla</b>, sonra yuxarıdakı xidmətləri (DNS, proqram). Ünvan olmadan yuxarıdakı heç nə işləmir.</p>' },
      ],
    },

    quiz: {
      draw: 8,
      gens: [
        () => {
          const toBin = PT.randInt(2) === 0;
          if (toBin) {
            const n = PT.pick([37, 77, 100, 130, 172, 200, 214, 225, 241, 250, 19, 66]); const b = bin8(n);
            const parts = []; let rest = n; [128, 64, 32, 16, 8, 4, 2, 1].forEach(w => { if (rest >= w) { parts.push(w); rest -= w; } });
            return { id: 'p1t1-g-bin', concept: 'convert', obj: 'Onluqdan ikiliyə çevirmə', type: 'num', stem: '<p>IP ünvanının bir oktetində onluq dəyər <b>' + n + '</b>-dir. Bu oktetin 8 bitlik ikilik yazılışı nədir?</p>', placeholder: '8 rəqəm (0 və 1)',
              check: raw => { const v = raw.replace(/\s/g, ''); if (!/^[01]+$/.test(v)) return { ok: false, note: 'Yalnız 0 və 1 yaz.' }; if (v.length !== 8) return { ok: false, note: 'Oktet düz 8 bit olmalıdır (soldakı sıfırları yazmağı unutma).' }; return v === b; },
              solution: 'Çəkilər 128 64 32 16 8 4 2 1. ' + n + ' = ' + parts.join(' + ') + ', yəni bu çəkilərin biti 1, qalanlarınki 0: <span class="m">' + b + '</span>.' };
          }
          const n = PT.pick([29, 64, 99, 128, 146, 192, 208, 224, 240, 252, 5, 170]); const b = bin8(n);
          const parts = []; b.split('').forEach((x, i) => { if (x === '1') parts.push([128, 64, 32, 16, 8, 4, 2, 1][i]); });
          return { id: 'p1t1-g-dec', concept: 'convert', obj: 'İkilikdən onluğa çevirmə', type: 'num', stem: '<p>IP ünvanının bir oktetində ikilik dəyər <span class="m">' + b + '</span>-dir. Onun onluq dəyəri nədir?</p>', placeholder: 'onluq ədəd',
            check: raw => parseInt(raw.trim(), 10) === n && /^\d+$/.test(raw.trim()),
            solution: '1 olan bitlərin çəkilərini topla: ' + parts.join(' + ') + ' = <b>' + n + '</b>.' };
        },
      ],
      pool: [
        { id: 'p1t1-q1', concept: 'why-addresses', obj: 'Router niyə IP ilə yönləndirir',
          stem: '<p>İnternetdə paketlər MAC ünvanına görə yox, IP ünvanına görə yönləndirilir. Əsas səbəb nədir?</p>',
          options: [
            { t: 'IP-də network hissəsi var, router bütün network üçün bir qeyd saxlayır. MAC-da bu quruluş yoxdur.', ok: true, why: 'Yönləndirmə qərarı ünvanın network hissəsinə görə verilir. Router hər cihazı ayrıca yadda saxlasaydı, cədvəl dünyadakı cihaz sayı qədər böyüyərdi. Burada: IP-nin network hissəsi bir qeydlə milyonlarla host-u əhatə edir.' },
            { t: 'MAC ünvanı IP ünvanından qısadır, ona görə router onunla yönləndirmə cədvəlini qura bilmir.', why: 'Əslində əksinədir: MAC 48 bitdir, IPv4 isə 32 bit. Uzunluq səbəb deyil; səbəb quruluşun olub-olmamasıdır.' },
            { t: 'MAC ünvanı proqramla dəyişdirilə bilməz, IP isə dəyişdirilə bilər, ona görə yönləndirməyə IP yararlıdır.', why: 'MAC ünvanı proqramla dəyişdirilə bilər (spoofing). Üstəlik dəyişdirilə bilmək yönləndirmə seçimini izah etmir; asıl məsələ MAC-da network hissəsinin olmamasıdır.' },
            { t: 'MAC ünvanı yalnız Wi-Fi-da işləyir, kabelli şəbəkədə istifadə olunmur, ona görə internetdə yararsızdır.', why: 'MAC ünvanı Ethernet və Wi-Fi-da eyni formada istifadə olunur. Bu, mövzuya aid olmayan yanlış təsəvvürdür.' },
          ] },
        { id: 'p1t1-q2', concept: 'why-addresses', obj: 'Ethernet başlığındakı ünvanlar',
          stem: '<p>PC1 (192.168.1.10) eyni switch-ə qoşulu PC2-yə (192.168.1.20) ping göndərir. Kadrın <b>Ethernet başlığında</b> hansı ünvanlar olur?</p>',
          options: [
            { t: 'Source MAC (PC1-in MAC-i) və Destination MAC (PC2-nin MAC-i).', ok: true, why: 'Qayda: Ethernet başlığı yalnız MAC ünvanlarını daşıyır. Niyə: Ethernet Layer 2-dir və switch yalnız bu başlığa baxır. Burada: IP ünvanları bir layer yuxarıdadır, IP başlığındadır.' },
            { t: 'Source IP (192.168.1.10) və Destination IP (192.168.1.20).', why: 'IP ünvanları IP başlığındadır, Ethernet başlığında deyil. Switch IP başlığını oxumur.' },
            { t: 'Source MAC (PC1-in MAC-i) və Destination IP (192.168.1.20).', why: 'Ünvan növləri qarışdırılıb: Ethernet başlığında MAC-lər, IP başlığında IP-lər olur, hər başlıq öz layer-inin ünvanını daşıyır.' },
            { t: 'Source MAC PC1-in MAC-i, Destination MAC isə həmişə FF:FF:FF:FF:FF:FF olur.', why: 'Broadcast MAC yalnız hamıya yönəlmiş kadrlarda olur (məsələn ARP sorğusu). Adi ping-də PC2-nin dəqiq MAC-i yazılır.' },
          ] },
        { id: 'p1t1-q3', concept: 'mac-parts', obj: 'OUI nədir',
          stem: '<p><span class="m">00:1A:2B:3C:4D:5E</span> MAC ünvanında <span class="m">00:1A:2B</span> hissəsi nəyi göstərir?</p>',
          options: [
            { t: 'Kartın istehsalçısını (OUI).', ok: true, why: 'İlk 24 bit OUI-dir və IEEE tərəfindən istehsalçıya verilir. Son 24 bitlik nömrələri hər istehsalçı özü verə bilsin və fərqli istehsalçıların ünvanları toqquşmasın. İlk 3 bayt istehsalçı, son 3 bayt kartın nömrəsidir.' },
            { t: 'Cihazın olduğu network-ün nömrəsini.', why: 'MAC ünvanında network hissəsi yoxdur: məhz buna görə router MAC ilə yönləndirmir. Network hissəsi yalnız IP ünvanında olur.' },
            { t: 'Kartın seriya nömrəsini (son 3 bayt kimi).', why: 'Kartın nömrəsi son 3 baytdır. İlk 3 bayt bütün həmin istehsalçının kartları üçün eynidir.' },
            { t: 'VLAN nömrəsini.', why: 'VLAN MAC ünvanında yox, ayrıca VLAN etiketində (802.1Q) göstərilir. Bunu Part 3-də görəcəksən.' },
          ] },
        { id: 'p1t1-q4', concept: 'mac', obj: 'MAC uzunluğu',
          stem: '<p>MAC ünvanı neçə bitdir və hex ilə neçə rəqəmlə yazılır?</p>',
          options: [
            { t: '48 bit, 12 hex rəqəm.', ok: true, why: 'Bir hex rəqəm 4 bitdir. 48 / 4 = 12 rəqəm. Bu, hər bayt üçün 2 rəqəm, cəmi 6 bayt deməkdir (00:1A:2B:3C:4D:5E: 6 qrup, hər qrupda 2 rəqəm).' },
            { t: '48 bit, 6 hex rəqəm.', why: 'Burada baytların sayı (6) ilə hex rəqəmlərin sayı qarışdırılıb. 6 bayt var, amma hər bayt 2 hex rəqəmdir, yəni cəmi 12 rəqəm.' },
            { t: '32 bit, 8 hex rəqəm.', why: '32 bit IPv4 ünvanının uzunluğudur. MAC 48 bitdir.' },
            { t: '64 bit, 16 hex rəqəm.', why: '64 bit EUI-64 formatına (IPv6-da istifadə olunur) aiddir. Klassik Ethernet MAC ünvanı 48 bitdir.' },
          ] },
        { id: 'p1t1-q6', concept: 'ip-binary', obj: 'Oktetin maksimum dəyəri',
          stem: '<p>Niyə IPv4 ünvanının hər oktetinin dəyəri ən çoxu 255 ola bilər?</p>',
          options: [
            { t: 'Oktet 8 bitdir və 8 bitin ən böyük dəyəri 11111111 = 255-dir.', ok: true, why: 'N bitlə 2^n dəyər yazmaq olar (0-dan 2^n - 1-ə qədər). 8 bit üçün 256 dəyər, yəni 0–255. Burada 192.168.1.300 yazmaq mümkün deyil.' },
            { t: '255 broadcast üçün ayrılıb və adi ünvanda işlənə bilməz.', why: 'Oktetin 255 olması qadağan deyil. Məsələn 10.255.1.1 normal ünvandır. Broadcast ünvan host hissəsinin bütün bitlərinin 1 olması ilə müəyyən olunur, tək oktetin 255 olması ilə yox.' },
            { t: 'Bu rəqəm standartla təsadüfi seçilib.', why: 'Hədd təsadüfi deyil, bitlərin sayından çıxır. 8 bit = 256 kombinasiya.' },
            { t: 'IP ünvanı 4 hissədən ibarətdir və hər hissə 64-ə qədər bölünür.', why: '4 hissənin olması hədd üçün səbəb deyil. Hədd hər hissənin neçə bitlik olmasından asılıdır.' },
          ] },
        { id: 'p1t1-q7', concept: 'special', obj: 'APIPA ünvanının mənası',
          stem: '<p>PC <span class="m">ipconfig</span>-də <b>169.254.12.7</b> göstərir. Bu nə deməkdir?</p>',
          options: [
            { t: 'PC DHCP server tapa bilməyib və özünə link-local ünvan verib.', ok: true, why: 'Qayda: DHCP cavab verməyəndə Windows 169.254.0.0/16 aralığından özü ünvan seçir (APIPA). Niyə: PC heç olmasa eyni link-dəki digər cihazlarla danışa bilsin. Əsas problem ünvan almamaqdır, yəni bağlantı və ya DHCP.' },
            { t: 'Administrator bu ünvanı əllə təyin edib ki, PC yalnız lokal şəbəkədə işləsin.', why: 'Bu aralıq adətən əllə verilmir; ünvanın özü DHCP uğursuzluğunun əlamətidir.' },
            { t: 'Bu, router-in LAN tərəfindəki ünvanıdır, PC-lər onu gateway kimi görür.', why: 'Router-in ünvanı adətən .1 və ya .254 ilə bitən private ünvandır (192.168.x.x, 10.x.x.x). 169.254 aralığı cihaz özü seçəndə görünür.' },
            { t: 'PC internetə qoşulub, hər şey normal işləyir, provayder ünvanı verib.', why: 'APIPA ünvanı yalnız lokal link daxilində işləyir, router onu route etmir, ona görə internetə çıxış olmur.' },
          ] },
        { id: 'p1t1-q8', concept: 'special', obj: 'Loopback testi',
          stem: '<p><span class="m">ping 127.0.0.1</span> uğurlu oldu. Bu nəyi sübut edir?</p>',
          options: [
            { t: 'PC-nin öz TCP/IP stack-ı işləyir. Paket kabelə çıxmayıb.', ok: true, why: 'Qayda: 127.0.0.1 loopback ünvanıdır; paket əməliyyat sisteminin daxilində geri qayıdır. Bu, şəbəkə kartı və kabel olmadan da cavab verir. Yalnız yerli proqram təminatını yoxlayır.' },
            { t: 'Default gateway-ə çatmaq mümkündür və router cavab verir.', why: 'Loopback paketi heç vaxt gateway-ə getmir. Gateway-i yoxlamaq üçün onun öz IP-sinə ping lazımdır.' },
            { t: 'Şəbəkə kartı və kabel sağlamdır, siqnal switch-ə çatır.', why: 'Loopback paketi karta çatmır, ona görə kartın və kabelin vəziyyəti haqqında heç nə demir. Kabel çıxarılmış olsa da bu ping uğurlu olar.' },
            { t: 'İnternet işləyir və paketlər xarici serverlərə çatır.', why: 'Bu ping şəbəkədən kənara çıxmır, ona görə internet haqqında məlumat vermir.' },
          ] },
        { id: 'p1t1-q9', concept: 'special', obj: 'Private aralıq',
          stem: '<p>Aşağıdakı ünvanlardan hansı <b>private deyil</b> (internetdə route olunur)?</p>',
          options: [
            { t: '172.32.10.5', ok: true, why: 'Private aralıq 172.16.0.0-dan 172.31.255.255-ə qədərdir. 172.32 bu aralığın xaricindədir, deməli public-dir. Tələ: "172.x.x.x hamısı private-dir" fikri yanlışdır.' },
            { t: '172.20.1.1', why: '172.20 aralığa (172.16–172.31) daxildir, deməli private-dir.' },
            { t: '10.200.30.40', why: '10.0.0.0/8 bütövlükdə private-dir, ikinci oktet nə olursa olsun.' },
            { t: '192.168.100.5', why: '192.168.0.0/16 private-dir (192.168.0.0–192.168.255.255).' },
          ] },
        { id: 'p1t1-q10', concept: 'ipconfig', obj: 'ipconfig-də Physical Address',
          stem: '<p><span class="m">ipconfig /all</span> çıxışında <b>Physical Address</b> sətri hansı ünvanı göstərir?</p>',
          options: [
            { t: 'Bu PC-nin şəbəkə kartının MAC ünvanını.', ok: true, why: '"Physical Address" Windows-un MAC ünvanına verdiyi addır. Çünki MAC fiziki kartla bağlıdır. IP ünvanı ayrıca "IPv4 Address" sətrindədir.' },
            { t: 'Default gateway-in (router-in) MAC ünvanını.', why: 'Bu sətir yalnız bu PC-nin öz adapterinə aiddir. Gateway-in MAC-ini ARP cache-də (arp -a) görərsən (növbəti mövzularda).' },
            { t: 'PC-nin IPv4 ünvanını və mask-ını birlikdə.', why: 'IPv4 ünvanı "IPv4 Address" sətrindədir. "Physical" sözü Layer 1/2 məlumatına işarədir.' },
            { t: 'İnternet provayderinin ünvanını (ISP tərəfdəki cihaz).', why: 'Provayder ünvanı bu çıxışda göstərilmir; "Physical Address" lokal adapterə aiddir.' },
          ] },
      ],
    },
  });
})();
