(function () {
  const A = PT.addr; const pick = PT.pick; const R = PT.randInt;
  const oct = ip => ip.split('.').map(Number);
  // fast-method explanation (HTML) for ip/p
  function fast(ip, p) {
    const k = Math.floor((p - 1) / 8); const bits = p - 8 * k; const block = Math.pow(2, 8 - bits); const m = 256 - block;
    const o = oct(ip); const v = o[k]; const nOct = Math.floor(v / block) * block; const names = ['birinci', 'ikinci', 'üçüncü', 'dördüncü'];
    const info = A.info(ip, p);
    return 'Mask <span class="m">' + A.maskS(p) + '</span>: maraqlı oktet ' + names[k] + 'dir (mask dəyəri ' + m + '), blok ölçüsü 256 − ' + m + ' = <b>' + block + '</b>. ' + names[k] + ' oktet ' + v + ' → ən yaxın kiçik blok misli <b>' + nOct + '</b>. Network: <b>' + info.net + '</b>, broadcast (növbəti network − 1): <b>' + info.bc + '</b>, host aralığı ' + info.first + ' – ' + info.last + '.';
  }
  function randNet() {
    if (R(10) < 7) { const p = pick([25, 26, 27, 28, 29, 30]); const b = pick(['192.168.1', '192.168.10', '10.1.1', '172.16.5', '192.168.77', '10.20.30']); return { ip: b + '.' + (R(253) + 1), p }; }
    const p = pick([18, 19, 20, 21, 22, 23]); return { ip: pick(['172.16', '10.20', '10.100', '172.20']) + '.' + R(256) + '.' + (R(253) + 1), p };
  }
  const normIp = raw => String(raw).trim();

  PT.topic({
    id: 'p1t2',
    objectives: [
      'IP ünvanının network və host hissəsini, mask-ın isə sərhədi göstərdiyini izah etmək',
      'Mask ilə prefix length arasında çevirmə aparmaq',
      'Verilmiş ünvan üçün network, broadcast, host aralığı və host sayını tapmaq',
      'Cihazın hədəfi birbaşa göndərib-göndərməyəcəyini mask ilə müəyyən etmək',
      '/24 network-ü bərabər subnet-lərə bölmək və host sayına görə prefix seçmək',
      'IP, mask və gateway ayarlarında səhvi tapmaq',
    ],
    explain: PT.frag['p1/t02/explain'], cheat: PT.frag['p1/t02/cheat'],

    lab: {
      title: 'Lab 2: Subnet hesablama və yoxlama',
      goal: 'Network və broadcast ünvanını tapmaq, same-network qərarı vermək, /24-ü bölmək və səhv konfiqurasiyanı aşkar etmək.',
      why: 'Şəbəkə mühəndisi və SOC analitiki hər gün "bu ünvan hansı subnet-dədir" sualına cavab verir: firewall qaydası, ACL və log təhlili bunsuz mümkün deyil.',
      minutes: 35,
      finish: 'Hesablamanı kağız üzərində edib yoxlaya bilirsən. Quizdə bu hesablamaların yeni variantları gələcək.',
      steps: [
        { id: 's1', title: 'Hazırlıq: 4 addımlı üsul', type: 'info', button: 'Başa düşdüm',
          body: '<p>Hesablamalarda İzah hissəsindəki üsulu işlədəcəksən:</p><ol><li>Mask-da 255 də olmayan, 0 da olmayan oktet tap.</li><li>Blok ölçüsü = 256 − həmin oktetin mask dəyəri.</li><li>Network = IP oktetindən böyük olmayan ən yaxın blok mislisi.</li><li>Broadcast = növbəti network − 1. Host-lar aradadır.</li></ol><p>Kalkulyator işlətmə, hesabı kağızda apar. Cavabını sonda bit grid ilə yoxlaya bilərsən.</p>' },
        { id: 's1b', title: 'Mask və prefix cütlərini birləşdir', type: 'match',
          body: '<p>Hər prefix-ə uyğun mask-ı seç.</p>',
          pairs: [
            { l: '<span class="m">/8</span>', r: '255.0.0.0', why: 'Bir tam oktet 255: 8 bit.' },
            { l: '<span class="m">/16</span>', r: '255.255.0.0', why: 'İki tam oktet: 16 bit.' },
            { l: '<span class="m">/24</span>', r: '255.255.255.0', why: 'Üç tam oktet: 24 bit.' },
            { l: '<span class="m">/25</span>', r: '255.255.255.128', why: '25 = 24 + 1. Dördüncü oktetdə ilk bit 1: 10000000 = 128.' },
            { l: '<span class="m">/27</span>', r: '255.255.255.224', why: '27 = 24 + 3. Üç bit 1: 11100000 = 224.' },
            { l: '<span class="m">/30</span>', r: '255.255.255.252', why: '30 = 24 + 6. Altı bit 1: 11111100 = 252.' },
          ],
          hints: ['Prefix-dən 8, 16 və ya 24 çıx. Qalan rəqəm dördüncü oktetdəki 1-lərin sayıdır.'] },
        { id: 's1c', title: 'Səhv mask-ı tap', type: 'spot',
          body: '<p>Kolleqa şəbəkə planı yazıb. Cədvəldə <b>bir mask etibarsızdır</b>. Onu tap və səbəbini yaz.</p>',
          lines: [
            { t: '1.  Satış        192.168.10.0   mask 255.255.255.192' },
            { t: '2.  Mühasibat    192.168.10.64  mask 255.255.255.192' },
            { t: '3.  İT           192.168.10.128 mask 255.255.253.192', bad: true, why: '253 = 11111101: 1-lərin arasında 0 qalır. Mask-da 1-lər solda, 0-lar sağda olmalıdır.' },
            { t: '4.  Qonaq        192.168.10.192 mask 255.255.255.192' },
          ],
          fix: { label: 'Üçüncü oktetdə hansı dəyər olmalıdır?', placeholder: 'məs. 255', answers: ['255'], wrong: 'Dördüncü oktet 192 olduğuna görə bu mask /26-dır. Üçüncü oktet tam 1-lərdən ibarət olmalıdır.' },
          hints: ['Hər mask oktetinin dəyəri 0, 128, 192, 224, 240, 248, 252, 254 və ya 255 olmalıdır.'] },
        { id: 's2', title: 'Mask ↔ prefix', type: 'form',
          fields: [
            { label: '/26 mask-ı', placeholder: 'a.b.c.d', check: r => normIp(r) === '255.255.255.192', wrong: '26 bit = 3 tam oktet (24) + 2 bit. 2 bit: 11000000 = 192.' },
            { label: '255.255.255.224 prefix-i', placeholder: '/xx', check: r => /^\/?27$/.test(r.trim()), wrong: '224 = 11100000: 3 bit 1. 24 + 3 = ?' },
            { label: '/20 mask-ı', placeholder: 'a.b.c.d', check: r => normIp(r) === '255.255.240.0', wrong: '20 = 16 + 4. Üçüncü oktetdə 4 bit 1: 11110000 = 240.' },
            { label: '255.255.254.0 prefix-i', placeholder: '/xx', check: r => /^\/?23$/.test(r.trim()), wrong: '254 = 11111110: 7 bit 1. 16 + 7 = ?' },
          ],
          hints: ['Hər oktet 8 bitdir. Tam 255 olan oktetlər 8 bit sayılır.', 'Qismən oktet: 128=1 bit, 192=2, 224=3, 240=4, 248=5, 252=6, 254=7.'],
          solution: '/26 = 255.255.255.192; 224 → /27; /20 = 255.255.240.0; 254 üçüncü oktetdə → /23.' },
        { id: 's3', title: 'Hesabla: 192.168.1.77/27', type: 'form',
          body: '<p>192.168.1.77/27 ünvanı üçün cavab ver. Bit grid-də yoxlaya bilərsən.</p>',
          sim: { name: 'bitgrid', opts: { ip: '192.168.1.77', prefix: 27, title: 'Yoxla: 192.168.1.77/27' } },
          fields: [
            { label: 'Network address', placeholder: 'a.b.c.d', check: r => normIp(r) === '192.168.1.64', wrong: 'Blok = 32. 32-nin misilləri: 0, 32, 64, 96. 77 hansı arasındadır?' },
            { label: 'Broadcast address', placeholder: 'a.b.c.d', check: r => normIp(r) === '192.168.1.95', wrong: 'Növbəti network (96) − 1.' },
            { label: 'İlk host', placeholder: 'a.b.c.d', check: r => normIp(r) === '192.168.1.65', wrong: 'Network + 1.' },
            { label: 'Son host', placeholder: 'a.b.c.d', check: r => normIp(r) === '192.168.1.94', wrong: 'Broadcast − 1.' },
            { label: 'İstifadə olunan host sayı', placeholder: 'rəqəm', check: r => r.trim() === '30', wrong: '/27: 5 host biti. 2^5 − 2.' },
          ],
          hints: ['/27 → mask 224, blok 256 − 224 = 32.', '77 üçün: 64 ≤ 77 < 96.'],
          solution: fast('192.168.1.77', 27) },
        { id: 's4', title: 'Eyni network-dürmü?', type: 'form',
          body: '<p>Hər iki host-un mask-ı <span class="m">255.255.240.0</span> (/20). PC-A <span class="m">172.16.5.10</span>, PC-B <span class="m">172.16.20.20</span>. Bu host-lar birbaşa danışa bilərmi?</p>',
          fields: [
            { label: 'PC-A-nın network ünvanı', placeholder: 'a.b.c.d', check: r => normIp(r) === '172.16.0.0', wrong: 'Maraqlı oktet üçüncüdür, blok 16. 5 hansı bloka düşür?' },
            { label: 'PC-B-nin network ünvanı', placeholder: 'a.b.c.d', check: r => normIp(r) === '172.16.16.0', wrong: '20: 16 ≤ 20 < 32.' },
            { label: 'Eyni network-dürmü? (bəli / xeyr)', answers: ['xeyr', 'yox', 'no'], wrong: 'Network ünvanları fərqlidirsə, host-lar eyni network-də deyil.' },
          ],
          hints: ['/20 = 255.255.240.0; 256 − 240 = 16. Üçüncü oktetdə bloklar: 0, 16, 32 …'],
          solution: 'A: 172.16.0.0/20 (0–15), B: 172.16.16.0/20 (16–31). Network-lər fərqlidir, deməli A paketi gateway-ə göndərəcək.',
          after: '<p>Diqqət et: 172.16.5.10 və 172.16.20.20 ilk iki oktetdə eyni görünür, amma /20 mask üçüncü oktetin də yarısını network hissəsinə daxil edir.</p>' },
        { id: 's5', title: '/24-ü 8 subnet-ə böl', type: 'form',
          body: '<p><span class="m">192.168.50.0/24</span> network-ünü <b>8 bərabər subnet-ə</b> bölürsən.</p>',
          sim: { name: 'splitnet', opts: {} },
          fields: [
            { label: 'Yeni prefix', placeholder: '/xx', check: r => /^\/?27$/.test(r.trim()), wrong: '2^n = 8 → n = 3 bit borc. 24 + 3.' },
            { label: 'Yeni mask', placeholder: 'a.b.c.d', check: r => normIp(r) === '255.255.255.224', wrong: '/27 = 255.255.255.224.' },
            { label: '3-cü subnet-in network ünvanı', placeholder: 'a.b.c.d', check: r => normIp(r) === '192.168.50.64', wrong: 'Blok 32: 1-ci .0, 2-ci .32, 3-cü .64.' },
            { label: '3-cü subnet-in broadcast ünvanı', placeholder: 'a.b.c.d', check: r => normIp(r) === '192.168.50.95', wrong: 'Növbəti network (.96) − 1.' },
            { label: 'Hər subnet-də host sayı', placeholder: 'rəqəm', check: r => r.trim() === '30', wrong: '5 host biti: 2^5 − 2.' },
          ],
          hints: ['8 subnet üçün neçə bit lazımdır? 2^3 = 8.', 'Blok = 256 / 8 = 32.'],
          solution: '3 bit → /27, mask 255.255.255.224, blok 32. Subnet-lər: .0, .32, .64, .96, .128, .160, .192, .224. 3-cü subnet: 192.168.50.64/27, broadcast .95, 30 host.' },
        { id: 's6', title: 'Üçüncü oktetdə hesablama: 10.20.133.5/18', type: 'form',
          fields: [
            { label: 'Network address', placeholder: 'a.b.c.d', check: r => normIp(r) === '10.20.128.0', wrong: '/18 = 255.255.192.0. Maraqlı oktet üçüncüdür, blok 64: 0, 64, 128, 192.' },
            { label: 'Broadcast address', placeholder: 'a.b.c.d', check: r => normIp(r) === '10.20.191.255', wrong: 'Növbəti network 10.20.192.0 → bir əvvəlki ünvan.' },
          ],
          hints: ['/18: 18 − 16 = 2 bit üçüncü oktetdə. 2 bit = 192, blok = 64.', '133: 128 ≤ 133 < 192.'],
          solution: fast('10.20.133.5', 18) },
        { id: 's7', title: 'Ticket: "Başqa şəbəkəyə çıxa bilmirəm"', type: 'ticket',
          body: '<p><b>İstifadəçi deyir:</b> "Eyni otaqdakı printerə və kolleqalara çatıram, amma şirkətin server şəbəkəsinə və internetə çıxa bilmirəm." <code>ipconfig</code> nəticəsi: IP <span class="m">192.168.10.200</span>, mask <span class="m">255.255.255.192</span>, gateway <span class="m">192.168.10.1</span>.</p>',
          stages: [
            { q: '<p>İlk addım: bu PC hansı subnet-dədir?</p>', options: [
              { t: '192.168.10.192/26: blok ölçüsü 64, 200 aralığı 192 – 255 olan blokdadır. Host aralığı .193 – .254.', ok: true, why: '/26 mask 255.255.255.192-dir, blok = 256 − 192 = 64. Bloklar 0, 64, 128, 192. 200 son blokdadır.' },
              { t: '192.168.10.128/26: blok 64, 200 aralığı 128 – 191 olan blokdadır.', why: '128 – 191 aralığına 200 düşmür. 200 ≥ 192-dir.' },
              { t: '192.168.10.0/24: mask /24-dür.', why: 'Mask 255.255.255.192-dir, bu /26-dır, /24 yox.' },
              { t: '192.168.10.200/26: network ünvanı IP-nin özüdür.', why: 'Network ünvanında host bitləri 0 olur. 200 bu blokun ilk ünvanı deyil (192-dir).' },
            ] },
            { q: '<p>Gateway <span class="m">192.168.10.1</span> hansı subnet-dədir və PC onu necə görür?</p>', options: [
              { t: 'Gateway 192.168.10.0/26 subnet-indədir (0 – 63). PC üçün bu başqa network-dür, ona görə PC gateway-ə birbaşa çata bilmir.', ok: true, why: 'PC və gateway fərqli subnet-lərdədir. Birbaşa göndərmək yalnız eyni network üçün mümkündür.' },
              { t: 'Gateway PC ilə eyni subnet-dədir, problem başqa yerdədir.', why: 'PC .192 – .255 blokundadır, gateway .1 isə .0 – .63 blokunda.' },
              { t: 'Gateway broadcast ünvanıdır.', why: 'Bu subnet-in broadcast-ı .63-dür, .1 adi host ünvanıdır.' },
              { t: 'Gateway mask-dan asılı deyil, hər zaman əlçatandır.', why: 'Əlçatanlıq PC-nin mask-ına görə hesablanır. Mask gateway-i "başqa network" göstərir.' },
            ] },
            { q: '<p>Düzgün həll hansıdır?</p>', options: [
              { t: 'PC-nin IP-sini gateway ilə eyni subnet-dən seçmək (məsələn 192.168.10.20/26) və ya düzgün gateway ünvanını yazmaq.', ok: true, why: 'PC və gateway eyni subnet-də olmalıdır. Hansı ayarın səhv olduğunu planda yoxlayıb onu düzəldirsən.' },
              { t: 'Mask-ı /24-ə dəyişib hər şeyi bir network etmək, planı yoxlamadan.', why: 'Mask şəbəkənin planına aiddir. Onu tək PC-də dəyişmək başqa cihazlarla uyğunsuzluq yaradır.' },
              { t: 'Gateway ünvanını broadcast ünvanına (.63) dəyişmək.', why: 'Broadcast ünvanı cihaza verilmir.' },
              { t: 'PC-ni yenidən başlatmaq.', why: 'Ayarlar səhvdir, yenidən başlatmaq onları dəyişmir.' },
            ] },
          ],
          after: '<p>Bu hal işdə tez-tez olur: IP və mask düzgündür, gateway başqa subnet-dən kopyalanıb.</p>' },
        { id: 's8', title: 'Dizayn qərarı: hansı mask?', type: 'choice',
          body: '<p><span class="m">192.168.20.0/24</span> bloku verilib. 4 şöbə üçün ayrı subnet lazımdır. Ən böyük şöbədə <b>50 host</b> var, hər şöbə üçün subnet ölçüsü eyni olacaq. Hansı mask-ı seçərdin?</p>',
          options: [
            { t: '/26 (255.255.255.192): 4 subnet, hər birində 62 host.', ok: true, why: '4 subnet üçün 2 bit lazımdır (/24 → /26). Hər subnet-də 2^6 − 2 = 62 host var və 50-yə kifayət edir. Həm subnet sayı, həm host sayı tələbi ödənir.' },
            { t: '/27 (255.255.255.224): 8 subnet, hər birində 30 host.', why: 'Subnet sayı bəs edir, amma 30 host 50-yə çatmır. Ən böyük şöbə sığmayacaq.' },
            { t: '/25 (255.255.255.128): 2 subnet, hər birində 126 host.', why: 'Host sayı çox kifayətdir, amma cəmi 2 subnet alınır, 4 şöbə üçün çatmır.' },
            { t: '/24-ü olduğu kimi saxlamaq, hamı eyni network-də.', why: 'Tələb ayrı subnet-lərdir. Eyni network-də şöbələr bir-birinin broadcast-ını alır və aralarında router səviyyəsində nəzarət etmək olmur.' },
          ],
          hints: ['İki tələb var: (1) ≥ 4 subnet, (2) hər subnet-də ≥ 50 host. Hər variantı hər iki tələbə qarşı yoxla.'] },
        { id: 's9', title: 'Qeyri-simmetrik ping: niyə?', type: 'choice',
          body: '<p>PC-A: <span class="m">192.168.1.10 / 255.255.255.0</span>. PC-B: <span class="m">192.168.1.200 / 255.255.255.128</span>. Hər ikisi eyni switch-dədir. Mühəndis görür ki, PC-A-dan PC-B-yə ping cavabsızdır. Ən yaxşı izah hansıdır?</p>',
          options: [
            { t: 'A B-ni eyni network sayır, B isə A-nı öz /25 mask-ına görə fərqli network sayır.', ok: true, why: 'Hər host eyni-network qərarını öz mask-ı ilə verir. A: 192.168.1.0/24 daxilində hər ikisi. B: 192.168.1.128/25-dədir, 192.168.1.10 isə 192.168.1.0/25-dədir, deməli B üçün fərqli networkdür. B cavabı gateway-ə yönəltməli olur (və ya gateway yoxdursa heç göndərə bilmir).' },
            { t: 'İki PC-nin IP ünvanı üst-üstə düşür, deməli IP conflict var və paketlər itir.', why: 'Ünvanlar fərqlidir (.10 və .200). Problem mask uyğunsuzluğundadır.' },
            { t: 'Switch iki fərqli mask-ı görüb kadrı atır, çünki mask uyğunsuzluğunu yoxlayır.', why: 'Switch mask-ı bilmir, o yalnız MAC ünvanlarına baxır. Qərarı hostlar verir.' },
            { t: 'Ping yalnız eyni mask olduqda keçir, çünki mask ICMP başlığında ötürülür.', why: 'Mask heç bir başlıqda ötürülmür. Hər host yalnız öz mask-ını bilir; problem məhz bundadır.' },
          ],
          hints: ['Əvvəl A-nın baxışı: 192.168.1.200 onun /24 network-ündədir? Sonra B-nin baxışı: 192.168.1.10 onun /25 network-ündədir?'] },
      ],
    },

    quiz: {
      draw: 8,
      gens: [
        // 1) network / broadcast / first / last
        () => {
          const n = randNet(); const info = A.info(n.ip, n.p); const kind = pick(['net', 'bc', 'first', 'last']);
          const lbl = { net: 'network address', bc: 'broadcast address', first: 'ilk istifadə olunan host', last: 'son istifadə olunan host' }[kind]; const ans = { net: info.net, bc: info.bc, first: info.first, last: info.last }[kind];
          return { id: 'p1t2-g-calc', concept: 'find-network', obj: 'Network / broadcast / host aralığı hesabı', type: 'num', _meta: { kind, ip: n.ip, p: n.p, ans },
            stem: '<p><span class="m">' + n.ip + '/' + n.p + '</span> ünvanı üçün <b>' + lbl + '</b> nədir?</p>', placeholder: 'a.b.c.d',
            check: r => r.trim() === ans, solution: fast(n.ip, n.p) };
        },
        // 2) same network decision
        () => {
          const p = pick([25, 26, 27, 28]); const b = pick(['192.168.1', '10.0.5', '172.16.9']); const block = Math.pow(2, 32 - p);
          const same = R(2) === 0; const base = block * R(256 / block); const h1 = base + 1 + R(block - 2); let h2;
          if (same) { do { h2 = base + 1 + R(block - 2); } while (h2 === h1); } else { const other = (base + block * (1 + R(Math.max(1, 256 / block - 1)))) % 256; h2 = other + 1 + R(block - 2); if (h2 > 254) h2 = other + 1; }
          const ipA = b + '.' + h1, ipB = b + '.' + h2; const nA = A.info(ipA, p).net, nB = A.info(ipB, p).net; const eq = nA === nB;
          const why = 'PC-A öz mask-ı ilə (' + A.maskS(p) + ') hesablayır: ' + ipA + ' → network ' + nA + '; ' + ipB + ' → network ' + nB + '. ' + (eq ? 'Network-lər eynidir, buna görə birbaşa göndərir.' : 'Network-lər fərqlidir, buna görə default gateway-ə göndərir.');
          return { id: 'p1t2-g-same', concept: 'same-network', obj: 'Eyni network qərarı', _meta: { ipA, ipB, p, eq },
            stem: '<p>PC-A: <span class="m">' + ipA + '</span>, mask <span class="m">' + A.maskS(p) + '</span>. O, <span class="m">' + ipB + '</span> ünvanına paket göndərmək istəyir. PC-A nə edəcək?</p>',
            options: [{ t: 'Birbaşa hədəfə göndərəcək (ARP ilə hədəfin MAC-ini soruşacaq).', ok: eq, why: eq ? 'Düzdür: ' + why : 'Hədəf başqa network-dədir, birbaşa göndərmək olmaz. ' + why }, { t: 'Default gateway-ə göndərəcək (ARP ilə gateway-in MAC-ini soruşacaq).', ok: !eq, why: !eq ? 'Düzdür: ' + why : 'Hədəf eyni network-dədir, gateway-ə ehtiyac yoxdur. ' + why }] };
        },
        // 3) prefix/mask/hosts/bits
        () => {
          const kind = pick(['p2m', 'm2p', 'hosts', 'borrow']);
          if (kind === 'p2m') { const p = pick([25, 26, 27, 28, 29, 30, 19, 20, 21, 22, 23]); const ans = A.maskS(p); return { id: 'p1t2-g-conv', concept: 'mid-masks', obj: 'Prefix ↔ mask', type: 'num', _meta: { kind, p, ans }, stem: '<p><span class="m">/' + p + '</span> prefix-in onluq mask-ı nədir?</p>', placeholder: 'a.b.c.d', check: r => r.trim() === ans, solution: p + ' bit 1: ' + A.bits(A.maskN(p)).join('').match(/.{8}/g).join('.') + ' = <span class="m">' + ans + '</span>.' }; }
          if (kind === 'm2p') { const p = pick([25, 26, 27, 28, 29, 30, 19, 20, 21, 22, 23]); const m = A.maskS(p); return { id: 'p1t2-g-conv', concept: 'mid-masks', obj: 'Prefix ↔ mask', type: 'num', _meta: { kind, p, ans: String(p) }, stem: '<p><span class="m">' + m + '</span> mask-ının prefix length-i (/n) nədir? Yalnız rəqəmi yaz.</p>', placeholder: 'rəqəm', check: r => r.trim().replace('/', '') === String(p), solution: 'Mask-ın ikilik yazılışında 1-lərin sayı: ' + A.bits(A.maskN(p)).join('').match(/.{8}/g).join('.') + ' → <b>' + p + '</b>.' }; }
          if (kind === 'hosts') { const p = pick([20, 22, 24, 25, 26, 27, 28, 29, 30]); const h = 32 - p; const ans = Math.pow(2, h) - 2; return { id: 'p1t2-g-hosts', concept: 'addr-types', obj: 'Host sayı', type: 'num', _meta: { kind, p, ans: String(ans) }, stem: '<p>/<b>' + p + '</b> prefix-li subnet-də <b>istifadə olunan host</b> ünvanlarının sayı neçədir?</p>', placeholder: 'rəqəm', check: r => r.trim() === String(ans), solution: 'Host bitləri: 32 − ' + p + ' = ' + h + '. 2^' + h + ' = ' + Math.pow(2, h) + ', network və broadcast ünvanlarını çıx: <b>' + ans + '</b>.' }; }
          const nsub = pick([2, 4, 8, 16, 32]); const n = Math.log2(nsub); return { id: 'p1t2-g-borrow', concept: 'split', obj: 'Subnetting: bit borc götürmə', type: 'num', _meta: { kind, nsub, ans: String(24 + n) }, stem: '<p><span class="m">192.168.0.0/24</span> network-ünü <b>' + nsub + '</b> bərabər subnet-ə bölürsən. Yeni prefix length nə olacaq? Yalnız rəqəmi yaz.</p>', placeholder: 'rəqəm', check: r => r.trim().replace('/', '') === String(24 + n), solution: '2^n = ' + nsub + ' → n = ' + n + ' bit borc. Yeni prefix: 24 + ' + n + ' = <b>' + (24 + n) + '</b>.' };
        },
      ],
      pool: [
        { id: 'p1t2-q1', concept: 'mask-what', obj: 'Mask-ın vəzifəsi',
          stem: '<p>Subnet mask-ın əsas vəzifəsi nədir?</p>',
          options: [
            { t: 'Network və host hissələrinin sərhədini göstərmək.', ok: true, why: 'Mask-da 1 olan bitlər network hissəsidir. Host hədəfin eyni network-də olub-olmadığını bununla müəyyən edir. Bu tək qərar paketin birbaşa, yoxsa gateway vasitəsilə gedəcəyini təyin edir.' },
            { t: 'IP ünvanını şifrələmək ki, paketi kənar şəxs oxuya bilməsin.', why: 'Mask heç nəyi şifrələmir. O, ünvanın hissələrini bölən sadə bit şablonudur.' },
            { t: 'Hədəf IP ünvanına uyğun cihazın MAC ünvanını tapmaq.', why: 'MAC ünvanını ARP tapır (Layer 2 məsələsi). Mask yalnız IP ünvanı üzərində işləyir.' },
            { t: 'Paketin keçə biləcəyi maksimum router sayını (TTL) təyin etmək.', why: 'Router sayını TTL məhdudlaşdırır və o, IP başlığının ayrıca sahəsidir; mask-la əlaqəsi yoxdur.' },
          ] },
        { id: 'p1t2-q2', concept: 'mid-masks', obj: 'Etibarlı mask',
          stem: '<p>Aşağıdakı mask-lardan hansı <b>etibarlı deyil</b>?</p>',
          options: [
            { t: '255.255.253.0', ok: true, why: '253 = 11111101: bir 0-dan sonra yenidən 1 gəlir. Mask yalnız ardıcıl 1-lərdən sonra ardıcıl 0-lardan ibarət ola bilər, çünki network hissəsi ünvanın əvvəlindən başlayan bir blok olmalıdır.' },
            { t: '255.255.255.224', why: '224 = 11100000: ardıcıl 3 bir, sonra sıfırlar. Etibarlıdır (/27).' },
            { t: '255.255.128.0', why: '128 = 10000000, etibarlıdır (/17).' },
            { t: '255.255.255.252', why: '252 = 11111100, etibarlıdır (/30).' },
          ] },
        { id: 'p1t2-q3', concept: 'addr-types', obj: 'Network address',
          stem: '<p><span class="m">192.168.1.64/26</span> ünvanı haqqında hansı fikir düzgündür?</p>',
          options: [
            { t: 'Bu, network address-dir: host bitlərinin hamısı 0-dır və cihaza verilmir.', ok: true, why: '/26-da blok 64-dür, 64 blok mislidir. Son 6 bit (host bitləri) 000000 olur, yəni bu ünvan network-ün özünü göstərir.' },
            { t: 'Bu, broadcast address-dir: network-dəki hamıya göndərmək üçündür.', why: 'Bu subnet-in broadcast ünvanı 192.168.1.127-dir (növbəti network 128 − 1). 64 host bitləri 0 olan ünvandır.' },
            { t: 'Bu, ilk istifadə olunan host ünvanıdır, ona cihaz təyin etmək olar.', why: 'İlk host network + 1 = 192.168.1.65-dir. .64 network address-dir.' },
            { t: 'Bu, son istifadə olunan host ünvanıdır.', why: 'Son host broadcast − 1 = 192.168.1.126-dır.' },
          ] },
        { id: 'p1t2-q4', concept: 'addr-types', obj: '2^h − 2 formulu',
          stem: '<p>Subnet-də istifadə olunan host sayı niyə 2<sup>h</sup> deyil, 2<sup>h</sup> − 2 ilə hesablanır?</p>',
          options: [
            { t: 'Network ünvanı (hamısı 0) və broadcast ünvanı (hamısı 1) host-a verilmir.', ok: true, why: 'Bu iki ünvan xüsusi məna daşıyır: biri network-ün özünü, digəri network daxilində hamıya göndərməyi göstərir. Buna görə 2^h ünvandan 2-si host üçün istifadə olunmur.' },
            { t: 'İki ünvan router interface-ləri və default gateway üçün ayrılır.', why: 'Router bir interface üçün bir ünvan götürür və o, istifadə olunan host ünvanlarından biridir; −2-yə daxil deyil. Çıxılan iki ünvan həmişə network və broadcast-dır.' },
            { t: 'İki ünvan DHCP server və DNS server üçün avtomatik rezerv olunur.', why: 'Bu serverlər də adi host ünvanı götürür. Heç bir protokol subnet-də avtomatik 2 ünvan rezerv etmir.' },
            { t: 'Ethernet standartı hər network-də 2 ünvanın boş saxlanmasını tələb edir.', why: 'Ethernet MAC ilə işləyir, IP ünvanlarının ayrılmasında iştirak etmir. Səbəb IP ünvanlama qaydasındadır.' },
          ] },
        { id: 'p1t2-q5', concept: 'same-network', obj: 'Fərqli network-ə göndərmə',
          stem: '<p>PC-A <span class="m">192.168.1.10/24</span> ünvanında <span class="m">192.168.2.20</span>-yə paket göndərmək istəyir. PC-A nə edir?</p>',
          options: [
            { t: 'Hədəf fərqli network-dədir, ona görə paketi default gateway-ə göndərir.', ok: true, why: '192.168.1.10/24-ün network-ü 192.168.1.0, hədəf isə 192.168.2.0-dadır. Fərqli network olduğu üçün kadrın Destination MAC-i gateway-in MAC-i olur; router paketi sonra yönləndirir.' },
            { t: 'ARP ilə 192.168.2.20-nin MAC-ini soruşur və paketi birbaşa ona göndərir.', why: 'ARP sorğusu broadcast-dır və router-dən keçmir; fərqli network-dəki cihaz bunu görə bilməz. Ona görə ARP gateway üçün göndərilir.' },
            { t: 'Paketi atır, çünki host fərqli network-ə birbaşa paket göndərə bilməz.', why: 'Fərqli network-lərə çıxmaq mümkündür: bu, default gateway-in vəzifəsidir.' },
            { t: 'Paketi broadcast kimi bütün network-ə göndərir ki, router onu tutsun.', why: 'Paket unicast-dır və tək hədəfə yönəlib. Broadcast yalnız xüsusi hallarda (ARP, DHCP) olur.' },
          ] },
        { id: 'p1t2-q6', concept: 'same-network', obj: 'Qərarı hansı mask verir',
          stem: '<p>Host hədəfin eyni network-də olub-olmadığına qərar verəndə <b>hansı mask-dan</b> istifadə edir?</p>',
          options: [
            { t: 'Yalnız öz mask-ından, hədəfin mask-ını bilmir.', ok: true, why: 'Hostun hədəfin mask-ını bilmək imkanı yoxdur: mask IP paketində və ya ARP-da ötürülmür. Ona görə hədəf IP-ni öz mask-ı ilə AND edib öz network-ü ilə müqayisə edir.' },
            { t: 'Hədəfin mask-ından, çünki ARP ona bunu bildirir.', why: 'ARP yalnız IP-ni MAC-ə çevirir, mask haqqında heç nə daşımır.' },
            { t: 'Router-in mask-ından, çünki qərarı router verir.', why: 'Qərar hostun öz daxilində verilir; router bu mərhələdə iştirak etmir.' },
            { t: 'İki mask-ın ortaq hissəsindən, yəni ortaq 1-lərdən.', why: 'İki mask müqayisə olunmur, çünki hədəfin mask-ı məlum deyil.' },
          ] },
        { id: 'p1t2-q7', concept: 'host-config', obj: 'Gateway subnet xətası',
          stem: '<p>PC: <span class="m">192.168.10.200/26</span>, gateway <span class="m">192.168.10.1</span>. Niyə gateway-ə çata bilmir?</p>',
          options: [
            { t: 'Gateway PC-dən fərqli subnet-dədir: PC .192/26-dadır, gateway .0/26-da.', ok: true, why: '/26: blok 64. 200 → subnet 192–255. Gateway .1 isə 0–63 subnet-indədir. PC .1-i fərqli network sayır, ona görə birbaşa göndərə bilmir. Gateway həmişə hostla eyni subnet-də olmalıdır.' },
            { t: '192.168.10.200 bu subnet-in broadcast ünvanıdır, host-a verilmir.', why: 'Bu subnet-də broadcast .255-dir. .200 adi host ünvanıdır.' },
            { t: 'Gateway ünvanı həmişə subnet-in son host ünvanı (.254) olmalıdır.', why: 'Gateway ünvanı üçün sabit qayda yoxdur. Vacib olan subnet daxilində olmasıdır.' },
            { t: '/26 mask-lı subnet-də default gateway təyin etmək mümkün deyil.', why: 'İstənilən subnet-də gateway ola bilər, mask ölçüsü buna mane olmur.' },
          ] },
        { id: 'p1t2-q8', concept: 'split', obj: 'Bit borc götürmə',
          stem: '<p>/24 network-ü <b>4</b> bərabər subnet-ə bölmək üçün neçə bit borc götürülür və yeni prefix nə olur?</p>',
          options: [
            { t: '2 bit, /26.', ok: true, why: '2^n = 4 → n = 2. Hər borc götürülən bit prefix-i 1 artırır: 24 + 2 = 26. Hər subnet-də 2^6 − 2 = 62 host.' },
            { t: '4 bit, /28.', why: '4 subnet sayıdır, bit sayı deyil. 4 bitlə 2^4 = 16 subnet alınardı.' },
            { t: '1 bit, /25.', why: '1 bit yalnız 2^1 = 2 subnet verir.' },
            { t: '3 bit, /27.', why: '3 bit 8 subnet verir (2^3). 4 subnet üçün 2 bit kifayətdir.' },
          ] },
        { id: 'p1t2-q9', concept: 'split', obj: 'Host hansı subnet-dədir',
          stem: '<p><span class="m">192.168.1.0/24</span> network-ü /26 ilə bölünüb. <span class="m">192.168.1.100</span> hansı subnet-dədir?</p>',
          options: [
            { t: '192.168.1.64/26 (host aralığı .65 – .126)', ok: true, why: '/26 blok ölçüsü 64: bloklar 0, 64, 128, 192. 100 üçün 64 ≤ 100 < 128, deməli subnet .64-dür, broadcast .127.' },
            { t: '192.168.1.0/26 (host aralığı .1 – .62)', why: 'Bu subnet .0–.63 aralığını əhatə edir, 100 bu aralığa düşmür.' },
            { t: '192.168.1.96/26 (host aralığı .97 – .158)', why: '.96 /26 üçün blok başlanğıcı deyil (blok ölçüsü 64-dür, mislilər 0, 64, 128, 192).' },
            { t: '192.168.1.128/26 (host aralığı .129 – .190)', why: 'Bu subnet .128-dən başlayır; 100 ondan kiçikdir.' },
          ] },
        { id: 'p1t2-q10', concept: 'host-config', obj: 'Broadcast ünvanı host-a verilməz',
          stem: '<p>Administrator PC-yə <span class="m">192.168.5.63/26</span> verib. Problem nədir?</p>',
          options: [
            { t: '192.168.5.63 bu subnet-in (.0/26) broadcast ünvanıdır, host-a verilmir.', ok: true, why: '/26: blok 64, subnet 0–63. Son ünvan (63) host bitlərinin hamısı 1 olan broadcast-dır.' },
            { t: '192.168.5.63 bu subnet-in (.0/26) network ünvanıdır, host-a verilmir.', why: 'Network ünvanı host bitlərinin hamısı 0 olandır, yəni burada .0. 63 isə hamısı 1 olandır.' },
            { t: 'Bu ünvan private aralığa düşmür, internetdə route olunur.', why: '192.168.0.0/16 private aralığıdır, ünvan private-dir. Problem ünvanın subnet daxilindəki mövqeyindədir.' },
            { t: 'Problem yoxdur, .63 bu subnet-də normal host ünvanıdır və verilə bilər.', why: '/26-da .63 broadcast-dır. Host ünvanları .1–.62 aralığındadır.' },
          ] },
      ],
    },
  });
})();
