(function () {
  const pick = PT.pick; const R = PT.randInt; const shuffle = PT.shuffle;
  const hx = n => n.toString(16).padStart(2, '0');
  const bin8 = n => n.toString(2).padStart(8, '0');

  /* destination -> cast type, for the generator */
  const DST = [
    ['MAC <span class="m">ff:ff:ff:ff:ff:ff</span>', 'broadcast', 'Bütün 48 bit 1 olan MAC broadcast-dır.'],
    ['IP <span class="m">255.255.255.255</span>', 'broadcast', '255.255.255.255 limited broadcast ünvanıdır.'],
    ['IP <span class="m">192.168.1.255</span> (mask /24)', 'broadcast', 'Host bitləri hamısı 1 olan ünvan subnet-in broadcast ünvanıdır.'],
    ['MAC <span class="m">01:00:5e:00:00:05</span>', 'multicast', '01:00:5E ilə başlayan MAC multicast üçündür.'],
    ['IP <span class="m">224.0.0.5</span>', 'multicast', '224.0.0.0 – 239.255.255.255 aralığı multicast-dır.'],
    ['IP <span class="m">239.1.1.1</span>', 'multicast', '239.x.x.x multicast aralığındadır.'],
    ['IP <span class="m">192.168.1.20</span> (mask /24, host ünvanı)', 'unicast', 'Tək cihaza aid adi host ünvanıdır.'],
    ['MAC <span class="m">00:50:56:a1:03:9b</span>', 'unicast', 'İlk bayt 00: I/G biti 0, tək cihazın MAC-idir.'],
  ];

  PT.topic({
    id: 'p1t4',
    objectives: [
      'Unicast, broadcast və multicast-ı Destination ünvanından tanımaq',
      'Switch və router-in hər növə necə davrandığını izah etmək',
      'Broadcast domain-ləri saymaq və böyük domain-in problemini izah etmək',
      'Limited və directed broadcast ünvanlarını fərqləndirmək',
      'Source MAC-də I/G bitinə görə anormal frame-i tapmaq',
    ],
    explain: PT.frag['p1/t04/explain'], cheat: PT.frag['p1/t04/cheat'],

    lab: {
      title: 'Lab 4: Cast növlərini tanı və trafiki oxu',
      goal: 'Trafiki Destination ünvanına görə təsnif etmək, broadcast domain saymaq, böyük domain-in problemini həll etmək və capture-də anormal frame tapmaq.',
      why: 'SOC-da hər capture və hər log əvvəlcə "bu trafik kimə yönəlib?" sualı ilə oxunur. Broadcast və multicast adi fon trafikidir, amma onların arasında anormal olanı seçə bilmək lazımdır.',
      minutes: 35,
      finish: 'Cast növlərini tanıyır, broadcast domain sayır və capture-də anormal frame-i seçə bilirsən. Növbəti mövzularda broadcast və unicast qarışığını bu biliklə oxuyacaqsan.',
      steps: [
        { id: 's1', title: 'Plan', type: 'info', button: 'Başlayaq',
          body: '<p>Bu labda Packet Tracer lazım deyil. Ardıcıllıq:</p><ol><li>Ünvanı cast növü ilə birləşdir.</li><li>Ssenariləri cast növünə görə ayır.</li><li>Broadcast domain-ləri say.</li><li>Capture-dəki yanlış şərhi tap.</li><li>Anormal frame-i tap.</li><li>İki real ticket-i həll et.</li></ol>' },
        { id: 's2', title: 'Ünvanı cast növü ilə birləşdir', type: 'match',
          body: '<p>Hər Destination ünvanı hansı cast növünə aiddir?</p>',
          pairs: [
            { l: 'MAC <span class="m">ff:ff:ff:ff:ff:ff</span>', r: 'Broadcast', why: 'Bütün bitlər 1: network-dəki hamıya.' },
            { l: 'IP <span class="m">192.168.1.255</span> (/24)', r: 'Broadcast', why: 'Host bitləri hamısı 1: subnet-in broadcast ünvanı.' },
            { l: 'IP <span class="m">239.1.1.1</span>', r: 'Multicast', why: '224.0.0.0 – 239.255.255.255 multicast aralığıdır.' },
            { l: 'MAC <span class="m">01:00:5e:00:00:05</span>', r: 'Multicast', why: '01:00:5E ilə başlayan MAC multicast üçündür.' },
            { l: 'IP <span class="m">192.168.1.20</span> (host ünvanı)', r: 'Unicast', why: 'Tək cihaza aid ünvandır.' },
            { l: 'MAC <span class="m">00:50:56:a1:03:9b</span>', r: 'Unicast', why: 'Adi cihaz MAC-i, I/G biti 0.' },
          ],
          hints: ['Əvvəl asan olanları seç: hamısı F olan MAC və 224-239 aralığı.'] },
        { id: 's3', title: 'Hansı cast növüdür?', type: 'form',
          body: '<p>Hər ssenari üçün cast növünü yaz: <b>unicast</b>, <b>broadcast</b> və ya <b>multicast</b>.</p>',
          fields: [
            { label: 'PC hədəfin MAC ünvanını bilmir və "bu IP kimindir?" sorğusunu hamıya göndərir', placeholder: 'növ', answers: ['broadcast'], wrong: 'Göndərən hədəfin kim olduğunu bilmir və hamıya soruşur.' },
            { label: 'PC veb serverə HTTP sorğusu göndərir', placeholder: 'növ', answers: ['unicast'], wrong: 'Bir göndərən, bir hədəf.' },
            { label: 'Router yerli router-lərə 224.0.0.5 ünvanına mesaj göndərir', placeholder: 'növ', answers: ['multicast'], wrong: '224.0.0.0 – 239.255.255.255 aralığı.' },
            { label: 'Yeni qoşulan PC-nin hələ IP ünvanı yoxdur və ünvan verən serveri axtarır', placeholder: 'növ', answers: ['broadcast'], wrong: 'Göndərən serverin kim olduğunu bilmir, hamıya yayır.' },
            { label: 'Server 20 izləyiciyə eyni video axınını bir paketlə göndərir', placeholder: 'növ', answers: ['multicast'], wrong: 'Yalnız group-a qoşulanlara.' },
          ],
          hints: ['Destination ünvan tək cihazdır, hamıdır, yoxsa group?'],
          solution: 'ARP-a bənzər sorğu: broadcast. HTTP: unicast. 224.0.0.5: multicast. Ünvan axtaran PC: broadcast. Video: multicast.' },
        { id: 's4', title: 'Broadcast domain-ləri say', type: 'form',
          body: '<div class="figure"><svg viewBox="0 0 700 200" role="img" aria-label="Üç switch, bir router"><rect x="30" y="40" width="90" height="34" rx="4" class="box-s"/><text x="75" y="62" text-anchor="middle" font-size="13">Switch A</text><rect x="30" y="110" width="40" height="28" rx="3" class="fill-blue"/><text x="50" y="129" text-anchor="middle" font-size="11">PC1</text><rect x="80" y="110" width="40" height="28" rx="3" class="fill-blue"/><text x="100" y="129" text-anchor="middle" font-size="11">PC2</text><line x1="50" y1="110" x2="65" y2="74" class="ln"/><line x1="100" y1="110" x2="85" y2="74" class="ln"/><line x1="120" y1="57" x2="235" y2="57" class="ln"/><rect x="235" y="40" width="90" height="34" rx="4" class="box-s"/><text x="280" y="62" text-anchor="middle" font-size="13">Switch B</text><rect x="235" y="110" width="40" height="28" rx="3" class="fill-blue"/><text x="255" y="129" text-anchor="middle" font-size="11">PC3</text><rect x="285" y="110" width="40" height="28" rx="3" class="fill-blue"/><text x="305" y="129" text-anchor="middle" font-size="11">PC4</text><line x1="255" y1="110" x2="270" y2="74" class="ln"/><line x1="305" y1="110" x2="290" y2="74" class="ln"/><line x1="325" y1="57" x2="440" y2="57" class="ln"/><circle cx="500" cy="57" r="38" class="fill-yel"/><text x="500" y="54" text-anchor="middle" font-size="13" font-weight="700">Router</text><text x="500" y="70" text-anchor="middle" font-size="10">Gi0/0</text><line x1="538" y1="57" x2="590" y2="57" class="ln"/><rect x="590" y="40" width="90" height="34" rx="4" class="box-s"/><text x="635" y="62" text-anchor="middle" font-size="13">Switch C</text><rect x="590" y="110" width="40" height="28" rx="3" class="fill-blue"/><text x="610" y="129" text-anchor="middle" font-size="11">PC5</text><rect x="640" y="110" width="40" height="28" rx="3" class="fill-blue"/><text x="660" y="129" text-anchor="middle" font-size="11">PC6</text><line x1="610" y1="110" x2="625" y2="74" class="ln"/><line x1="660" y1="110" x2="645" y2="74" class="ln"/><text x="440" y="100" text-anchor="middle" font-size="10" class="t-dim">Gi0/1</text><text x="380" y="180" text-anchor="middle" font-size="12" class="t-dim">Switch A - Switch B kabellə birləşib. Switch B router-in Gi0/0 interface-inə, Switch C Gi0/1 interface-inə qoşulub.</text></svg></div><p>Sxemə bax. Broadcast domain-ləri say.</p>',
          fields: [
            { label: 'Broadcast domain sayı', placeholder: 'rəqəm', check: r => r.trim() === '2', wrong: 'Router-in neçə interface-i var? Kabellə birləşən Switch A və B neçə domain edir?' },
            { label: 'PC1 broadcast göndərir. Neçə PC onu alır? (PC1 daxil deyil)', placeholder: 'rəqəm', check: r => r.trim() === '3', wrong: 'PC1 ilə eyni broadcast domain-də başqa neçə PC var? Router broadcast-ı keçirmir.' },
          ],
          hints: ['Switch-lər broadcast domain-i böyüdür. Router hər interface üçün ayrı domain yaradır.', 'Switch A və B kabellə birləşib: hamısı bir domain-dir.'],
          solution: '2 domain: (1) Switch A + Switch B (PC1-PC4), (2) Switch C (PC5, PC6). PC1-in broadcast-ını PC2, PC3 və PC4 alır (3 PC).' },
        { id: 's5', title: 'Capture şərhində səhvi tap', type: 'spot',
          body: '<p>Analitik capture-dən aşağıdakı qeydləri yazıb. <b>Bir qeyd səhvdir.</b> Onu tap.</p>',
          lines: [
            { t: '1.  Destination MAC ff:ff:ff:ff:ff:ff olan frame broadcast-dır, switch onu bütün portlara göndərir.' },
            { t: '2.  Router eyni frame-i başqa network-ə də ötürür ki, hamı görsün.', bad: true, why: 'Router broadcast-ı ötürmür. Router interface-i broadcast domain-in sərhədidir.' },
            { t: '3.  Destination IP 224.0.0.5 multicast-dır, MAC-i 01:00:5e ilə başlayır.' },
            { t: '4.  Destination IP 255.255.255.255 limited broadcast-dır və öz network-ündə qalır.' },
            { t: '5.  Destination IP 192.168.1.20 olan frame unicast-dır və yalnız bir cihaza gedir.' },
          ],
          fix: { label: 'Router broadcast-ı ötürürmü? (bəli / xeyr)', placeholder: 'bəli / xeyr', answers: ['xeyr', 'yox', 'no'], wrong: 'Router interface-i broadcast domain-in sərhədidir.' },
          hints: ['Router hansı sərhədi yaradır?'] },
        { id: 's6', title: 'Capture oxu: anormal frame hansıdır?', type: 'choice',
          body: '<p>Wireshark capture-ində beş sətir var. Biri normal cihazın göndərə <b>bilməyəcəyi</b> frame-dir.</p><pre class="pre">1  src 00:50:56:a1:03:9b  dst ff:ff:ff:ff:ff:ff  broadcast sorğusu\n2  src 00:0c:29:7e:41:d2  dst ff:ff:ff:ff:ff:ff  0.0.0.0 → 255.255.255.255\n3  src 00:1a:2b:3c:4d:5e  dst 01:00:5e:00:00:05  192.168.1.1 → 224.0.0.5\n4  src ff:ff:ff:ff:ff:ff  dst 00:0c:29:7e:41:d2  192.168.1.77 → 192.168.1.10\n5  src 00:0c:29:aa:bb:cc  dst 01:00:5e:00:00:fb  → 224.0.0.251</pre>',
          options: [
            { t: '4-cü sətir: Source MAC broadcast ünvanıdır.', ok: true, why: 'Source MAC unicast olmalıdır (ilk baytın I/G biti 0). ff:ff:ff:ff:ff:ff group ünvanıdır və heç bir cihazın öz ünvanı ola bilməz. Bu frame ya saxtadır, ya da xətalı cihazdan gəlir.' },
            { t: '1-ci sətir: Destination MAC broadcast-dır.', why: 'Broadcast Destination tərəfdə normaldır: göndərən hamıya soruşur.' },
            { t: '2-ci sətir: Source IP 0.0.0.0, Destination 255.255.255.255.', why: 'Hələ IP ünvanı olmayan cihaz belə göndərir: Source 0.0.0.0, Destination limited broadcast. Normaldır.' },
            { t: '3-cü sətir: Destination multicast MAC 01:00:5e:00:00:05.', why: '224.0.0.5 ünvanının MAC-i budur. Source MAC unicast-dır. Normaldır.' },
            { t: '5-ci sətir: Destination 224.0.0.251.', why: 'Bu multicast ünvanıdır və MAC-i 01:00:5e ilə başlayır. Source unicast olduğu üçün normaldır.' },
          ],
          hints: ['Destination tərəfdə broadcast və multicast normaldır. Source MAC tərəfə bax: hansı cihaz öz frame-ini group ünvanından göndərə bilər?'],
          after: '<p>Bu yoxlama capture-də sürətli filtrdir: Source MAC-də I/G biti 1 olan frame həmişə şübhəlidir.</p>' },
        { id: 's7', title: 'Ticket: "Şəbəkə yavaşdır"', type: 'ticket',
          body: '<p><b>İstifadəçilər deyir:</b> "Mərtəbədəki bütün 300 PC bir network-dədir, səhər şəbəkə yavaşdır." Monitorinq göstərir ki, switch portlarında saniyədə yüzlərlə broadcast frame var.</p>',
          stages: [
            { q: '<p>300 PC-nin bir broadcast domain-də olması nə deməkdir?</p>', options: [
              { t: 'Bir PC broadcast göndərəndə həmin frame qalan 299 PC-yə də çatır və hər biri onu emal edir.', ok: true, why: 'Broadcast domain-dəki bütün cihazlar bir-birinin broadcast-ını alır. Cihaz sayı artdıqca broadcast yükü artır.' },
              { t: 'Hər PC yalnız öz switch-inin broadcast-ını alır.', why: 'Kabellə birləşən switch-lər bir domain edir, yük bütün cihazlara paylanır.' },
              { t: 'Broadcast yalnız server-ə çatır.', why: 'Broadcast bütün cihazlara çatır, ünvan "hamı"dır.' },
              { t: 'Domain böyük olduqda broadcast avtomatik azalır.', why: 'Əksinə, cihaz sayı artdıqca broadcast-ların sayı artır.' },
            ] },
            { q: '<p>Problemi azaltmaq üçün nə etmək lazımdır?</p>', options: [
              { t: 'Network-ü bir neçə kiçik subnet-ə bölüb aralarına router qoymaq. Hər subnet ayrı broadcast domain olur.', ok: true, why: 'Router broadcast-ı ötürmür. Hər subnet-in broadcast-ı yalnız öz cihazlarına çatır.' },
              { t: 'Daha çox switch əlavə etmək.', why: 'Kabellə birləşən switch-lər domain-i ayırmır, əksinə böyüdür.' },
              { t: 'Bütün PC-lərə statik IP vermək.', why: 'IP ünvanının statik olması broadcast sayına təsir etmir.' },
              { t: 'Switch portlarını sürətləndirmək.', why: 'Sürət broadcast-ın hər cihaza çatmasını dəyişmir.' },
            ] },
            { q: '<p>300 PC 3 subnet-ə bölündü (hər birində 100 PC). PC1 broadcast göndərir. Neçə PC onu alır (PC1 daxil deyil)?</p>', options: [
              { t: '99 PC: yalnız PC1-in öz subnet-indəkilər.', ok: true, why: 'Router broadcast-ı ötürmür. PC1-in domain-ində 100 PC var, PC1 xaric 99.' },
              { t: '299 PC: broadcast hamıya çatır.', why: 'Bu bölünməzdən əvvəlki vəziyyətdir. Router indi araya girib.' },
              { t: '200 PC: digər iki subnet.', why: 'Digər subnet-lər başqa domain-dir və PC1-in broadcast-ını almır.' },
              { t: '0 PC: broadcast artıq işləmir.', why: 'Broadcast öz domain-ində işləməyə davam edir.' },
            ] },
          ],
          after: '<p>Bu bölmənin əsas səbəbi bundan ibarətdir: subnetting həm ünvanları təşkil edir, həm də broadcast domain-i kiçildir.</p>' },
        { id: 's8', title: 'Qərar: 200 PC-yə axın', type: 'choice',
          body: '<p>Şirkətdə 200 PC-dən yalnız 40-ı canlı təlimi izləyir. Video axını bir serverdən gəlir. Mühəndis hansı üsulu seçməlidir?</p>',
          options: [
            { t: 'Multicast: izləyən PC-lər group-a qoşulur, server bir axın göndərir.', ok: true, why: 'Server bir axın göndərir və şəbəkə onu yalnız group-a qoşulan cihazlara çatdırır. Server yükü izləyici sayından asılı deyil.' },
            { t: 'Unicast: server hər izləyən PC-yə ayrıca axın göndərir.', why: 'Bu işləyir, amma server və link yükü izləyici sayına mütənasib artır (40 axın, eyni məlumat).' },
            { t: 'Broadcast: server axını hamıya göndərir, lazım olan alsın.', why: 'Broadcast 200 PC-nin hamısına çatır və hər birinin prosessorunu yükləyir. Router-dən keçmədiyi üçün başqa subnet-dəkilər də axını almır.' },
          ],
          hints: ['Tələblər: yalnız lazım olanlar alsın, server yükü az olsun.'],
          after: '<p>Qaydası: bir göndərən və seçilmiş çox qəbuledən varsa multicast, hamıya lazımdırsa broadcast, bir hədəf varsa unicast.</p>' },
      ],
    },

    quiz: {
      draw: 8,
      gens: [
        /* classify a destination */
        () => {
          const it = pick(DST); const types = ['unicast', 'broadcast', 'multicast'];
          return { id: 'p1t4-g-cls', concept: 'cast-why', obj: 'Destination ünvandan cast növünü tanımaq', _meta: { item: it[0], ans: it[1] },
            stem: '<p>Frame-in Destination ünvanı: ' + it[0] + '. Bu hansı cast növüdür?</p>',
            options: types.map(t => ({ t: t.charAt(0).toUpperCase() + t.slice(1), ok: t === it[1], why: t === it[1] ? it[2] : 'Bu ünvan ' + it[1] + ' növüdür. ' + it[2] })) };
        },
        /* invalid source MAC finder */
        () => {
          const evens = [0x00, 0x02, 0x0a, 0x3c, 0x52, 0x7c, 0x1a, 0xa4, 0xd8, 0xfa, 0x04, 0x68, 0x00, 0x00];
          const rb = () => R(256); const mk = f => [f, rb(), rb(), rb(), rb(), rb()];
          const badKind = pick(['01', '33', 'ff', '03']);
          let bad;
          if (badKind === '01') bad = [0x01, 0x00, 0x5e, rb() & 0x7f, rb(), rb()]; else if (badKind === '33') bad = [0x33, 0x33, rb(), rb(), rb(), rb()]; else if (badKind === 'ff') bad = [255, 255, 255, 255, 255, 255]; else bad = mk(0x03);
          const goods = []; const used = new Set();
          while (goods.length < 3) { const f = pick(evens); if (used.has(f)) continue; used.add(f); goods.push(mk(f)); }
          const all = shuffle([bad, ...goods]); const m = b => b.map(hx).join(':');
          const idx = all.indexOf(bad);
          const why = b => { const f = b[0]; const bits = bin8(f); const odd = f & 1; return 'Birinci bayt ' + hx(f) + ' = ' + bits + ', ən sağ bit (I/G) = ' + odd + (odd ? ': group ünvanıdır, Source MAC ola bilməz.' : ': unicast ünvanıdır, Source MAC kimi normaldır.'); };
          return { id: 'p1t4-g-srcmac', concept: 'ig-bit', obj: 'Source MAC I/G biti', _meta: { macs: all.map(m), ans: idx },
            stem: '<p>Wireshark capture-ində dörd frame-in <b>Source MAC</b> ünvanı belədir. Hansı biri normal cihaz tərəfindən göndərilə <b>bilməz</b>?</p>',
            options: all.map(b => ({ t: m(b), ok: b === bad, why: why(b) })) };
        },
      ],
      pool: [
        { id: 'p1t4-q1', concept: 'broadcast-why', obj: 'Broadcast nə üçün lazımdır',
          stem: '<p>Cihaz hədəfin MAC ünvanını bilmir və onu soruşur. Sorğu niyə unicast yox, broadcast kimi göndərilir?</p>',
          options: [
            { t: 'Göndərən hədəfin MAC-ini bilmir, unicast üçün isə MAC lazımdır, ona görə hamıya yayır.', ok: true, why: 'Göndərən hədəfin MAC-ini bilmədiyi üçün unicast ünvanlaya bilmir. Yeganə yol hamıya göndərib sahibinin cavab verməsini gözləməkdir.' },
            { t: 'Sorğu çox böyük paketdir və unicast kanal onu daşıya bilmir, ona görə hamıya göndərilir.', why: 'Belə sorğu kiçik paketdir. Seçim ölçüdən yox, ünvanın bilinməməsindən asılıdır.' },
            { t: 'Broadcast daha təhlükəsizdir, çünki hamı görür və hər kəs onu yoxlaya bilir.', why: 'Broadcast təhlükəsizlik üçün deyil, ünvan bilinmədiyi üçündür. Əksinə, hamının görməsi saxta cavab hücumlarına şərait yaradır.' },
            { t: 'Switch unicast sorğuları keçirmir, yalnız broadcast keçirir, ona görə belə göndərilir.', why: 'Switch unicast frame-ləri keçirir. Ünvan məlum olsaydı sorğu unicast ola bilərdi.' },
          ] },
        { id: 'p1t4-q2', concept: 'unicast', obj: 'Switch unicast frame-i necə göndərir',
          stem: '<p>PC1 PC3-ə unicast frame göndərir. PC3-ün MAC ünvanı switch-in cədvəlindədir. Frame-i hansı portlara göndərir?</p>',
          options: [
            { t: 'Yalnız PC3-ün qoşulu olduğu porta.', ok: true, why: 'Switch Destination MAC-ə baxıb cihazın portunu tapır və frame-i yalnız ora göndərir. Digər cihazlar frame-i görmür.' },
            { t: 'Gələn port istisna olmaqla bütün portlara.', why: 'Hamıya göndərmək broadcast üçündür. Unicast frame yalnız hədəfə gedir.' },
            { t: 'PC3-ün portuna və qonşu portlara, ehtiyat üçün.', why: 'Switch "qonşu port" anlayışı ilə işləmir. Qərar MAC ünvanına görə verilir.' },
            { t: 'Heç hara, əvvəl hədəfdən təsdiq gözləyir.', why: 'Switch təsdiq istəmir, cədvələ baxıb dərhal göndərir.' },
          ] },
        { id: 'p1t4-q3', concept: 'bdomain', obj: 'Router və broadcast',
          stem: '<p>Router broadcast frame-i niyə başqa network-ə ötürmür?</p>',
          options: [
            { t: 'Router interface-i broadcast domain-in sərhədidir, ötürsə sorğular bütün şəbəkələrə yayılar.', ok: true, why: 'Router hər interface üçün ayrı network yaradır. Broadcast yalnız öz network-ü üçündür.' },
            { t: 'Router yalnız unicast paketləri başa düşür, broadcast formatını tanımır və atır.', why: 'Router broadcast-ı tanıyır. Ötürməməsi dizayn qərarıdır, qabiliyyətsizlik deyil.' },
            { t: 'Router-in prosessoru broadcast-ı emal etmək üçün çox yavaşdır, ona görə ötürmür.', why: 'Səbəb sürət deyil. Sürətli router da broadcast-ı ötürmür.' },
            { t: 'Broadcast frame-in TTL-i 1 olur və ilk router onu atır, ona görə ötürmür.', why: 'TTL IP-nin sahəsidir, broadcast frame isə Layer 2 hadisəsidir. Router onu ötürməməyi qərar verir.' },
          ] },
        { id: 'p1t4-q4', concept: 'bdomain', obj: 'Broadcast domain sayı',
          stem: '<p>Üç switch bir-birinə kabellə birləşib (A-B-C zənciri). Cəmi 12 PC var. Switch B router-in <b>tək</b> interface-inə qoşulub. Neçə broadcast domain var?</p>',
          options: [
            { t: '1, çünki birləşmiş switch-lər bir Layer 2 şəbəkəsi yaradır.', ok: true, why: 'Router-in tək interface-i də bu şəbəkəyə qoşulub, yəni bir domain var. Domain-ləri router interface-ləri ayırır, switch sayı yox.' },
            { t: '3, çünki hər switch öz broadcast domain-ini yaradır.', why: 'Switch domain-i ayırmır, böyüdür.' },
            { t: '4, çünki hər switch üçün bir, router üçün də bir domain sayılır.', why: 'Router bir interface vasitəsilə qoşulub və bu domain-in üzvüdür, ayrıca domain yaratmır.' },
            { t: '12, çünki hər PC-nin öz portu var.', why: 'PC-lər eyni Layer 2 şəbəkəsindədir. Hər PC ayrı domain olsaydı, heç biri digərini görməzdi.' },
          ] },
        { id: 'p1t4-q5', concept: 'bcast-ip', obj: 'Limited və directed broadcast',
          stem: '<p><span class="m">255.255.255.255</span> ilə <span class="m">192.168.1.255</span> (mask /24) arasında əsas fərq nədir?</p>',
          options: [
            { t: '255.255.255.255 router-dən keçmir, 192.168.1.255 konkret subnet üçündür.', ok: true, why: '255.255.255.255 limited broadcast-dır: göndərənin öz network-ündə qalır. 192.168.1.255 isə 192.168.1.0/24 subnet-in broadcast ünvanıdır (host bitləri hamısı 1).' },
            { t: 'Fərq yoxdur, hər ikisi şəbəkənin eyni broadcast ünvanını göstərir.', why: 'Biri ümumi limited broadcast-dır, digəri konkret subnet-in ünvanıdır.' },
            { t: '192.168.1.255 multicast ünvanıdır, 255.255.255.255 isə broadcast.', why: 'Multicast aralığı 224.0.0.0 – 239.255.255.255-dir. 192.168.1.255 subnet broadcast-ıdır.' },
            { t: '255.255.255.255 yalnız IPv6 üçündür.', why: '255.255.255.255 IPv4 ünvanıdır. IPv6-da broadcast ümumiyyətlə yoxdur.' },
          ] },
        { id: 'p1t4-q6', concept: 'multicast', obj: 'Multicast və broadcast fərqi',
          stem: '<p>Multicast broadcast-dan hansı əsas cəhətinə görə fərqlənir?</p>',
          options: [
            { t: 'Multicast yalnız group-a qoşulanlara çatır, broadcast hamıya.', ok: true, why: 'Multicast lazım olmayan cihazları yükləmir. Cihaz group-a qoşulmaq istədiyini bildirir və yalnız onlar frame-i emal edir.' },
            { t: 'Multicast router-dən həmişə keçir, broadcast isə heç vaxt keçmir.', why: 'Məsələn 224.0.0.0/24 aralığı router-dən heç vaxt keçmir. Keçmək group-un aralığından asılıdır, multicast-ın özündən yox.' },
            { t: 'Multicast yalnız IPv6-da mövcuddur, IPv4-də belə növ yoxdur.', why: 'IPv4-də də multicast aralığı var: 224.0.0.0 – 239.255.255.255.' },
            { t: 'Multicast frame-in Destination MAC-i FF:FF:FF:FF:FF:FF olur.', why: 'Bu broadcast MAC-idir. Multicast MAC 01:00:5E ilə başlayır.' },
          ] },
        { id: 'p1t4-q7', concept: 'multicast', obj: 'Multicast ünvan aralığı',
          stem: '<p>Hansı IP ünvanı IPv4 multicast aralığındadır?</p>',
          options: [
            { t: '239.1.1.1', ok: true, why: 'Multicast aralığı 224.0.0.0 – 239.255.255.255-dir.' },
            { t: '192.168.1.255', why: 'Bu ünvan 192.168.1.0/24 subnet-in broadcast ünvanıdır.' },
            { t: '127.0.0.1', why: 'Bu loopback ünvanıdır: cihazın özü.' },
            { t: '240.0.0.1', why: '240.x.x.x multicast aralığından kənardır. Multicast 239.255.255.255-də bitir.' },
          ] },
        { id: 'p1t4-q8', concept: 'ig-bit', obj: 'Anormal Source MAC',
          stem: '<p>Capture-də bir frame-in Source MAC-i <span class="m">01:00:5e:00:00:05</span>-dir. Bu nəyi göstərir?</p>',
          options: [
            { t: 'Anormaldır: group ünvanı Source MAC ola bilməz.', ok: true, why: '01 = 00000001: I/G biti 1, yəni group ünvanıdır. Source MAC bir cihazı göstərməlidir, ona görə yalnız unicast ola bilər.' },
            { t: 'Normaldır: router-lər öz frame-lərini bu MAC-dən göndərir.', why: '01:00:5E:00:00:05 router-lərin göndərdiyi mesajın Destination MAC-idir. Source router-in öz unicast MAC-idir.' },
            { t: 'Normaldır: bu, switch-in öz idarəetmə MAC-idir.', why: 'Switch-in öz MAC-i də unicast olmalıdır.' },
            { t: 'Yalnız Windows kompüterlər belə Source MAC-dən istifadə edir.', why: 'Heç bir əməliyyat sistemi Source MAC-ini group ünvanı kimi qurmur.' },
          ] },
        { id: 'p1t4-q9', concept: 'soc-cast', obj: 'Broadcast storm',
          stem: '<p>Switch portlarında saniyədə minlərlə broadcast frame görünür və şəbəkə yavaşlayıb. Ən ehtimal olunan səbəb nədir?</p>',
          options: [
            { t: 'Layer 2 loop: frame-lər switch-lər arasında dövr edir.', ok: true, why: 'Broadcast bütün portlara göndərilir. Switch-lər arasında loop varsa eyni frame dövr edir və hər dövrdə çoxalır. Layer 2-də TTL olmadığı üçün özü dayanmır.' },
            { t: 'Çox istifadəçi eyni anda sorğu göndərir və bu normal haldır.', why: 'Normal şəbəkədə broadcast saniyədə bir neçə olur, minlərlə yox. Bu həcm loop və ya hücum əlamətidir.' },
            { t: 'Router DNS sorğularını broadcast kimi bütün şəbəkəyə göndərir.', why: 'DNS sorğuları unicast gedir və router broadcast-ı ötürmür.' },
            { t: 'Switch portlarının sürəti həddindən yüksəkdir.', why: 'Sürət broadcast sayını artırmır.' },
          ] },
        { id: 'p1t4-q10', concept: 'cast-why', obj: 'Cast növü Destination-dan tanınır',
          stem: '<p>Cast növünü hansı sahədən tanıyırsan?</p>',
          options: [
            { t: 'Destination MAC və Destination IP ünvanından.', ok: true, why: 'Broadcast ünvanı hamısı 1, multicast 01:00:5E və 224-239 aralığı, unicast isə tək cihaz ünvanıdır.' },
            { t: 'Frame-in Source MAC ünvanından və göndərən cihazdan.', why: 'Source MAC həmişə unicast olmalıdır. Növü Destination göstərir.' },
            { t: 'Paketin TTL sahəsindən və yoldakı router sayından.', why: 'TTL paketin neçə router-dən keçə biləcəyini göstərir.' },
            { t: 'Layer 4 port nömrəsindən və protocol növündən.', why: 'Port nömrəsi hədəfdəki proqramı seçir, cast növünü yox.' },
          ] },
      ],
    },
  });
})();
