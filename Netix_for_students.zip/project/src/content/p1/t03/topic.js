(function () {
  const A = PT.addr; const pick = PT.pick; const R = PT.randInt;
  const hx = n => n.toString(16).padStart(2, '0');
  const macNorm = s => String(s).toLowerCase().replace(/[^0-9a-f]/g, '');
  const csum = b => { let s = 0; for (let i = 0; i < b.length; i += 2) s += (b[i] << 8) + (b[i + 1] || 0); while (s >> 16) s = (s & 0xFFFF) + (s >> 16); return (~s) & 0xFFFF; };
  const layerNo = n => r => { const d = String(r).match(/\d+/g) || []; return d.length === 1 && d[0] === String(n); };
  const rows16 = bytes => { const out = []; for (let i = 0; i < bytes.length; i += 16) out.push(('0000' + i.toString(16)).slice(-4) + '  ' + bytes.slice(i, i + 16).map(hx).join(' ')); return out.join('\n'); };
  const macStr = b => b.slice(0, 6).map(hx).join(':');
  const ipStr = b => b.join('.');

  // random Ethernet + IPv4 header (34 bytes), valid checksum
  function genFrame() {
    const mac = () => [0x00, pick([0x0c, 0x50, 0x1a, 0x0a, 0x25, 0x3c]), pick([0x29, 0x56, 0xa1, 0xf3, 0x7b, 0x44]), R(256), R(256), R(256)];
    const ipr = () => pick([[192, 168, R(250) + 1, R(250) + 2], [10, R(250) + 1, R(250) + 1, R(250) + 2], [172, 16 + R(16), R(250) + 1, R(250) + 2], [203, 0, 113, R(250) + 2]]);
    const dm = mac(), sm = mac(); let sip = ipr(), dip = ipr(); while (ipStr(sip) === ipStr(dip)) dip = ipr();
    const ttl = pick([32, 58, 63, 64, 117, 127, 128, 254, 255]); const proto = pick([1, 6, 17]); const len = 40 + R(1400); const id = R(65536);
    const ip = [0x45, 0, len >> 8, len & 255, id >> 8, id & 255, 0x40, 0, ttl, proto, 0, 0, ...sip, ...dip]; const c = csum(ip); ip[10] = c >> 8; ip[11] = c & 255;
    return { bytes: [...dm, ...sm, 0x08, 0x00, ...ip], dm, sm, sip, dip, ttl, proto };
  }
  const PN = { 1: 'ICMP', 6: 'TCP', 17: 'UDP' };

  PT.topic({
    id: 'p1t3',
    objectives: [
      'Encapsulation və decapsulation addımlarını, PDU adlarını sıra ilə demək',
      'Hər layer-in header-ində hansı sahələrin olduğunu demək (port, IP, TTL, Protocol, MAC, EtherType)',
      'TCP ilə UDP-ni müqayisə etmək və 3-way handshake-i izah etmək',
      'Router-dən keçəndə hansı ünvanların dəyişdiyini, hansıların dəyişmədiyini müəyyən etmək',
      'Hex dump-da Ethernet və IPv4 header-lərini oxumaq',
      'Log mənbəyinin hansı layer-ə qədər sübut verdiyini müəyyən etmək',
    ],
    explain: PT.frag['p1/t03/explain'], cheat: PT.frag['p1/t03/cheat'],

    lab: {
      title: 'Lab 3: Paketi izlə, başlığı oxu, layer-i tap',
      goal: 'PDU sırasını qurmaq, router-dən keçən paketin başlıqlarını izləmək, hex dump oxumaq və problemi layer-ə görə təyin etmək.',
      why: 'SOC analitiki log-a baxanda ilk sual "bu məlumat hansı layer-dən gəlir və mənə nəyi sübut edir?" olur. Bu lab həmin düşüncəni qurur.',
      minutes: 40,
      finish: 'Paketi başlıq-başlıq oxuya və problemi layer-ə bağlaya bilirsən. Bu bacarıq ARP, ICMP və switch mövzularında hər addımda lazım olacaq.',
      steps: [
        { id: 's1', title: 'Plan', type: 'info', button: 'Başlayaq',
          body: '<p>Bu labda Packet Tracer lazım deyil. Hər addımda əvvəl özün cavab ver, sonra yoxla. Cavab səhvdirsə ipucu istə, birbaşa həllə baxma.</p><ol><li>PDU sırasını qur.</li><li>PDU adlarını layer ilə bağla.</li><li>Switch hansı başlığa baxır?</li><li>Router-dən keçən paketin başlıqlarını izlə.</li><li>Hex dump-u özün oxu.</li><li>Log-dan nəyi bilmək olar? Problem hansı layer-dədir?</li></ol>' },
        { id: 's2', title: 'Encapsulation sırası', type: 'order',
          body: '<p>Brauzer veb sorğusu göndərir. Göndərən PC-də məlumat yuxarıdan aşağı gedir. PDU-ları yaranma sırası ilə düz (ilk yaranan yuxarıda olmaqla) düz.</p>',
          items: [
            { t: 'Data (Application layer)', why: 'Başlanğıc: proqramın göndərmək istədiyi məlumat. Hələ ünvan yoxdur.' },
            { t: 'Segment (Transport layer, TCP header əlavə olunur)', why: 'Transport layer port nömrələrini əlavə edir.' },
            { t: 'Packet (Network layer, IP header əlavə olunur)', why: 'Network layer IP ünvanlarını əlavə edir.' },
            { t: 'Frame (Data Link layer, Ethernet header və FCS əlavə olunur)', why: 'Data Link layer MAC ünvanlarını əlavə edir.' },
            { t: 'Bits (Physical layer, siqnal kimi göndərilir)', why: 'Sonda kadr bitlərə çevrilib kabelə verilir.' },
          ],
          hints: ['Hər layer yuxarıdan aldığını sarıyır. Ən yuxarı layer hansıdır, ən aşağı hansıdır?'],
          after: '<p>Qəbul edən cihaz bunu tərs sırada edir (decapsulation): Bits → Frame → Packet → Segment → Data.</p>' },
        { id: 's3', title: 'PDU adları', type: 'form',
          body: '<p>Hər layer-in PDU adını yaz (ingiliscə: Segment, Packet və ya Frame).</p>',
          fields: [
            { label: 'Layer 2 PDU adı', placeholder: 'ad', answers: ['frame', 'kadr'], wrong: 'Ethernet header əlavə olunan vahid.' },
            { label: 'Layer 3 PDU adı', placeholder: 'ad', answers: ['packet', 'paket'], wrong: 'IP header əlavə olunan vahid.' },
            { label: 'Layer 4 PDU adı (TCP)', placeholder: 'ad', answers: ['segment'], wrong: 'TCP header əlavə olunan vahid.' },
          ],
          hints: ['Layer 2 → F, Layer 3 → P, Layer 4 → S ilə başlayır.'],
          solution: 'Layer 2 = Frame, Layer 3 = Packet, Layer 4 = Segment (UDP-də datagram).' },
        { id: 's4', title: 'Switch nəyə baxır?', type: 'choice',
          body: '<p>PC1 eyni switch-ə qoşulu PC2-yə veb sorğusu (TCP, port 80) göndərir. Switch gələn kadrı hara göndərəcəyini <b>hansı məlumata</b> əsasən müəyyən edir?</p>',
          options: [
            { t: 'Ethernet başlığındakı Destination MAC ünvanına.', ok: true, why: 'Switch Layer 2 cihazıdır: yalnız Ethernet başlığını oxuyur və Destination MAC-i MAC address table-da axtarır. Başlığın içindəki IP və port onun üçün sadəcə payload-dır.' },
            { t: 'IP başlığındakı Destination IP ünvanına, çünki məlumat IP ilə ünvanlanıb.', why: 'IP başlığı Layer 3-dür. Adi switch kadrı IP-yə görə yönləndirmir, onun qərarı Layer 2 başlığındakı MAC-ə əsaslanır (Layer 3 switch ayrı haldır).' },
            { t: 'TCP başlığındakı Destination port nömrəsinə (80), çünki hədəf veb serverdir.', why: 'Port nömrəsi Layer 4 məlumatıdır və switch bunu oxumur. Port nömrəsini qəbul edən cihaz öz daxilində proqramı seçmək üçün istifadə edir.' },
            { t: 'Application layer-dəki HTTP sorğusunun məzmununa.', why: 'Switch Application layer-ə qədər heç vaxt açmır. Məzmuna baxan cihazlar proxy və WAF kimi Layer 7 cihazlarıdır.' },
          ],
          hints: ['Switch hansı layer-də işləyir? O layer-in başlığında hansı ünvan var?'],
          after: '<p>Bu səbəbdən switch-in log-unda IP ünvanları olmur, yalnız MAC ünvanları və portlar görünür.</p>' },
        { id: 's4b', title: 'Sahəni layer-ə bağla', type: 'match',
          body: '<p>Hər sahə hansı layer-in header-indədir?</p>',
          pairs: [
            { l: 'Destination port', r: 'Layer 4', why: 'Port nömrəsi Transport layer-in sahəsidir.' },
            { l: 'TTL', r: 'Layer 3', why: 'TTL IP header-indədir.' },
            { l: 'Source IP', r: 'Layer 3', why: 'IP ünvanı Network layer-dədir.' },
            { l: 'Protocol (1, 6, 17)', r: 'Layer 3', why: 'IP header-indəki bu sahə içəridəki Layer 4 protocol-unu göstərir.' },
            { l: 'EtherType', r: 'Layer 2', why: 'Ethernet header-indədir.' },
            { l: 'Destination MAC', r: 'Layer 2', why: 'MAC ünvanı Data Link layer-dədir.' },
          ],
          hints: ['Ünvanın növünə bax: port, IP və ya MAC.'] },
        { id: 's4c', title: 'Router-dən sonrakı frame-də səhv tap', type: 'spot',
          body: '<p>PC1 (192.168.1.10) PC2-yə (192.168.2.20) ping göndərir. Kolleqa router-dən <b>sonrakı</b> link-dəki frame üçün header-ləri yazıb. <b>Bir sətir səhvdir.</b> Onu tap.</p>',
          lines: [
            { t: 'Destination MAC: PC2-nin MAC-i' },
            { t: 'Source MAC: PC1-in MAC-i', bad: true, why: 'Router yeni Ethernet header-i yazır. Bu link-də Source MAC router-in PC2 tərəfindəki interface-inin MAC-idir.' },
            { t: 'Source IP: 192.168.1.10' },
            { t: 'Destination IP: 192.168.2.20' },
            { t: 'TTL: 127 (ilkin 128)' },
          ],
          fix: { label: 'Source MAC kimin olmalıdır?', placeholder: 'məs. PC1', answers: ['router', 'routerin', 'router-in', 'router interface', 'routerin interface-i', 'router-in interface-i'], wrong: 'Frame bu link-ə kim göndərir? PC1 yox, router.' },
          hints: ['Ethernet header-i hər link üçün yenidən yazılır.'],
          after: '<p>IP ünvanları dəyişmir, MAC ünvanları hər link-də dəyişir.</p>' },
        { id: 's5', title: 'Paketi izlə: router-dən sonra', type: 'form',
          body: '<p>PC1 (192.168.1.10) PC2-yə (192.168.2.20) ping göndərir. Yol: PC1 → Router → PC2. İlkin TTL = 128.</p><div class="tbl-wrap"><table class="tbl"><tr><th>Interface</th><th>IP</th><th>MAC</th></tr><tr><td>PC1</td><td class="m">192.168.1.10</td><td class="m">0001.4321.AAAA</td></tr><tr><td>Router Gi0/0</td><td class="m">192.168.1.1</td><td class="m">0001.4321.B001</td></tr><tr><td>Router Gi0/1</td><td class="m">192.168.2.1</td><td class="m">0001.4321.B002</td></tr><tr><td>PC2</td><td class="m">192.168.2.20</td><td class="m">0001.4321.CCCC</td></tr></table></div><p>Router-dən sonrakı link-də (Router → PC2) kadrın başlıqlarını yaz. MAC ünvanını istədiyin formatda yaza bilərsən.</p>',
          fields: [
            { label: 'Source MAC', placeholder: 'MAC', check: r => macNorm(r) === '00014321b002', wrong: 'Kadrı bu link-ə router göndərir. Hansı interface PC2-nin olduğu link-dədir?' },
            { label: 'Destination MAC', placeholder: 'MAC', check: r => macNorm(r) === '00014321cccc', wrong: 'Bu link-də kadrı kim qəbul edir?' },
            { label: 'Source IP', placeholder: 'a.b.c.d', check: r => r.trim() === '192.168.1.10', wrong: 'Router IP ünvanlarını dəyişmir. Paketi əsl göndərən kimdir?' },
            { label: 'Destination IP', placeholder: 'a.b.c.d', check: r => r.trim() === '192.168.2.20', wrong: 'Paket əvvəldən kimə ünvanlanıb?' },
            { label: 'TTL', placeholder: 'rəqəm', check: r => r.trim() === '127', wrong: 'Router TTL-i 1 azaldır.' },
          ],
          hints: ['Router-in iki interface-i var. Kadr PC2-yə hansı interface-dən çıxır?', 'MAC yalnız link üçündür (dəyişir). IP yalnız yönləndirmə üçündür (dəyişmir).'],
          solution: 'Source MAC = 0001.4321.B002 (Router Gi0/1), Destination MAC = 0001.4321.CCCC (PC2), Source IP = 192.168.1.10, Destination IP = 192.168.2.20, TTL = 127.',
          after: '<p>Əgər Source MAC yerinə PC1-in MAC-ini yazmısansa, bu çox yayılmış səhvdir: PC1-in MAC-i yalnız Link 1-də var.</p>' },
        { id: 's6', title: 'Hex dump-u özün oxu', type: 'form',
          body: '<p>Şəbəkədən tutulan kadrın ilk 38 baytı. Heç bir alətdən istifadə etmədən oxu.</p><pre class="pre">0000  00 0c 29 7e 41 d2 00 50 56 a1 03 9b 08 00 45 00\n0010  00 34 4f 2a 40 00 3f 06 17 bb c0 a8 0a 32 0a 00\n0020  00 05 c4 0e 01 bb</pre><p>Xatırlatma: Ethernet 14 bayt, IPv4 20 bayt (ilk bayt 45), ondan sonra TCP/UDP başlığının ilk 4 baytı (Source port, Destination port).</p>',
          fields: [
            { label: 'Destination MAC', placeholder: 'MAC', check: r => macNorm(r) === '000c297e41d2', wrong: 'Bayt 0-5.' },
            { label: 'Source MAC', placeholder: 'MAC', check: r => macNorm(r) === '005056a1039b', wrong: 'Bayt 6-11.' },
            { label: 'Protocol (ad)', placeholder: 'ad', answers: ['tcp'], wrong: 'Bayt 23. 01=ICMP, 06=TCP, 11 (hex)=UDP.' },
            { label: 'TTL (onluq)', placeholder: 'rəqəm', check: r => r.trim() === '63', wrong: 'Bayt 22. Hex 3f onluqda neçədir? (3 x 16 + 15)' },
            { label: 'Source IP', placeholder: 'a.b.c.d', check: r => r.trim() === '192.168.10.50', wrong: 'Bayt 26-29: c0 a8 0a 32.' },
            { label: 'Destination IP', placeholder: 'a.b.c.d', check: r => r.trim() === '10.0.0.5', wrong: 'Bayt 30-33: 0a 00 00 05.' },
            { label: 'Destination port (onluq)', placeholder: 'rəqəm', check: r => r.trim() === '443', wrong: 'Bayt 36-37: 01 bb. 0x01bb = 1 x 256 + 187.' },
          ],
          hints: ['Hər sətir 16 bayt göstərir. 12-13-cü baytlar (08 00) EtherType-dır, ondan sonra IP başlığı başlayır.', 'IP başlığı 14-cü baytdan başlayır. TTL ondan 8 bayt sonradır (bayt 22), Protocol ondan sonrakı (bayt 23).'],
          solution: 'Dst MAC 00:0c:29:7e:41:d2, Src MAC 00:50:56:a1:03:9b, EtherType 0800 (IPv4), Protocol 06 = TCP, TTL 3f = 63, Src IP c0 a8 0a 32 = 192.168.10.50, Dst IP 0a 00 00 05 = 10.0.0.5, Dst port 01 bb = 443 (HTTPS).',
          after: '<p>Nəticə: 192.168.10.50 host-u 10.0.0.5 server-inin HTTPS portuna (443) qoşulur. TTL 63 olması çox ehtimalla ilkin 64-ün bir router-dən keçdiyini göstərir.</p>' },
        { id: 's7', title: 'Firewall log-u: nəyi bilirsən?', type: 'choice',
          body: '<p>Firewall log sətri:</p><pre class="pre">10.1.1.5:51234 → 203.0.113.9:443  TCP  allow</pre><p>Analitik olaraq bu log-dan <b>nəyi etibarla</b> deyə bilərsən?</p>',
          options: [
            { t: '10.1.1.5 host-u 203.0.113.9 server-inin 443 portuna TCP ilə qoşulub, firewall icazə verib.', ok: true, why: 'Log Layer 3-4 sahələrini göstərir: IP ünvanları, portlar, protokol və qərar. Bu faktları log özü sübut edir.' },
            { t: '10.1.1.5 istifadəçisi hansı veb səhifəyə (URL) girib, hansı faylı yükləyib və nə yazıb.', why: 'URL və məzmun Layer 7-dədir. 443 HTTPS-dir və məzmun şifrəlidir; bu log Layer 7 məlumatı daşımır. URL üçün proxy log-u, DNS log-u və ya TLS inspection lazımdır.' },
            { t: '203.0.113.9 server-i zərərlidir, çünki trafik 443 portuna gedir və bu risklidir.', why: '443 portu HTTPS üçün standart portdur və tamamilə normaldır. Port nömrəsi tək başına zərərli deyil; təhlükəni IP-nin reputasiyası, davranış və digər sübut göstərər.' },
            { t: '51234 serverin portudur və həmin portda veb xidmət işləyir, 443 isə client portudur.', why: '51234 client-in müvəqqəti (yüksək) portudur. Serverin portu Destination tərəfdədir (443). Source port hər əlaqə üçün təsadüfi seçilir.' },
          ],
          hints: ['Log-da hansı layer-lərin sahələri var? Oradan kənar nəyisə log sübut edə bilərmi?'],
          after: '<p>Hər log mənbəyi yalnız öz layer-inə qədər sübut verir. Daha dərin sual (URL, fayl) üçün başqa mənbə axtarırsan.</p>' },
        { id: 's8', title: 'Ticket: ping işləyir, səhifə açılmır', type: 'choice',
          body: '<p>İstifadəçi şikayət edir: server səhifəsi açılmır. Sən yoxladın:</p><ul><li><span class="m">ipconfig</span>: IP, mask və gateway düzgündür.</li><li><span class="m">ping</span> gateway-ə uğurludur.</li><li><span class="m">ping 192.168.1.20</span> (server) uğurludur.</li><li>Brauzer <span class="m">http://192.168.1.20</span> açanda "connect olmaq mümkün olmadı" yazır.</li></ul><p>Növbəti addımın nə olmalıdır?</p>',
          options: [
            { t: 'Server-də 80 portunun dinləndiyini və firewall-un onu buraxdığını yoxlamaq.', ok: true, why: 'Ping uğurlu olduğu üçün Layer 1-3 sübut olunub. Qalan şübhə Layer 4 (port bağlı, firewall) və Layer 7 (xidmət işləmir). Növbəti yoxlama məhz buradadır.' },
            { t: 'Kabeli dəyişmək və switch portunu yoxlamaq, çünki bağlantı problemi var.', why: 'Kabel və port Layer 1-dir. Ping uğurlu olduğu üçün fiziki bağlantı sübut olunub, burada vaxt itirmək lazım deyil.' },
            { t: 'Kompüterin IP ünvanını və mask-ını yenidən təyin etmək.', why: 'IP ayarları düzgündür və ping işləyir: əgər IP səhv olsaydı ping də uğursuz olardı. Bu, Layer 3-dür və artıq sübut olunub.' },
            { t: 'Switch-də MAC address table-ı silmək, çünki MAC problemi ola bilər.', why: 'MAC problemi (Layer 2) olsaydı ping də keçməzdi, çünki ping də Ethernet kadrında gedir. Ping uğurludursa Layer 2 işləyir.' },
          ],
          hints: ['Ping hansı layer-ləri sübut edir? Bu layer-lərdən yuxarıda hansı layer-lər qalır?'],
          after: '<p>Metod: aşağıdan yuxarı sübut et, sübut olunmuş layer-ləri bir daha yoxlama.</p>' },
        { id: 's9', title: 'Hansı layer-dir?', type: 'form',
          body: '<p>Hər problem üçün <b>ən uyğun layer nömrəsini</b> yaz (1, 2, 3, 4 və ya 7).</p>',
          fields: [
            { label: 'Switch portundakı kabel çıxıb', placeholder: 'layer', check: layerNo(1), wrong: 'Fiziki bağlantıdır.' },
            { label: 'PC-yə səhv mask verilib, gateway fərqli subnet-dədir', placeholder: 'layer', check: layerNo(3), wrong: 'IP ünvanı və mask Layer 3-dür.' },
            { label: 'Firewall 443 portunu bloklayıb', placeholder: 'layer', check: layerNo(4), wrong: 'Port nömrəsi hansı layer-in başlığındadır?' },
            { label: 'Veb server proqramı dayanıb, port bağlıdır', placeholder: 'layer', check: r => layerNo(7)(r) || layerNo(4)(r), wrong: 'Proqram səviyyəsidir (xidmət işləmir).' },
            { label: 'Switch yanlış MAC-i yanlış portda öyrənib', placeholder: 'layer', check: layerNo(2), wrong: 'MAC ünvanı və switch hansı layer-dədir?' },
          ],
          hints: ['Hər problemin hansı ünvana, başlığa və ya fiziki hissəyə aid olduğunu düşün.'],
          solution: 'Kabel: 1. Səhv mask: 3. Port blok: 4. Server xidməti dayanıb: 7 (port bağlı olduğu üçün 4 də qəbul olunur). MAC öyrənmə: 2.' },
        { id: 's10', title: 'Öz kompüterində: portları gör', type: 'form',
          body: '<p>Öz kompüterində brauzerdə bir sayt aç (səhifə yüklənsin). Sonra CMD-də (Windows) və ya terminalda (Linux, macOS) bu əmri yaz:</p><pre class="pre"><span class="p">C:\\&gt;</span>netstat -an</pre><p><b>ESTABLISHED</b> sətirlərinə bax. Sütunlar: Proto, Local Address, Foreign Address, State. Foreign Address-də (<span class="m">IP:port</span>) <b>ən çox rast gəldiyin port nömrəsi</b> hansıdır?</p>',
          fields: [{ label: 'Ən çox port', placeholder: 'rəqəm', answers: ['443', '80'], wrong: 'Brauzer əlaqələri üçün çox ehtimalla 443 (HTTPS). Əgər çıxışda bir neçə ESTABLISHED sətir yoxdursa, saytı yenidən açıb təkrar yoxla.' }],
          hints: ['Sütun adlarına bax: Foreign Address uzaq serverin IP:port-udur.'],
          solution: 'Müasir saytlar HTTPS işlədir, ona görə Foreign Address sütununda adətən :443 görünür.',
          after: '<p>Burada gördüyün hər sətir Layer 4 səviyyəsində bir TCP əlaqəsidir: Local IP:port ↔ Foreign IP:port. Firewall log-undakı sətirlər də bu formadadır.</p>' },
      ],
    },

    quiz: {
      draw: 8,
      gens: [
        // hex dump decode
        () => {
          const f = genFrame(); const kind = pick(['ttl', 'proto', 'srcip', 'dstip', 'dstmac', 'srcmac']); const dump = '<pre class="pre">' + rows16(f.bytes) + '</pre>';
          const hexstr = f.bytes.map(hx).join('');
          const head = '<p>Kadrın ilk 34 baytı (Ethernet + IPv4 başlığı) hex formatındadır:</p>' + dump;
          const base = { concept: 'hex-read', obj: 'Hex dump-da sahəni tapmaq' };
          if (kind === 'proto') {
            const correct = PN[f.proto]; const opts = [['ICMP', 'IPv4 Protocol 1 olanda içəridə ICMP olur.'], ['TCP', 'IPv4 Protocol 6 olanda içəridə TCP olur.'], ['UDP', 'IPv4 Protocol 17 (hex 11) olanda içəridə UDP olur.'], ['ARP', 'ARP IPv4 paketinin içində getmir. ARP ayrıca kadr növüdür və EtherType-ı 0x0806-dır; bu kadrın EtherType-ı 0x0800-dür, yəni IPv4.']];
            return Object.assign({}, base, { id: 'p1t3-g-hex', _meta: { hex: hexstr, kind, ans: correct },
              stem: head + '<p>IPv4 başlığının <b>Protocol</b> sahəsinə görə içəridəki məlumat hansı protokoldur?</p>',
              options: opts.map(o => ({ t: o[0], ok: o[0] === correct, why: (o[0] === correct ? 'Düzdür: Protocol baytı (bayt 23) = ' + hx(f.proto) + '. ' : 'Protocol baytı (bayt 23) ' + hx(f.proto) + '-dir, ' + correct + ' deməkdir. ') + o[1] })) });
          }
          const spec = {
            ttl: { q: '<b>TTL</b> dəyəri onluqda nədir?', ans: String(f.ttl), ph: 'rəqəm', sol: 'TTL bayt 22-dədir: hex ' + hx(f.ttl) + ' = <b>' + f.ttl + '</b>.', chk: r => r.trim() === String(f.ttl) },
            srcip: { q: '<b>Source IP</b> ünvanı nədir?', ans: ipStr(f.sip), ph: 'a.b.c.d', sol: 'Source IP bayt 26-29: ' + f.sip.map(hx).join(' ') + ' = <b>' + ipStr(f.sip) + '</b>.', chk: r => r.trim() === ipStr(f.sip) },
            dstip: { q: '<b>Destination IP</b> ünvanı nədir?', ans: ipStr(f.dip), ph: 'a.b.c.d', sol: 'Destination IP bayt 30-33: ' + f.dip.map(hx).join(' ') + ' = <b>' + ipStr(f.dip) + '</b>.', chk: r => r.trim() === ipStr(f.dip) },
            dstmac: { q: '<b>Destination MAC</b> ünvanı nədir? İstədiyin formatda yaz.', ans: macStr(f.dm), ph: 'MAC', sol: 'Destination MAC ilk 6 bayt (0-5): <b>' + macStr(f.dm) + '</b>.', chk: r => macNorm(r) === macNorm(macStr(f.dm)) },
            srcmac: { q: '<b>Source MAC</b> ünvanı nədir? İstədiyin formatda yaz.', ans: macStr(f.sm), ph: 'MAC', sol: 'Source MAC bayt 6-11: <b>' + macStr(f.sm) + '</b>.', chk: r => macNorm(r) === macNorm(macStr(f.sm)) },
          }[kind];
          return Object.assign({}, base, { id: 'p1t3-g-hex', type: 'num', _meta: { hex: hexstr, kind, ans: spec.ans }, stem: head + '<p>' + spec.q + '</p>', placeholder: spec.ph, check: spec.chk, solution: spec.sol });
        },
        // router hop: what changes
        () => {
          const kind = pick(['mac', 'mac', 'ip', 'ttl']);
          const a = R(100) + 1; let b = R(100) + 101; const suf = () => ('0000' + R(65536).toString(16)).slice(-4).toUpperCase();
          const used = new Set(); const nm = () => { let m; do { m = '0001.43' + suf().slice(0, 2) + '.' + suf(); } while (used.has(m)); used.add(m); return m; };
          const M = { pc1: nm(), r0: nm(), r1: nm(), pc2: nm() };
          const I = { pc1: '192.168.' + a + '.' + (R(150) + 10), r0: '192.168.' + a + '.1', r1: '192.168.' + b + '.1', pc2: '192.168.' + b + '.' + (R(150) + 10) };
          if (kind === 'ttl') {
            const t0 = pick([64, 128, 255]); const n = 1 + R(3); const ans = t0 - n;
            return { id: 'p1t3-g-hop', concept: 'hop', obj: 'Router-dən keçəndə TTL', type: 'num', _meta: { kind, t0, n, ans: String(ans) },
              stem: '<p>PC1 TTL = <b>' + t0 + '</b> ilə paket göndərir. PC2-yə çatana qədər paket <b>' + n + '</b> router-dən keçir. PC2-yə çatanda TTL neçə olacaq?</p>', placeholder: 'rəqəm',
              check: r => r.trim() === String(ans), solution: 'Hər router TTL-i 1 azaldır: ' + t0 + ' − ' + n + ' = <b>' + ans + '</b>.' };
          }
          const table = '<div class="tbl-wrap"><table class="tbl"><tr><th>Interface</th><th>IP</th><th>MAC</th></tr><tr><td>PC1</td><td class="m">' + I.pc1 + '</td><td class="m">' + M.pc1 + '</td></tr><tr><td>Router Gi0/0 (PC1 tərəfi)</td><td class="m">' + I.r0 + '</td><td class="m">' + M.r0 + '</td></tr><tr><td>Router Gi0/1 (PC2 tərəfi)</td><td class="m">' + I.r1 + '</td><td class="m">' + M.r1 + '</td></tr><tr><td>PC2</td><td class="m">' + I.pc2 + '</td><td class="m">' + M.pc2 + '</td></tr></table></div>';
          const intro = '<p>PC1 → Router → PC2. PC1 PC2-yə ping göndərir. Hər link-də ayrı kadr var: <b>Link 1</b> (PC1 → Router) və <b>Link 2</b> (Router → PC2).</p>' + table;
          if (kind === 'ip') {
            const wantSrc = R(2) === 0; const ans = wantSrc ? I.pc1 : I.pc2; const link = pick(['Link 1', 'Link 2']);
            const why = { pc1: 'PC1-in IP ünvanıdır.', pc2: 'PC2-nin IP ünvanıdır.', r0: 'Router interface ünvanıdır. Router IP paketin Source/Destination sahəsinə yazılmır, çünki o, paketin göndərəni və ya hədəfi deyil.', r1: 'Router interface ünvanıdır. Router IP paketin Source/Destination sahəsinə yazılmır, çünki o, paketin göndərəni və ya hədəfi deyil.' };
            return { id: 'p1t3-g-hop', concept: 'hop', obj: 'Router-dən keçəndə IP dəyişmir', _meta: { kind: 'ip', wantSrc, ans }, stem: intro + '<p><b>' + link + '</b>-dəki kadrın IP başlığında <b>' + (wantSrc ? 'Source IP' : 'Destination IP') + '</b> hansıdır?</p>',
              options: ['pc1', 'pc2', 'r0', 'r1'].map(k => ({ t: I[k], ok: I[k] === ans, why: I[k] === ans ? 'Router adi routing zamanı IP ünvanlarını dəyişmir: Source IP həmişə ilk göndərən (PC1), Destination IP həmişə son hədəf (PC2) olaraq qalır. Bu IP ' + why[k] : 'Bu ' + I[k] + ' ' + why[k] + ' Düzgün cavab ' + ans + '-dir, çünki IP ünvanları yol boyu dəyişmir.' })) };
          }
          const which = pick(['src1', 'dst1', 'src2', 'dst2']);
          const info = { src1: ['Link 1', 'Source MAC', 'pc1', 'Kadrı bu link-ə PC1 göndərir.'], dst1: ['Link 1', 'Destination MAC', 'r0', 'PC1 kadrı gateway-ə (Router-in PC1 tərəfindəki interface-inə) göndərir.'], src2: ['Link 2', 'Source MAC', 'r1', 'Kadrı bu link-ə router öz PC2 tərəfli interface-indən göndərir.'], dst2: ['Link 2', 'Destination MAC', 'pc2', 'Kadr bu link-in son hədəfi olan PC2-yə ünvanlanır.'] }[which];
          const ans = M[info[2]]; const lbl = { pc1: 'PC1-in MAC-i', r0: 'Router Gi0/0-ın MAC-i', r1: 'Router Gi0/1-in MAC-i', pc2: 'PC2-nin MAC-i' };
          return { id: 'p1t3-g-hop', concept: 'hop', obj: 'Hər link-də MAC ünvanları', _meta: { kind: 'mac', which, ans }, stem: intro + '<p><b>' + info[0] + '</b>-dəki kadrın Ethernet başlığında <b>' + info[1] + '</b> hansıdır?</p>',
            options: ['pc1', 'r0', 'r1', 'pc2'].map(k => ({ t: M[k], ok: M[k] === ans, why: k === info[2] ? info[3] + ' MAC yalnız bir link üçün keçərlidir və router hər link üçün yeni Ethernet başlığı yazır, buna görə bu link-in iki ucundakı cihazların MAC-ləri yazılır.' : 'Bu ' + lbl[k] + '. ' + info[0] + '-də ' + info[1] + ' olaraq ' + lbl[info[2]] + ' yazılmalıdır, çünki MAC ünvanı yalnız həmin link-in iki ucunu göstərir.' })) };
        },
      ],
      pool: [
        { id: 'p1t3-q2', concept: 'soc-layers', obj: 'Qaydanın hansı layer-ə baxdığı',
          stem: '<p>Firewall qaydası belədir: <span class="m">allow tcp any 10.0.0.5 eq 443</span>. Bu qayda <b>hansı layer-lərin</b> məlumatına əsasən qərar verir?</p>',
          options: [
            { t: 'Layer 3 (hədəf IP) və Layer 4 (TCP protokolu, port 443).', ok: true, why: 'Qayda hədəf IP-ni (Layer 3), protokolu və portu (Layer 4) yoxlayır. Layer 7 məzmununa baxmır, ona görə məzmun fərqli olsa da qayda eyni işləyir.' },
            { t: 'Yalnız Layer 2: qayda kadrın MAC ünvanlarına baxır və hədəf IP-yə baxmır.', why: 'Qaydada MAC ünvanı yoxdur. IP ünvanı və port var, bunlar Layer 3-4 məlumatıdır. MAC link səviyyəsidir və firewall qaydalarında nadir hallarda istifadə olunur.' },
            { t: 'Layer 7: qayda səhifənin məzmununa, başlıqlarına və URL-ə baxır.', why: 'URL və məzmun Layer 7-dədir və bu qayda onları qeyd etmir. 443-də şifrələnmiş trafikdə məzmun görünmür, ona görə belə qayda yalnız port səviyyəsində işləyir.' },
            { t: 'Layer 1: qayda kabelin siqnal keyfiyyətinə baxır.', why: 'Physical layer bitlərin siqnalıdır. Firewall qaydaları paketin başlıq sahələrinə baxır, siqnala yox.' },
          ] },
        { id: 'p1t3-q3', concept: 'encap', obj: 'Göndərən cihazda PDU sırası', type: 'order',
          stem: '<p>Göndərən cihazda veb sorğusu şəbəkəyə çıxana qədər PDU-lar <b>hansı sırada</b> yaranır? İlk yaranan yuxarıda olsun.</p>',
          items: [
            { t: 'Data', why: 'Proqram məlumatı yaradır: hələ heç bir başlıq yoxdur.' },
            { t: 'Segment', why: 'Transport layer TCP header (portlar) əlavə edir.' },
            { t: 'Packet', why: 'Network layer IP header (IP ünvanları) əlavə edir.' },
            { t: 'Frame', why: 'Data Link layer Ethernet header (MAC ünvanları) və FCS əlavə edir.' },
            { t: 'Bits', why: 'Physical layer kadrı siqnala çevirir.' },
          ], why: 'Encapsulation yuxarıdan aşağıdır, hər layer öz başlığını əlavə edir.' },
        { id: 'p1t3-q4', concept: 'encap', obj: 'Başlıqların yığılma sırası',
          stem: '<p>Kadrda TCP başlığı niyə IP başlığının <b>içindədir</b>, əksinə yox?</p>',
          options: [
            { t: 'Hər layer yuxarıdan aldığını payload kimi sarıyır: IP üçün TCP segment payload-dır.', ok: true, why: 'Aşağı layer yuxarını payload kimi qəbul edir. Niyə: IP TCP-nin daxilini oxumur və ona yalnız "ötürüləcək baytlar" kimi baxır. Ən xaricdə Ethernet, onun içində IP, onun içində TCP gəlir.' },
            { t: 'TCP daha vacib protokoldur, ona görə mühafizə üçün başqa başlığın içində saxlanılır.', why: 'Layer-lərin vacibliyi sıranı təyin etmir. Sıranı yalnız hansı layer-in aşağıda, hansının yuxarıda olması müəyyən edir.' },
            { t: 'İçəridəki başlıq avtomatik şifrələnir ki, aralıq cihazlar və ya hücumçu onu oxuya bilməsin.', why: 'TCP başlığı şifrələnmir (TLS yalnız Application payload-ını şifrələyir). Switch onu oxumur, çünki Ethernet başlığından sonra baxmır, şifrələnmə ilə əlaqəsi yoxdur.' },
            { t: 'Başlıqların sırası təsadüfidir, standart yalnız uzunluqlarını müəyyən edir.', why: 'Sıra qəti şəkildə təyin olunub. Qəbul edən cihaz əvvəlcə Ethernet-i, sonra IP-ni, sonra TCP-ni açır; sıra pozulsa heç bir cihaz kadrı oxuya bilməz.' },
          ] },
        { id: 'p1t3-q5', concept: 'decap', obj: 'IPv4 Protocol sahəsi',
          stem: '<p>Qəbul edən cihaz IPv4 başlığında <b>Protocol = 17</b> görür. Paketin içindəki məlumatı kimə verir?</p>',
          options: [
            { t: 'UDP-yə, çünki 17 UDP-nin protokol nömrəsidir.', ok: true, why: 'IPv4 Protocol sahəsi "içəridə nə var?" sualının cavabıdır: 1 = ICMP, 6 = TCP, 17 = UDP. Qəbul edən cihaz paketi UDP-yə verir, o da portlara baxıb proqramı seçir.' },
            { t: 'TCP-yə, çünki bütün şəbəkə məlumatı TCP ilə gedir.', why: 'Hər məlumat TCP ilə getmir. TCP-nin nömrəsi 6-dır; DNS və DHCP kimi bir çox xidmət UDP işlədir.' },
            { t: 'ICMP-yə, çünki IP ilə birbaşa ICMP işləyir.', why: 'ICMP IP-nin içində gedir, amma onun nömrəsi 1-dir. 17 ICMP üçün deyil.' },
            { t: 'Paketi atır, çünki 17 tanınmış dəyər deyil.', why: '17 geniş tanınan dəyərdir (UDP). Qəbul edən cihaz bunu əsas protokol kimi tanıyır və paketi atmır.' },
          ] },
        { id: 'p1t3-q6', concept: 'decap', obj: 'EtherType-ın vəzifəsi',
          stem: '<p>Qəbul edən cihaz kadrı açır. Kadrın içindəki məlumatı <b>hansı protokola</b> verməyi ona hansı sahə deyir?</p>',
          options: [
            { t: 'Ethernet başlığındakı EtherType sahəsi.', ok: true, why: 'EtherType (məsələn 0x0800 = IPv4, 0x0806 = ARP) Layer 2 başlığındakı "yuxarıda kim var?" sahəsidir. Qəbul edən cihaz məhz buna baxıb kadrı IP-yə və ya ARP-ya verir.' },
            { t: 'Ethernet başlığındakı Destination MAC ünvanı.', why: 'Destination MAC kadrı kimin qəbul edəcəyini göstərir, içindəki protokolu yox. İçəridəki protokolu müəyyən etmək EtherType-ın işidir.' },
            { t: 'IPv4 başlığındakı Time to Live (TTL) sahəsi.', why: 'TTL paketin neçə router-dən keçə biləcəyini göstərir. Üstəlik bu sahə IP başlığındadır və kadr açılmamış oxunmur.' },
            { t: 'Ethernet kadrının sonundakı FCS sahəsi.', why: 'Checksum yalnız başlığın zədələnmədən çatıb-çatmadığını yoxlayır, protokolu bildirmir.' },
          ] },
        { id: 'p1t3-q7', concept: 'hop', obj: 'Router-dən sonra Source MAC',
          stem: '<p>PC1 başqa network-dəki PC2-yə paket göndərir (arada bir router). PC2-nin qəbul etdiyi kadrın <b>Source MAC</b> ünvanı kimindir?</p>',
          options: [
            { t: 'Router-in PC2 tərəfindəki interface-inin MAC-i.', ok: true, why: 'Router kadrı qəbul edəndə Ethernet başlığını silir və PC2-nin link-i üçün yeni başlıq yazır. Bu yeni başlıqda Source MAC kadrı göndərən cihazın, yəni router interface-inin MAC-idir.' },
            { t: 'PC1-in MAC ünvanı.', why: 'PC1-in MAC-i yalnız Link 1-də var. Router Ethernet başlığını yeniləyir, ona görə PC2 PC1-in MAC-ini heç vaxt görmür. Bunun bəlli göstərəni IP ünvanıdır.' },
            { t: 'PC2-nin öz MAC ünvanı.', why: 'PC2-nin MAC-i bu kadrda Destination MAC olur. Source MAC həmişə kadrı göndərən cihazın MAC-idir.' },
            { t: 'Router-in PC1 tərəfindəki interface-inin MAC-i.', why: 'Bu MAC Link 1-də Destination MAC idi. Link 2-yə kadrı router-in PC2 tərəfli interface-i göndərir, ona görə orada onun MAC-i olur.' },
          ] },
        { id: 'p1t3-q8', concept: 'hop', obj: 'Router nəyi dəyişir',
          stem: '<p>Paket router-dən keçdi (NAT yoxdur). <b>Hansı</b> sahələr dəyişib?</p>',
          options: [
            { t: 'Source MAC, Destination MAC və TTL dəyişib; IP ünvanları dəyişməyib.', ok: true, why: 'Router yeni link üçün yeni Ethernet başlığı yazır (iki MAC dəyişir) və TTL-i 1 azaldır. IP ünvanları paketin əsl göndərənini və hədəfini göstərir və yol boyu eyni qalır.' },
            { t: 'Yalnız TTL dəyişib, Ethernet və IP başlıqlarının qalan hissəsi eynidir.', why: 'Ethernet başlığı dəyişir, çünki MAC ünvanı yalnız bir link üçün keçərlidir. Router yeni link üçün yeni MAC-lər yazır, bunu TTL-lə birlikdə görürsən.' },
            { t: 'Source IP və Destination IP dəyişib, Ethernet başlığındakı MAC-lər eyni qalıb.', why: 'Tərsidir: adi routing zamanı IP ünvanları qalır, MAC-lər dəyişir. IP-nin dəyişməsi yalnız NAT kimi xüsusi funksiyada olur.' },
            { t: 'Heç nə dəyişməyib, router paketi başlıqlara toxunmadan olduğu kimi ötürür.', why: 'Heç olmasa TTL azalır və Ethernet başlığı yenilənir. Router paketi "olduğu kimi" ötürsəydi, yeni link-də Destination MAC səhv olardı.' },
          ] },
        { id: 'p1t3-q9', concept: 'tcp-udp', obj: 'DNS niyə UDP işlədir',
          stem: '<p>DNS sorğusu adətən UDP ilə göndərilir. Əsas səbəb nədir?</p>',
          options: [
            { t: 'Sorğu kiçikdir, itərsə təkrar göndərmək asandır; TCP-nin əlaqə qurma yükü lazım deyil.', ok: true, why: 'UDP əlaqə qurmur və təsdiq göndərmir, ona görə sürətlidir. DNS sorğusu tək kiçik paketdir: itərsə proqram sadəcə təkrar göndərir, əvvəlcədən 3-way handshake etmək isə lazımsız gecikmə olardı.' },
            { t: 'UDP TCP-dən daha etibarlıdır, çünki çatdırılmanı təsdiqləyir və itəni təkrar göndərir.', why: 'Əksinədir: UDP çatdırılmanı təsdiqləmir və itən məlumatı özü təkrar göndərmir. Etibarlılıq TCP-nin xüsusiyyətidir.' },
            { t: 'DNS TCP ilə işləyə bilməz, çünki 53 portu TCP üçün istifadə olunmur və bağlıdır.', why: 'DNS TCP ilə də işləyir (məsələn, böyük cavablar və zone transfer üçün) və port 53 hər ikisində istifadə olunur. UDP seçimi texniki mümkünsüzlük deyil, səmərəlilik məsələsidir.' },
            { t: 'UDP sorğunu avtomatik şifrələyir ki, aralıq cihazlar oxuya bilməsin.', why: 'UDP şifrələmə etmir. Şifrələmə TLS kimi ayrı protokolun işidir, DNS isə adətən şifrələnməmiş gedir.' },
          ] },
        { id: 'p1t3-q10', concept: 'tcp-udp', obj: 'Eyni serverə iki client',
          stem: '<p>Veb server 443 portunu dinləyir. İki fərqli PC eyni anda bu serverə qoşulub. Server bu iki əlaqəni bir-birindən <b>necə ayırır</b>?</p>',
          options: [
            { t: 'Source IP və Source port fərqlidir, əlaqə dörd dəyərin birləşməsi ilə tanınır.', ok: true, why: 'Hər TCP əlaqəsi dörd dəyərlə tanınır: Source IP, Source port, Destination IP, Destination port. Destination hissə eynidir (server, 443), amma iki client-in Source IP və Source port fərqli olur, ona görə əlaqələr qarışmır.' },
            { t: 'Destination port fərqlidir: server hər client üçün ayrıca yeni port açır və dinləyir.', why: 'Server hamı üçün eyni portu (443) dinləyir. Fərqlənən client tərəfdir, server tərəfi deyil.' },
            { t: 'Destination MAC ünvanları fərqlidir, server MAC-ə görə ayırır.', why: 'Destination MAC hər iki halda eyni cihazın (server və ya gateway) MAC-idir. Üstəlik əlaqəni ayırmaq Layer 4-ün işidir, MAC isə Layer 2-dir.' },
            { t: 'TTL dəyərləri fərqlidir, server əlaqələri TTL dəyərinə görə ayırır.', why: 'TTL paketin ömrünü göstərir və əlaqəni müəyyən etmir. İki client eyni TTL ilə də qoşula bilər.' },
          ] },
        { id: 'p1t3-q11', concept: 'hex-read', obj: 'IPv4 ilk baytı',
          stem: '<p>Hex dump-da Ethernet başlığından sonra gələn ilk bayt <span class="m">45</span>-dir. Bu nə deməkdir?</p>',
          options: [
            { t: 'Version 4 (IPv4), header uzunluğu 5 × 4 = 20 bayt.', ok: true, why: 'Bu bayt iki hissəyə bölünür: 4 (IP versiyası) və 5 (header uzunluğu 32-bitlik söz sayı, 5 x 4 = 20 bayt). Buna görə IPv4 başlığının ilk baytı adətən 45 olur və bu, IP başlığının harada bitdiyini göstərir.' },
            { t: 'TTL dəyəri 45-dir, paket 45 router-dən keçə bilər.', why: 'TTL 22-ci baytdadır (Ethernet başlığından 8 bayt sonra), ilk bayt deyil. Üstəlik 45 hex-dir, onluqda 69 olardı.' },
            { t: 'Protocol 45-dir, yəni IP içində xüsusi protokol daşınır.', why: 'Protocol 23-cü baytdadır. İlk bayt versiya və header uzunluğunu daşıyır.' },
            { t: 'Version 4, header uzunluğu 5 bayt, yəni çox qısa başlıq.', why: 'Header uzunluğu 5 x 4 = 20 bayt-dır, 5 bayt deyil. Sahə 4 baytlıq sözlərlə sayılır.' },
          ] },
        { id: 'p1t3-q12', concept: 'soc-layers', obj: 'Ping uğurlu, xidmət işləmir',
          stem: '<p>Server-ə ping uğurludur, amma veb səhifə açılmır. İlk şübhəni <b>harada</b> axtarmalısan?</p>',
          options: [
            { t: 'Layer 4 və 7: server-də xidmət, port və ya firewall qaydası.', ok: true, why: 'Ping Layer 1-3-ün işlədiyini sübut edir: kabel, MAC çatdırılması və IP işləyir. Qalan layer-lər yuxarıdadır, ona görə yoxlama port və xidmətdən başlayır.' },
            { t: 'Layer 1: kabel xarab ola bilər və ya switch portu söndürülüb.', why: 'Əgər kabel xarab olsaydı ping də keçməzdi. Ping uğurlu olduğu üçün Layer 1 artıq sübut olunub.' },
            { t: 'Layer 2: switch MAC address table-da MAC-i səhv portda öyrənib.', why: 'Ping də Ethernet kadrında gedir. MAC çatdırılması səhv olsaydı ping də uğursuz olardı.' },
            { t: 'Layer 3: server-in IP ünvanı və ya mask-ı səhv təyin olunub.', why: 'IP səhv olsaydı ping hədəfə çatmazdı. Ping IP səviyyəsində uğurlu olubsa, IP düzgündür.' },
          ] },
        { id: 'p1t3-q13', concept: 'soc-layers', obj: 'Log sübutunun hüdudu',
          stem: '<p>Firewall log-unda yalnız <span class="m">10.1.1.5:51234 → 203.0.113.9:443 TCP allow</span> var. Bu log-dan <b>nəyi bilmək mümkün deyil</b>?</p>',
          options: [
            { t: 'İstifadəçinin girdiyi URL-i və yüklədiyi məzmunu.', ok: true, why: 'URL və məzmun Layer 7-dədir. Port 443 HTTPS-dir, məzmun şifrəlidir və firewall log-u yalnız Layer 3-4 sahələrini göstərir. Bunun üçün proxy, DNS log-u və ya TLS inspection lazımdır.' },
            { t: 'Qoşulmanın hansı hədəf IP ünvanına getdiyini.', why: 'Destination IP log-da açıq yazılıb: 203.0.113.9. Bu, Layer 3 məlumatıdır və log bunu göstərir.' },
            { t: 'Qoşulmanın hansı protokol və hansı portla edildiyini.', why: 'Protokol (TCP) və Destination port (443) log-da yazılıb. Bu, Layer 4 məlumatıdır və log bunu göstərir.' },
            { t: 'Firewall-un qoşulmaya icazə verib-verməməsini.', why: 'Qərar log-da var: "allow". Hər firewall log sətri adətən qərarı da yazır.' },
          ] },
      ],
    },
  });
})();
