(function () {
  const A = PT.addr; const pick = PT.pick; const R = PT.randInt; const shuffle = PT.shuffle;
  const ms = x => (x < 1 ? '<1 ms' : x + ' ms').padStart(8);
  const row = (n, a, b, c, ip) => String(n).padStart(3) + [a, b, c].map(ms).join('') + '  ' + ip;
  const starRow = n => String(n).padStart(3) + '     *        *        *     Request timed out.';
  const pad2 = n => String(n).padStart(2, '0');
  const rnd = (lo, hi) => lo + R(hi - lo + 1);

  PT.topic({
    id: 'p1t6',
    objectives: [
      'ICMP-nin nə üçün lazım olduğunu və əsas Type dəyərlərini (8, 0, 3, 11) izah etmək',
      'Ping nəticələrini fərqləndirmək: timeout, unreachable (kim göndərib), TTL expired',
      'TTL-in və tracert-in necə işlədiyini izah etmək, tracert çıxışını oxumaq',
      'Ping ardıcıllığı ilə problemi layer-lərə ayırmaq və ping sweep-i log-da tanımaq',
    ],
    explain: PT.frag['p1/t06/explain'], cheat: PT.frag['p1/t06/cheat'],

    lab: {
      title: 'Lab 6: Ping və tracert-i oxu, problemi tap',
      goal: 'ICMP Type-larını situasiyaya uyğun tanımaq, TTL-dən keçən router sayını çıxarmaq, PC praktikasında ping və tracert işlətmək və üç ayrı uğursuzluğu səbəbinə görə ayırmaq.',
      why: 'Hər şəbəkə problemində ilk əmr pingdir. Nəticənin mətni kimin yazdığını və problemin harada olduğunu göstərir. Bunu oxuya bilmirsənsə, əmrləri təsadüfi işlədirsən.',
      minutes: 40,
      finish: 'Ping və tracert nəticəsini oxuyub problemin hansı hissədə olduğunu deyə bilirsən. Növbəti mövzuda switch-in kadrları necə yönləndirdiyini görəcəksən: ping-in birinci addımı olan ARP kadrı switch-dən necə keçir.',
      steps: [
        { id: 's1', title: 'Plan', type: 'info', button: 'Başlayaq',
          body: '<p>Bu labda Packet Tracer lazım deyil.</p><ol><li>Situasiyaya uyğun ICMP Type-ı tap.</li><li>TTL-dən keçən router sayını hesabla.</li><li>PC praktikasında ping və tracert işlət.</li><li>İki uğursuzluğu (səhv gateway və qırıq yol) diaqnoz et.</li><li>Routing loop və ping sweep izlərini tanı.</li><li>Öz kompüterində yoxla.</li></ol>' },

        { id: 's2', title: 'Situasiya → ICMP Type', type: 'form',
          body: '<p>Hər situasiya üçün ICMP <b>Type</b> nömrəsini yaz. Lazım olsa, izah bölməsindəki cədvələ bax.</p>',
          fields: [
            { label: 'PC ping başladır: göndərilən mesajın Type-ı', placeholder: 'rəqəm', check: r => r.trim() === '8', wrong: 'Ping-i başladan mesaj Echo Request-dir. Cədvəldə Echo Request üçün hansı rəqəm yazılıb?' },
            { label: 'Hədəf ping-ə cavab verir: Type', placeholder: 'rəqəm', check: r => r.trim() === '0', wrong: 'Cavab Echo Reply-dır.' },
            { label: 'R2 TTL-i 0 olan paketi atır və göndərənə xəbər verir: Type', placeholder: 'rəqəm', check: r => r.trim() === '11', wrong: 'TTL bitəndə göndərilən mesaj Time Exceeded-dir.' },
            { label: 'R1-in hədəfə marşrutu yoxdur və göndərənə xəbər verir: Type', placeholder: 'rəqəm', check: r => r.trim() === '3', wrong: 'Hədəfə çatmaq mümkün deyil: Destination Unreachable.' },
          ],
          hints: ['Dörd mesaj var: Echo Request, Echo Reply, Destination Unreachable, Time Exceeded. Situasiyada hansı biri baş verir?'],
          solution: 'Echo Request = 8, Echo Reply = 0, Time Exceeded = 11, Destination Unreachable = 3.' },

        { id: 's3', title: 'TTL-dən keçən router sayı', type: 'form',
          body: '<p>Üç ping cavabı gəlib. Hər birində ən yaxın <b>böyük</b> ilkin TTL dəyərini (64, 128 və ya 255) seç və keçən router sayını hesabla.</p><pre class="pre">a) Reply from 10.9.8.7: bytes=32 time=2ms TTL=125\nb) Reply from 10.9.8.8: bytes=32 time=9ms TTL=58\nc) Reply from 10.9.8.9: bytes=56 time=4ms TTL=250</pre>',
          fields: [
            { label: 'a) keçən router sayı', placeholder: 'rəqəm', check: r => r.trim() === '3', wrong: 'TTL=125: ən yaxın böyük ilkin dəyər 128. 128 − 125 = ?' },
            { label: 'b) keçən router sayı', placeholder: 'rəqəm', check: r => r.trim() === '6', wrong: 'TTL=58: ən yaxın böyük ilkin dəyər 64. 64 − 58 = ?' },
            { label: 'c) keçən router sayı', placeholder: 'rəqəm', check: r => r.trim() === '5', wrong: 'TTL=250: ən yaxın böyük ilkin dəyər 255. 255 − 250 = ?' },
            { label: 'Hansı cavab (a, b və ya c) çox güman ki, Cisco cihazından gəlib?', placeholder: 'a / b / c', answers: ['c'], wrong: 'Cisco IOS ilkin TTL-i 255 ilə başlayır. Hansı cavab 255-ə yaxındır?' },
          ],
          hints: ['Metod: cavabdakı TTL-dən böyük ən yaxın standart dəyəri tap (64, 128 və ya 255), sonra fərqi hesabla.'],
          solution: 'a) 128 − 125 = 3 router. b) 64 − 58 = 6 router. c) 255 − 250 = 5 router, ilkin 255 olduğu üçün Cisco cihazı ehtimalı yüksəkdir.',
          after: '<p>Unutma: bu hesablama təxmindir. İlkin TTL dəyişdirilə bilər, ona görə nəticə sübut yox, işçi fərziyyədir.</p>' },

        { id: 's4', title: 'PC praktikası: ping nərdivanı və tracert', type: 'terminal',
          body: '<p>PC1 (<span class="m">192.168.1.10/24</span>, gateway <span class="m">192.168.1.1</span>) aşağıdakı ardıcıllıqla yoxlama aparır. Əmrləri sıra ilə yaz:</p><ol><li><span class="m">ping 127.0.0.1</span> (PC-nin öz stack-ı)</li><li><span class="m">ping 192.168.1.1</span> (gateway)</li><li><span class="m">ping 172.16.0.10</span> (uzaq server)</li><li><span class="m">tracert 172.16.0.10</span></li><li><span class="m">ping 8.8.8.8</span>, sonra <span class="m">ping google.com</span></li></ol>',
          term: { kind: 'host', host: { name: 'PC1', ip: '192.168.1.10', mask: '255.255.255.0', gw: '192.168.1.1', mac: '0001.4321.AAAA' },
            peers: [{ name: 'R1', ip: '192.168.1.1', mac: '0001.4321.DDDD', ttl: 255 }],
            remote: [{ ip: '172.16.0.10', ttl: 125 }, { ip: '8.8.8.8', ttl: 62 }],
            hops: { '172.16.0.10': ['192.168.1.1', '10.0.12.2', '10.0.23.3', '172.16.0.10'], '8.8.8.8': ['192.168.1.1', '203.0.113.1', '8.8.8.8'] },
            quick: ['ping 127.0.0.1', 'ping 192.168.1.1', 'ping 172.16.0.10', 'tracert 172.16.0.10', 'ping 8.8.8.8', 'ping google.com'],
            goals: [
              { text: '<span class="m">ping 127.0.0.1</span> işlət', test: d => d.pings.some(p => p.ip === '127.0.0.1') },
              { text: '<span class="m">ping 192.168.1.1</span> işlət (gateway)', test: d => d.pings.some(p => p.ip === '192.168.1.1') },
              { text: '<span class="m">ping 172.16.0.10</span> işlət', test: d => d.pings.some(p => p.ip === '172.16.0.10') },
              { text: '<span class="m">tracert 172.16.0.10</span> işlət', test: d => d.tracerts.includes('172.16.0.10') },
              { text: '<span class="m">ping 8.8.8.8</span> işlət', test: d => d.pings.some(p => p.ip === '8.8.8.8') },
              { text: 'Bir ad ilə ping işlət (məsələn <span class="m">ping google.com</span>) və nəticəyə bax', test: d => d.has(/^ping\s+[a-z][a-z0-9-]*(\.[a-z0-9-]+)+$/i) },
            ] },
          hints: ['Əmri yaz və Enter bas. Sağdakı panelə də bax: gateway ilə danışandan sonra ARP cache-ə yeni sətir əlavə olunur.'],
          after: '<p>Müşahidələr: 127.0.0.1 heç bir şəbəkə trafiki yaratmır. Gateway-ə ping-dən sonra ARP cache-də gateway girişi yarandı. Ad ilə ping isə <b>ping göndərilməzdən əvvəl</b> xəta verdi: ad IP-yə çevrilmədi. IP ilə ping işləyirsə, problem DNS-dədir.</p>' },

        { id: 's5', title: 'Çıxışdan oxu', type: 'form',
          body: '<p>Əvvəlki praktikada <span class="m">172.16.0.10</span> üçün ping və tracert nəticələrinə bax.</p>',
          fields: [
            { label: '172.16.0.10 ping cavabında TTL', placeholder: 'rəqəm', check: r => r.trim() === '125', wrong: 'Reply sətirindəki TTL=... dəyərinə bax.' },
            { label: 'Keçən router sayı (TTL-dən: 128 − TTL)', placeholder: 'rəqəm', check: r => r.trim() === '3', wrong: '128 − 125 = ?' },
            { label: 'tracert-də hədəf daxil olmaqla neçə sətir var?', placeholder: 'rəqəm', check: r => r.trim() === '4', wrong: 'tracert çıxışında hop nömrələrinə bax.' },
            { label: 'tracert-də 2-ci hop-un IP-si', placeholder: 'a.b.c.d', check: r => r.trim() === '10.0.12.2', wrong: 'tracert-də 2 nömrəli sətirə bax.' },
          ],
          hints: ['Çıxış görünmürsə, əvvəlki praktikaya qayıdıb əmrləri yenidən işlət.'],
          solution: 'TTL = 125, router sayı 3, tracert 4 sətir (3 router + hədəf), 2-ci hop 10.0.12.2.',
          after: '<p>İki ayrı üsul eyni nəticəni verdi: TTL-dən 3 router, tracert-dən də 3 router (4 sətir − hədəf). Bu uyğunluq doğru oxuduğunu göstərir.</p>' },

        { id: 's6', title: 'Ticket 1: ping işləmir', type: 'terminal',
          body: '<p>İstifadəçi deyir ki, server-ə (<span class="m">172.16.0.10</span>) çatmır. Bu PC-nin vəziyyətini yoxla:</p><ol><li><span class="m">ipconfig</span></li><li><span class="m">ping 192.168.1.1</span> (real router)</li><li><span class="m">ping 172.16.0.10</span></li></ol><p>Nəticələri müqayisə et, sonra növbəti addımda diaqnoz ver.</p>',
          term: { kind: 'host', host: { name: 'PC3', ip: '192.168.1.30', mask: '255.255.255.0', gw: '192.168.1.254', mac: '0001.4321.CCCC' },
            peers: [{ name: 'R1', ip: '192.168.1.1', mac: '0001.4321.DDDD', ttl: 255 }],
            remote: [{ ip: '172.16.0.10', ttl: 125 }],
            quick: ['ipconfig', 'ping 192.168.1.1', 'ping 172.16.0.10'],
            goals: [
              { text: '<span class="m">ipconfig</span> ilə PC-nin ayarlarına bax', test: d => d.has(/^ipconfig(\s+\/all)?$/i) },
              { text: '<span class="m">ping 192.168.1.1</span> işlət', test: d => d.pings.some(p => p.ip === '192.168.1.1') },
              { text: '<span class="m">ping 172.16.0.10</span> işlət', test: d => d.pings.some(p => p.ip === '172.16.0.10') },
            ] },
          hints: ['Üç nəticəni yan-yana qoy: PC-nin gateway ayarı, router-ə ping, serverə ping. Mesajı kim yazdı?'],
          after: '<p>Serverə ping-in mesajı <span class="m">Reply from 192.168.1.30: Destination host unreachable</span> idi. Mesajı yazan IP-yə diqqət et.</p>' },

        { id: 's7', title: 'Diaqnoz: ticket 1', type: 'choice',
          body: '<p>Əvvəlki praktikanın nəticələri: PC3-ün gateway ayarı <span class="m">192.168.1.254</span> idi. <span class="m">ping 192.168.1.1</span> uğurlu oldu. <span class="m">ping 172.16.0.10</span> isə <span class="m">Reply from 192.168.1.30: Destination host unreachable</span> verdi (192.168.1.30 PC-nin öz IP-sidir). Problem nədir?</p>',
          options: [
            { t: 'Gateway ünvanı səhv yazılıb: 192.168.1.254-də router yoxdur və ARP-a cavab gəlmir.', ok: true, why: 'Mesajı PC özü yazıb: PC fərqli network üçün gateway-in MAC-ini ARP ilə soruşur, 192.168.1.254-dən cavab gəlmir və kadr qurula bilmir. Real router 192.168.1.1-dir və ona ping uğurludur. Həll: gateway-i 192.168.1.1 et.' },
            { t: 'R1 (192.168.1.1) söndürülüb və paketləri ötürmür, ona görə server əlçatmazdır.', why: 'R1-ə ping uğurlu oldu, yəni R1 işləyir və PC ilə əlaqə var. Üstəlik mesajı R1 deyil, PC özü göndərib.' },
            { t: 'Server 172.16.0.10 söndürülüb, ona görə router paketi geri qaytarıb.', why: 'Mesaj router-dən gəlmir, PC-nin öz IP-sindən gəlir: paket PC-dən ümumiyyətlə çıxmayıb. Server söndürülü olsaydı, PC paketi göndərib cavab gözləyərdi.' },
            { t: 'Mask yanlışdır və PC serveri eyni network sayıb birbaşa ARP göndərir.', why: 'Mask /24 düzgündür: 192.168.1.30 və 172.16.0.10 fərqli network-lərdədir. PC doğru olaraq gateway-ə göndərməyə çalışır, amma gateway ünvanı səhvdir.' },
          ],
          hints: ['Mesajı hansı IP yazdı: PC-nin özü, yoxsa router? Bu, problemin harada olduğunu deyir.'],
          after: '<p>Qayda: <b>öz IP</b> = problem PC-nin yanındadır (ARP/gateway). <b>Gateway IP</b> = paket router-ə çatdı, problem router-dən sonradır. Bunu ticket-lərdə hər dəfə yoxla.</p>' },

        { id: 's8', title: 'Ticket 2: TTL expired', type: 'choice',
          body: '<p>Başqa istifadəçinin PC-sində (gateway 192.168.1.1) nəticələr belədir:</p><pre class="pre"><span class="p">C:\\&gt;</span>ping 10.9.9.9\nReply from 10.0.12.2: TTL expired in transit.\nReply from 10.0.12.2: TTL expired in transit.\n\n<span class="p">C:\\&gt;</span>tracert 10.9.9.9\n  1    &lt;1 ms    &lt;1 ms    &lt;1 ms  192.168.1.1\n  2     1 ms     1 ms     1 ms  10.0.12.2\n  3     1 ms     1 ms     1 ms  10.0.23.3\n  4     1 ms     1 ms     1 ms  10.0.12.2\n  5     1 ms     1 ms     1 ms  10.0.23.3\n  6     2 ms     1 ms     1 ms  10.0.12.2</pre><p>Nəticəni necə qiymətləndirirsən?</p>',
          options: [
            { t: 'Routing loop: 10.0.12.2 və 10.0.23.3 paketi bir-birinə ötürür, TTL sıfıra enir.', ok: true, why: 'tracert-də eyni iki IP növbələşir (10.0.12.2, 10.0.23.3, 10.0.12.2 ...): paket iki router arasında dövr edir. TTL hər dövrdə azalır, 0 olanda router atır və TTL expired göndərir. Hədəfə heç vaxt çatmır.' },
            { t: 'Hədəf 10.9.9.9 söndürülüb və router-lər onun cavabını gözləyir.', why: 'Hədəfin söndürülü olması TTL expired yaratmır. Söndürülmüş hədəf adətən timeout və ya unreachable verir. Burada isə yolun özündə təkrarlanan router-lər görünür.' },
            { t: 'Hədəfin firewall-u ping-i bloklayır və router-lər bunu TTL expired kimi bildirir.', why: 'Firewall paketi atanda adətən heç nə göndərmir (timeout). TTL expired yalnız TTL bitəndə göndərilir və paket hədəfə çatmamış router-lər arasında bitib.' },
            { t: 'PC-nin gateway-i səhvdir və paketlər yanlış router-ə gedir.', why: 'Gateway (192.168.1.1) tracert-in 1-ci hop-udur və cavab verib. Yəni PC paketi düzgün göndərir. Problem sonrakı router-lərin marşrutlarındadır.' },
          ],
          hints: ['tracert-də hansı IP-lər təkrarlanır? Paket hədəfə çatırmı?'],
          after: '<p>Düzəliş PC-də yox, router-lərdədir (marşrutlar bir-birinə göstərir). İndi isə TTL-in niyə lazım olduğunu gördün: loop olmasaydı bu paket əbədi dövr edərdi.</p>' },

        { id: 's9', title: 'Ticket 3: qırıq yol', type: 'terminal',
          body: '<p>Server <span class="m">172.16.0.10</span> əlçatmazdır. Yolun harada qırıldığını tap:</p><ol><li><span class="m">ping 172.16.0.10</span></li><li><span class="m">tracert 172.16.0.10</span></li></ol>',
          term: { kind: 'host', host: { name: 'PC4', ip: '192.168.1.10', mask: '255.255.255.0', gw: '192.168.1.1', mac: '0001.4321.AAAA' },
            peers: [{ name: 'R1', ip: '192.168.1.1', mac: '0001.4321.DDDD', ttl: 255 }],
            remote: [{ ip: '172.16.0.10', fail: 'timeout' }],
            broken: { '172.16.0.10': ['192.168.1.1', '10.0.12.2'] },
            quick: ['ping 172.16.0.10', 'tracert 172.16.0.10'],
            goals: [
              { text: '<span class="m">ping 172.16.0.10</span> işlət', test: d => d.pings.some(p => p.ip === '172.16.0.10') },
              { text: '<span class="m">tracert 172.16.0.10</span> işlət', test: d => d.tracerts.includes('172.16.0.10') },
            ] },
          hints: ['Ping yalnız "çatmadı" deyir. tracert-də son cavab verən hop-u tap.'],
          after: '<p>ping yalnız <span class="m">Request timed out</span> verdi. tracert isə yolun hansı hop-dan sonra dayandığını göstərdi.</p>' },

        { id: 's10', title: 'Qırıq yolu oxu', type: 'form',
          body: '<p>Əvvəlki praktikanın tracert nəticəsinə bax.</p>',
          fields: [
            { label: 'Son cavab verən hop-un IP-si', placeholder: 'a.b.c.d', check: r => r.trim() === '10.0.12.2', wrong: 'tracert-də ulduzlardan (* * *) əvvəlki sonuncu sətirə bax.' },
            { label: 'İlk cavab verməyən hop-un nömrəsi', placeholder: 'rəqəm', check: r => r.trim() === '3', wrong: 'İlk * * * sətrinin nömrəsi.' },
          ],
          hints: ['Əvvəlki praktikada tracert nəticəsi görünmürsə, onu yenidən işlət.'],
          solution: 'Son cavab verən hop 10.0.12.2 (hop 2). İlk cavab verməyən hop 3.',
          after: '<p>Verdikt: paket 10.0.12.2-yə qədər çatır və ondan sonra itir. Problem 10.0.12.2-dən sonrakı hissədədir: onun növbəti link-i, növbəti router və ya hədəfin özü. <b>Hansı</b> olduğunu yalnız bu nəticə ilə söyləmək olmaz: növbəti addım 10.0.12.2 router-inin özündən növbəti hop-a ping və marşrut cədvəlinə baxmaqdır.</p>' },

        { id: 's11', title: 'SOC: log-da ICMP', type: 'choice',
          body: '<p>Firewall log-da qısa müddətdə bu izləri görürsən:</p><pre class="pre">10:14:01  10.1.20.45 → 10.1.10.1     ICMP Echo Request\n10:14:01  10.1.20.45 → 10.1.10.2     ICMP Echo Request\n10:14:01  10.1.20.45 → 10.1.10.3     ICMP Echo Request\n10:14:02  10.1.20.45 → 10.1.10.4     ICMP Echo Request\n   ... (daha 250 sətir: eyni mənbə, hər dəfə növbəti Destination IP)\n10:14:02  10.1.10.17 → 10.1.20.45    ICMP Echo Reply\n10:14:03  10.1.10.23 → 10.1.20.45    ICMP Echo Reply</pre><p>Bu nədir və <b>ilk</b> nəyi yoxlayırsan?</p>',
          options: [
            { t: 'Ping sweep (kəşfiyyat): 10.1.20.45 ardıcıl IP-lərə ping atır. Əvvəl onun rolunu yoxlayıram.', ok: true, why: 'Bir mənbə, çoxlu fərqli Destination, hamısı Echo Request: canlı host-ları tapmaq üçün ping sweep. Cavab verənlər (10.1.10.17, 10.1.10.23) canlı host-lardır. Əvvəl 10.1.20.45-in inventardakı rolunu yoxla: monitoring və ya scanner ola bilər.' },
            { t: 'Adi ping-dir: istifadəçi şəbəkənin işləməsini yoxlayır, buna ayrıca baxmaq lazım deyil.', why: 'Adi ping bir hədəfə atılır. Eyni mənbədən yüzlərlə fərqli ardıcıl hədəfə sorğu atmaq adi istifadəçi davranışı deyil.' },
            { t: 'DoS hücumudur: 10.1.20.45 hədəfləri çoxlu sorğu ilə yükləyib cavab verməməyə çalışır.', why: 'DoS-da çox sorğu çox vaxt bir hədəfə yönəlir. Burada hər hədəf bir sorğu alır və hədəflər fərqlidir, bu kəşfiyyat nümunəsidir.' },
            { t: 'Routing loop-dur: TTL bitən paketlər router-lər arasında təkrar-təkrar göndərilir.', why: 'Routing loop-da Time Exceeded (Type 11) mesajları görünür. Burada isə Echo Request (Type 8) və Echo Reply (Type 0) var.' },
          ],
          hints: ['Neçə fərqli Destination var? Hansı Type-lar görünür? Cavab verənlər kimdir?'],
          after: '<p>Sonrakı addım scope-dur: 10.1.20.45 başqa nə etdi (port scan, login cəhdləri)? Cavab verən host-lardan hansı ona sonra bağlandı? Kəşfiyyat tək başına incident deyil, amma çox vaxt hücumun ilk addımıdır.</p>' },

        { id: 's12', title: 'Öz kompüterində: ping və TTL', type: 'form',
          body: '<p>Öz kompüterində əvvəl <span class="m">ipconfig</span> (və ya Linux/macOS-da <span class="m">ip route</span>, <span class="m">route -n get default</span>) ilə default gateway-i tap. Sonra ona ping at:</p><pre class="pre"><span class="p">C:\\&gt;</span>ping &lt;gateway ip&gt;</pre><p>Cavabdakı <b>TTL</b> dəyərinə və bu mövzunun qaydasına görə ilkin TTL-i yaz.</p>',
          fields: [
            { label: 'Gateway-ə ping cavabında TTL', placeholder: 'rəqəm (1-255)', check: r => /^\d{1,3}$/.test(r.trim()) && +r.trim() >= 1 && +r.trim() <= 255, wrong: 'Reply sətirindəki TTL=... rəqəmini yaz (1 ilə 255 arası).' },
            { label: 'Bu TTL-ə görə cihazın ilkin TTL-i', placeholder: '64 / 128 / 255', answers: ['64', '128', '255'], wrong: 'Üç standart dəyərdən biri: 64, 128 və ya 255. Cavabdakı TTL-dən böyük ən yaxını seç.' },
          ],
          hints: ['Gateway eyni network-dədir, ona görə TTL ilkin dəyərə çox yaxındır: adətən 64, 128 və ya 255.'],
          solution: 'Ev router-ləri çox vaxt 64 (Linux əsaslı) göstərir. Cisco cihazı 255 göstərə bilər. Eyni network-də olduğu üçün TTL ilkin dəyərə yaxın və ya bərabərdir.',
          after: '<p>Əgər TTL ilkin dəyərdən kiçikdirsə, arada router olub. Gateway birbaşa qonşudur və TTL azalmır.</p>' },
      ],
    },

    quiz: {
      draw: 8,
      gens: [
        // reply TTL -> number of routers passed
        () => {
          const start = pick([64, 128, 255]); const n = 1 + R(15); const T = start - n;
          const ip = pick(['172.16.0', '10.50.3', '203.0.113', '198.51.100']) + '.' + (10 + R(200));
          const t = rnd(1, 40);
          return { id: 'p1t6-g-ttl', concept: 'ttl-read', obj: 'Cavabdakı TTL-dən router sayı', type: 'num', _meta: { T, start, n },
            stem: '<p>Ping cavabı gəldi:</p><pre class="pre">Reply from ' + ip + ': bytes=32 time=' + t + 'ms TTL=' + T + '</pre><p>Cavabdakı TTL-dən <b>böyük ən yaxın</b> standart ilkin dəyəri (64, 128 və ya 255) götür. Paket yolda <b>neçə router</b> keçib?</p>', placeholder: 'rəqəm',
            check: r => r.trim() === String(n),
            solution: 'TTL=' + T + ' dəyərindən böyük ən yaxın standart dəyər ' + start + '-dır. Hər router 1 azaldır: ' + start + ' − ' + T + ' = <b>' + n + '</b> router.' };
        },
        // TTL on path: where does it die?
        () => {
          const k = 3 + R(4); const reach = R(4) === 0; const t = reach ? k + 1 + R(3) : 1 + R(k);
          const dies = t <= k;
          const lab = j => 'R' + j + '-də atılır, mənbəyə Time Exceeded gedir';
          const labReach = 'Hədəfə çatır, hədəf Echo Reply göndərir';
          const label = x => x === 0 ? labReach : lab(x);
          const correct = dies ? t : 0;
          const cands = []; for (let j = 1; j <= k; j++) if (j !== correct) cands.push(j); if (correct !== 0) cands.push(0);
          const chosen = shuffle(cands).slice(0, 3); chosen.push(correct);
          const whyFor = x => {
            if (x === correct) return dies
              ? 'Hər router TTL-i 1 azaldır. R' + t + '-ə çatanda TTL 1 qalır, R' + t + ' onu 0 edir və paketi atır. Mənbəyə R' + t + ' ünvanından Time Exceeded gəlir.'
              : k + ' router TTL-i ' + k + ' azaldır: ' + t + ' − ' + k + ' = ' + (t - k) + ' qalır, bu 0 deyil. Paket hədəfə çatır və hədəf Echo Reply göndərir.';
            if (x === 0) return 'Çatması üçün TTL router sayından (' + k + ') böyük olmalıdır, yəni ən azı ' + (k + 1) + '. Burada TTL = ' + t + ' olduğu üçün paket R' + t + '-də atılır.';
            if (x < t) return 'R' + x + ' TTL-i ' + (t - x + 1) + '-dən ' + (t - x) + '-ə endirir. Bu hələ 0 deyil, paket ötürülür.';
            return 'Paket R' + t + '-də artıq atılıb və R' + x + '-ə çatmır.';
          };
          return { id: 'p1t6-g-path', concept: 'ttl', obj: 'TTL paketi harada atılır', _meta: { k, t, correct },
            stem: '<p>PC hədəfə <b>TTL = ' + t + '</b> olan paket göndərir. Yolda ' + k + ' router var (R1 ... R' + k + '), sonra hədəf. Paketin aqibəti nə olur?</p>',
            options: chosen.map(x => ({ t: label(x), ok: x === correct, why: whyFor(x) })) };
        },
        // tracert verdict
        () => {
          const kind = R(2) === 0 ? 'A' : 'B';
          const used = new Set(); const rip = () => { let s; do { s = '10.' + rnd(1, 250) + '.' + rnd(1, 250) + '.' + rnd(1, 250); } while (used.has(s)); used.add(s); return s; };
          const gw = '192.168.' + rnd(10, 200) + '.1'; const dest = '172.16.' + rnd(1, 250) + '.' + rnd(2, 250);
          const hdr = 'Tracing route to ' + dest + ' over a maximum of 30 hops\n\n';
          let hops, lines, q, opts, meta;
          const cell = n => { const t = Math.max(0, Math.floor(n * 1.5) - 2); return [t, t + R(2), t + R(3)]; };
          if (kind === 'A') {
            const n = 6 + R(2); hops = [gw]; for (let i = 2; i < n; i++) hops.push(rip()); hops.push(dest);
            const m = 2 + R(n - 3);
            lines = hops.map((ip, i) => (i + 1 === m ? starRow(i + 1) : row(i + 1, ...cell(i + 1), ip))).join('\n') + '\n\nTrace complete.';
            q = 'Hop ' + m + ' cavab vermir, amma sonuncu sətir hədəfdir. Düzgün nəticə hansıdır?';
            opts = [
              { t: 'Yol işləyir: hop ' + m + ' cavab göndərmir, amma paketlər onun üstündən keçib.', ok: true, why: 'Hədəf cavab verib (sonuncu sətir), yəni paketlər hop ' + m + '-dən keçib. Router-lər Time Exceeded göndərməyə bilər (çox vaxt filtr və ya rate limit). Bu özü-özlüyündə problem deyil.' },
              { t: 'Hədəfə çatılmayıb, çünki paketlər hop ' + m + '-də itir və sonrakı hop-lara keçmir.', why: 'Əgər paketlər hop ' + m + '-də itsəydi, sonrakı hop-lar və hədəf cavab verə bilməzdi. Sonuncu sətir hədəfdir və cavab verib.' },
              { t: 'Hop ' + m + ' routing loop yaradır: paketlər orada dövr edir və hədəfə çatmır.', why: 'Loop olsaydı, tracert-də eyni IP-lər təkrarlanardı və hədəfə çatılmazdı. Burada hop-lar fərqlidir və hədəf cavab verib.' },
              { t: 'Hədəfdə firewall ICMP-ni bloklayır, ona görə ortadakı hop-dan cavab gəlmir.', why: 'Hədəf Echo Reply göndərib, yəni onun ICMP-si açıqdır. Ortadakı hop-un cavab verməməsi hədəfin firewall-undan asılı deyil.' },
            ];
            meta = { kind, hops, m };
          } else {
            const k = 3 + R(3); hops = []; hops.push(gw); for (let i = 2; i < k; i++) hops.push(rip());
            const X = hops[hops.length - 1];
            lines = hops.map((ip, i) => row(i + 1, ...cell(i + 1), ip)).join('\n') + '\n' + starRow(k) + '\n' + starRow(k + 1) + '\n' + starRow(k + 2) + '\n  ...  (30-cu hop-a qədər belə davam edir)';
            q = 'Son cavab verən hop <span class="m">' + X + '</span>-dir və ondan sonra hər sətir <span class="m">* * *</span>-dır. Düzgün nəticə hansıdır?';
            const all = [
              { t: 'Paketlər ' + X + '-ə çatır və ondan sonra itir: problem sonrakı hissədədir.', ok: true, why: X + ' cavab verib, yəni paket ona qədər çatır. Sonrakı hop-lardan cavab yoxdur: problem onun növbəti link-ində, növbəti router-də və ya hədəfdə ola bilər. Bu nəticə yalnız axtarış sahəsini daraldır.' },
              { t: 'Problem PC-dədir: PC-nin ayarları səhvdir və paketlər düzgün qurulmur.', why: 'İlk hop-lar cavab verir, yəni PC paketləri düzgün qurur və göndərir. PC-nin ayarları işləyir.' },
              { t: X + ' router-i söndürülüb, ona görə yol onun üstündə qırılır və paketlər keçmir.', why: X + ' cavab verib: söndürülmüş cihaz Time Exceeded göndərə bilməz. Yəni o işləyir.' },
              { t: 'Problem DNS-dədir: tracert ad çevirə bilmir, ona görə nəticə yarımçıq qalır.', why: 'tracert burada IP ilə işləyir və hop-lar IP kimi göründü. DNS-in bu çıxışla əlaqəsi yoxdur.' },
              { t: 'Problem ' + X + '-dən əvvəlkidir: ilk hop-lar arasında bir link qırılıb və paket keçmir.', why: 'İlk hop-lar cavab verib, yəni paketlər ' + X + '-ə qədər çatıb. Qırılma bundan sonradır.' },
            ];
            opts = [all[0]].concat(shuffle(all.slice(1)).slice(0, 3));
            meta = { kind, hops, k, lastResp: X };
          }
          return { id: 'p1t6-g-tracert-' + kind, concept: 'tracert', obj: 'tracert çıxışını oxumaq', _meta: meta,
            stem: '<p>Windows-da tracert nəticəsi:</p><pre class="pre">' + hdr + lines + '</pre><p>' + q + '</p>', options: opts };
        },
        // ping sweep in a log
        () => {
          const used = new Set(); const rip = (a, b) => { let s; do { s = '10.' + rnd(a, b) + '.' + rnd(1, 250) + '.' + rnd(2, 250); } while (used.has(s)); used.add(s); return s; };
          const S = [rip(1, 9), rip(10, 19), rip(20, 29), rip(30, 39)];
          const [sw, rp, sg, rpl] = S;
          const base = '10.' + rnd(60, 80) + '.' + rnd(1, 250) + '.'; const a0 = rnd(1, 240);
          const t0 = 10 * 3600 + 14 * 60 + R(30); const L = [];
          for (let i = 0; i < 4; i++) L.push({ t: t0 + (i >> 1), src: sw, dst: base + (a0 + i), ty: 'Echo Request' });
          const rdst = rip(90, 99); const r0 = t0 - 1 - R(2); for (let i = 0; i < 3; i++) L.push({ t: r0 + i, src: rp, dst: rdst, ty: 'Echo Request' });
          L.push({ t: t0 + R(3), src: sg, dst: rip(90, 99), ty: 'Echo Request' });
          for (let i = 0; i < 4; i++) L.push({ t: t0 + R(4), src: rpl, dst: rip(100, 109), ty: 'Echo Reply' });
          L.forEach(x => { x.k = Math.random(); }); L.sort((x, y) => x.t - y.t || x.k - y.k);
          const fmt = t => pad2(Math.floor(t / 3600)) + ':' + pad2(Math.floor(t / 60) % 60) + ':' + pad2(t % 60);
          const lines = L.map(x => fmt(x.t) + '  ' + x.src.padEnd(14) + ' → ' + x.dst.padEnd(14) + ' ICMP ' + x.ty).join('\n');
          const whys = {};
          whys[sw] = 'Bu mənbə 4 fərqli ardıcıl IP-yə (' + base + a0 + ' ... ' + base + (a0 + 3) + ') Echo Request göndərir: canlı host-ları axtaran ping sweep nümunəsidir.';
          whys[rp] = 'Bu mənbə eyni hədəfə (' + rdst + ') 3 dəfə, bir saniyə fasilə ilə Echo Request göndərir. Bu adi ping-dir (Windows default 4 sorğu).';
          whys[sg] = 'Bu mənbə yalnız bir Echo Request göndərib. Tək sorğu kəşfiyyat əlaməti deyil.';
          whys[rpl] = 'Bu mənbə 4 fərqli ünvana yazır, amma bunlar Echo <b>Reply</b>-dır (Type 0): bu host başqalarının sorğusuna cavab verir. Sweep sorğu göndərəndir, cavab verən yox.';
          return { id: 'p1t6-g-sweep', concept: 'soc-icmp', obj: 'Ping sweep-i log-da tanımaq', _meta: { sweeper: sw, lines: L.length },
            stem: '<p>Firewall log-da qısa müddətdə bu ICMP qeydləri var:</p><pre class="pre">' + lines + '</pre><p>Hansı Source IP <b>ping sweep</b> (kəşfiyyat) davranışı göstərir?</p>',
            options: S.map(ip => ({ t: ip, ok: ip === sw, why: whys[ip] })) };
        },
      ],
      pool: [
        { id: 'p1t6-q1', concept: 'icmp-what', obj: 'ICMP xəta bildirir',
          stem: '<p>Router-in marşrut cədvəlində hədəf üçün giriş yoxdur və paketi atır. Göndərən PC bunu necə öyrənir?</p>',
          options: [
            { t: 'Router PC-yə ICMP Destination Unreachable (Type 3) mesajı göndərir.', ok: true, why: 'Qayda: IP çatdırılma təminatı vermir, xəbəri ICMP verir. Marşrut yoxdursa router paketi atır və mənbəyə Type 3 göndərir. Burada: PC ekranında "Destination ... unreachable" çıxır.' },
            { t: 'IP başlığındakı xəta bayrağı qaldırılır və paket PC-yə geri qayıdır.', why: 'IP başlığında belə bayraq yoxdur və paket geri qayıtmır. Xətanı ayrıca ICMP mesajı bildirir.' },
            { t: 'Switch kadrı geri qaytarır və PC öz ARP cache-ini silir.', why: 'Switch kadrı geri qaytarmır, Layer 2-də xəta bildirmə mexanizmi yoxdur. ARP cache də bu hadisədən silinmir.' },
            { t: 'Router ARP reply göndərir və cavabın içində xəta kodu olur.', why: 'ARP yalnız IP → MAC həll edir və xəta kodu daşımır. Xəta məlumatı ICMP-nin işidir.' },
          ] },
        { id: 'p1t6-q2', concept: 'icmp-what', obj: 'ICMP-nin quruluşu',
          stem: '<p>ICMP mesajı TCP və UDP-dən struktur baxımından nə ilə fərqlənir?</p>',
          options: [
            { t: 'ICMP-də port yoxdur, mesajı Type və Code sahələri təyin edir.', ok: true, why: 'Port TCP və UDP başlığının sahəsidir. ICMP-də mesajı Type (növ) və Code (dəqiq səbəb) təyin edir. IP başlığında Protocol = 1 içəridə ICMP olduğunu bildirir.' },
            { t: 'ICMP IP-dən istifadə etmir və birbaşa Ethernet kadrında gedir.', why: 'ICMP IP paketinin içində gedir (Protocol = 1). Birbaşa Ethernet-də gedən ARP-dır, ICMP deyil.' },
            { t: 'ICMP yalnız broadcast ünvanlarına göndərilə bilər.', why: 'ICMP adi unicast ünvanlara göndərilir. Ping bir hədəfə atılan unicast ICMP-dir.' },
            { t: 'ICMP yalnız router-lərdə işləyir, host-lar onu istifadə etmir.', why: 'Host-lar ICMP işlədir: ping-i də host göndərir, cavabı da host verir.' },
          ] },
        { id: 'p1t6-q3', concept: 'ping', obj: 'Ping iki istiqamətli yol tələb edir',
          stem: '<p>PC ping göndərir. Echo Request hədəfə çatır və hədəf Echo Reply göndərir, amma cavabın qayıdış yolunda router-in marşrutu yoxdur. PC ekranında nə görünür?</p>',
          options: [
            { t: 'Request timed out: cavab qayıtmır, ping iki istiqamətli yol tələb edir.', ok: true, why: 'Ping-in uğurlu sayılması üçün həm sorğu çatmalı, həm cavab qayıtmalıdır. Cavab yolda itirsə, PC heç nə almır və timeout yazır.' },
            { t: 'Reply from hədəf: sorğu çatıb, ona görə ping uğurlu sayılır.', why: 'Reply sətri yalnız Echo Reply PC-yə çatanda yazılır. Sorğunun çatması kifayət deyil.' },
            { t: 'Reply from öz IP: Destination host unreachable, çünki PC cavabı qəbul edə bilmir.', why: 'Öz IP-dən gələn unreachable PC-nin yerli ARP və marşrut problemidir. Burada PC sorğunu uğurla göndərib.' },
            { t: 'TTL expired in transit, çünki marşrutu olmayan yolda TTL tez bitir.', why: 'Cavab marşrut tapmadığı üçün atılır, bunun TTL-lə əlaqəsi yoxdur. Üstəlik router bu halda Unreachable-ı cavabın mənbəyinə (hədəfə) göndərərdi, PC-yə yox.' },
          ] },
        { id: 'p1t6-q4', concept: 'ping-results', obj: 'Unreachable-ı kim göndərib',
          stem: '<p>PC (192.168.1.10/24) 192.168.1.50-yə ping atır və ekranda görünür: <span class="m">Reply from 192.168.1.10: Destination host unreachable.</span> Bu mesajı kim göndərib və nə deməkdir?</p>',
          options: [
            { t: 'PC özü: ARP-a cavab gəlmədi, ona görə paketi göndərmək mümkün olmadı.', ok: true, why: 'Mesaj PC-nin öz IP-sindən gəlir, yəni PC özü yazıb. Hədəf eyni network-dədir, PC onun MAC-ini ARP ilə soruşur, cavab gəlmir və kadr qurulmur. Hədəf söndürülüb, IP səhvdir və ya link qırıqdır.' },
            { t: '192.168.1.50 hostu: o, Echo Request-i aldı və ping-i qəbul etməkdən imtina etdi.', why: 'Hədəfin imtinası öz IP-sindən (192.168.1.50) gələrdi. Mesaj isə 192.168.1.10-dan gəlir. Üstəlik host adətən sorğu qəbul etmirsə sadəcə cavab verməz (timeout).' },
            { t: 'Gateway router: onun hədəf üçün marşrut cədvəlində giriş yoxdur və paketi atdı.', why: 'Hədəf eyni network-dədir, paket gateway-ə getmir. Gateway olsaydı, mesaj onun IP-sindən (məsələn 192.168.1.1) gələrdi.' },
            { t: 'Switch: hədəfin MAC-i onun MAC address table-ında yoxdur və kadrı atdı.', why: 'Switch Layer 2 cihazıdır, ICMP mesajı yaratmır. MAC cədvəlində giriş olmasa switch kadrı flood edir, atmır.' },
          ] },
        { id: 'p1t6-q5', concept: 'ping-results', obj: 'Gateway-dən gələn unreachable',
          stem: '<p>PC (gateway 192.168.1.1) 172.16.0.10-a ping atır və görür: <span class="m">Reply from 192.168.1.1: Destination host unreachable.</span> Nə baş verib?</p>',
          options: [
            { t: 'Paket router-ə çatıb, router onu hədəfə çatdıra bilmir (çox vaxt marşrut yoxdur).', ok: true, why: 'Mesajı router göndərib, yəni PC-dən router-ə qədər hissə işləyir. Router paketi hədəfə yönəldə bilmir: marşrut yoxdur, ya da hədəfin qoşulduğu network-də ARP cavab gəlmir. Problem router-dən sonrakı hissədədir.' },
            { t: 'PC ilə router arasındakı kabel qırılıb, ona görə paket router-ə çata bilmir və ya itir.', why: 'Mesajı router özü göndərib, yəni paket router-ə çatıb. Kabel qırıq olsaydı, heç bir cavab gəlməzdi.' },
            { t: 'PC-nin TCP/IP stack-ı xarab olub və paketləri düzgün qura bilmir.', why: 'Stack xarab olsaydı, router-dən heç bir cavab gəlməzdi. Router paketi aldığı üçün stack işləyir.' },
            { t: 'DNS server 172.16.0.10 ünvanını tapa bilmir, ona görə router xəta göndərir.', why: 'DNS ad üçündür, burada IP ilə ping edilir. Router DNS qərarı vermir, o marşrut cədvəli ilə işləyir.' },
          ] },
        { id: 'p1t6-q6', concept: 'ping-results', obj: 'Timeout nə deyir',
          stem: '<p>Ping nəticəsi: <span class="m">Request timed out.</span> Bu nəticə sənə nəyi <b>dəqiq</b> deyir?</p>',
          options: [
            { t: 'Cavabın gəlmədiyini: səbəb (söndürülüb, firewall, qayıdış yolu) ayrıca tapılmalıdır.', ok: true, why: 'Timeout heç kimin cavab vermədiyini bildirir. Eyni nəticəni bir neçə səbəb verir: hədəf söndürülüb, firewall atır, cavabın qayıdış marşrutu yoxdur, yolda ACL var. Ayırmaq üçün tracert və hədəfə yaxın nöqtələrdən ping lazımdır.' },
            { t: 'Hədəf söndürülüb, çünki işləyən cihaz həmişə ping-ə cavab verir və gecikmir.', why: 'Hədəf işləyə bilər, amma firewall ICMP-ni atır. Yəni cavab verməmək söndürülmə demək deyil.' },
            { t: 'Router paketi atıb və bunu PC-yə TTL expired ilə bildirib, ona görə cavab gəlmir.', why: 'Router atanda mesaj göndərir və ekranda "TTL expired" və ya "unreachable" yazılır. Timeout isə heç bir mesaj olmaması deməkdir.' },
            { t: 'Hədəfin firewall-u ICMP-ni bloklayır və başqa heç bir izah mümkün deyil.', why: 'Firewall mümkün səbəblərdən yalnız biridir. Hədəf söndürülü ola bilər, qayıdış marşrutu qırıq ola bilər.' },
          ] },
        { id: 'p1t6-q7', concept: 'ttl', obj: 'TTL=1 router-də',
          stem: '<p>TTL = 1 olan paket router-ə çatır. Router nə edir?</p>',
          options: [
            { t: 'TTL-i 0 edir, paketi atır, mənbəyə Time Exceeded göndərir.', ok: true, why: 'Router ötürməzdən əvvəl TTL-i 1 azaldır. Nəticə 0 olduqda paketi ötürmür, atır və mənbəyə ICMP Time Exceeded (Type 11) göndərir. tracert-in işləməsinin əsasıdır.' },
            { t: 'Paketi ötürür, TTL-i 1 olaraq saxlayır, növbəti router atır.', why: 'Router həmişə TTL-i azaldır. TTL 1 olanda nəticə 0 olur və paket həmin router-də atılır.' },
            { t: 'TTL-i 0 edib paketi ötürür, hədəf onu atır.', why: 'TTL = 0 olan paket ötürülmür. Onu atmaq router-in vəzifəsidir, hədəfə çatmır.' },
            { t: 'Paketi atır və mənbəyə Destination Unreachable göndərir.', why: 'TTL bitəndə göndərilən mesaj Time Exceeded-dir (Type 11). Destination Unreachable (Type 3) marşrut yoxluğu kimi hallarda göndərilir.' },
          ] },
        { id: 'p1t6-q8', concept: 'ttl', obj: 'TTL-in məqsədi',
          stem: '<p>IP başlığında TTL sahəsi niyə var?</p>',
          options: [
            { t: 'Routing loop-da paket əbədi dövr etməsin: hər router 1 azaldır, 0 olanda paket atılır.', ok: true, why: 'Routing səhvi olanda paket router-lər arasında dövr edə bilər. TTL olmasaydı belə paketlər şəbəkəni əbədi dolduracaqdı. TTL hər paketə məhdud ömür verir.' },
            { t: 'Paketin hədəfdə nə qədər saxlanacağını göstərir, vaxt bitəndə ARP cache silinir.', why: 'TTL hədəfdə saxlama müddəti deyil, paketin keçə biləcəyi router sayıdır. ARP cache-in öz timeout-u var və TTL ilə əlaqəsi yoxdur.' },
            { t: 'Paketin neçə millisaniyəyə çatmalı olduğunu göstərir və gecikməni məhdudlaşdırır.', why: 'TTL adı vaxt kimi səslənsə də, praktikada hop sayğacıdır. Gecikmə ping-də time=...ms ilə ölçülür, TTL ilə yox.' },
            { t: 'Hədəfə göndərənin əməliyyat sistemini bildirir ki, cavab düzgün formatda olsun.', why: 'İlkin TTL OS-dən asılı olsa da, TTL-in vəzifəsi OS bildirmək deyil, loop-u məhdudlaşdırmaqdır.' },
          ] },
        { id: 'p1t6-q9', concept: 'tracert', obj: 'tracert-in mexanizmi',
          stem: '<p><span class="m">tracert</span> yoldakı hər router-in IP ünvanını necə öyrənir?</p>',
          options: [
            { t: 'TTL-i 1, 2, 3 ... artırır: hər atan router öz IP-sini Time Exceeded ilə verir.', ok: true, why: 'TTL = 1 olan paket ilk router-də ölür və o, öz ünvanından Time Exceeded göndərir. TTL = 2 olan paket ikinci router-də ölür və s. Hər cavab bir hop-u üzə çıxarır.' },
            { t: 'Hər router-ə ayrıca ping göndərir, cavab verənlərin ünvanını siyahıya yazır.', why: 'Hansı router-lərin yolda olduğu əvvəlcədən bilinmir, ona görə onlara ayrıca ping göndərmək olmaz. tracert yalnız hədəfə ünvanlanmış paketlərin TTL-ini dəyişir.' },
            { t: 'Router-lər tracert sorğusuna cavab olaraq öz marşrut cədvəllərini PC-yə göndərir.', why: 'Router-lər marşrut cədvəllərini tracert-ə vermir. Onların ünvanı yalnız Time Exceeded mesajlarının mənbə IP-sindən görünür.' },
            { t: 'Ünvanları DNS-dən alır: hər router-in adı və IP-si orada saxlanılır və sorğulanır.', why: 'DNS yolun hansı router-lərdən keçdiyini bilmir. IP ünvanları paketlərin cavabından gəlir, DNS-dən yox.' },
          ] },
        { id: 'p1t6-q10', concept: 'ping-method', obj: 'Ping ardıcıllığı: gateway uğursuz',
          stem: '<p><span class="m">ping 127.0.0.1</span> və öz IP-yə ping uğurludur, amma gateway-ə ping uğursuzdur. Problemi harada axtarırsan?</p>',
          options: [
            { t: 'PC ilə gateway arasında: kabel və port, VLAN, səhv IP/mask və ya ARP.', ok: true, why: 'Ardıcıllıq aşağıdan yuxarı gedir: öz stack-ı və adapter işləyir, ilk uğursuz addım gateway-dir. Deməli problem PC-dən gateway-ə qədər olan yerli hissədədir.' },
            { t: 'PC-nin TCP/IP stack-ında: əməliyyat sistemi şəbəkə hissəsini yenidən quraşdırmaq lazımdır.', why: '127.0.0.1-ə ping stack-ı yoxlayır və uğurludur. Stack işləyir, problem başqa yerdədir.' },
            { t: 'İnternet provayderində: provayderin xətti bağlanıb.', why: 'Gateway yerli şəbəkədədir və provayderdən əvvəl gəlir. Provayder problemi gateway-ə ping-i pozmaz.' },
            { t: 'DNS serverdə: gateway adı IP-yə çevrilmir.', why: 'Ping gateway-in IP-sinə edilir, ad lazım deyil. DNS bu addımda iştirak etmir.' },
          ] },
        { id: 'p1t6-q11', concept: 'ping-method', obj: 'IP işləyir, ad işləmir',
          stem: '<p><span class="m">ping 8.8.8.8</span> uğurludur, amma <span class="m">ping google.com</span> <span class="m">could not find host</span> yazır. Ən ehtimal səbəb nədir?</p>',
          options: [
            { t: 'DNS: ad IP-yə çevrilmir, şəbəkə yolu isə işləyir.', ok: true, why: 'IP ilə ping işləyir, yəni yol qaydasındadır. Ad ilə ping isə əvvəlcə adı IP-yə çevirməlidir. Çevrilmə alınmayanda ping heç göndərilmir və "could not find host" yazılır.' },
            { t: 'Default gateway yoxdur, ona görə ad ilə ping keçmir.', why: 'Gateway olmasaydı, 8.8.8.8-ə ping də keçməzdi (fərqli network). Gateway işləyir.' },
            { t: 'Google-un firewall-u ping-i atır, ona görə host tapılmır.', why: '"could not find host" ping göndərilməzdən əvvəl çıxır: ad IP-yə çevrilməyib. Firewall isə timeout verərdi.' },
            { t: 'Yolda routing loop var və paketlərin TTL-i bitir.', why: 'Loop olsaydı, 8.8.8.8-ə ping də TTL expired verərdi. Üstəlik "could not find host" ad çevrilməsinin xətasıdır.' },
          ] },
        { id: 'p1t6-q12', concept: 'ttl-read', obj: 'TTL-dən nəticə çıxarmaq',
          stem: '<p>Ping cavabında <span class="m">TTL=117</span> gəlir. Bundan nə nəticə çıxarırsan?</p>',
          options: [
            { t: 'Ehtimal ki, ilkin TTL 128 olub, 11 router keçib. Bu təxmindir, sübut deyil.', ok: true, why: '117-dən böyük ən yaxın standart dəyər 128, 128 − 117 = 11. İlkin TTL dəyişdirilə bilər və bəzi cihazlar fərqli dəyər işlədir, ona görə bu işçi fərziyyədir.' },
            { t: 'Hədəf mütləq Windows-dur və yolda tam 11 router var, bu qəti faktdır.', why: 'İlkin TTL-in 128 olması Windows-a işarə edir, amma ilkin TTL dəyişdirilə bilər. "Mütləq" demək olmaz, bu yalnız ehtimaldır.' },
            { t: 'Paketin ömrü 117 saniyədir, bu müddət bitəndə paket silinir.', why: 'TTL saniyə yox, hop sayğacıdır. Hər router 1 azaldır, vaxtla əlaqəsi yoxdur.' },
            { t: 'Hədəf 117 millisaniyə uzaqdadır və TTL gecikməni ms ilə göstərir.', why: 'Gecikmə ping-də ayrıca time=...ms kimi göstərilir. TTL ilə qarışdırma: TTL router sayını göstərir.' },
          ] },
      ],
    },
  });
})();
