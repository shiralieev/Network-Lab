(function () {
  const R = n => PT.randInt(n), pick = PT.pick, shuffle = PT.shuffle;
  const LAYER_NAME = { 7: 'Application', 6: 'Presentation', 5: 'Session', 4: 'Transport', 3: 'Network', 2: 'Data Link', 1: 'Physical' };

  const ITEMS = [
    ['HTTP', 7, 'HTTP is the set of rules a program uses to talk to a web server. That is the application level.'],
    ['A DNS lookup', 7, 'DNS is a service the program asks for (turning a name into an IP address), so it is Layer 7.'],
    ['DHCP', 7, 'DHCP is how a device asks for an address. It is an application protocol, Layer 7.'],
    ['TCP', 4, 'TCP works with port numbers and reliable delivery. That is the Transport layer.'],
    ['UDP', 4, 'UDP also works with port numbers (without reliable delivery). That is Layer 4.'],
    ['Port number 443', 4, 'A port number picks the program on the destination. That is a Transport layer job.'],
    ['An IP address', 3, 'An IP address finds a device across networks. That is the Network layer.'],
    ['ICMP (ping)', 3, 'ICMP works together with IP and is a helper protocol of the Network layer.'],
    ['A MAC address', 2, 'A MAC address picks the next device on the same link. That is the Data Link layer.'],
    ['An Ethernet frame', 2, 'A frame is the unit of Layer 2.'],
    ['An electric signal on a copper cable', 1, 'Carrying the signal over the cable is a Physical layer job.'],
    ['A light signal in a fiber cable', 1, 'Light is the physical carrier of the bits. That is Layer 1.'],
  ];
  const PDU = [[4, 'segment'], [3, 'packet'], [2, 'frame'], [1, 'bits']];

  PT.topicEn({
    id: 'p1t10',
    objectives: [
      'Explain what a network is and how devices split into end devices and network devices',
      'Explain why the work is split into layers',
      'Name the 7 layers, put them in order and say what each one does',
      'Link a protocol, a device and a PDU name to each layer',
      'Hunt for a problem with layers, from the bottom up',
    ],
    explain: PT.frag['p1/t10/explain.en'], cheat: PT.frag['p1/t10/cheat.en'],

    lab: {
      title: 'Lab 1: Think in layers',
      goal: 'Know the 7 layers, link protocols and devices to a layer, and work through a real complaint layer by layer.',
      why: 'In helpdesk and SOC work, every problem starts with "which layer is broken?". The layer number is the shared language of the team.',
      minutes: 35,
      finish: 'You can think in layers now. On to the quiz.',
      steps: [
        { id: 's1', title: 'Get ready', type: 'info', button: 'Let\'s start',
          body: '<p>You do not build anything in this lab. You practice thinking in layers: recognizing them, grouping things, then working through a real complaint one layer at a time. At the end there is an optional check in Packet Tracer.</p>' },
        { id: 's2', title: 'Match each layer with its job', type: 'match',
          body: '<p>Pick the job of every layer.</p>',
          pairs: [
            { l: '<b>Layer 7</b> Application', r: 'Says what the program wants from the network', why: 'Protocols like HTTP and DNS live here.' },
            { l: '<b>Layer 6</b> Presentation', r: 'Format and encryption of the data', why: 'For example the encryption in HTTPS.' },
            { l: '<b>Layer 5</b> Session', r: 'Opening, keeping and closing a conversation', why: 'A session between two programs.' },
            { l: '<b>Layer 4</b> Transport', r: 'Delivers the data to the right program (port)', why: 'TCP and UDP. The port number picks the program.' },
            { l: '<b>Layer 3</b> Network', r: 'Finds the way to another network with the IP address', why: 'The router works at this layer.' },
            { l: '<b>Layer 2</b> Data Link', r: 'Delivers to the next device on the same link with the MAC address', why: 'The switch works at this layer.' },
            { l: '<b>Layer 1</b> Physical', r: 'Sends bits over the cable as signals', why: 'Cable, connector, radio.' },
          ],
          hints: ['Start from the bottom: the lowest layer is the cable itself.', 'For Layer 4 look for the word "port", for Layer 3 "IP", for Layer 2 "MAC".'] },
        { id: 's3', title: 'Put each thing on its layer', type: 'match',
          body: '<p>Which layer does each of these belong to?</p>',
          pairs: [
            { l: 'HTTP', r: 'Layer 7', why: 'An application protocol.' },
            { l: 'TCP', r: 'Layer 4', why: 'Ports and reliable delivery.' },
            { l: 'IP address', r: 'Layer 3', why: 'The address of the Network layer.' },
            { l: 'ICMP (ping)', r: 'Layer 3', why: 'A Network layer protocol that works with IP.' },
            { l: 'MAC address', r: 'Layer 2', why: 'The address of a device on the link.' },
            { l: 'Switch', r: 'Layer 2', why: 'It looks at the MAC address of the frame.' },
            { l: 'Router', r: 'Layer 3', why: 'It looks at the IP address of the packet.' },
            { l: 'Fiber cable', r: 'Layer 1', why: 'The physical medium.' },
          ],
          hints: ['Do the easy ones first: the cable and HTTP.', 'Which address does a switch look at? And a router?'] },
        { id: 's4', title: 'The way of the data on the sending device', type: 'order',
          body: '<p>A browser sends a web request. On the sending PC, the data passes through the layers <b>from top to bottom</b>. Put the steps in the right order.</p>',
          items: [
            { t: 'Layer 7: the browser creates the request (HTTP)', why: 'The data is born in the program, so it comes first.' },
            { t: 'Layer 4: the data is cut up and the destination port number is added', why: 'The Transport layer adds the port that picks the program.' },
            { t: 'Layer 3: the destination IP address is added', why: 'The Network layer adds the address that points to the device and the network.' },
            { t: 'Layer 2: the MAC address of the next device on the link is added', why: 'The Data Link layer only knows the next step.' },
            { t: 'Layer 1: the bits go onto the cable as signals', why: 'In the end everything becomes bits and goes onto the cable.' },
          ],
          hints: ['At which layer is the data born?', 'The last step is going out onto the cable.'] },
        { id: 's5', title: 'Which device reads what?', type: 'choice',
          body: '<p>A web request goes from PC1 to a server in another network. On the way there is a <b>switch</b> and then a <b>router</b>. Which statement is right?</p>',
          options: [
            { t: 'The switch looks at the MAC address of the frame, and the router looks at the IP address of the packet. Neither one looks at the port number or the HTTP content.', ok: true, why: 'A switch reads up to Layer 2 and a router up to Layer 3. The port is Layer 4 and HTTP is Layer 7. These devices do not need them for their job.' },
            { t: 'The switch looks at the IP address, because every packet has one.', why: 'The IP address is Layer 3. A switch works at Layer 2 and only looks at the MAC address.' },
            { t: 'The router reads the HTTP content and only blocks sites that way.', why: 'A normal router reads up to Layer 3. A device that reads HTTP content is a firewall or a proxy, which works on the upper layers.' },
            { t: 'Both devices read all 7 layers, because the packet arrives whole.', why: 'The packet does arrive whole, but a device only reads the header of its own layer. The rest is just data for it.' },
          ],
          hints: ['Which address does a switch work with: MAC or IP?'] },
        { id: 's6', title: 'Find the wrong line', type: 'spot',
          body: '<p>A colleague wrote a "symptom, layer" table in the problem log. <b>One line has the wrong layer.</b> Find it, then type the right layer number.</p>',
          lines: [
            { t: '1.  No light on the switch port, cable is out   ->  Layer 1' },
            { t: '2.  The IP address on the PC is typed wrong      ->  Layer 3' },
            { t: '3.  A switch decides by the MAC address of the frame  ->  Layer 3', bad: true, why: 'A MAC address is a Layer 2 address. A switch is a Layer 2 device.' },
            { t: '4.  The firewall blocks port 443                 ->  Layer 4' },
            { t: '5.  The web page shows a 404 error               ->  Layer 7' },
          ],
          fix: { label: 'Right layer number', placeholder: 'e.g. 5', answers: ['2', 'layer 2', 'l2'], wrong: 'Which layer is the MAC address on? Which layer is a switch?' },
          hints: ['In every line, look at the kind of address or service: cable, IP, MAC, port, HTTP.'],
          after: '<p>A table like this is very useful at work: when you link a symptom to a layer, the area you have to search gets smaller.</p>' },
        { id: 's7', title: 'Ticket: "I cannot reach the web server"', type: 'ticket',
          body: '<p><b>The user says:</b> "I cannot open the company\'s internal web server. Everybody else can." You work through the problem from the bottom up. <i>Note: ping is a command that sends a small test message to the other side and waits for the answer. The default gateway is the router address a PC uses to leave its own network.</i></p>',
          stages: [
            { q: '<p>Where do you start, and why?</p>', options: [
              { t: 'At Layer 1: the cable and the port light. If a lower layer is not working, there is no point in checking the ones above it.', ok: true, why: 'Rule: check from the bottom up. Why: every layer stands on the one below it. Here: with no cable, the IP address and the browser will never work.' },
              { t: 'At Layer 7: I remove and reinstall the browser.', why: 'Everybody else opens the same site, so the program itself is most likely not the problem. Starting at the top also wastes time.' },
              { t: 'I restart the server.', why: 'Others can reach it, so the server works. Check this user\'s side first.' },
              { t: 'I replace the user\'s network card.', why: 'Replacing hardware without any check is expensive, and you still do not know the cause.' },
            ] },
            { q: '<p>You checked: the light on the switch port is on. The PC pings a printer on the same switch and <b>gets an answer</b>. The server is in another network, and pings to it <b>get no answer</b>. Which layer do you suspect?</p>', options: [
              { t: 'Layer 3: getting out to another network (IP address, mask, default gateway).', ok: true, why: 'Layers 1 and 2 work (there is a light, and the neighbor answers). The problem starts when the device leaves its own network, and that is a Layer 3 job.' },
              { t: 'Layer 1: the cable is broken.', why: 'If the cable were broken, the printer next door would not answer either. The light is on and the ping reaches the neighbor.' },
              { t: 'Layer 7: the web site program is broken.', why: 'You do not even reach the program yet: the ping does not reach the server. Others can open the site, so the program works.' },
              { t: 'Layer 4: the server blocks a port number.', why: 'With a port problem the ping would still be answered (ping does not use a port). Here the ping fails too, so the problem is lower down.' },
            ] },
            { q: '<p>Next step: what do you check on the PC?</p>', options: [
              { t: 'The IP address, the mask and the default gateway: is it in the right network, and is the router address filled in?', ok: true, why: 'Reaching another network depends on these three values. The PC reaches its neighbor, so the IP works, and an empty or wrong gateway gives exactly this symptom.' },
              { t: 'I clear the browser cache.', why: 'The browser is Layer 7, and ping does not need a browser. The problem is lower down.' },
              { t: 'I replace the cable.', why: 'The cable works: the light is on and the neighbor answers.' },
              { t: 'I open firewall rules on the server.', why: 'Others can reach it, and the ping fails before it gets to the server. Look at this PC\'s settings first.' },
            ] },
          ],
          after: '<p>The line of thought: <b>light</b> → <b>neighbor</b> → <b>another network</b> → <b>port</b> → <b>program</b>. Every step confirms or rules out one layer.</p>' },
        { id: 's8', title: 'Ticket: "Ping works, the site does not"', type: 'ticket',
          body: '<p><b>The user says:</b> "I ping the server and I get answers, but the site will not open in the browser."</p>',
          stages: [
            { q: '<p>What does a ping answer tell you?</p>', options: [
              { t: 'Layers 1, 2 and 3 work between the PC and the server: the cable, the link and the IP delivery.', ok: true, why: 'Ping works on the IP level, and to get an answer all the layers below have to work.' },
              { t: 'Everything works, so it is the user\'s mistake.', why: 'Ping only checks up to Layer 3. A site also needs Layer 4 and 7.' },
              { t: 'The web server is running.', why: 'Ping shows that the server answers as a computer, not that the web service is running.' },
              { t: 'Layers 1 and 2 are checked, but Layer 3 is not.', why: 'Ping works with IP, so it does check Layer 3.' },
            ] },
            { q: '<p>What should the next step be?</p>', options: [
              { t: 'Check that the web port (80 or 443) is open and that the service is running: Layers 4 and 7.', ok: true, why: 'The lower layers are confirmed, so what is left to suspect is above them. A port can be blocked (Layer 4), or the web service can be down (Layer 7).' },
              { t: 'Replace the cable.', why: 'The ping gets an answer, so the cable and the link work.' },
              { t: 'Change the IP address of the PC.', why: 'The IP works: the ping talks to the server over IP.' },
              { t: 'Restart the switch.', why: 'The ping works, so the switch is not causing the problem.' },
            ] },
          ],
          after: '<p>Ping proves that the network part works. If the site does not open, point your search upward, to the port and the service.</p>' },
        { id: 's9', title: 'Check it in Packet Tracer (optional)', type: 'ptsteps',
          body: '<p>This step is a check. Build two PCs and a switch in Packet Tracer.</p>',
          checks: [
            { t: 'Connect the two PCs to the switch with cables. Give the PCs addresses from the same network: PC1 <span class="m">192.168.1.10</span>, PC2 <span class="m">192.168.1.20</span>, mask <span class="m">255.255.255.0</span> (Desktop, IP Configuration).' },
            { t: 'Switch to <b>Simulation Mode</b> in the bottom right corner.' },
            { t: 'Use Add Simple PDU to send a message from PC1 to PC2, then step forward with <b>Capture / Forward</b>.' },
            { t: 'When the packet reaches the switch, click the envelope on it and look at the <b>OSI Model</b> tab. Which layers are lit?' },
          ] },
        { id: 's10', title: 'Write down what you saw', type: 'form',
          body: '<p>Which layers were lit in the OSI Model tab for the switch? Type the layer numbers (for example "1 and 3").</p>',
          fields: [{ label: 'Layers at the switch', placeholder: 'e.g. 1 and 3', check: raw => (raw.match(/\d/g) || []).slice().sort().join('') === '12', wrong: 'Which address does a switch look at? Which layer is that address on? Start from the bottom.' }],
          hints: ['A switch works with the MAC address. Which layer is that?', 'If Layer 2 works, the layer under it (the signal) has to work too.'],
          solution: 'Layers 1 and 2. This shows that a switch is a Layer 2 device. The screen may look a little different in your version.',
          after: '<p>For a router, layers 1 to 3 light up, and for a PC all of them. A device reads only up to its own layer.</p>' },
      ],
    },

    quiz: {
      draw: 8,
      gens: [
        () => {
          const it = pick(ITEMS); const layers = [1, 2, 3, 4, 7];
          const wrong = shuffle(layers.filter(x => x !== it[1])).slice(0, 3);
          const opts = shuffle([it[1]].concat(wrong));
          return { id: 'p1t10-g-layer', concept: 'l' + it[1], obj: 'Link a protocol or idea to its layer', _meta: { item: it[0], layer: it[1] },
            stem: '<p>Which layer does this belong to: <b>' + it[0] + '</b>?</p>',
            options: opts.map(n => ({ t: 'Layer ' + n + ' (' + LAYER_NAME[n] + ')', ok: n === it[1], why: n === it[1] ? it[2] : 'Layer ' + n + ' (' + LAYER_NAME[n] + ') does a different job. ' + it[0] + ' is on Layer ' + it[1] + '.' })) };
        },
        () => {
          const p = pick(PDU); const dir = R(2);
          if (dir === 0) {
            const names = shuffle(['segment', 'packet', 'frame', 'bits']);
            return { id: 'p1t10-g-pdu', concept: 'osi-overview', obj: 'PDU name', _meta: { layer: p[0], pdu: p[1] },
              stem: '<p>What is the data unit called at Layer <b>' + p[0] + '</b>?</p>',
              options: names.map(n => ({ t: n, ok: n === p[1], why: n === p[1] ? 'Layer 4: segment, Layer 3: packet, Layer 2: frame, Layer 1: bits. For Layer ' + p[0] + ' it is ' + p[1] + '.' : 'That name belongs to another layer. At Layer ' + p[0] + ' the unit is the ' + p[1] + '.' })) };
          }
          const ls = shuffle([1, 2, 3, 4]);
          return { id: 'p1t10-g-pdu', concept: 'osi-overview', obj: 'PDU name', _meta: { layer: p[0], pdu: p[1] },
            stem: '<p>Which layer\'s data unit is the <b>' + p[1] + '</b>?</p>',
            options: ls.map(n => ({ t: 'Layer ' + n + ' (' + LAYER_NAME[n] + ')', ok: n === p[0], why: n === p[0] ? 'The segment is Layer 4, the packet Layer 3, the frame Layer 2 and the bits Layer 1.' : 'The unit of that layer has another name. The ' + p[1] + ' is Layer ' + p[0] + '.' })) };
        },
      ],
      pool: [
        { id: 'p1t10-q1', concept: 'why-layers', obj: 'What layers are good for',
          stem: '<p>A company moves all its PCs from Ethernet cables to Wi-Fi. The browser and the mail program keep working without any change. What explains this?</p>',
          options: [
            { t: 'The layers are independent: a new cable type only changes the bottom layers.', ok: true, why: 'Rule: each layer does only its own job. Why: nothing depends on anything else, so changing one layer does not touch the others. Here: moving from Ethernet to Wi-Fi only changes Layer 1 and 2.' },
            { t: 'Wi-Fi uses the same protocols as Ethernet for all programs, so nothing changes.', why: 'Wi-Fi and Ethernet work differently on the lower layers. The programs do not change because they cannot see that difference, not because the protocols are the same.' },
            { t: 'Browsers recognize every type of network and set themselves up again each time you switch.', why: 'A browser knows nothing about the type of network. The separation of the layers does this.' },
            { t: 'Wi-Fi only works at Layer 7 (the program level), so the lower layers stay untouched.', why: 'Wi-Fi is about radio signals and the link (Layer 1-2), not the program protocols of Layer 7.' },
          ] },
        { id: 'p1t10-q2', concept: 'troubleshoot', obj: 'Search for a problem from the bottom up',
          stem: '<p>A user\'s browser says "page not found". What is the right way to investigate?</p>',
          options: [
            { t: 'Cable and port light first, then the IP and a ping, and only then the program.', ok: true, why: 'Rule: bottom up. Why: an upper layer stands on the one below it, so checking the top while the bottom is broken is pointless. Here: the browser message is only the result, and the cause can be lower down.' },
            { t: 'Reinstall the browser, because the message comes from the browser.', why: 'The message comes from the browser, but the cause can be the cable or the address. The browser is only saying it got no answer.' },
            { t: 'Look at the server logs first, because the page itself is on the server.', why: 'If the request never reached the server, the log will show nothing. First show that the way to the server works.' },
            { t: 'Restart the network devices, because that helps most of the time and is quick.', why: 'Restarting devices without knowing the cause can cut off other users too, and it does not find the root.' },
          ] },
        { id: 'p1t10-q3', concept: 'troubleshoot', obj: 'Read a ping result by layer',
          stem: '<p>A ping to the server gets answers, but the site does not open with <b>https://</b>. What is the most logical suspicion?</p>',
          options: [
            { t: 'Layer 4 or 7: port 443 is blocked or the service is down.', ok: true, why: 'Ping checks up to Layer 3, so the lower part works. The web port (Layer 4) and the service (Layer 7) are what is left.' },
            { t: 'Layer 1: the cable or the connector on the PC is broken.', why: 'With a broken cable the ping would not get an answer either.' },
            { t: 'Layer 2: the switch does not know the MAC address of the server.', why: 'If the switch did not know the MAC address, the frame would not arrive and the ping would not work.' },
            { t: 'Layer 3: the IP address of the PC is typed wrong.', why: 'Ping works over IP and gets answers, so the IP is right.' },
          ] },
        { id: 'p1t10-q4', concept: 'osi-overview', obj: 'The layer a device reads',
          stem: '<p>Which device forwards a packet <b>only by its IP address</b> and does not look at the port number?</p>',
          options: [
            { t: 'The router.', ok: true, why: 'A router works at Layer 3: it looks at the IP address and picks the way. The port is Layer 4, and it does not need it.' },
            { t: 'The switch.', why: 'A switch is at Layer 2 and decides by the MAC address. It does not look at the IP.' },
            { t: 'The network card (NIC).', why: 'The NIC is the device\'s own card, not a forwarding device. It checks whether the address of the frame is its own.' },
            { t: 'The web server.', why: 'The packet ends at the server, and it opens it up to the top layers. It does not forward it.' },
          ] },
        { id: 'p1t10-q5', concept: 'osi-overview', obj: 'Switch and layer',
          stem: '<p>Which address does a switch decide by, and which layer is that?</p>',
          options: [
            { t: 'The MAC address, Layer 2.', ok: true, why: 'A switch delivers on one link, and the address of a link is the MAC. That is the Data Link layer.' },
            { t: 'The IP address, Layer 3.', why: 'A router looks at the IP address. A normal switch does not look at the IP.' },
            { t: 'The port number, Layer 4.', why: 'Devices on upper layers, like a firewall, look at port numbers. A switch does not go that deep into the frame.' },
            { t: 'The domain name, Layer 7.', why: 'DNS turns the domain name into an IP address. A switch does not see domain names.' },
          ] },
        { id: 'p1t10-q6', concept: 'l4', obj: 'The port number',
          stem: '<p>A PC runs a browser, a mail program and a music program at the same time, and all of them use the same cable. Which layer decides which program the incoming data belongs to?</p>',
          options: [
            { t: 'Transport (Layer 4): with the port number.', ok: true, why: 'Rule: Layer 4 picks the right program with the port number. Why: one device runs many programs, and each one needs a number. Here: 443 for web, another port for mail.' },
            { t: 'Network (Layer 3): with the IP address.', why: 'The IP address finds the device, not the program inside it. All the programs share the same IP address.' },
            { t: 'Data Link (Layer 2): with the MAC address.', why: 'The MAC points to the card, not the program. All the programs belong to the same card.' },
            { t: 'Physical (Layer 1): with the type of signal.', why: 'The type of signal does not point to a program. It only carries the bits.' },
          ] },
        { id: 'p1t10-q7', concept: 'osi-overview', obj: 'The order of the 7 layers', type: 'order',
          stem: '<p>Put the OSI layers in order <b>from the bottom up</b> (Layer 1 to Layer 7).</p>',
          items: [
            { t: 'Physical', why: 'Layer 1: bits and signals.' },
            { t: 'Data Link', why: 'Layer 2: MAC, delivery on one link.' },
            { t: 'Network', why: 'Layer 3: IP, between networks.' },
            { t: 'Transport', why: 'Layer 4: ports, TCP and UDP.' },
            { t: 'Session', why: 'Layer 5: sessions.' },
            { t: 'Presentation', why: 'Layer 6: format, encryption.' },
            { t: 'Application', why: 'Layer 7: program protocols.' },
          ] },
        { id: 'p1t10-q8', concept: 'l3', obj: 'The job of Layer 3',
          stem: '<p>Which job belongs to <b>Layer 3</b>?</p>',
          options: [
            { t: 'Delivering a packet to another network by its IP address.', ok: true, why: 'The Network layer finds devices across networks with the IP address, and the router does this job.' },
            { t: 'Delivering a frame to a device on the same switch with the MAC.', why: 'That is the job of Layer 2: delivery inside a link.' },
            { t: 'Giving the data to the right program with the port number.', why: 'That is the job of Layer 4.' },
            { t: 'Sending the bits over the cable as electric or light signals.', why: 'That is the job of Layer 1.' },
          ] },
        { id: 'p1t10-q9', concept: 'osi-overview', obj: 'The layer of a firewall rule',
          stem: '<p>A firewall rule says: "block TCP port 22". Which layer\'s information does this rule look at?</p>',
          options: [
            { t: 'Layer 4: TCP and the port number.', ok: true, why: 'The rule has "TCP" and "port 22", and both are ideas of the Transport layer.' },
            { t: 'Layer 2: the MAC address.', why: 'There is no MAC address in the rule. The port number is higher up.' },
            { t: 'Layer 7: the content of the SSH program.', why: 'The rule only looks at the port number and does not open the content. Port 22 is usually used for SSH, but the rule does not read the content.' },
            { t: 'Layer 1: the type of cable.', why: 'A firewall rule does not see the physical medium.' },
          ] },
        { id: 'p1t10-q10', concept: 'l1', obj: 'A Layer 1 symptom',
          stem: '<p>The light on the switch port is off and the PC says "network cable unplugged". Which layer is it?</p>',
          options: [
            { t: 'Layer 1: the cable, the connector or the port.', ok: true, why: 'The cable and the signal are the Physical layer. No light means no link has come up.' },
            { t: 'Layer 3: the IP address on the PC is wrong.', why: 'Even with a wrong IP address the link light would be on. No light means the problem is lower down.' },
            { t: 'Layer 4: a port number is blocked on a firewall.', why: 'With a port problem the link light would still be on.' },
            { t: 'Layer 7: the program that you use has an error.', why: 'A program error does not change the light of the cable.' },
          ] },
      ],
    },
  });
})();
