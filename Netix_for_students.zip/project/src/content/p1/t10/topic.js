(function () {
  const R = n => PT.randInt(n), pick = PT.pick, shuffle = PT.shuffle;
  const m = s => '<span class="m">' + PT.esc(s) + '</span>';
  const LAYER_NAME = { 7: 'Application', 6: 'Presentation', 5: 'Session', 4: 'Transport', 3: 'Network', 2: 'Data Link', 1: 'Physical' };

  /* items for the "which layer" generator: [text, layer, why] */
  const ITEMS = [
    ['HTTP', 7, 'HTTP proqramın veb server ilə danışma qaydasıdır, yəni proqram səviyyəsidir.'],
    ['DNS sorğusu', 7, 'DNS proqramın istədiyi xidmətdir (adı IP ünvanına çevirmək), ona görə Layer 7-dir.'],
    ['DHCP', 7, 'DHCP cihazın ünvan istəməsi üçün proqram protocol-udur, Layer 7-dir.'],
    ['TCP', 4, 'TCP port nömrələri və etibarlı çatdırma ilə işləyir, bu Transport layer-dir.'],
    ['UDP', 4, 'UDP də port nömrələri ilə işləyir (etibarlı çatdırma olmadan), bu Layer 4-dür.'],
    ['443 port nömrəsi', 4, 'Port nömrəsi hədəfdəki proqramı seçir, bu Transport layer-in işidir.'],
    ['IP ünvanı', 3, 'IP ünvanı cihazı şəbəkələr arasında tapır, bu Network layer-dir.'],
    ['ICMP (ping)', 3, 'ICMP IP ilə birlikdə işləyir və Network layer-in xidməti protocol-udur.'],
    ['MAC ünvanı', 2, 'MAC ünvanı eyni link-də növbəti cihazı seçir, bu Data Link layer-dir.'],
    ['Ethernet frame', 2, 'Frame Layer 2-nin vahididir.'],
    ['Mis kabeldən keçən elektrik siqnalı', 1, 'Siqnalın kabeldə ötürülməsi Physical layer-in işidir.'],
    ['Optik kabeldən keçən işıq siqnalı', 1, 'İşıq siqnalı bitlərin fiziki daşıyıcısıdır, bu Layer 1-dir.'],
  ];
  const PDU = [[4, 'segment'], [3, 'packet'], [2, 'frame'], [1, 'bits']];

  PT.topic({
    id: 'p1t10',
    objectives: [
      'Şəbəkənin nə olduğunu və cihazların end device və network device-ə necə bölündüyünü izah etmək',
      'İşin niyə layer-lərə bölündüyünü izah etmək',
      '7 layer-in adını, sırasını və hər birinin işini demək',
      'Hər layer-ə protocol, cihaz və PDU adı bağlamaq',
      'Problemi layer-lərlə aşağıdan yuxarı axtarmaq',
    ],
    explain: PT.frag['p1/t10/explain'], cheat: PT.frag['p1/t10/cheat'],

    lab: {
      title: 'Lab 1: Layer-lərlə düşün',
      goal: '7 layer-i tanımaq, protocol və cihazları layer-ə bağlamaq və real şikayəti layer-lərlə araşdırmaq.',
      why: 'Helpdesk və SOC-da hər problem "hansı layer-də qırılıb?" sualı ilə başlayır. Layer nömrəsi komandanın ortaq dilidir.',
      minutes: 35,
      finish: 'Layer-lərlə düşünə bilirsən. İndi quizə keç.',
      steps: [
        { id: 's1', title: 'Hazırlıq', type: 'info', button: 'Başladım',
          body: '<p>Bu labda heç nə qurmursan. Layer-lərlə düşünməyi məşq edirsən: tanımaq, qruplamaq, sonra real şikayəti layer-layer araşdırmaq. Sonda Packet Tracer-də yoxlama addımı var.</p>' },
        { id: 's2', title: 'Hər layer-i işi ilə birləşdir', type: 'match',
          body: '<p>Hər layer-in işini seç.</p>',
          pairs: [
            { l: '<b>Layer 7</b> Application', r: 'Proqramın şəbəkədən nə istədiyini deyir', why: 'HTTP, DNS kimi protocol-lar buradadır.' },
            { l: '<b>Layer 6</b> Presentation', r: 'Məlumatın formatı və şifrələnməsi', why: 'Məsələn HTTPS-də şifrələmə.' },
            { l: '<b>Layer 5</b> Session', r: 'Əlaqənin açılması, davam etməsi və bağlanması', why: 'İki proqram arasında sessiya.' },
            { l: '<b>Layer 4</b> Transport', r: 'Məlumatı düzgün proqrama çatdırır (port)', why: 'TCP və UDP. Proqramı port nömrəsi seçir.' },
            { l: '<b>Layer 3</b> Network', r: 'IP ünvanı ilə başqa şəbəkəyə yol tapır', why: 'Router bu layer-də işləyir.' },
            { l: '<b>Layer 2</b> Data Link', r: 'MAC ünvanı ilə eyni link-də növbəti cihaza çatdırır', why: 'Switch bu layer-də işləyir.' },
            { l: '<b>Layer 1</b> Physical', r: 'Bitləri kabeldə siqnal kimi ötürür', why: 'Kabel, konnektor, radio.' },
          ],
          hints: ['Aşağıdan başla: ən aşağı layer kabelin özüdür.', 'Layer 4 üçün "port" sözünü axtar, Layer 3 üçün "IP", Layer 2 üçün "MAC".'] },
        { id: 's3', title: 'Hər şeyi öz layer-inə yerləşdir', type: 'match',
          body: '<p>Aşağıdakı hər şey hansı layer-ə aiddir?</p>',
          pairs: [
            { l: 'HTTP', r: 'Layer 7', why: 'Proqram protocol-u.' },
            { l: 'TCP', r: 'Layer 4', why: 'Port və etibarlı çatdırma.' },
            { l: 'IP ünvanı', r: 'Layer 3', why: 'Network layer-in ünvanı.' },
            { l: 'ICMP (ping)', r: 'Layer 3', why: 'IP ilə birlikdə işləyən Network layer protocol-u.' },
            { l: 'MAC ünvanı', r: 'Layer 2', why: 'Link-dəki cihazın ünvanı.' },
            { l: 'Switch', r: 'Layer 2', why: 'Frame-in MAC ünvanına baxır.' },
            { l: 'Router', r: 'Layer 3', why: 'Paketin IP ünvanına baxır.' },
            { l: 'Optik kabel', r: 'Layer 1', why: 'Fiziki mühit.' },
          ],
          hints: ['Əvvəl asan olanları yerləşdir: kabel və HTTP.', 'Switch hansı ünvana baxır? Router hansına?'] },
        { id: 's4', title: 'Göndərən cihazda məlumatın yolu', type: 'order',
          body: '<p>Brauzer bir veb sorğusu göndərir. Göndərən PC-də məlumat layer-lərdən <b>yuxarıdan aşağı</b> keçir. Addımları düzgün sırala.</p>',
          items: [
            { t: 'Layer 7: brauzer sorğunu yaradır (HTTP)', why: 'Məlumat proqramda doğulur, ona görə birincidir.' },
            { t: 'Layer 4: məlumat parçalanır və hədəf port nömrəsi əlavə olunur', why: 'Transport layer proqramı seçən portu qoyur.' },
            { t: 'Layer 3: hədəf IP ünvanı əlavə olunur', why: 'Network layer cihazı və şəbəkəni göstərən ünvanı qoyur.' },
            { t: 'Layer 2: link-dəki növbəti cihazın MAC ünvanı əlavə olunur', why: 'Data Link layer yalnız növbəti addımı bilir.' },
            { t: 'Layer 1: bitlər siqnal kimi kabelə çıxır', why: 'Hər şey sonda bitə çevrilib kabelə verilir.' },
          ],
          hints: ['Məlumat hansı layer-də yaranır?', 'Ən son addım kabelə çıxmaqdır.'] },
        { id: 's5', title: 'Hansı cihaz nəyi oxuyur?', type: 'choice',
          body: '<p>PC1-dən başqa şəbəkədəki server-ə veb sorğusu gedir. Yolda <b>switch</b> və sonra <b>router</b> var. Hansı fikir düzgündür?</p>',
          options: [
            { t: 'Switch frame-in MAC ünvanına, router isə paketin IP ünvanına baxır. İkisi də port nömrəsinə və HTTP məzmununa baxmır.', ok: true, why: 'Switch Layer 2-yə qədər, router Layer 3-ə qədər oxuyur. Port Layer 4-dədir, HTTP Layer 7-dədir, bu cihazların işinə lazım deyil.' },
            { t: 'Switch IP ünvanına baxır, çünki hər paketdə IP var.', why: 'IP ünvanı Layer 3-dədir. Switch Layer 2-də işləyir və yalnız MAC ünvanına baxır.' },
            { t: 'Router HTTP məzmununu oxuyur və yalnız saytı bloklamaq üçün onu keçirmir.', why: 'Adi router Layer 3-ə qədər oxuyur. HTTP məzmununa baxan cihaz firewall və ya proxy kimi yuxarı layer-lərdə işləyən cihazdır.' },
            { t: 'Hər iki cihaz bütün 7 layer-i oxuyur, çünki paket bütöv gəlir.', why: 'Paket bütöv gəlir, amma cihaz yalnız öz layer-inin başlığını oxuyur. Qalan hissə onun üçün sadəcə məlumatdır.' },
          ],
          hints: ['Switch hansı ünvanla işləyir: MAC yoxsa IP?'] },
        { id: 's6', title: 'Səhv sətri tap', type: 'spot',
          body: '<p>Bir kolleqa problem jurnalına "simptom, layer" cədvəli yazıb. <b>Bir sətirdə layer səhvdir.</b> Onu tap, sonra düzgün layer nömrəsini yaz.</p>',
          lines: [
            { t: '1.  Switch portunda işıq yanmır, kabel çıxıb    ->  Layer 1' },
            { t: '2.  PC-nin IP ünvanı səhv yazılıb              ->  Layer 3' },
            { t: '3.  Switch frame-in MAC ünvanına baxıb qərar verir  ->  Layer 3', bad: true, why: 'MAC ünvanı Layer 2-nin ünvanıdır. Switch Layer 2 cihazıdır.' },
            { t: '4.  Firewall 443 portunu bloklayır             ->  Layer 4' },
            { t: '5.  Veb səhifə 404 xətası verir                 ->  Layer 7' },
          ],
          fix: { label: 'Düzgün layer nömrəsi', placeholder: 'məs. 5', answers: ['2', 'layer 2', 'l2'], wrong: 'MAC ünvanı hansı layer-dədir? Switch hansı layer-in cihazıdır?' },
          hints: ['Hər sətirdə ünvan və ya xidmət növünə bax: kabel, IP, MAC, port, HTTP.'],
          after: '<p>Bu cür cədvəl işdə çox faydalıdır: simptomu layer ilə bağlayanda araşdırma sahəsi kiçilir.</p>' },
        { id: 's7', title: 'Ticket: "Veb serverə çata bilmirəm"', type: 'ticket',
          body: '<p><b>İstifadəçi deyir:</b> "Şirkətin daxili veb serverinə girə bilmirəm. Digər işçilər girir." Sən problemi aşağıdan yuxarı araşdırırsan. <i>Qeyd: ping, qarşı tərəfə kiçik test mesajı göndərib cavab gözləyən əmrdir. Default gateway, PC-nin başqa şəbəkəyə çıxmaq üçün istifadə etdiyi router ünvanıdır.</i></p>',
          stages: [
            { q: '<p>Hardan başlayırsan və niyə?</p>', options: [
              { t: 'Layer 1-dən: kabel və port işığı. Aşağıdakı layer işləməsə, yuxarıdakıların yoxlanmasının mənası yoxdur.', ok: true, why: 'Aşağıdan yuxarı yoxla. Hər layer aşağıdakına söykənir. Kabel yoxdursa, IP və brauzer heç vaxt işləməyəcək.' },
              { t: 'Layer 7-dən: brauzeri silib yenidən quraşdırıram.', why: 'Digər işçilər eyni saytı açır, deməli proqramın özü çox güman ki problem deyil. Üstəlik yuxarıdan başlamaq vaxt itkisidir.' },
              { t: 'Server-in özünü yenidən başladıram.', why: 'Digərləri girə bildiyi üçün server işləyir. Əvvəl bu istifadəçinin tərəfini yoxla.' },
              { t: 'İstifadəçinin şəbəkə kartını dəyişirəm.', why: 'Heç bir yoxlama aparmadan avadanlığı dəyişmək həm bahalıdır, həm də səbəbi bilmirsən.' },
            ] },
            { q: '<p>Yoxladın: switch portunda işıq yanır. PC eyni switch-dəki printer-ə ping atır və <b>cavab gəlir</b>. Server başqa şəbəkədədir və ona ping <b>cavabsız qalır</b>. Hansı layer-dən şübhələnirsən?</p>', options: [
              { t: 'Layer 3: başqa şəbəkəyə çıxış (IP ünvanı, mask, default gateway).', ok: true, why: 'Layer 1 və 2 işləyir (işıq var, qonşuya çatır). Problem cihaz öz şəbəkəsindən çıxanda başlayır, bu da Layer 3-ün işidir.' },
              { t: 'Layer 1: kabel xarabdır.', why: 'Kabel xarab olsaydı, qonşu printer-ə də çatmazdı. İşıq yanır və ping qonşuya çatır.' },
              { t: 'Layer 7: veb sayt proqramı xarabdır.', why: 'Hələ proqrama çatmırsan: ping serverə də çatmır. Digər işçilər girir, yəni proqram işləyir.' },
              { t: 'Layer 4: server port nömrəsini bloklayır.', why: 'Port problemi olsaydı, ping cavab verərdi (ping portdan istifadə etmir). Burada ping də cavabsızdır, yəni daha aşağıdadır.' },
            ] },
            { q: '<p>Növbəti addım: PC-də nəyi yoxlayırsan?</p>', options: [
              { t: 'IP ünvanını, mask-ı və default gateway-i: düzgün şəbəkədədirmi və router ünvanı yazılıbmı.', ok: true, why: 'Başqa şəbəkəyə çıxış bu üç dəyərdən asılıdır. Qonşuya çatması IP-nin işlədiyini göstərir, gateway-in boş və ya səhv olması isə bu simptomu verir.' },
              { t: 'Brauzerin keş-ini təmizləyirəm.', why: 'Brauzer Layer 7-dir, ping isə brauzersiz də işləmir. Problem daha aşağıdadır.' },
              { t: 'Kabeli dəyişirəm.', why: 'Kabel işləyir: işıq yanır və qonşuya çatır.' },
              { t: 'Server-də firewall qaydalarını açıram.', why: 'Digərləri girir və ping də serverə çatmır. Əvvəl bu PC-nin ayarlarına bax.' },
            ] },
          ],
          after: '<p>Düşüncə yolu: <b>işıq</b> → <b>qonşu</b> → <b>başqa şəbəkə</b> → <b>port</b> → <b>proqram</b>. Hər addım bir layer-i təsdiqləyir və ya istisna edir.</p>' },
        { id: 's8', title: 'Ticket: "Ping var, sayt yoxdur"', type: 'ticket',
          body: '<p><b>İstifadəçi deyir:</b> "Server-ə ping atıram, cavab gəlir, amma brauzerdə sayt açılmır."</p>',
          stages: [
            { q: '<p>Ping-in cavab verməsi nəyi göstərir?</p>', options: [
              { t: 'PC ilə server arasında Layer 1, 2 və 3 işləyir: kabel, link və IP çatdırılması.', ok: true, why: 'Ping IP səviyyəsində işləyir və cavab almaq üçün aşağıdakı layer-lərin hamısı işləməlidir.' },
              { t: 'Hər şey işləyir, problem istifadəçinin səhvidir.', why: 'Ping yalnız Layer 3-ə qədər yoxlayır. Sayt Layer 4 və 7-ni də tələb edir.' },
              { t: 'Veb server işləyir.', why: 'Ping serverin kompüter kimi cavab verdiyini göstərir, veb xidmətin işlədiyini yox.' },
              { t: 'Layer 1 və 2 yoxlanıb, Layer 3 yoxlanmayıb.', why: 'Ping məhz IP ilə işləyir və Layer 3-ü yoxlayır.' },
            ] },
            { q: '<p>Növbəti addım hansı olmalıdır?</p>', options: [
              { t: 'Veb xidmətin portunun (80 və ya 443) açıq olduğunu və xidmətin işlədiyini yoxlamaq: Layer 4 və 7.', ok: true, why: 'Aşağı layer-lər təsdiqlənib, qalan şübhəli yer yuxarıdır. Port bloklana bilər (Layer 4) və ya veb xidmət dayana bilər (Layer 7).' },
              { t: 'Kabeli dəyişmək.', why: 'Ping cavab verir, yəni kabel və link işləyir.' },
              { t: 'PC-nin IP ünvanını dəyişmək.', why: 'IP işləyir: ping server ilə IP ilə danışır.' },
              { t: 'Switch-i yenidən başlatmaq.', why: 'Ping işləyir, yəni switch problemi yaratmır.' },
            ] },
          ],
          after: '<p>Ping yoxlayır ki, şəbəkə qatı işləyir. Sayt açılmırsa, axtarışı yuxarı, yəni port və xidmət tərəfə çevir.</p>' },
        { id: 's9', title: 'Packet Tracer-də yoxla (istəyə bağlı)', type: 'ptsteps',
          body: '<p>Bu addım yoxlamadır. Packet Tracer-də iki PC və bir switch qur.</p>',
          checks: [
            { t: 'İki PC-ni switch-ə kabellə birləşdir. PC-lərə eyni şəbəkədən ünvan ver: PC1 <span class="m">192.168.1.10</span>, PC2 <span class="m">192.168.1.20</span>, mask <span class="m">255.255.255.0</span> (Desktop, IP Configuration).' },
            { t: 'Sağ alt küncdən <b>Simulation Mode</b>-a keç.' },
            { t: 'Add Simple PDU ilə PC1-dən PC2-yə mesaj göndər, <b>Capture / Forward</b> ilə addım-addım irəlilə.' },
            { t: 'Paket switch-ə çatanda üstündəki zərfə klik et və <b>OSI Model</b> nişanına bax. Hansı layer-lər işıqlanıb?' },
          ] },
        { id: 's10', title: 'Gördüyünü yaz', type: 'form',
          body: '<p>Switch üçün OSI Model nişanında hansı layer-lər işıqlanmışdı? Layer nömrələrini yaz (məsələn "1 və 3").</p>',
          fields: [{ label: 'Switch-də layer-lər', placeholder: 'məs. 1 və 3', check: raw => (raw.match(/\d/g) || []).slice().sort().join('') === '12', wrong: 'Switch hansı ünvana baxır? O ünvan hansı layer-dədir? Aşağıdan başla.' }],
          hints: ['Switch MAC ünvanı ilə işləyir. Bu, hansı layer-dir?', 'Layer 2 işləyirsə, onun altındakı layer də (siqnal) işləməlidir.'],
          solution: 'Layer 1 və 2. Bu, switch-in Layer 2 cihazı olduğunu göstərir. Versiyanda görünüş bir qədər fərqli ola bilər.',
          after: '<p>Router üçün 1-dən 3-ə qədər, PC üçün hamısı işıqlanır. Cihaz yalnız öz layer-inə qədər oxuyur.</p>' },
      ],
    },

    quiz: {
      draw: 8,
      gens: [
        () => {
          const it = pick(ITEMS); const layers = [1, 2, 3, 4, 7];
          const wrong = shuffle(layers.filter(x => x !== it[1])).slice(0, 3);
          const opts = shuffle([it[1]].concat(wrong));
          return { id: 'p1t10-g-layer', concept: 'l' + it[1], obj: 'Protocol və ya anlayışı layer-ə bağlamaq', _meta: { item: it[0], layer: it[1] },
            stem: '<p>Aşağıdakı hansı layer-ə aiddir: <b>' + it[0] + '</b>?</p>',
            options: opts.map(n => ({ t: 'Layer ' + n + ' (' + LAYER_NAME[n] + ')', ok: n === it[1], why: n === it[1] ? it[2] : 'Layer ' + n + ' (' + LAYER_NAME[n] + ') başqa işlə məşğuldur. ' + it[0] + ' Layer ' + it[1] + '-dədir.' })) };
        },
        () => {
          const p = pick(PDU); const dir = R(2);
          if (dir === 0) {
            const names = shuffle(['segment', 'packet', 'frame', 'bits']);
            return { id: 'p1t10-g-pdu', concept: 'osi-overview', obj: 'PDU adı', _meta: { layer: p[0], pdu: p[1] },
              stem: '<p>Layer <b>' + p[0] + '</b>-də məlumat vahidinin adı nədir?</p>',
              options: names.map(n => ({ t: n, ok: n === p[1], why: n === p[1] ? 'Layer 4: segment, Layer 3: packet, Layer 2: frame, Layer 1: bits. Layer ' + p[0] + ' üçün ' + p[1] + '.' : 'Bu ad başqa layer-in vahididir. Layer ' + p[0] + '-də vahid ' + p[1] + '-dir.' })) };
          }
          const ls = shuffle([1, 2, 3, 4]);
          return { id: 'p1t10-g-pdu', concept: 'osi-overview', obj: 'PDU adı', _meta: { layer: p[0], pdu: p[1] },
            stem: '<p><b>' + p[1] + '</b> hansı layer-in məlumat vahididir?</p>',
            options: ls.map(n => ({ t: 'Layer ' + n + ' (' + LAYER_NAME[n] + ')', ok: n === p[0], why: n === p[0] ? 'Segment Layer 4-ün, packet Layer 3-ün, frame Layer 2-nin, bits Layer 1-in vahididir.' : 'Bu layer-in vahidi başqa addır. ' + p[1] + ' Layer ' + p[0] + '-dir.' })) };
        },
      ],
      pool: [
        { id: 'p1t10-q1', concept: 'why-layers', obj: 'Layer-lərin faydası',
          stem: '<p>Şirkət bütün PC-ləri Ethernet kabelindən Wi-Fi-a keçirir. Brauzer və mail proqramı dəyişmədən işləyir. Bu nə ilə izah olunur?</p>',
          options: [
            { t: 'Layer-lər müstəqildir: yeni kabel növü yalnız aşağı layer-ləri dəyişir.', ok: true, why: 'Hər layer yalnız öz işini görür. Asılılıq yoxdur, ona görə birini dəyişmək digərlərinə toxunmur. Burada: Ethernet-dən Wi-Fi-a keçəndə yalnız Layer 1 və 2 dəyişir.' },
            { t: 'Wi-Fi bütün proqramlar üçün Ethernet-lə eyni protocol-ları işlədir, ona görə heç nə dəyişmir.', why: 'Wi-Fi və Ethernet aşağı layer-lərdə fərqli işləyir. Proqramlar dəyişmir, çünki onlar bu fərqi görmürlər, protocol-ların eyni olmasından deyil.' },
            { t: 'Brauzerlər hər şəbəkə növünü avtomatik tanıyıb özünü hər dəfə yenidən qurur.', why: 'Brauzer şəbəkə növü haqqında heç nə bilmir. Bunu layer-lərin ayrılması təmin edir.' },
            { t: 'Wi-Fi yalnız Layer 7-də (proqram səviyyəsində) işləyir, ona görə aşağı layer-lər toxunulmaz qalır.', why: 'Wi-Fi radio siqnal və link səviyyəsindədir (Layer 1-2). Layer 7-də işləyən proqram protocol-ları deyil.' },
          ] },
        { id: 'p1t10-q2', concept: 'troubleshoot', obj: 'Problemi aşağıdan yuxarı axtarmaq',
          stem: '<p>İstifadəçinin brauzeri "səhifə tapılmadı" yazır. Düzgün araşdırma yolu hansıdır?</p>',
          options: [
            { t: 'Əvvəl kabel və işıq, sonra IP və ping, ən axırda proqram.', ok: true, why: 'Aşağıdan yuxarı. Yuxarı layer aşağıdakına söykənir, aşağıda qırıq varsa yuxarını yoxlamaq mənasızdır. Brauzer mesajı yalnız nəticədir, səbəb aşağıda ola bilər.' },
            { t: 'Brauzeri yenidən quraşdırmaq, çünki mesaj brauzerdən gəlir.', why: 'Mesaj brauzerdən gəlsə də, səbəb kabel və ya ünvan ola bilər. Brauzer sadəcə cavab almadığını bildirir.' },
            { t: 'Əvvəl serverin log-larına baxmaq, çünki səhifənin özü serverdədir.', why: 'Əgər sorğu serverə çatmayıbsa, serverin log-unda heç nə olmaz. Əvvəl yolun işlədiyini göstərmək lazımdır.' },
            { t: 'Şəbəkə cihazlarını yenidən başlatmaq, çünki ən çox bu kömək edir və sürətlidir.', why: 'Səbəb bilinmədən cihazları yenidən başlatmaq başqa istifadəçiləri də kəsə bilər və kökü tapmır.' },
          ] },
        { id: 'p1t10-q3', concept: 'troubleshoot', obj: 'Ping nəticəsini layer-lə oxumaq',
          stem: '<p>Server-ə ping cavab verir, amma <b>https://</b> ilə sayt açılmır. Ən məntiqli şübhə hansıdır?</p>',
          options: [
            { t: 'Layer 4 və ya 7: 443 portu bloklanıb, ya da xidmət dayanıb.', ok: true, why: 'Ping Layer 3-ə qədər yoxlayır, yəni aşağı hissə işləyir. Veb port (Layer 4) və xidmət (Layer 7) qalır.' },
            { t: 'Layer 1: kabel və ya konnektor xarabdır.', why: 'Kabel xarab olsaydı, ping də cavab verməzdi.' },
            { t: 'Layer 2: switch serverin MAC ünvanını bilmir.', why: 'Switch MAC-ı bilməsəydi, frame çatmazdı və ping işləməzdi.' },
            { t: 'Layer 3: PC-nin IP ünvanı səhv yazılıb.', why: 'Ping IP ilə işləyir və cavab gəlir, deməli IP düzgündür.' },
          ] },
        { id: 'p1t10-q4', concept: 'osi-overview', obj: 'Cihazın oxuduğu layer',
          stem: '<p>Hansı cihaz paketi <b>yalnız IP ünvanına görə</b> yönləndirir və port nömrəsinə baxmır?</p>',
          options: [
            { t: 'Router.', ok: true, why: 'Router Layer 3-də işləyir: IP ünvanına baxıb yol seçir. Port Layer 4-dədir, buna ehtiyacı yoxdur.' },
            { t: 'Switch.', why: 'Switch Layer 2-dədir və MAC ünvanına görə qərar verir, IP-yə baxmır.' },
            { t: 'Şəbəkə kartı (NIC).', why: 'NIC cihazın öz kartıdır, yönləndirmə cihazı deyil. Frame-in ünvanı ona aidirmi, ona baxır.' },
            { t: 'Veb server.', why: 'Server paketin sonuna çatır və yuxarı layer-lərə qədər açır, yönləndirmir.' },
          ] },
        { id: 'p1t10-q5', concept: 'osi-overview', obj: 'Switch və layer',
          stem: '<p>Switch hansı ünvana görə qərar verir və bu hansı layer-dir?</p>',
          options: [
            { t: 'MAC ünvanı, Layer 2.', ok: true, why: 'Switch eyni link-də çatdırır və bunun ünvanı MAC-dır. Bu, Data Link layer-dir.' },
            { t: 'IP ünvanı, Layer 3.', why: 'IP ünvanına router baxır. Adi switch IP-yə baxmır.' },
            { t: 'Port nömrəsi, Layer 4.', why: 'Port nömrəsinə firewall kimi yuxarı layer cihazları baxır. Switch frame-in daxilinə bu qədər getmir.' },
            { t: 'Domain adı, Layer 7.', why: 'Domain adını DNS IP ünvanına çevirir. Switch domain adı görmür.' },
          ] },
        { id: 'p1t10-q6', concept: 'l4', obj: 'Port nömrəsi',
          stem: '<p>Bir PC-də eyni anda brauzer, mail və musiqi proqramı işləyir, hamısı eyni kabeldən istifadə edir. Gələn məlumatın hansı proqrama aid olduğunu hansı layer müəyyən edir?</p>',
          options: [
            { t: 'Transport (Layer 4): port nömrəsi ilə.', ok: true, why: 'Qayda: Layer 4 port nömrəsi ilə düzgün proqramı seçir. Bir cihazda çox proqram var, hər birinə nömrə lazımdır. Veb üçün 443, mail üçün başqa port.' },
            { t: 'Network (Layer 3): IP ünvanı ilə.', why: 'IP ünvanı cihazı tapır, cihazın içindəki proqramı yox. Hamısı eyni IP ünvanını paylaşır.' },
            { t: 'Data Link (Layer 2): MAC ünvanı ilə.', why: 'MAC kartı göstərir, proqramı yox. Bütün proqramlar eyni karta aiddir.' },
            { t: 'Physical (Layer 1): siqnalın növü ilə.', why: 'Siqnalın növü proqramı göstərmir, yalnız bitləri daşıyır.' },
          ] },
        { id: 'p1t10-q7', concept: 'osi-overview', obj: '7 layer-in sırası', type: 'order',
          stem: '<p>OSI-nin layer-lərini <b>aşağıdan yuxarı</b> (Layer 1-dən 7-yə) sırala.</p>',
          items: [
            { t: 'Physical', why: 'Layer 1: bitlər və siqnal.' },
            { t: 'Data Link', why: 'Layer 2: MAC, link daxilində çatdırma.' },
            { t: 'Network', why: 'Layer 3: IP, şəbəkələr arası.' },
            { t: 'Transport', why: 'Layer 4: port, TCP və UDP.' },
            { t: 'Session', why: 'Layer 5: sessiya.' },
            { t: 'Presentation', why: 'Layer 6: format, şifrələmə.' },
            { t: 'Application', why: 'Layer 7: proqram protocol-ları.' },
          ] },
        { id: 'p1t10-q8', concept: 'l3', obj: 'Layer 3-ün işi',
          stem: '<p>Hansı iş <b>Layer 3</b>-ün işidir?</p>',
          options: [
            { t: 'Paketi başqa şəbəkəyə IP ünvanı ilə çatdırmaq.', ok: true, why: 'Network layer cihazları şəbəkələr arasında IP ünvanı ilə tapır və router bu işi görür.' },
            { t: 'Frame-i eyni switch-dəki cihaza MAC ilə çatdırmaq.', why: 'Bu Layer 2-nin işidir: link daxilində çatdırma.' },
            { t: 'Məlumatı düzgün proqrama port nömrəsi ilə vermək.', why: 'Bu Layer 4-ün işidir.' },
            { t: 'Bitləri kabeldə elektrik və ya işıq siqnalı kimi ötürmək.', why: 'Bu Layer 1-in işidir.' },
          ] },
        { id: 'p1t10-q9', concept: 'osi-overview', obj: 'Firewall qaydasının layer-i',
          stem: '<p>Firewall qaydası: "TCP 22 portuna giriş bloklansın". Bu qayda hansı layer-in məlumatına baxır?</p>',
          options: [
            { t: 'Layer 4: TCP və port nömrəsi.', ok: true, why: 'Qaydada "TCP" və "port 22" var, ikisi də Transport layer-in anlayışıdır.' },
            { t: 'Layer 2: MAC ünvanı.', why: 'Qaydada MAC ünvanı yoxdur. Port nömrəsi daha yuxarıdadır.' },
            { t: 'Layer 7: SSH proqramının məzmunu.', why: 'Qayda yalnız port nömrəsinə baxır, məzmunu açmır. 22 portu adətən SSH üçündür, amma qayda məzmunu oxumur.' },
            { t: 'Layer 1: kabelin növü.', why: 'Firewall qaydası fiziki mühiti görmür.' },
          ] },
        { id: 'p1t10-q10', concept: 'l1', obj: 'Layer 1 simptomu',
          stem: '<p>Switch portunda işıq yanmır və PC "network cable unplugged" yazır. Hansı layer-dir?</p>',
          options: [
            { t: 'Layer 1: kabel, konnektor və ya port.', ok: true, why: 'Kabel və siqnal Physical layer-dir. İşıq olmaması link qurulmadığını göstərir.' },
            { t: 'Layer 3: PC-də IP ünvanı səhv yazılıb.', why: 'IP ünvanı səhv olsa da, link işığı yanardı. İşıq yoxdursa, problem aşağıdadır.' },
            { t: 'Layer 4: firewall-da port nömrəsi bloklanıb.', why: 'Port problemi olsa, link işığı yenə yanardı.' },
            { t: 'Layer 7: istifadə etdiyin proqramda xəta var.', why: 'Proqram xətası kabelin işığına təsir etmir.' },
          ] },
      ],
    },
  });
})();
