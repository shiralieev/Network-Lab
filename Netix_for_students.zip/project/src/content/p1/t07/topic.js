(function () {
  const pick = PT.pick; const R = PT.randInt; const shuffle = PT.shuffle;
  const rnd = (lo, hi) => lo + R(hi - lo + 1);
  const MAC = x => '0001.4321.' + x;
  const act = (label, who, mac, port, txt) => ({ label, run: (dev, o) => { dev.act = dev.act || []; dev.act.push(who); dev.learn(mac, port); o.print(txt, 'dim'); } });
  const shRe = /^sh\w*\s+mac\s+addr/i; const clRe = /^cl\w*\s+mac\s+addr\w*\s+dyn/i;

  PT.topic({
    id: 'p1t7',
    objectives: [
      'Hub ilə switch-in fərqini və switch-in MAC address table ilə necə işlədiyini izah etmək',
      'Hər frame üçün learn və forward / filter / flood qərarını müəyyən etmək',
      'Aging, köçürülən MAC və bir portda çox MAC hallarını izah etmək',
      'MAC address table-dan problemi və MAC flooding hücumunu tanımaq',
    ],
    explain: PT.frag['p1/t07/explain'], cheat: PT.frag['p1/t07/cheat'],

    lab: {
      title: 'Lab 7: Switch-in qərarlarını izlə və cədvəli oxu',
      goal: 'Switch-in learn / forward / flood / filter qərarlarını proqnozlaşdırmaq, MAC address table-ın necə dolduğunu praktika terminalında görmək və cədvələ əsasən problem və hücum tapmaq.',
      why: 'Switch-in MAC cədvəli şəbəkənin xəritəsidir. Hansı cihazın hansı portda olduğunu, kadrın niyə hamıya getdiyini və ya niyə heç yerə getmədiyini bu cədvəl və dörd qərar izah edir.',
      minutes: 45,
      finish: 'Switch-in qərarını cədvələ baxaraq proqnozlaşdırır, cədvəldən problem və hücum əlaməti tapırsan. Növbəti mövzuda Packet Tracer interfeysini öyrənəcəksən: bundan sonra bu cədvəli öz topologiyanda canlı görəcəksən.',
      steps: [
        { id: 's1', title: 'Plan', type: 'info', button: 'Başlayaq',
          body: '<p>Bu labda Packet Tracer lazım deyil.</p><ol><li>Bir kadrın switch-də həyatını sıraya düz.</li><li>Simulyatorda və kağız üzərində qərarları proqnozlaşdır.</li><li>Praktika switch-ində cədvəlin dolmasını və silinməsini gör.</li><li>İki cədvəl və bir log oxu, domain say.</li><li>Üç ticket: itən MAC, aging uyğunsuzluğu və MAC flooding.</li></ol>' },

        { id: 's2', title: 'Bir kadrın switch-də həyatı', type: 'order',
          body: '<p>Switch-ə bir unicast kadr gəlir. Switch-in etdiyi işləri baş vermə sırası ilə düz (ilk iş yuxarıda).</p>',
          items: [
            { t: 'Kadr bir portdan daxil olur', why: 'Switch kadrı almadan heç nə edə bilməz. Hər şey bu andan başlayır.' },
            { t: 'Switch Source MAC-i gələn portla birlikdə cədvələ yazır və ya yeniləyir (learn)', why: 'Öyrənmə qərardan əvvəl olur. Source MAC kadrın gəldiyi portun arxasında olduğunu əmin şəkildə göstərir.' },
            { t: 'Switch Destination MAC-i cədvəldə axtarır', why: 'Hara göndərəcəyini bilmək üçün Destination MAC cədvəldə axtarılır.' },
            { t: 'Switch qərar verir: forward, filter və ya flood', why: 'Axtarışın nəticəsi qərarı müəyyən edir: başqa portda tapıldı, gələn portda tapıldı və ya tapılmadı.' },
            { t: 'Kadr seçilmiş portlara göndərilir (filter olubsa atılır)', why: 'Qərar icra olunur. Kadrın özü dəyişmir, olduğu kimi göndərilir.' },
          ],
          hints: ['Switch əvvəl nəyi öyrənir, sonra nəyə baxıb qərar verir?'],
          after: '<p>Öyrənmə həmişə birinci gəlir. Buna görə switch ilk kadrı flood etsə belə, göndərənin yerini artıq bilir.</p>' },

        { id: 's3', title: 'Simulyatorda yoxla', type: 'form',
          sim: { name: 'switchsim' },
          body: '<p>Əvvəl "Hamısını sıfırla" bas ki, cədvəl boş olsun. Sonra PC-A-dan PC-B-yə, ardınca PC-B-dən PC-A-ya kadr göndər. Hər dəfə qərarı əvvəl təxmin et.</p>',
          fields: [
            { label: 'PC-A → PC-B kadrından sonra cədvəldə neçə giriş var?', placeholder: 'rəqəm', check: r => r.trim() === '1', wrong: 'Switch yalnız Source MAC-dən öyrənir. İlk kadrın Source MAC-i kimindir?' },
            { label: 'Bu birinci kadrın qərarı (flood / forward / filter)', placeholder: 'qərar', answers: ['flood'], wrong: 'Destination MAC (PC-B) cədvəldə var idi?' },
            { label: 'PC-B → PC-A kadrının qərarı', placeholder: 'qərar', answers: ['forward'], wrong: 'Bu anda PC-A-nın MAC-i cədvəldədir. Hansı portdadır?' },
            { label: 'İkinci kadrdan sonra cədvəldə neçə giriş var?', placeholder: 'rəqəm', check: r => r.trim() === '2', wrong: 'İndi PC-B-nin MAC-i də öyrənilib.' },
          ],
          hints: ['Qaydanı xatırla: əvvəl Source MAC öyrənilir, sonra Destination MAC cədvəldə axtarılır.'],
          solution: 'İlk kadr: Source A öyrənilir (1 giriş), Destination B cədvəldə yoxdur, flood. İkinci kadr: Source B öyrənilir (2 giriş), Destination A cədvəldə Fa0/1 portundadır, forward.' },

        { id: 's4', title: 'Kağız üzərində: beş kadr', type: 'form',
          body: '<p>Switch-in dörd portu var: PC-A <span class="m">Fa0/1</span>, PC-B <span class="m">Fa0/2</span>, PC-C <span class="m">Fa0/3</span>, PC-D <span class="m">Fa0/4</span>. Cədvəl <b>boşdur</b>. Beş kadr ardıcıllıqla gəlir. Hər kadr üçün qərarı yaz (flood, forward və ya filter).</p><pre class="pre">1.  A → B   (A Fa0/1 portundan)\n2.  B → A\n3.  C → A\n4.  A → D   (D hələ heç vaxt göndərməyib)\n5.  D → C</pre>',
          fields: [
            { label: '1-ci kadr', placeholder: 'qərar', answers: ['flood'], wrong: 'Cədvəl boşdur: B-nin yeri məlum deyil.' },
            { label: '2-ci kadr', placeholder: 'qərar', answers: ['forward'], wrong: '1-ci kadrdan sonra A cədvələ yazılıb.' },
            { label: '3-cü kadr', placeholder: 'qərar', answers: ['forward'], wrong: 'A hələ də cədvəldə Fa0/1 portundadır.' },
            { label: '4-cü kadr', placeholder: 'qərar', answers: ['flood'], wrong: 'D indiyə qədər heç bir kadr göndərməyib: switch onun portunu bilmir.' },
            { label: '4-cü kadrdan sonra cədvəldə neçə giriş var?', placeholder: 'rəqəm', check: r => r.trim() === '3', wrong: 'Yalnız Source MAC-lər yazılır. İndiyə qədər kim göndərib: A, B, C. D hələ yox.' },
            { label: '5-ci kadr (D → C)', placeholder: 'qərar', answers: ['forward'], wrong: 'C cədvəldədir (3-cü kadr). Hansı portda?' },
          ],
          hints: ['Hər kadr üçün iki sual ver: (1) Source MAC cədvəldədirmi, yoxsa yeni yazılır? (2) Destination MAC cədvəldə varmı və hansı portdadır?'],
          solution: '1: flood (cədvəl boş). 2: forward (A cədvəldədir). 3: forward (A Fa0/1). 4: flood (D bilinmir). 4-cü kadrdan sonra giriş sayı 3 (A, B, C). 5: forward (C Fa0/3).',
          after: '<p>Cədvəl yalnız <b>göndərənlərdən</b> öyrənir. D yalnız 5-ci kadrda göndərəndə öyrənilir.</p>' },

        { id: 's5', title: 'Praktika switch-i: cədvəl necə dolur', type: 'terminal',
          body: '<p>Sağda switch-in vəziyyəti görünür. Aşağıdakı düymələr PC-lərin kadr göndərməsini simulyasiya edir.</p><ol><li>Üç düyməni bas: PC-A, PC-B və PC-C kadr göndərsin.</li><li><span class="m">show mac address-table</span> yaz və cədvəli oxu.</li><li><span class="m">enable</span> yaz, sonra <span class="m">clear mac address-table dynamic</span>.</li><li>Cədvələ yenidən bax.</li></ol>',
          term: { kind: 'switch', hostname: 'SW1', title: 'SW1', ports: ['Fa0/1', 'Fa0/2', 'Fa0/3', 'Fa0/4'], cables: { 'Fa0/1': 'PC-A', 'Fa0/2': 'PC-B', 'Fa0/3': 'PC-C', 'Fa0/4': 'PC-D' }, macPanel: true,
            quick: ['show mac address-table', 'enable', 'clear mac address-table dynamic'],
            actions: [
              act('PC-A kadr göndərir', 'A', MAC('aaaa'), 'Fa0/1', '[PC-A Fa0/1 portundan kadr göndərdi]'),
              act('PC-B kadr göndərir', 'B', MAC('bbbb'), 'Fa0/2', '[PC-B Fa0/2 portundan kadr göndərdi]'),
              act('PC-C kadr göndərir', 'C', MAC('cccc'), 'Fa0/3', '[PC-C Fa0/3 portundan kadr göndərdi]'),
            ],
            goals: [
              { text: 'PC-A, PC-B və PC-C düymələrini bas', test: d => new Set(d.act || []).size >= 3 },
              { text: '<span class="m">show mac address-table</span> işlət', test: d => d.history.some(l => shRe.test(l)) },
              { text: '<span class="m">enable</span> yaz, sonra <span class="m">clear mac address-table dynamic</span> işlət', test: d => d.history.some(l => clRe.test(l)) },
              { text: 'Silindikdən sonra <span class="m">show mac address-table</span> yenidən işlət', test: d => { const i = d.history.findIndex(l => clRe.test(l)); return i >= 0 && d.history.slice(i + 1).some(l => shRe.test(l)); } },
            ] },
          hints: ['Əvvəl sağdakı düymələri bas, sonra sol tərəfdə əmr yaz. Cədvəl hər düymədən sonra dəyişir.', '"clear" əmri yalnız privileged rejimdədir: əvvəl enable yaz.'],
          after: '<p>Müşahidə: hər düymədən sonra cədvəldə bir giriş əlavə olundu. <span class="m">clear</span> hamısını sildi. Bu, aging-in (300 saniyə) etdiyi işin sürətli versiyasıdır: switch hər şeyi yenidən öyrənəcək. Silmək heç bir cihazı pozmur.</p>' },

        { id: 's6', title: 'Cədvəli oxu: Fa0/2-də üç MAC', type: 'choice',
          body: '<p>Switch-də:</p><pre class="pre"><span class="p">SW1#</span>show mac address-table\nVlan    Mac Address       Type        Ports\n----    -----------       --------    -----\n   1    0001.4321.aaaa    DYNAMIC     Fa0/1\n   1    0001.4321.bbbb    DYNAMIC     Fa0/2\n   1    0001.4321.cccc    DYNAMIC     Fa0/2\n   1    0001.4321.dddd    DYNAMIC     Fa0/2\n   1    0001.4321.eeee    DYNAMIC     Fa0/3</pre><p>Fa0/2 portunda üç fərqli MAC var. Bu nə deməkdir?</p>',
          options: [
            { t: 'Fa0/2-nin arxasında başqa switch və ya access point var, cihazlar oradadır.', ok: true, why: 'Cədvəl "MAC → port (arxasında olan)" saxlayır. Bir portda çox MAC varsa, onun arxasında bir neçə cihaz var, yəni port başqa switch-ə və ya access point-ə gedir. Bu normal topologiyadır.' },
            { t: 'Üç MAC mütləq MAC flooding hücumudur, port heç bir yoxlama aparılmadan dərhal söndürülməlidir.', why: 'Üç MAC hücum əlaməti deyil. Hücumda qısa müddətdə minlərlə təsadüfi MAC görünür. Bir portda bir neçə MAC başqa switch və ya access point-in arxasında normaldır.' },
            { t: 'Switch səhv edib və eyni MAC-i üç dəfə cədvələ yazıb, cədvəl yenilənməlidir.', why: 'MAC-lər fərqlidir (bbbb, cccc, dddd). Cədvəldə hər MAC bir dəfə yazılır, bunlar üç ayrı cihazdır.' },
            { t: 'Fa0/2 üç VLAN-ın üzvüdür, ona görə hər VLAN üçün cədvəldə ayrıca MAC yazılıb.', why: 'Vlan sütununa bax: hamısı 1-dir. Üç fərqli VLAN olsaydı, bu sütun fərqli olardı. Burada bir VLAN və üç MAC var.' },
          ],
          hints: ['Cədvəl hər MAC üçün nəyi göstərir: cihazın özünü, yoxsa arxasında olduğu portu?'],
          after: '<p>Tərsinə düşün: cədvəldən topologiyanı çıxara bilirsən. Fa0/1 və Fa0/3 tək cihaz portlarıdır, Fa0/2 isə başqa bir şəbəkə hissəsinə gedir.</p>' },

        { id: 's7', title: 'Ticket 1: ping işləyir, amma niyə hamıya getdi?', type: 'choice',
          body: '<p>PC-A-nın ARP cache-ində PC-B (192.168.1.20) var. Switch-də isə PC-B-nin MAC-i artıq yoxdur: 300 saniyə susduğu üçün aging onu silib. PC-A ping göndərir. Nə baş verəcək?</p>',
          options: [
            { t: 'İlk kadr flood olunur, B cavab verir, switch onu yenidən öyrənir.', ok: true, why: 'PC-A-nın ARP cache-i hələ B-nin MAC-ini bilir, ona görə yeni ARP yoxdur və kadr birbaşa B-nin MAC-i ilə qurulur. Switch bu Destination MAC-i tapmır (unknown unicast) və flood edir. B cavab verəndə switch onu öyrənir.' },
            { t: 'Ping uğursuz olur, çünki switch B-ni tanımır və kadrı atır, ARP də kömək etmir.', why: 'Switch bilinməyən unicast kadrı atmır, flood edir. Atsaydı, hər aging-dən sonra ilk ping uğursuz olardı və şəbəkə bu yolla işləməzdi.' },
            { t: 'PC-A yeni ARP göndərməli olur, çünki switch ARP cache-i də silir və bunu bildirir.', why: 'ARP cache host-dadır, switch ona toxunmur. Switch yalnız öz MAC cədvəlini silir. İki ayrı cədvəldir.' },
            { t: 'Switch kadrı atır və PC-A-ya ICMP Destination Unreachable mesajı göndərir.', why: 'Switch Layer 2 cihazıdır, ICMP mesajı yaratmır. ICMP Unreachable göndərən router-lərdir.' },
          ],
          hints: ['Switch-in cədvəlində Destination MAC yoxdur. Dörd qərardan hansı bu hala uyğundur?'],
          after: '<p>Bu real şəbəkədə tez-tez baş verir və adətən heç kim hiss etmir: bir kadr hamıya gedir, sonra hər şey yenə unicast olur.</p>' },

        { id: 's8', title: 'Ticket 2: filter nə vaxt?', type: 'choice',
          body: '<p>PC-C və PC-D kiçik bir switch-in arxasındadır. Həmin switch əsas switch-in <span class="m">Fa0/3</span> portuna qoşulub. Cədvəldə C və D hər ikisi Fa0/3 portundadır. PC-C PC-D-yə kadr göndərir və kadr Fa0/3 portundan switch-ə gəlir. Switch nə edir?</p>',
          options: [
            { t: 'Filter: kadrı atır, çünki D artıq həmin kiçik switch vasitəsilə kadrı alıb.', ok: true, why: 'Destination MAC cədvəldə kadrın gəldiyi portdadır (Fa0/3). C və D eyni portun arxasındadır və kiçik switch kadrı D-yə özü çatdırıb. Switch kadrı başqa yerə ötürmür, atır.' },
            { t: 'Forward: kadrı yenidən Fa0/3 portuna qaytarır ki, D kadrı alsın.', why: 'Switch kadrı heç vaxt gələn portdan geri göndərmir. Üstəlik D kadrı artıq alıb, təkrar göndərmək lazım deyil.' },
            { t: 'Flood: kadrı bütün digər portlara göndərir, çünki hub-dan gəlir.', why: 'Flood yalnız Destination MAC cədvəldə olmayanda (və ya broadcast olanda) baş verir. D cədvəldə var və yeri məlumdur.' },
            { t: 'Kadrı Fa0/1 və Fa0/2 portlarına göndərir ki, hədəfi tapsın.', why: 'Hədəfin yeri məlumdur və Fa0/1, Fa0/2-də deyil. Switch yalnız lazım olan yerə göndərir, bu halda heç yerə.' },
          ],
          hints: ['D hansı portdadır və kadr hansı portdan gəlib?'],
          after: '<p>Filter nadir görünür, çünki adətən hər port bir cihaza gedir. Amma o, "switch kadrı yalnız lazım olan yerə göndərir" qaydasının sərhəd halıdır.</p>' },

        { id: 's10', title: 'Ticket 3: A-nın MAC-i cədvəldə yoxdur', type: 'choice',
          body: '<p>PC-A (Fa0/1) PC-B-yə (Fa0/2) ping edə bilmir. İkisi də eyni switch-dədir və IP, mask düzgündür. PC-A saniyələr əvvəl bir neçə dəfə ping atıb. Switch-də:</p><pre class="pre"><span class="p">SW1#</span>show mac address-table\nVlan    Mac Address       Type        Ports\n----    -----------       --------    -----\n   1    0001.4321.bbbb    DYNAMIC     Fa0/2\nTotal Mac Addresses for this criterion: 1</pre><p>PC-A-nın MAC-i <span class="m">0001.4321.aaaa</span>-dır. Ən məntiqli növbəti addım nədir?</p>',
          options: [
            { t: 'PC-A-nın portunu (Fa0/1) və kabelini yoxla: switch ondan kadr görməyib.', ok: true, why: 'PC-A ping atıb, yəni kadr göndərib. Əgər kadr switch-ə çatsaydı, switch onun Source MAC-ini öyrənərdi. Cədvəldə aaaa yoxdur, deməli kadrlar switch-ə çatmır: kabel, port (shutdown) və ya NIC problemi (Layer 1).' },
            { t: 'PC-A-nın IP ünvanını dəyiş, çünki switch kadrları IP ünvanına görə yönləndirir.', why: 'Switch IP-yə baxmır, yalnız MAC ilə işləyir. Cədvəldə PC-A-nın MAC-inin olmaması IP ayarı ilə izah olunmur: IP səhv olsa belə, ARP kadrı switch-ə çatıb MAC-i öyrədərdi.' },
            { t: 'Aging müddətini artır ki, PC-A-nın girişi tez silinməsin və qalsın.', why: 'PC-A-nın girişi silinməyib, heç yaranmayıb. PC-A saniyələr əvvəl göndərib, aging 300 saniyədir. Problem aging deyil.' },
            { t: 'Switch-i yenidən yüklə, çünki MAC cədvəli xarabdır və yenilənməlidir.', why: 'Cədvəl xarab deyil: PC-B-nin girişi var. Yeniləmək əvvəl səbəbi tapmadan sübut yox, təxmindir.' },
          ],
          hints: ['PC-A kadr göndərib. Kadr switch-ə çatsa cədvəldə nə olardı?'],
          after: '<p>Metod: <b>MAC cədvəldə yoxdur = switch ondan kadr görməyib</b>. Əvvəl Layer 1 yoxlanılır (kabel, port statusu). Cədvəldə hər iki MAC varsa, problem artıq Layer 3-dədir.</p>' },

        { id: 's11', title: 'SOC: bir portda minlərlə MAC', type: 'choice',
          body: '<p>Monitoring bu xəbərdarlığı verdi: access switch-də <span class="m">Fa0/7</span> portunda 40 saniyə ərzində <b>6000</b> yeni MAC öyrənilib. Fa0/7 ofisdəki tək bir kompüterin portudur. MAC-lər təsadüfi görünür, tanınan istehsalçı prefiksləri yoxdur. Switch-in ümumi cədvəli tutumuna yaxınlaşıb. Bu nədir və ilk addımın nədir?</p>',
          options: [
            { t: 'MAC flooding: portu izolə edib kompüteri tapıram, sonra port security qururam.', ok: true, why: 'Tək kompüter portunda qısa müddətdə minlərlə təsadüfi MAC cədvəli doldurmaq cəhdidir. Cədvəl dolanda switch bilinməyən unicast-ı flood edəcək və trafik dinlənə bilər. Əvvəl port izolə olunur, cihaz tapılır, uzunmüddətli həll port security-dir.' },
            { t: 'Normaldır: switch bütün MAC-ləri öyrənməlidir və tutuma yaxınlaşmaq təbiidir.', why: 'Switch öyrənməlidir, amma tək kompüter portunda 40 saniyədə 6000 təsadüfi MAC normal deyil. Normal access portu bir MAC görür.' },
            { t: 'ARP spoofing: hücumçu gateway-in MAC-ini saxtalaşdırır, ona görə cədvəl dolur.', why: 'ARP spoofing bir IP üçün saxta MAC cavabıdır və cədvəli doldurmur. Burada minlərlə fərqli Source MAC var, bu MAC flooding-dir.' },
            { t: 'Aging müddəti çox yüksəkdir: onu azaldıb cədvəlin özü təmizlənməsini gözləyirəm.', why: 'Aging-i azaltmaq hücumu dayandırmır: hücumçu 40 saniyədə 6000 MAC göndərə bilirsə, qısa aging də onu qarşılaya bilməz. Əvvəl mənbə dayandırılmalıdır.' },
          ],
          hints: ['Normal access portunda neçə MAC olmalıdır? Bu portda nə qeyri-adidir?'],
          after: '<p>Doğrulamaq üçün: <span class="m">show mac address-table interface fa0/7</span> ilə MAC-lərə baxarsan. Əgər Fa0/7 əslində başqa switch-ə gedən uplink olsaydı, çox MAC normal olardı. Buna görə əvvəl portun nəyə qoşulduğunu yoxlayırsan: roldan asılı olaraq eyni rəqəm normal və ya hücum ola bilər.</p>' },

        { id: 's12', title: 'Log oxu: MAC flapping', type: 'choice',
          body: '<p>Switch log-da bir neçə saniyədə dəfələrlə:</p><pre class="pre">%SW_MATM-4-MACFLAP_NOTIF: Host 0001.4321.aaaa in vlan 1\n  is flapping between port Fa0/1 and port Fa0/2\n%SW_MATM-4-MACFLAP_NOTIF: Host 0001.4321.aaaa in vlan 1\n  is flapping between port Fa0/2 and port Fa0/1</pre><p>Bu nə deməkdir?</p>',
          options: [
            { t: 'Eyni MAC iki port arasında növbələşir: ola bilsin loop var, kabelləri yoxlayıram.', ok: true, why: 'Switch eyni MAC-i növbə ilə iki portdan görür və girişi hər dəfə yeniləyir. Səbəb adətən loop (kadr kabellərlə dövr edib başqa porta qayıdır) və ya eyni MAC-in iki yerdə olmasıdır (duplicate, MAC spoofing). Kabelləri yoxlayıram.' },
            { t: 'Portlardan biri söndürülüb və switch ona yenidən qoşulmağa çalışır, bu müvəqqətidir.', why: 'Söndürülmüş port kadr almır, deməli MAC ondan görünməzdi. Mesaj MAC-in hər iki portdan canlı gəldiyini göstərir.' },
            { t: 'Aging müddəti çox qısadır, onu artırmaq problemi həll edəcək və log kəsiləcək.', why: 'Aging silmə ilə bağlıdır. Flapping isə MAC-in iki portdan növbə ilə görünməsidir. Aging-i artırmaq səbəbi aradan qaldırmır.' },
            { t: 'Normaldır: cihaz hər iki porta qoşulub və switch hər ikisini cədvələ yazır.', why: 'Cədvəldə hər MAC üçün bir port yazılır. Kadr iki portdan növbə ilə gəlirsə, giriş dəyişib durur. Bu normal vəziyyət deyil, yoxlamaq lazımdır.' },
          ],
          hints: ['Cədvəldə bir MAC neçə portda yazıla bilər? Kadr eyni anda iki portdan gəlirsə nə olur?'],
          after: '<p>İndi log-un nə dediyini oxuya bilirsən: "bu MAC iki yerdən görünür".</p>' },
      ],
    },

    quiz: {
      draw: 8,
      gens: [
        // frame decision from a table
        () => {
          const hx = shuffle(['a1b2', 'c3d4', 'e5f6', '1a2b', '3c4d', '5e6f', '7a8b', '9c0d']);
          const ports = shuffle([1, 2, 3, 4, 5, 6]).map(n => 'Fa0/' + n);
          const ent = [{ mac: MAC(hx[0]), port: ports[0] }, { mac: MAC(hx[1]), port: ports[1] }, { mac: MAC(hx[2]), port: ports[2] }];
          const sh = R(3); ent.push({ mac: MAC(hx[3]), port: ports[sh] });
          const unknown = MAC(hx[4]); const kind = pick(['forward', 'forward', 'flood-u', 'flood-b', 'filter', 'newsrc']);
          let src, dst, inPort, decision, dport, newSrc = false, bc = false;
          if (kind === 'forward') { src = pick(ent); const c = ent.filter(e => e.port !== src.port); const d = pick(c); dst = d.mac; dport = d.port; inPort = src.port; decision = 'forward'; }
          else if (kind === 'filter') { const a = ent[sh], b = ent[3]; src = R(2) ? a : b; const o = src === a ? b : a; dst = o.mac; inPort = src.port; dport = o.port; decision = 'filter'; }
          else if (kind === 'flood-u') { src = pick(ent); dst = unknown; inPort = src.port; decision = 'flood'; }
          else if (kind === 'flood-b') { src = pick(ent); dst = 'ffff.ffff.ffff'; inPort = src.port; decision = 'flood'; bc = true; }
          else { newSrc = true; const freePort = ports[3]; src = { mac: MAC(hx[5]), port: freePort }; const d = pick(ent); dst = d.mac; dport = d.port; inPort = freePort; decision = 'forward'; }
          const others = ['Fa0/1', 'Fa0/2', 'Fa0/3', 'Fa0/4', 'Fa0/5', 'Fa0/6'].filter(p => p !== inPort);
          const fwd = p => 'Forward: kadr yalnız ' + p + ' portuna göndərilir'; const fl = 'Flood: kadr gələn portdan başqa hamısına gedir'; const fi = 'Filter: kadr atılır, heç bir porta getmir';
          const wrongP = shuffle(others.filter(p => p !== dport));
          const mk = (type, p) => ({ type, p });
          let set;
          if (decision === 'forward') set = [mk('fwd', dport), mk('fwd', wrongP[0]), mk('fl'), mk('fi')];
          else if (decision === 'flood') set = [mk('fl'), mk('fwd', wrongP[0]), mk('fwd', wrongP[1]), mk('fi')];
          else set = [mk('fi'), mk('fl'), mk('fwd', wrongP[0]), mk('fwd', wrongP[1])];
          const ok = (o, i) => (decision === 'forward' && o.type === 'fwd' && o.p === dport) || (decision === 'flood' && o.type === 'fl') || (decision === 'filter' && o.type === 'fi');
          const learnTxt = 'Switch əvvəl Source MAC-i ' + (newSrc ? 'öyrənir (cədvəldə yox idi): ' + src.mac + ' = ' + inPort + '. ' : 'yeniləyir (' + src.mac + ' = ' + inPort + '). ');
          const why = (o) => {
            const good = ok(o);
            if (o.type === 'fwd') {
              if (good) return learnTxt + 'Destination ' + dst + ' cədvəldə ' + dport + ' portundadır və gələn port (' + inPort + ') deyil, ona görə kadr yalnız ' + dport + ' portuna göndərilir.';
              if (decision === 'forward') return 'Cədvələ görə Destination ' + dst + ' ' + dport + ' portundadır, ' + o.p + ' portunda deyil.';
              if (decision === 'flood') return 'Forward üçün Destination MAC cədvəldə olmalıdır. ' + (bc ? 'Broadcast ünvan heç vaxt cədvəldə olmur.' : dst + ' cədvəldə yoxdur') + ', ona görə konkret port seçilə bilməz.';
              return 'Destination ' + dst + ' kadrın gəldiyi portdadır (' + inPort + '). ' + o.p + ' portuna göndərməyə ehtiyac yoxdur.';
            }
            if (o.type === 'fl') {
              if (good) return learnTxt + (bc ? 'Destination ffff.ffff.ffff broadcast-dır və cədvəldə olmur, kadr həmişə flood olunur.' : 'Destination ' + dst + ' cədvəldə yoxdur (unknown unicast), ona görə switch kadrı gələn port istisna olmaqla hamıya göndərir.');
              return 'Flood yalnız Destination MAC cədvəldə olmayanda (və ya broadcast olanda) baş verir. Burada ' + dst + ' cədvəldə ' + (decision === 'filter' ? inPort : dport) + ' portundadır.';
            }
            if (good) return learnTxt + 'Destination ' + dst + ' cədvəldə ' + dport + ' portundadır. Kadr da elə bu portdan (' + inPort + ') gəlib, yəni hədəf göndərənlə eyni seqmentdədir. Switch kadrı atır (filter).';
            if (decision === 'forward') return 'Filter yalnız hədəf kadrın gəldiyi portun özündə olanda baş verir. Burada hədəf ' + dport + ' portundadır, kadr isə ' + inPort + ' portundan gəlib.';
            return 'Filter üçün hədəf cədvəldə gələn portda olmalıdır. ' + (bc ? 'Broadcast ünvan cədvəldə olmur.' : dst + ' cədvəldə yoxdur.');
          };
          const table = ent.map(e => '   1    ' + e.mac + '    DYNAMIC     ' + e.port).join('\n');
          return { id: 'p1t7-g-sw-' + kind, concept: 'actions', obj: 'Switch qərarı: forward, filter, flood', _meta: { kind, decision, inPort, dport: dport || null, dst, src: src.mac, newSrc, table: ent.map(e => [e.mac, e.port]) },
            stem: '<p>Switch-in MAC address table-ı:</p><pre class="pre">Vlan    Mac Address       Type        Ports\n----    -----------       --------    -----\n' + table + '</pre><p><b>' + inPort + '</b> portundan kadr gəlir: Source MAC <span class="m">' + src.mac + '</span>, Destination MAC <span class="m">' + dst + '</span>. Switch kadrla nə edir?</p>',
            options: set.map(o => ({ t: o.type === 'fwd' ? fwd(o.p) : (o.type === 'fl' ? fl : fi), ok: ok(o), why: why(o) })) };
        },
        // how many entries after a frame sequence
        () => {
          const hx = shuffle(['a1b2', 'c3d4', 'e5f6', '1a2b', '3c4d', '5e6f']); const macs = hx.map(MAC);
          const nSrc = pick([3, 4]); const srcs = macs.slice(0, nSrc);
          const portOf = {}; srcs.forEach((m, i) => { portOf[m] = 'Fa0/' + (i + 1); });
          const seq = shuffle(srcs).map(m => ({ m, p: portOf[m] }));
          while (seq.length < 6) { const m = pick(srcs); seq.push({ m, p: portOf[m] }); }
          seq[5] = { m: seq[0].m, p: 'Fa0/' + (nSrc + 1 + R(2)) };
          const lines = seq.map((f, i) => {
            const dstPool = macs.filter(x => x !== f.m).concat(['ffff.ffff.ffff', 'ffff.ffff.ffff']);
            return (i + 1) + '.  ' + f.p + '   ' + f.m + ' → ' + pick(dstPool);
          });
          const ans = new Set(seq.map(f => f.m)).size;
          return { id: 'p1t7-g-learn', concept: 'actions', obj: 'Cədvəldəki giriş sayı', type: 'num', _meta: { ans, srcs: seq.map(f => f.m), n: seq.length },
            stem: '<p>Switch-in MAC cədvəli <b>boşdur</b>. Bu 6 kadr ardıcıllıqla gəlir (port, Source MAC → Destination MAC):</p><pre class="pre">' + lines.join('\n') + '</pre><p>Aging nəzərə alınmasın. 6-cı kadrdan sonra cədvəldə <b>neçə giriş</b> olacaq?</p>', placeholder: 'rəqəm',
            check: r => r.trim() === String(ans),
            solution: 'Switch yalnız <b>Source MAC</b>-dən öyrənir. Fərqli Source MAC-lər: ' + ans + '. Destination MAC-lər və broadcast cədvələ düşmür. Eyni MAC başqa portdan görünəndə yeni giriş yaranmır, mövcud giriş yenilənir. Cavab: <b>' + ans + '</b>.' };
        },
        // broadcast domain counting
        () => {
          const k = pick([2, 2, 3]); const a = rnd(1, 3); const hasSw2 = R(2) === 0; const b = hasSw2 ? rnd(1, 3) : 0;
          const items = ['Router: ' + k + ' interface, hər biri ayrı switch-ə qoşulub (Switch 1' + (k > 2 ? ', Switch 3, Switch 4' : ', Switch 3') + ').'];
          items.push('Switch 1-də ' + a + ' PC birbaşa qoşulub.');
          if (hasSw2) items.push('Switch 1 kabellə Switch 2-yə birləşib, Switch 2-də ' + b + ' PC var.');
          for (let i = 1; i < k; i++) items.push('Switch ' + (i === 1 ? 3 : 4) + '-də ' + rnd(1, 3) + ' PC birbaşa qoşulub.');
          const stem = '<p>Şəbəkə:</p><ul>' + items.map(x => '<li>' + x + '</li>').join('') + '</ul><p>Bütün cihazlar eyni virtual şəbəkədədir (VLAN bölgüsü yoxdur). <b>Neçə broadcast domain</b> var?</p>';
          return { id: 'p1t7-g-dom-bro', concept: 'domains', obj: 'Broadcast domain sayı', type: 'num', _meta: { ans: k, k, a, b, hasSw2 }, stem, placeholder: 'rəqəm', check: r => r.trim() === String(k),
            solution: 'Switch-lər (və aralarındakı kabellər) broadcast domain-i ayırmır, router ayırır. Router-in ' + k + ' interface-i var: <b>' + k + '</b> broadcast domain.' };
        },
      ],
      pool: [
        { id: 'p1t7-q1', concept: 'why-switch', obj: 'Hub ilə switch',
          stem: '<p>Hub ilə switch arasında <b>əsas</b> fərq nədir?</p>',
          options: [
            { t: 'Hub kadrı oxumur, hamıya təkrarlayır. Switch Destination MAC-ə baxıb seçir.', ok: true, why: 'Hub Layer 1 cihazıdır: siqnalı olduğu kimi hamıya verir. Switch Layer 2 cihazıdır: kadrın başlığını oxuyur və MAC cədvəlinə əsasən qərar verir.' },
            { t: 'Hub Layer 3 cihazıdır və IP-yə baxır, switch isə yalnız siqnalı gücləndirir.', why: 'Tərsinədir. Hub heç bir başlığa baxmır (Layer 1), switch isə MAC-ə baxır (Layer 2). Hub IP-yə baxmır.' },
            { t: 'Hub yalnız broadcast üçün, switch yalnız unicast üçün istifadə olunur.', why: 'Hər iki cihaz hər növ kadrı ötürür. Fərq kadrın kimə göndərilməsindədir: hub hamıya, switch seçilmiş porta.' },
            { t: 'Hub switch-dən ağıllıdır, çünki MAC cədvəli saxlayır.', why: 'Hub heç bir cədvəl saxlamır və heç nəyi oxumur. MAC cədvəli switch-in xüsusiyyətidir.' },
          ] },
        { id: 'p1t7-q3', concept: 'table', obj: 'Nədən öyrənir',
          stem: '<p>Switch MAC cədvəlini hansı məlumata görə doldurur və niyə?</p>',
          options: [
            { t: 'Source MAC: kadr bu portdan gəlib, MAC bu portun arxasındadır.', ok: true, why: 'Source MAC switch üçün əmin məlumatdır: kadr elə bu portdan gəldi. Destination MAC isə kadrın hara getdiyini deyir, hədəfin harada olduğunu yox.' },
            { t: 'Destination MAC: kadr hədəfin yerini göstərir, switch onu cədvələ yazır.', why: 'Destination MAC hədəfin hansı portda olduğunu bildirmir. Switch onu cədvəldə axtarır, yazmır.' },
            { t: 'Source IP: switch IP-ni MAC-ə çevirib port ilə əlaqələndirir.', why: 'Switch IP başlığına baxmır. IP → MAC çevirməsi ARP-ın işidir və hostlarda saxlanılır.' },
            { t: 'Hər ikisindən: Destination MAC-i də yazır ki, növbəti dəfə tez tapsın.', why: 'Destination MAC üçün port bilinmir, ona görə yazıla bilməz. Switch yalnız Source MAC-i yazır.' },
          ] },
        { id: 'p1t7-q4', concept: 'table', obj: 'IP → MAC → port',
          stem: '<p>SOC-da şübhəli IP ünvanının <b>hansı switch portuna</b> qoşulduğunu tapmalısan. Düzgün ardıcıllıq hansıdır?</p>',
          options: [
            { t: 'Əvvəl ARP cache ilə IP → MAC, sonra switch-in MAC cədvəli ilə MAC → port.', ok: true, why: 'İki cədvəl iki fərqli çevirmə edir: ARP cache IP-ni MAC-ə, switch-in MAC address table-ı MAC-i portuna çevirir. İkisini ardıcıl işlətməklə IP-dən fiziki porta çatırsan.' },
            { t: 'Switch cədvəlində birbaşa IP-ni axtarırsan, çünki cədvəl IP və port saxlayır.', why: 'Switch-in MAC cədvəli IP saxlamır. Orada yalnız VLAN, MAC, tip və port var.' },
            { t: 'Yalnız routing table-a baxırsan, çünki orada hər IP-nin portu yazılıb.', why: 'Routing table şəbəkələr və növbəti hop saxlayır, tək host-un switch portunu yox.' },
            { t: 'IP-yə ping atırsan və cavabdan port nömrəsini oxuyursan.', why: 'Ping cavabında port yoxdur. ICMP-də port anlayışı yoxdur (üçüncü və altıncı mövzu), switch portu isə yalnız switch cədvəlində olur.' },
          ] },
        { id: 'p1t7-q5', concept: 'actions', obj: 'Unknown unicast',
          stem: '<p>Switch-ə unicast kadr gəlir, amma Destination MAC cədvəldə yoxdur. Switch nə edir?</p>',
          options: [
            { t: 'Kadrı gələn port istisna olmaqla bütün portlara göndərir (flood).', ok: true, why: 'Switch hara göndərəcəyini bilmir. Kadrı atsa, hədəf onu heç vaxt almazdı. Flood çatmağı təmin edir, hədəf cavab verəndə switch onun yerini öyrənir.' },
            { t: 'Kadrı atır və göndərənə ICMP Destination Unreachable göndərir.', why: 'Switch ICMP yaratmır (Layer 2 cihazıdır) və bilinməyən unicast-ı atmır, flood edir.' },
            { t: 'Kadrı yalnız router portuna göndərir, çünki router hamının yerini bilir.', why: 'Switch router-i xüsusi saymır. Router öz interface-ində olan MAC-ləri bilir, amma switch bu qərarı vermir.' },
            { t: 'Hədəfin MAC-ini tapmaq üçün ARP request göndərir.', why: 'ARP hostların işidir və IP → MAC çevirir. Switch ARP göndərmir, MAC → port cədvəlini kadrlardan öyrənir.' },
          ] },
        { id: 'p1t7-q6', concept: 'actions', obj: 'Broadcast MAC cədvəldə',
          stem: '<p>FF:FF:FF:FF:FF:FF niyə switch-in MAC cədvəlində heç vaxt görünmür?</p>',
          options: [
            { t: 'Broadcast ünvanı Source MAC olmur, switch isə yalnız Source MAC-dən öyrənir.', ok: true, why: 'Switch cədvəli Source MAC-lərlə doldurur. Broadcast ünvan yalnız Destination kimi işlənir, heç bir NIC onu özünün MAC-i kimi göndərmir. Buna görə cədvələ düşmür və kadr həmişə flood olunur.' },
            { t: 'Switch broadcast kadrları qəbul etmir, onları router-ə ötürür.', why: 'Switch broadcast kadrı qəbul edir və bütün portlara flood edir. Router-ə tək ötürmür.' },
            { t: 'Broadcast üçün switch-də ayrıca gizli cədvəl var və o show əmri ilə görünmür.', why: 'Belə gizli cədvəl yoxdur. Broadcast qərarı sadəcə "Destination broadcast-dır, flood" qaydasıdır.' },
            { t: 'Cədvəl dolanda broadcast girişi ilk silinir.', why: 'Broadcast girişi heç vaxt yaranmır ki, silinsin. Səbəb cədvəlin dolması deyil, Source MAC qaydasıdır.' },
          ] },
        { id: 'p1t7-q7', concept: 'actions', obj: 'Filter nə vaxt',
          stem: '<p>Switch kadrla <b>filter</b> qərarını nə vaxt verir?</p>',
          options: [
            { t: 'Destination MAC cədvəldə gələn portun özündə yazılıbsa.', ok: true, why: 'Hədəf göndərənlə eyni portun arxasındadır. Kadrı artıq alıb, ona görə switch başqa yerə ötürmür və atır.' },
            { t: 'Destination MAC cədvəldə heç bir portda göstərilməyibsə.', why: 'Bu halda switch flood edir (unknown unicast). Filter yalnız yeri məlum və gələn portla eyni olanda baş verir.' },
            { t: 'Destination MAC FF:FF:FF:FF:FF:FF broadcast ünvanıdırsa.', why: 'Broadcast həmişə flood olunur. Filter edilmir.' },
            { t: 'Source MAC cədvəldə hələ yazılmayıbsa və yeni görünürsə.', why: 'Source MAC yoxdursa switch onu öyrənir (learn), kadrın taleyi Destination MAC-dən asılıdır. Source yoxluğu filter yaratmır.' },
          ] },
        { id: 'p1t7-q8', concept: 'walkthrough', obj: 'ARP reply switch-də',
          stem: '<p>Cədvəl boşdur. PC-A (Fa0/1) ARP request göndərdi və switch onu flood etdi. İndi PC-B (Fa0/2) A-ya unicast ARP reply göndərir. Switch reply-i necə emal edir?</p>',
          options: [
            { t: 'B-ni Fa0/2-də öyrənir, Destination A cədvəldə Fa0/1 olduğu üçün yalnız Fa0/1-ə forward edir.', ok: true, why: 'Hər kadrda əvvəl Source MAC öyrənilir (B = Fa0/2). A request-dən artıq cədvəldədir (Fa0/1), ona görə reply forward edilir, flood yox.' },
            { t: 'B-ni öyrənmir, çünki reply unicast-dır və switch yalnız broadcast kadrlardan öyrənir.', why: 'Switch hər kadrdan, unicast olsa belə, Source MAC-i öyrənir. Broadcast-a məhdud deyil.' },
            { t: 'Reply-i də bütün portlara flood edir, çünki ARP kadrları həmişə flood olunur və filter edilmir.', why: 'ARP request broadcast olduğu üçün flood olunur. Reply isə unicast-dır və Destination məlum olanda forward edilir.' },
            { t: 'A-nın MAC-ini yenidən öyrənir və reply-i atır (filter), çünki A artıq cədvəldədir.', why: 'A Fa0/1-dədir, reply isə Fa0/2-dən gəlib: port fərqlidir, filter olmur. Switch reply-i Fa0/1-ə göndərir.' },
          ] },
        { id: 'p1t7-q9', concept: 'aging', obj: 'Köçürülən MAC',
          stem: '<p>Cihaz Fa0/1 portundan çıxarılıb Fa0/5-ə taxıldı. İlk kadr Fa0/5 portundan gəlir. Cədvəldə nə olur?</p>',
          options: [
            { t: 'MAC-in girişi dərhal Fa0/5-ə yenilənir, aging-i gözləmir.', ok: true, why: 'Switch Source MAC-i yeni portda görəndə girişi yeniləyir. Bu, cihaz köçürüləndə şəbəkənin sürətlə düzəlməsini təmin edir.' },
            { t: 'İki giriş olur: köhnə Fa0/1 girişi aging ilə silinənə qədər qalır.', why: 'Cədvəldə hər MAC üçün bir giriş olur. Port dəyişəndə eyni giriş yenilənir, ikinci giriş yaranmır.' },
            { t: 'Kadr atılır, çünki MAC başqa portda qeydiyyatdadır.', why: 'Switch Source MAC üçün başqa portu "saxta" saymır, yalnız yeniləyir. Kadr normal emal olunur.' },
            { t: 'Giriş yalnız 300 saniyə aging bitəndən sonra Fa0/5-ə dəyişir.', why: 'Yenilənmə aging-dən asılı deyil. Aging yalnız istifadə olunmayan girişləri silir.' },
          ] },
        { id: 'p1t7-q10', concept: 'aging', obj: 'MAC spoofing niyə işləyir',
          stem: '<p>Hücumçu başqasının MAC-ini Source MAC kimi yazaraq kadr göndərir və həmin MAC-ə gedən trafik ona yönəlir. Bu niyə işləyir?</p>',
          options: [
            { t: 'Switch Source MAC-i yoxlamır və başqa portdan görünəndə girişi dərhal yeniləyir.', ok: true, why: 'Öyrənmə heç bir doğrulama tələb etmir. Hücumçunun portundan həmin MAC gələn kimi switch girişi hücumçunun portuna dəyişir və sonrakı kadrlar ora gedir.' },
            { t: 'Switch hər MAC üçün iki port saxlayır və trafiki hər ikisinə də göndərir, buna görə yavaşlayır.', why: 'Hər MAC üçün bir port yazılır. Hücum girişin dəyişməsi ilə işləyir, iki port saxlanması ilə yox.' },
            { t: 'Switch Destination MAC-dən öyrənir və hücumçu hədəf MAC kimi saxta ünvan yazır.', why: 'Switch Destination MAC-dən öyrənmir. Hücum Source MAC sahəsini saxtalaşdırmağa əsaslanır.' },
            { t: 'Aging bitənə qədər cədvəl dəyişmir, hücumçu bu müddəti yalnız gözləməlidir.', why: 'Cədvəl aging-i gözləmir. Yeni portdan gələn ilk kadrda giriş yenilənir.' },
          ] },
        { id: 'p1t7-q13', concept: 'domains', obj: 'Switch broadcast domain-i bölürmü',
          stem: '<p>Switch-in hər portu ayrı collision domain-dir. Bu o deməkdirmi ki, broadcast da hər portda ayrı qalır?</p>',
          options: [
            { t: 'Xeyr: switch broadcast-ı hamıya göndərir, yalnız collision domain-lər ayrılır.', ok: true, why: 'İki ayrı sualdır. Collision: "kim kiminlə toqquşa bilər?" (hər port ayrı). Broadcast: "broadcast kimə çatır?" (switch flood edir, hamıya). Broadcast domain-i router (və VLAN) ayırır.' },
            { t: 'Bəli: collision domain ayrılanda broadcast domain-lər də avtomatik ayrılır.', why: 'Bu iki anlayış bir-birindən asılı deyil. Switch collision-ı bölür, broadcast-ı bölmür.' },
            { t: 'Bəli, amma yalnız switch-in bütün portları full-duplex işləyəndə baş verir.', why: 'Duplex rejimi collision-a təsir edir, broadcast-a yox. Full-duplex olsa belə broadcast bütün portlara çatır.' },
            { t: 'Xeyr: switch broadcast kadrları qəbul etmir və atır, yalnız unicast ötürür.', why: 'Switch broadcast kadrları qəbul edir və flood edir. Atsaydı, ARP işləməzdi.' },
          ] },
        { id: 'p1t7-q14', concept: 'trouble', obj: 'Hər iki MAC var, ping yox',
          stem: '<p>PC-A ilə PC-B eyni switch-dədir. Cədvəldə hər iki MAC öz portunda görünür, amma ping işləmir. Növbəti addımın nədir?</p>',
          options: [
            { t: 'Layer 3-ü yoxlayıram: IP, mask, VLAN, host firewall. Switch öz işini görür.', ok: true, why: 'Hər iki MAC cədvəldə olması deyir ki, switch hər iki cihazdan kadr alıb və öyrənib: Layer 1-2 işləyir. Problem artıq yuxarıdadır.' },
            { t: 'Switch-i yenidən yükləyirəm, çünki MAC cədvəlinin xarab olduğunu düşünürəm.', why: 'Cədvəl düzgün doludur. Yenidən yükləmə səbəbi tapmadan edilən təxmindir və problemi həll etməz.' },
            { t: 'Aging müddətini artırıram ki, girişlər tez silinməsin və cədvəl dolu qalsın.', why: 'Girişlər artıq var və silinməyib. Aging bu problemlə əlaqəli deyil.' },
            { t: 'Kabelləri dəyişirəm, çünki portlar işləmir və cihazlar bir-birini görmür.', why: 'Portlar işləyir: switch hər iki cihazdan kadr alıb. Kabel problemi olsaydı, MAC-lər öyrənilməzdi.' },
          ] },
        { id: 'p1t7-q15', concept: 'mac-flap', obj: 'MAC flapping',
          stem: '<p>Log-da: <span class="m">Host 0001.4321.aaaa in vlan 1 is flapping between port Fa0/1 and port Fa0/2</span>. Ən ehtimal səbəb nədir?</p>',
          options: [
            { t: 'Eyni MAC iki port arasında növbələşir: loop və ya eyni MAC-in iki yerdə olması.', ok: true, why: 'Cədvəldə hər MAC üçün bir port olur. Kadr iki portdan növbə ilə gəlirsə, giriş dəyişib durur. Bu loop (kadr dövr edir) və ya duplicate/saxta MAC əlamətidir.' },
            { t: 'Fa0/2 portu müvəqqəti söndürülüb və switch ona yenidən qoşulmağa çalışır, bu log normaldır.', why: 'Söndürülmüş portdan kadr gəlmir, MAC ondan görünməz. Mesaj iki canlı portdan gələn kadrlara aiddir.' },
            { t: 'Aging müddəti çox qısadır və giriş tez-tez silinir.', why: 'Aging silmək haqqındadır. Flapping isə MAC-in bir portdan digərinə keçməsidir, silinmə yox.' },
            { t: 'Normaldır: switch ikisini də yazır və hər iki portdan istifadə edir.', why: 'Switch bir MAC üçün bir port yazır. Giriş bu qədər tez dəyişirsə, bu normal deyil və yoxlanmalıdır.' },
          ] },
        { id: 'p1t7-q17', concept: 'attack-flood', obj: 'MAC flooding switch-i hub-a çevirir',
          stem: '<p>MAC flooding hücumu nəticəsində switch niyə başqalarının trafikini hücumçuya göstərməyə başlayır?</p>',
          options: [
            { t: 'Cədvəl dolur, real MAC-lər öyrənilmir və unicast kadrlar flood olunur.', ok: true, why: 'Cədvəl dolu olanda switch yeni girişlər əlavə edə bilmir. Real istifadəçilərin MAC-i cədvəldə olmadığı üçün onların kadrları unknown unicast kimi flood olunur və hücumçu da onları alır.' },
            { t: 'Switch yaddaşı dolanda hub rejiminə keçmək üçün özünü söndürüb yenidən yüklənir.', why: 'Switch yenidən yüklənmir. Cədvəl dolu qalır və switch işləməyə davam edir, sadəcə bilinməyən unicast-ı flood edir.' },
            { t: 'Hücumçu switch-in routing table-ını dəyişir və trafik ona yönləndirilir.', why: 'Layer 2 switch-də routing table yoxdur. Hücum MAC cədvəlinin dolmasına əsaslanır.' },
            { t: 'Saxta MAC-lər real istifadəçilərin ARP cache-ini zəhərləyir.', why: 'ARP cache hostlardadır və bu hücum ona toxunmur. Hücum switch-in MAC cədvəlini hədəf alır, bu isə ARP spoofing-dən fərqlidir.' },
          ] },
        { id: 'p1t7-q18', concept: 'attack-flood', obj: 'MAC flooding müdafiəsi',
          stem: '<p>MAC flooding-ə qarşı switch səviyyəsində <b>ən birbaşa</b> müdafiə hansıdır?</p>',
          options: [
            { t: 'Port security: hər portda MAC sayına limit qoymaq.', ok: true, why: 'Hücum bir portdan minlərlə MAC öyrətməklə işləyir. Port security hər portun MAC sayını məhdudlaşdırır və limit aşılanda portu söndürür və ya kadrları atır.' },
            { t: 'Aging müddətini 10 saniyəyə endirmək ki, saxta girişlər tez silinsin və cədvəl dolmasın.', why: 'Hücumçu saniyədə minlərlə yeni MAC göndərə bilir, qısa aging cədvəli yenə doldurar. Mənbəni dayandırmadan aging kömək etmir.' },
            { t: 'Bütün portları eyni VLAN-a qoymaq ki, cədvəl vahid olsun.', why: 'Bu, trafikin bir VLAN-a yığılmasını artırır, hücumçunun görə biləcəyi trafiki çoxaldır. Müdafiə deyil.' },
            { t: 'Switch-in ARP cache-ini təmizləməyi planlaşdırmaq.', why: 'Switch ARP cache ilə deyil, MAC address table ilə işləyir. Bu iki ayrı cədvəldir.' },
          ] },
        { id: 'p1t7-q16', concept: 'domains', obj: 'Switch kadrı dəyişirmi',
          stem: '<p>Switch kadrı bir portdan digərinə ötürəndə kadrın nəyini dəyişir?</p>',
          options: [
            { t: 'Heç nəyi: kadr eyni Source və Destination MAC ilə çıxır.', ok: true, why: 'Switch kadrı olduğu kimi ötürür. MAC-ləri və başqa sahələri dəyişən router-dir: o, hər link üçün yeni Ethernet başlığı qurur.' },
            { t: 'Source MAC-i öz MAC-i ilə əvəz edir, çünki hər cihaz kadrı yenidən yazır.', why: 'Switch Source MAC-i dəyişsəydi, öyrənmə işləməzdi: hədəf kimin göndərdiyini bilməzdi.' },
            { t: 'IP başlığındakı TTL-i 1 azaldır.', why: 'Switch IP başlığına baxmır. TTL-i router azaldır (altıncı mövzu).' },
            { t: 'Destination MAC-i növbəti cihazın MAC-i ilə əvəz edir.', why: 'Destination MAC-i əvəz etmək router-in işidir. Switch Destination MAC-ə yalnız baxır və portu seçir.' },
          ] },
      ],
    },
  });
})();
