(function () {
  const pick = PT.pick; const R = PT.randInt; const shuffle = PT.shuffle;
  const rnd = (lo, hi) => lo + R(hi - lo + 1);
  const F = n => 'FastEthernet0/' + n;
  const brRe = /^(do\s+)?sh\w*\s+ip\s+int\w*\s+br/i;
  const last = d => d.history[d.history.length - 1] || '';
  const mk = d => (d.mark = d.mark || {});
  const norm = r => String(r).toLowerCase().replace(/[\/,]/g, ' ').replace(/\s+/g, ' ').trim();
  const rx = re => r => re.test(String(r).trim().toLowerCase());
  const e = s => String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
  const m = s => '<span class="m">' + e(s) + '</span>';

  /* ---- mode machine used by the quiz generators ---- */
  const MODE_N = { user: 'User EXEC', priv: 'Privileged EXEC', config: 'Global configuration', if: 'Interface configuration' };
  const SUF = { user: '>', priv: '#', config: '(config)#', if: '(config-if)#' };
  const promptOf = (h, m) => h + SUF[m];
  const TR = {
    user: { 'enable': 'priv' },
    priv: { 'configure terminal': 'config', 'disable': 'user' },
    config: { 'interface fa0/1': 'if', 'end': 'priv', 'exit': 'priv' },
    if: { 'exit': 'config', 'end': 'priv', 'interface fa0/2': 'if' },
  };
  const MODES = ['user', 'priv', 'config', 'if'];
  const dist = (a, b) => { if (a === b) return 0; const seen = { [a]: 0 }; const q = [a]; while (q.length) { const x = q.shift(); for (const c of Object.keys(TR[x])) { const y = TR[x][c]; if (!(y in seen)) { seen[y] = seen[x] + 1; if (y === b) return seen[y]; q.push(y); } } } return 99; };
  const INVALID = { user: ['configure terminal', 'interface fa0/1', 'end'], priv: ['interface fa0/1', 'end'], config: ['configure terminal'], if: ['configure terminal'] };
  const HOSTS = ['SW1', 'SW2', 'Core-SW', 'Access1', 'Lab-SW', 'Switch', 'DIST-SW', 'HQ-SW', 'Floor2'];
  const GOALS = { priv: ['show running-config', 'show startup-config', 'copy running-config startup-config', 'reload'], config: ['hostname LAB-SW', 'ip default-gateway 192.168.1.1', 'interface fa0/5'], if: ['shutdown', 'description PC-A', 'no shutdown'] };

  PT.topic({
    id: 'p1t9',
    objectives: [
      'IOS rejimlərini (User EXEC, Privileged EXEC, Global config, Interface config) prompt-dan tanımaq və aralarında keçmək',
      '?, Tab və qısaltma ilə əmri tapmaq, üç xəta mesajını oxuyub səbəbi müəyyən etmək',
      'hostname, interface description, shutdown / no shutdown və switch-in idarəetmə IP-sini yazıb show ilə yoxlamaq',
      'running-config ilə startup-config fərqini izah etmək və konfiqurasiyanı düzgün saxlamaq',
    ],
    explain: PT.frag['p1/t09/explain'], cheat: PT.frag['p1/t09/cheat'],

    lab: {
      title: 'Lab 9: CLI-da işlə, yoxla və saxla',
      goal: 'Praktika terminalında rejimlərdə hərəkət etmək, kömək və xəta mesajlarını işlətmək, əmr yazıb show ilə yoxlamaq, konfiqurasiyanı saxlayıb saxlamamağın nəticəsini görmək, sonra Packet Tracer-də switch-i CLI ilə qurmaq.',
      why: 'Router, VLAN, ACL, NAT və OSPF bundan sonra hamısı bu əmr xətti ilə qurulur. Rejimi bilmək, xətanı oxumaq və yazdığını yoxlamaq (əmr + proof) real işdə də hər konfiqurasiyanın əsasıdır.',
      minutes: 55,
      finish: 'Rejimlərdə hərəkət edir, xətaları oxuyur, əmr yazıb yoxlayır və konfiqurasiyanı saxlayırsan. Bu, Hissə 1-in sonudur: ünvanlar, subnetting, layer-lər, ARP, ICMP, switch, Packet Tracer və CLI. Növbəti hissədə router-lərə keçirik: şəbəkələri necə birləşdirmək olar.',
      steps: [
        { id: 's1', title: 'Plan', type: 'info', button: 'Başlayaq',
          body: '<p>Bu labda iki yerdə işləyirsən: əvvəl bu səhifənin <b>praktika terminalında</b> (IOS-a bənzəyir, real IOS deyil), sonda isə <b>Packet Tracer</b>-də.</p><ol><li>Switch-ə girişdən konfiqurasiyaya qədər addımları düz.</li><li>Rejimlərdə gəz və hostname-i dəyiş.</li><li><span class="m">?</span> ilə kömək al.</li><li>Üç xəta mesajını özün yarat və oxu.</li><li>Nəticəni əvvəl <b>proqnozlaşdır</b>, sonra yoxla.</li><li>Əmr yaz və <span class="m">show</span> ilə sübut et.</li><li>Konfiqurasiyanı saxlamasan nə baş verdiyini gör.</li><li>İki ticket və Packet Tracer-də eyni işi et.</li></ol>' },

        { id: 's2', title: 'Girişdən ilk konfiqurasiyaya', type: 'order',
          body: '<p>Switch-ə console-dan girmisən. Prompt <span class="m">Switch&gt;</span>-dir. Məqsədin: switch-in adını <b>SW1</b> etmək və nəticəni görmək. Addımları düzgün sırayla düz (ilk iş yuxarıda).</p>',
          items: [
            { t: 'Switch> prompt-undasan (User EXEC)', why: 'Cihaza girəndə həmişə User EXEC-dən başlayırsan: yalnız sadə baxış.' },
            { t: 'enable yazırsan: prompt Switch# olur (Privileged EXEC)', why: 'Konfiqurasiya rejiminə birbaşa keçə bilməzsən. Əvvəl Privileged EXEC-ə keçmək lazımdır.' },
            { t: 'configure terminal yazırsan: prompt Switch(config)# olur', why: 'Cihazın ümumi ayarlarını dəyişmək üçün Global configuration rejimi lazımdır.' },
            { t: 'hostname SW1 yazırsan: prompt SW1(config)# olur', why: 'hostname Global configuration əmridir. Ad dəyişən kimi prompt-da dərhal görünür.' },
            { t: 'end yazırsan: prompt SW1# olur, sonra show running-config ilə yoxlayırsan', why: 'end config rejimindən Privileged EXEC-ə qaytarır. Yoxlama (proof) config-dən sonra və Privileged rejimində edilir.' },
          ],
          hints: ['Hər rejimdən növbəti rejimə keçid üçün ayrıca əmr lazımdır. İlk keçid hansıdır?'],
          after: '<p>Hər addımda prompt dəyişir. Prompt-a baxmaq vərdişi bundan sonra hər səhvdə sənə yol göstərəcək.</p>' },

        { id: 's3', title: 'Rejimlərdə gəz', type: 'terminal',
          body: '<p>Sağda cihazın vəziyyəti (rejim, ad, interface-lər) görünür. Hər əmrdən sonra ona bax.</p><ol><li><span class="m">enable</span> yaz.</li><li><span class="m">configure terminal</span> yaz.</li><li><span class="m">hostname SW1</span> yaz: prompt dəyişəcək.</li><li><span class="m">end</span> yaz.</li><li><span class="m">show running-config</span> yaz və hostname sətrini tap.</li></ol>',
          term: { kind: 'switch', hostname: 'Switch', title: 'Switch', ports: ['Fa0/1', 'Fa0/2', 'Fa0/3'], cables: { 'Fa0/1': 'PC-A', 'Fa0/2': 'PC-B' }, quick: ['enable', 'configure terminal', 'hostname SW1', 'end', 'show running-config'],
            goals: [
              { text: '<span class="m">enable</span> yaz', test: d => d.hist(/^en(a|ab|abl|able)?$/i) },
              { text: '<span class="m">configure terminal</span> yaz', test: d => d.hist(/^conf\w*\s+t\w*$/i) },
              { text: 'Ad <span class="m">SW1</span> olsun (prompt dəyişməlidir)', test: d => d.run.hostname === 'SW1' },
              { text: '<span class="m">end</span> ilə Privileged EXEC-ə qayıt (prompt <span class="m">SW1#</span>)', test: d => d.run.hostname === 'SW1' && d.mode === 'priv' },
              { text: '<span class="m">show running-config</span> işlət', test: d => d.hist(/^sh\w*\s+run/i) },
            ] },
          hints: ['Hər əmri ayrıca sətirdə yaz. Qısaltma da işləyir: <span class="m">conf t</span>.', 'Rejim dəyişəndə prompt-un sonu dəyişir: &gt;, #, (config)#.'],
          after: '<p>Hostname-i dəyişəndə prompt dərhal dəyişdi, <span class="m">show running-config</span> isə eyni adı göstərdi. Bu "əmr + proof"-un ilk nümunəsidir: yazdın, sonra yoxladın.</p>' },

        { id: 's4', title: 'Kömək al: ? və qısaltma', type: 'terminal',
          body: '<p>Əmrləri bilməsən, əmr xəttinin özündən soruş. Prompt <span class="m">Switch&gt;</span>-dir.</p><ol><li>Boş sətirdə <span class="m">?</span> yaz (Enter basma, kömək dərhal çıxır).</li><li><span class="m">show ?</span> yaz (<span class="m">show</span>, boşluq, <span class="m">?</span>).</li><li><span class="m">show ip ?</span> yaz.</li><li><span class="m">sh?</span> yaz (boşluq olmadan) və fərqi gör.</li></ol>',
          term: { kind: 'switch', hostname: 'Switch', title: 'Switch', ports: ['Fa0/1', 'Fa0/2'], cables: { 'Fa0/1': 'PC-A' }, quick: ['show ?', 'show ip ?'],
            goals: [
              { text: 'Boş sətirdə <span class="m">?</span> işlət', test: d => d.history.some(l => l === '?') },
              { text: '<span class="m">show ?</span> işlət', test: d => d.hist(/^sh\w*\s+\?$/i) },
              { text: '<span class="m">show ip ?</span> işlət', test: d => d.hist(/^sh\w*\s+ip\s+\?$/i) },
              { text: '<span class="m">sh?</span> (boşluqsuz) işlət', test: d => d.hist(/^sh\?$/i) },
            ] },
          hints: ['<span class="m">?</span> yazanda Enter basmaq lazım deyil: kömək dərhal çıxır.', '<span class="m">sh?</span> və <span class="m">sh ?</span> fərqlidir: birində boşluq yoxdur.'],
          after: '<p>Fərq: <span class="m">show ?</span> "show-dan sonra nə yazılır" soruşur. <span class="m">sh?</span> "sh ilə başlayan nə var" soruşur. İkisi də işlədir, amma müxtəlif suallara cavab verir.</p>' },

        { id: 's5', title: 'Xəta lab: üç mesajı özün yarat', type: 'terminal',
          body: '<p>Bu dəfə <b>qəsdən səhv</b> et. Hər xəta mesajından <b>birini</b> özün yarat. Prompt <span class="m">Switch&gt;</span>-dir (User EXEC). Hər mesajın nə dediyinə diqqətlə bax: xəta səni düzəltməyə yönəldir.</p>',
          term: { kind: 'switch', hostname: 'Switch', title: 'Switch', ports: ['Fa0/1', 'Fa0/2'], cables: { 'Fa0/1': 'PC-A' },
            goals: [
              { text: '<span class="m">% Incomplete command.</span> mesajını yarat', test: d => (d.errKinds.incomplete || 0) >= 1 },
              { text: '<span class="m">% Invalid input detected at \'^\' marker.</span> mesajını yarat', test: d => (d.errKinds.invalid || 0) >= 1 },
              { text: '<span class="m">% Ambiguous command</span> mesajını yarat', test: d => (d.errKinds.ambiguous || 0) >= 1 },
            ] },
          hints: ['Incomplete: əmrin yarısını yaz. Məsələn əmr bir söz tələb edir, sən tək sözü yaz.', 'Ambiguous: bir hərf yaz ki, bir neçə əmr onunla başlasın. User EXEC-də <span class="m">enable</span> və <span class="m">exit</span> var.', 'Invalid: birinci söz düzgün olsun, ikinci söz səhv: məsələn <span class="m">show ipp</span>. Birinci söz səhv olsa, User EXEC-də başqa mesaj çıxır.'],
          solution: 'Incomplete: <span class="m">show</span> (tək). Invalid: <span class="m">show ipp</span> (ikinci söz səhv). Ambiguous: <span class="m">e</span> (enable və exit eyni hərflə başlayır).',
          after: '<p>Üç mesaj üç fərqli şeydir: <b>Incomplete</b> = əmr yarımçıq, <b>Invalid</b> = tanınmadı (^ yerini göstərir), <b>Ambiguous</b> = qısaltma birdən çox əmrə uyğundur.</p><p>Əlavə: <span class="m">shw</span> kimi <b>birinci söz</b> səhv olsa, User və Privileged EXEC-də başqa mesaj çıxır (<span class="m">Unknown command or computer name</span>): IOS sözü hostname sayıb DNS-ə baxır. Ona görə real cihazlarda çox vaxt <span class="m">no ip domain-lookup</span> yazılır.</p>' },

        { id: 's6', title: 'Mesajı oxu: hansı xəta?', type: 'form',
          body: '<p>İndi tərsinə işlə: əmr və prompt verilib, <b>nə olacağını</b> deyirsən. Hər sətirdə yaz: <b>incomplete</b>, <b>invalid</b>, <b>ambiguous</b> və ya <b>xəta yoxdur</b> (əmr işləyir).</p><pre class="pre"><span class="p">Switch&gt;</span>sh ip int br\n<span class="p">Switch#</span>co\n<span class="p">Switch(config)#</span>hostname\n<span class="p">Switch&gt;</span>show running-config\n<span class="p">Switch(config-if)#</span>shutdwn</pre>',
          fields: [
            { label: '1. <span class="m">sh ip int br</span> (User EXEC)', placeholder: 'xəta növü', check: rx(/^(x[eə]ta yoxdur|yoxdur|yox|no error|none|işləyir|isleyir|ok)$/), wrong: 'Hər söz unikaldır (sh → show, int → interface, br → brief). Qısaltma işləyir.' },
            { label: '2. <span class="m">co</span> (Privileged EXEC)', placeholder: 'xəta növü', check: rx(/ambig/), wrong: 'Bu rejimdə hansı əmrlər <span class="m">co</span> ilə başlayır? Configure və copy.' },
            { label: '3. <span class="m">hostname</span> (config rejimi)', placeholder: 'xəta növü', check: rx(/incomp/), wrong: 'Əmr tanındı, amma ad (argument) çatışmır.' },
            { label: '4. <span class="m">show running-config</span> (User EXEC)', placeholder: 'xəta növü', check: rx(/invalid/), wrong: 'Əmr düzgün yazılıb, amma bu rejimdə tanınmır: running-config yalnız Privileged EXEC-dədir.' },
            { label: '5. <span class="m">shutdwn</span> (interface config)', placeholder: 'xəta növü', check: rx(/invalid/), wrong: 'Yazı səhvidir: əmr tanınmır. ^ işarəsi s hərfindən sonrakı yeri göstərərdi.' },
          ],
          hints: ['Üç söz: incomplete (yarımçıq), invalid (tanınmadı), ambiguous (birdən çox uyğun). Və ya əmr işləyir.', 'Əvvəl prompt-a bax: əmr bu rejimdə mövcuddurmu?'],
          solution: '1: xəta yoxdur. 2: ambiguous. 3: incomplete. 4: invalid (səhv rejim). 5: invalid (yazı səhvi).',
          after: '<p>4-cü nümunə vacibdir: <b>düzgün yazılmış əmr də "invalid" verə bilər, çünki rejim səhvdir</b>. Əvvəl prompt, sonra yazı.</p>' },

        { id: 's7', title: 'Əvvəl proqnoz ver: interface statusları', type: 'form',
          body: '<p>SW1-in interface-ləri belədir:</p><ul><li><span class="m">Fa0/1</span>: PC-A qoşulub, konfiqurasiyada <span class="m">shutdown</span> yoxdur.</li><li><span class="m">Fa0/2</span>: PC-B qoşulub, interface-də <span class="m">shutdown</span> yazılıb.</li><li><span class="m">Fa0/3</span>: heç nə qoşulmayıb.</li><li><span class="m">Vlan1</span>: IP verilib və <span class="m">no shutdown</span> edilib.</li></ul><p><span class="m">show ip interface brief</span> yazsan, hər birinin <b>Status</b> və <b>Protocol</b> sütunu nə olacaq? Yaz: məsələn <span class="m">up up</span>, <span class="m">down down</span> və ya <span class="m">administratively down down</span>.</p>',
          fields: [
            { label: 'Fa0/1', placeholder: 'status protocol', check: r => norm(r) === 'up up', wrong: 'Kabel qoşulub və interface söndürülməyib. Link işləyir.' },
            { label: 'Fa0/2', placeholder: 'status protocol', check: r => norm(r) === 'administratively down down', wrong: 'Kabel qoşulub, amma kimsə interface-də shutdown yazıb. Bunun üçün xüsusi status var.' },
            { label: 'Fa0/3', placeholder: 'status protocol', check: r => norm(r) === 'down down', wrong: 'Heç nə qoşulmayıb, amma interface söndürülməyib. Fiziki link yoxdur.' },
            { label: 'Vlan1', placeholder: 'status protocol', check: r => norm(r) === 'up up', wrong: 'Vlan1 no shutdown olub. Switch-də ən azı bir port up olanda Vlan1 də up olur.' },
          ],
          hints: ['Üç hal var: işləyir (up up), fiziki link yoxdur (down down), inzibati söndürülüb (administratively down down).', 'Vlan1 virtual interface-dir. O, switch-də ən azı bir port up olanda up olur.'],
          solution: 'Fa0/1: up up. Fa0/2: administratively down down (shutdown yazılıb). Fa0/3: down down (kabel yoxdur). Vlan1: up up (shutdown deyil və Fa0/1 up-dır).',
          after: '<p>İndi bunu terminalda yoxlayaq.</p>' },

        { id: 's8', title: 'Proqnozu terminalda yoxla', type: 'terminal',
          body: '<p>Bu terminal əvvəlki addımdakı switch-dir: hostname <span class="m">SW1</span>, Fa0/2 shutdown, Fa0/3-də kabel yoxdur. Əvvəlcə <span class="m">show ip interface brief</span> yaz və proqnozunla müqayisə et. Sonra <span class="m">show interfaces status</span> işlət: bu switch-də portların qısa siyahısıdır.</p>',
          term: { kind: 'switch', hostname: 'SW1', title: 'SW1', ports: ['Fa0/1', 'Fa0/2', 'Fa0/3'], cables: { 'Fa0/1': 'PC-A', 'Fa0/2': 'PC-B' }, quick: ['show ip interface brief', 'show interfaces status'],
            initial: { ifs: { 'Fa0/2': { shut: true, desc: 'PC-B' }, 'Vlan1': { shut: false, ip: '192.168.1.2', mask: '255.255.255.0' } } },
            goals: [
              { text: '<span class="m">show ip interface brief</span> işlət', test: d => d.history.some(l => brRe.test(l)) },
              { text: '<span class="m">show interfaces status</span> işlət', test: d => d.hist(/^sh\w*\s+int\w*\s+st/i) },
            ] },
          hints: ['Əmr User EXEC-də də işləyir, enable lazım deyil.'],
          after: '<p><span class="m">show interfaces status</span>-də eyni üç hal başqa sözlərlə yazılır: <b>connected</b> (işləyir), <b>notconnect</b> (link yoxdur), <b>disabled</b> (shutdown). Proqnozun uyğun gəldisə, statusları oxumağı bacarırsan. Uyğun gəlmədisə, hansı qaydanı qarışdırdığını tap: Fa0/2 ilə Fa0/3 çox qarışdırılır.</p>' },

        { id: 's9', title: 'Əmr + proof: shutdown və geri', type: 'terminal',
          body: '<p>Hər dəyişikliyi əmrlə et və dərhal <b>show ilə sübut et</b>. Fa0/2-də PC-B qoşulub.</p><ol><li><span class="m">enable</span>, <span class="m">configure terminal</span>, <span class="m">interface fa0/2</span>.</li><li><span class="m">description PC-B</span> yaz.</li><li><span class="m">shutdown</span> yaz.</li><li><span class="m">end</span>, sonra <span class="m">show ip interface brief</span>: Fa0/2 <b>administratively down</b> olmalıdır.</li><li>Geri qayıt: <span class="m">configure terminal</span>, <span class="m">interface fa0/2</span>, <span class="m">no shutdown</span>, <span class="m">end</span>, yenidən <span class="m">show ip interface brief</span>: Fa0/2 <b>up</b> olmalıdır.</li></ol>',
          term: { kind: 'switch', hostname: 'SW1', title: 'SW1', ports: ['Fa0/1', 'Fa0/2', 'Fa0/3'], cables: { 'Fa0/1': 'PC-A', 'Fa0/2': 'PC-B' }, quick: ['enable', 'configure terminal', 'interface fa0/2', 'shutdown', 'no shutdown', 'end', 'show ip interface brief'],
            goals: [
              { text: 'Fa0/2-yə <span class="m">description PC-B</span> yaz', test: d => d.run.ifs[F(2)].desc === 'PC-B' },
              { text: 'Fa0/2-ni <span class="m">shutdown</span> et və <span class="m">show ip interface brief</span> ilə <b>administratively down</b> gör', test: d => { if (d.run.ifs[F(2)].shut && brRe.test(last(d))) mk(d).p1 = true; return !!mk(d).p1; } },
              { text: '<span class="m">no shutdown</span> yaz və <span class="m">show ip interface brief</span> ilə Fa0/2-nin yenidən <b>up</b> olduğunu gör', test: d => { if (mk(d).p1 && !d.run.ifs[F(2)].shut && brRe.test(last(d))) mk(d).p2 = true; return !!mk(d).p2; } },
            ] },
          hints: ['Rejim zənciri: <span class="m">enable</span> → <span class="m">configure terminal</span> → <span class="m">interface fa0/2</span>. Prompt-a bax.', '<span class="m">show</span> əmrini config rejimindən çıxandan sonra (end) yaz.', 'Fa0/2-də kabel var, ona görə <span class="m">no shutdown</span>-dan sonra status up olur. Fa0/3-də kabel olmadığı üçün onda <span class="m">no shutdown</span> kömək etməzdi.'],
          after: '<p>Burada gördüyün nümunə bütün kursun şablonudur: <b>əmr yaz, sonra yoxla</b>. <span class="m">shutdown</span> statusu <b>administratively down</b> etdi, <span class="m">no shutdown</span> isə onu geri qaytardı. Kabel olmayan porta <span class="m">no shutdown</span> yazsan, status <b>down</b> qalardı (fiziki link yoxdur).</p>' },

        { id: 's10', title: 'Tərsinə: konfiqurasiyadan əmrləri tap', type: 'form',
          body: '<p>Kimsə sənə bu hissəni göndərib, <span class="m">show running-config</span>-dən:</p><pre class="pre">hostname DIST-SW\n!\ninterface FastEthernet0/5\n description Printer\n shutdown\n!\ninterface Vlan1\n ip address 10.10.10.5 255.255.255.0\n!\nend</pre><p>Bu çıxışa əsasən cavab ver.</p>',
          fields: [
            { label: 'Privileged EXEC-də prompt necə görünür?', placeholder: 'prompt', check: r => /^dist-sw#$/i.test(String(r).trim()), wrong: 'Hostname + rejim işarəsi. Privileged EXEC üçün hansı işarə?' },
            { label: 'Fa0/5-in description-ı', placeholder: 'mətn', check: rx(/^printer$/), wrong: 'Interface bölməsindəki <span class="m">description</span> sətrinə bax.' },
            { label: 'Fa0/5-in statusu (show ip interface brief)', placeholder: 'status protocol', check: r => norm(r) === 'administratively down down', wrong: 'Interface-də shutdown sətri var. Bu hansı statusu verir?' },
            { label: 'Fa0/5-i aktiv etmək üçün əmr', placeholder: 'əmr', check: rx(/^no\s+shutdown$/), wrong: 'Əmri ləğv etmək üçün əvvəlinə nə yazılır?' },
            { label: 'Vlan1 inzibati söndürülüb? (bəli / xeyr)', placeholder: 'bəli / xeyr', answers: ['xeyr', 'yox', 'no', 'xeyir'], wrong: 'Vlan1 bölməsində <span class="m">shutdown</span> sətri varmı? Yoxdursa, interface söndürülməyib.' },
          ],
          hints: ['<span class="m">shutdown</span> sətri interface-in bölməsində yazılıbsa, o interface söndürülüb. Sətir yoxdursa, söndürülməyib.', 'Hostname + # = Privileged EXEC prompt-u.'],
          solution: 'DIST-SW#. Printer. administratively down down. no shutdown (interface fa0/5 rejimində). Xeyr: Vlan1-də shutdown sətri yoxdur.',
          after: '<p>Bu real iş vərdişidir: başqasının konfiqurasiyasını oxuyub nə baş verdiyini çıxarmaq. <b>shutdown sətri varsa söndürülüb, yoxdursa aktivdir</b>: running-config-də "no shutdown" sətri görünmür.</p>' },

        { id: 's11', title: 'Saxla və itir: reload lab', type: 'terminal',
          body: '<p>İndi konfiqurasiyanı saxlamağın nəticəsini özün gör. Bu cihazda hələ heç nə saxlanmayıb.</p><ol><li><span class="m">enable</span>, <span class="m">configure terminal</span>, <span class="m">hostname LAB-SW</span>, <span class="m">end</span>. (prompt <span class="m">LAB-SW#</span> olacaq)</li><li><b>Saxlamadan</b> <span class="m">reload</span> yaz. "Save? [yes/no]" soruşanda <span class="m">no</span> yaz, "Proceed with reload?" soruşanda Enter bas. Cihaz yenidən açılır: ad nə olacaq?</li><li>Yenidən <span class="m">enable</span>, <span class="m">configure terminal</span>, <span class="m">hostname LAB-SW</span>, <span class="m">end</span> yaz.</li><li>İndi <span class="m">copy running-config startup-config</span> yaz (Enter bas) və yenidən <span class="m">reload</span> et. Bu dəfə ad qalacaq?</li></ol>',
          term: { kind: 'switch', hostname: 'Switch', title: 'Switch', ports: ['Fa0/1', 'Fa0/2'], cables: { 'Fa0/1': 'PC-A' }, quick: ['enable', 'configure terminal', 'hostname LAB-SW', 'end', 'reload', 'copy running-config startup-config', 'show startup-config'],
            goals: [
              { text: 'Hostname-i <span class="m">LAB-SW</span> et', test: d => { if (d.run.hostname === 'LAB-SW') mk(d).changed = true; return !!mk(d).changed; } },
              { text: '<b>Saxlamadan</b> reload et: ad yenidən <span class="m">Switch</span> olmalıdır', test: d => { if (mk(d).changed && !mk(d).lost && d.reloads >= 1 && d.run.hostname === 'Switch') { mk(d).lost = true; mk(d).rl = d.reloads; } return !!mk(d).lost; } },
              { text: 'Yenidən <span class="m">LAB-SW</span> yaz, <span class="m">copy running-config startup-config</span> et, reload et: ad <b>qalmalıdır</b>', test: d => { if (mk(d).lost && d.reloads > mk(d).rl && d.startHas('hostname LAB-SW') && d.run.hostname === 'LAB-SW') mk(d).kept = true; return !!mk(d).kept; } },
            ] },
          hints: ['Reload zamanı IOS iki sual verir: "Save? [yes/no]" (no yaz) və "Proceed with reload? [confirm]" (Enter bas).', 'Reload-dan sonra cihaz yenidən User EXEC-də (&gt;) başlayır: <span class="m">enable</span> yaz.', 'Saxlamaq üçün: <span class="m">copy running-config startup-config</span>, sonra "Destination filename?" sualında Enter.', 'Birinci reload-dan əvvəl səhvən saxlasan: <span class="m">erase startup-config</span> yaz (Enter ilə təsdiq), sonra <span class="m">reload</span> et, ad yenidən Switch olacaq.'],
          after: '<p>Birinci reload-da ad itdi, çünki dəyişiklik yalnız <b>running-config-də</b> idi (RAM). İkinci reload-da ad qaldı, çünki <span class="m">copy running-config startup-config</span> onu <b>startup-config-ə</b> yazmışdı (NVRAM). Cihaz açılanda startup-config oxuyur: nə yazılıbsa, o qayıdır.</p>' },

        { id: 's12', title: 'Ticket 1: elektrik kəsildi, konfiqurasiya yoxdur', type: 'choice',
          body: '<p>Əməliyyat gecəsi switch-in elektriki kəsilib, sonra yenidən açılıb. Səhər görürsən ki, switch <span class="m">Switch&gt;</span> kimi açılıb və dünən yazdığın VLAN 1 IP-si, hostname və bütün description-lar yoxdur. Dünən heç nə saxlamamışdın. Ən yaxşı izah hansıdır?</p>',
          options: [
            { t: 'Dəyişikliklər yalnız running-config-də (RAM) idi. startup-config-ə yazılmadığı üçün söndürülmə onları itirdi.', ok: true, why: 'running-config RAM-dadır və cihaz söndürüləndə silinir. Açılışda cihaz startup-config-i (NVRAM) oxuyur. Orada dəyişiklik yox idi, ona görə cihaz əvvəlki (köhnə və ya boş) konfiqurasiya ilə açıldı. Həll: konfiqurasiyanı yazandan sonra <span class="m">copy running-config startup-config</span>.' },
            { t: 'NVRAM da RAM kimi söndürüləndə silinir, ona görə heç bir konfiqurasiya qala bilməzdi.', why: 'NVRAM məhz söndürüləndə də saxlayan yaddaşdır. Saxlanmış konfiqurasiya orada qalır. Problem yazmaq yox, saxlamamaqdır.' },
            { t: 'IOS bir neçə saat sonra konfiqurasiyanı özü silir, ona görə hostname itib.', why: 'IOS belə bir şey etmir. Konfiqurasiya yalnız söndürülməklə (RAM-da olduğuna görə) və ya sən siləndə itir.' },
            { t: 'Switch factory reset olub, çünki elektrik kəsilməsi hər zaman erase startup-config yerinə keçir.', why: 'Elektrik kəsilməsi erase əmri deyil. Əgər startup-config-də konfiqurasiya olsaydı, o qalardı. Burada itki saxlamamaqdan gəlir.' },
          ],
          hints: ['Cihaz açılanda hansı konfiqurasiyanı oxuyur: running yoxsa startup?'],
          after: '<p>Əməliyyat qaydası: <b>konfiqurasiyanı yazdın, show ilə yoxladın, sonra saxla.</b> İkincisi və üçüncüsü olmadan işini bitmiş saymırsan.</p>' },

        { id: 's13', title: 'Ticket 2: PC-B işləmir: tap, düzəlt, saxla', type: 'terminal',
          body: '<p>PC-B switch-ə qoşulub, amma şəbəkəyə çıxa bilmir. Fa0/2 linki qırmızıdır. Kabel dəyişdirilib, problem qalıb. Aşağıdakı switch-ə qoşul və:</p><ol><li>Əvvəl <span class="m">show ip interface brief</span> ilə vəziyyəti gör.</li><li>Səbəbi tap və düzəlt.</li><li>Düzəlişi yoxla (show) və <b>saxla</b>.</li></ol>',
          term: { kind: 'switch', hostname: 'SW1', title: 'SW1', ports: ['Fa0/1', 'Fa0/2', 'Fa0/3'], cables: { 'Fa0/1': 'PC-A', 'Fa0/2': 'PC-B', 'Fa0/3': 'PC-C' }, quick: ['show ip interface brief', 'enable', 'configure terminal', 'interface fa0/2', 'no shutdown', 'end', 'copy running-config startup-config'],
            initial: { ifs: { 'Fa0/2': { shut: true } } },
            goals: [
              { text: 'Problemi tap: <span class="m">show ip interface brief</span> işlət', test: d => d.history.some(l => brRe.test(l)) },
              { text: 'Fa0/2-ni aktiv et (<span class="m">no shutdown</span>)', test: d => d.run.ifs[F(2)].shut === false },
              { text: 'Düzəlişi yoxla: show ilə Fa0/2 <b>up</b>', test: d => { if (d.run.ifs[F(2)].shut === false && brRe.test(last(d))) mk(d).chk = true; return !!mk(d).chk; } },
              { text: 'Düzəlişi <b>saxla</b> (startup-config-də də Fa0/2 aktiv olsun)', test: d => !!(d.start && d.start.ifs[F(2)] && d.start.ifs[F(2)].shut === false) },
            ] },
          hints: ['Link qırmızıdır, kabel dəyişib. <span class="m">show ip interface brief</span>-də Fa0/2-nin Status-una bax: "administratively down" nəyi göstərir?', 'Düzəliş: <span class="m">enable</span> → <span class="m">configure terminal</span> → <span class="m">interface fa0/2</span> → <span class="m">no shutdown</span> → <span class="m">end</span>.', 'Saxlamaq üçün Privileged EXEC-də <span class="m">copy running-config startup-config</span>.'],
          after: '<p>Əvvəl <b>proof</b> ilə səbəbi tapdın (administratively down), kabel dəyişməyə ehtiyac yox idi. Sonra düzəltdin, yoxladın və saxladın. Bu üç addım ("tap, düzəlt, yoxla və saxla") real incident-lərdə də eynidir.</p>' },

        { id: 's14', title: 'Packet Tracer-də qur: switch-i CLI ilə', type: 'ptsteps',
          body: '<p>İndi eyni işi Packet Tracer-də et. Packet Tracer-də üç PC və switch topologiyasını aç (üç PC və switch, PC-lərin IP-ləri <span class="m">192.168.1.10</span>, <span class="m">.11</span>, <span class="m">.12</span>) və ya yenidən qur.</p>',
          checks: [
            { t: 'Switch-in üstünə klik et və <b>CLI</b> nişanına keç. <span class="m">Press RETURN to get started!</span> yazılıbsa, Enter bas.' },
            { t: '<span class="m">enable</span> yaz, sonra <span class="m">configure terminal</span>.' },
            { t: 'Ad ver: <span class="m">hostname SW1</span>. Prompt dəyişdimi?' },
            { t: 'İdarəetmə IP-si ver:', cmd: ['interface vlan 1', 'ip address 192.168.1.2 255.255.255.0', 'no shutdown', 'end'] },
            { t: '<span class="m">show ip interface brief</span> yaz və Vlan1 sətrinə bax.' },
            { t: 'Konfiqurasiyanı saxla: <span class="m">copy running-config startup-config</span> (Enter bas).' },
            { t: 'PC-A-da <i>Desktop → Command Prompt</i> aç və yaz:', cmd: 'ping 192.168.1.2' },
          ],
          button: 'Hamısını etdim' },

        { id: 's15', title: 'Packet Tracer nəticəsini yaz', type: 'form',
          body: '<p>Packet Tracer-də gördüklərini yaz.</p>',
          fields: [
            { label: 'Vlan1-in Status və Protocol-u (show ip interface brief)', placeholder: 'status protocol', check: r => norm(r) === 'up up', wrong: 'Vlan1 no shutdown olub, switch-də PC-lərin portları up-dır. Əgər sənin Packet Tracer-də fərqlidirsə, əvvəl Fast Forward Time bas və yenidən yoxla (portlar hələ hazır olmaya bilər).' },
            { label: 'Ping-dən 4 paketin neçəsi uğurlu oldu?', placeholder: 'rəqəm', check: r => ['3', '4'].includes(String(r).trim()), wrong: 'Ping ya hamısı (4), ya da ilk paket ARP səbəbindən itərsə 3 olmalıdır. Başqa rəqəm görürsənsə, IP-ləri və Vlan1-in no shutdown olduğunu yoxla.' },
          ],
          hints: ['Əgər ping 0 paket verirsə: Vlan1 "no shutdown" olub? PC-A-nın IP-si <span class="m">192.168.1.10/24</span>-dür?'],
          solution: 'Vlan1: up up. Ping: 4 paketdən 3 və ya 4 uğurlu (ilk paket çox vaxt ARP səbəbindən itir).',
          after: 'Switch Layer 2 cihazıdır: IP ünvanı yalnız onu idarə etmək üçündür. Kadr ötürmək üçün isə switch-in IP-si heç vaxt lazım olmayıb.</p>' },

        { id: 's16', title: 'Packet Tracer-də poz: shutdown', type: 'ptsteps',
          body: '<p>İndi bilərəkdən poz və nəticəni gör.</p>',
          checks: [
            { t: 'Switch CLI-ında <span class="m">configure terminal</span> yaz, sonra:', cmd: ['interface fa0/1', 'shutdown', 'end'] },
            { t: 'Topologiyaya bax: PC-A ilə switch arasındakı linkin işığı necə dəyişdi?' },
            { t: '<span class="m">show ip interface brief</span> yaz və Fa0/1-in Status-una bax.' },
            { t: 'PC-A-da yenidən <span class="m">ping 192.168.1.2</span> yaz.' },
          ],
          button: 'Etdim' },

        { id: 's17', title: 'Pozulanın nəticəsi', type: 'form',
          body: '<p>Nəticəni yaz, sonra düzəlt.</p>',
          fields: [
            { label: 'Fa0/1-in Status-u (show ip interface brief)', placeholder: 'status', check: rx(/admin/), wrong: 'Interface-də shutdown yazılıb. Bu hansı statusu verir?' },
            { label: 'Ping işləyirmi? (bəli / xeyr)', placeholder: 'bəli / xeyr', answers: ['xeyr', 'yox', 'no', 'xeyir'], wrong: 'PC-A-nın switch-ə linki söndürülüb: kadr switch-ə çatmır.' },
            { label: 'Düzəltmək üçün əmr (interface fa0/1 rejimində)', placeholder: 'əmr', check: rx(/^no\s+shutdown$/), wrong: 'shutdown-u ləğv etmək üçün əvvəlinə nə yazılır?' },
          ],
          hints: ['Düzəliş: <span class="m">configure terminal</span> → <span class="m">interface fa0/1</span> → <span class="m">no shutdown</span> → <span class="m">end</span>. Sonra link işığının yaşıl olmasını gözlə (Fast Forward Time) və yenidən ping at.'],
          solution: 'administratively down. Xeyr, ping işləmir. <span class="m">no shutdown</span>.',
          after: '<p>Fa0/1-i <span class="m">no shutdown</span> et, link yaşıl olsun, ping işləsin. Bunu <span class="m">copy running-config startup-config</span> ilə də saxla. İndi Hissə 1-i bitirdin: əsas biliklər tamamdır. Növbəti hissədə iki fərqli şəbəkəni necə birləşdirəcəyini öyrənəcəksən.</p>' },
      ],
    },

    quiz: {
      draw: 8,
      gens: [
        /* 1) hədəf rejimə ən az əmrlə gedən ardıcıllıq */
        () => {
          const pairs = [['user', 'priv'], ['user', 'config'], ['user', 'if'], ['priv', 'config'], ['priv', 'if'], ['config', 'if'], ['config', 'priv'], ['if', 'priv']];
          const pr = pick(pairs); const M = pr[0], need = pr[1]; const host = pick(HOSTS); const p = rnd(1, 7);
          const goal = pick(GOALS[need]);
          const sub = c => c.replace('fa0/1', 'fa0/' + p).replace('fa0/2', 'fa0/' + (p + 1));
          const d0 = dist(M, need);
          const P = (() => { const par = { [M]: null }; const q = [M]; while (q.length) { const x = q.shift(); for (const c of Object.keys(TR[x])) { const y = TR[x][c]; if (!(y in par)) { par[y] = { from: x, c }; q.push(y); } } } const out = []; let cur = need; while (par[cur]) { out.unshift(par[cur].c); cur = par[cur].from; } return out; })();
          const sim = seq => { let md = M; for (let i = 0; i < seq.length; i++) { const to = TR[md][seq[i]]; if (!to) return { ok: false, at: i, md }; md = to; } return { ok: md === need, md }; };
          const txt = seq => seq.map(sub).concat([goal]).join(' → ');
          const seen = new Set([P.join('|')]); const cands = [];
          const push = seq => { const k = seq.join('|'); if (seen.has(k)) return; const r = sim(seq); if (r.ok && seq.length <= d0) return; seen.add(k); cands.push(seq); };
          P.forEach((_, i) => push(P.filter((__, j) => j !== i)));
          Object.keys(TR[need]).forEach(c1 => { const X = TR[need][c1]; if (X === need) return; Object.keys(TR[X]).forEach(c2 => { if (TR[X][c2] === need) push(P.concat([c1, c2])); }); });
          Object.keys(TR[M]).forEach(c => { if (c !== P[0]) push([c].concat(P.slice(1))); });
          if (P.length >= 2) push([P[1], P[0]].concat(P.slice(2)));
          INVALID[M].forEach(c => push([c].concat(P.slice(1))));
          const L0 = txt(P).length; let pickd = null;
          for (let t = 0; t < 60 && !pickd; t++) { const sel = shuffle(cands).slice(0, 3); const ls = sel.map(x => txt(x).length); if (L0 < Math.max.apply(null, ls) * 1.15 && L0 > Math.min.apply(null, ls) / 1.15) pickd = sel; }
          if (!pickd) pickd = shuffle(cands).slice(0, 3);
          const set = shuffle([P].concat(pickd));
          const modesAlong = (() => { let md = M; return P.map(c => { md = TR[md][c]; return md; }); })();
          const why = seq => {
            if (seq === P) return 'Rejimlər arasında hər keçid ayrıca əmrdir və yalnız cari rejimdə tanınan əmri yaza bilərsən. Hər addım prompt-u dəyişir. Burada: ' + P.map((c, i) => m(sub(c)) + ' → ' + m(promptOf(host, modesAlong[i]))).join('; ') + '. ' + m(goal) + ' artıq ' + MODE_N[need] + ' rejimində yazılır.';
            const r = sim(seq);
            if (!r.ok && r.at !== undefined) return (r.at + 1) + '-ci addımda ' + m(sub(seq[r.at])) + ' dayanır: o, ' + MODE_N[r.md] + ' rejimində tanınmır və xəta verir.';
            if (!r.ok) return 'Ardıcıllıq bitəndə ' + MODE_N[r.md] + ' rejimində qalırsan, ' + m(goal) + ' isə ' + MODE_N[need] + ' tələb edir.';
            return 'İşləyir, amma ' + (seq.length - d0) + ' əmr artıqdır: ' + MODE_N[need] + ' rejimindən çıxıb yenidən girirsən. Sualda ən az əmr tələb olunur.';
          };
          const goalTxt = need === 'priv' ? m(goal) + ' yazmaq istəyirsən (<span class="m">do</span> işlətmədən: bu əmr Privileged EXEC-də yazılır).'
            : need === 'config' ? m(goal) + ' yazmaq istəyirsən (Global configuration əmridir).'
            : 'Fa0/' + p + ' interface-ində ' + m(goal) + ' yazmaq istəyirsən.';
          return { id: 'p1t9-g-mode', concept: 'modes', obj: 'Rejimlərə ən qısa yol', _meta: { M, need, p, goal, P, set, d0, host },
            stem: '<p>Prompt: ' + m(promptOf(host, M)) + '. ' + goalTxt + ' Hansı ardıcıllıq bu əmri <b>ən az əmrlə</b> yazmağa aparır? Hər seçimin sonunda həmin əmrin özü yazılıb.</p>',
            options: set.map(sq => ({ t: m(txt(sq)), ok: sq === P, why: why(sq) })) };
        },
        /* 2) əmr ardıcıllığından sonra prompt */
        () => {
          let mode = pick(['user', 'priv']); let host = pick(HOSTS); const startHost = host, startMode = mode;
          const steps = []; const states = []; let renamed = false; const n = rnd(5, 6);
          for (let i = 0; i < n; i++) {
            let c;
            if (mode === 'user') c = 'enable';
            else if (mode === 'priv') c = (i > 0 && R(4) === 0) ? 'disable' : 'configure terminal';
            else if (mode === 'config') c = pick(renamed ? ['interface', 'end', 'exit'] : ['interface', 'end', 'exit', 'hostname']);
            else c = pick(['exit', 'end', 'interface']);
            let line = c, to = mode;
            if (c === 'enable') to = 'priv';
            else if (c === 'configure terminal') to = 'config';
            else if (c === 'disable') to = 'user';
            else if (c === 'interface') { line = 'interface fa0/' + rnd(1, 8); to = 'if'; }
            else if (c === 'hostname') { const nn = pick(HOSTS.filter(x => x !== host)); line = 'hostname ' + nn; host = nn; renamed = true; to = 'config'; }
            else if (c === 'exit') to = mode === 'config' ? 'priv' : 'config';
            else if (c === 'end') to = 'priv';
            mode = to; steps.push(line); states.push(promptOf(host, mode));
          }
          const final = promptOf(host, mode);
          const wrong = shuffle(MODES.filter(x => x !== mode)); const info = {}; const cand = [];
          const add = (h, md) => { const s = promptOf(h, md); info[s] = { h, md }; cand.push(s); };
          if (renamed) { add(startHost, mode); add(host, wrong[0]); add(host, wrong[1]); } else wrong.forEach(md => add(host, md));
          const set = shuffle([final].concat(cand));
          const lines = steps.map((s, i) => (i + 1) + '. ' + m(s) + ' → ' + m(states[i])).join('<br>');
          const why = s => {
            if (s === final) return 'Hər əmr rejimi (bəzən adı) dəyişir, prompt isə həmişə cari vəziyyəti göstərir. Niyə: IOS hər əmrdən sonra prompt-u yenidən qurur. Burada addım-addım:<br>' + lines;
            const idx = states.indexOf(s);
            if (idx >= 0 && idx < n - 1) return 'Bu, ' + (idx + 1) + '-ci əmrdən (' + m(steps[idx]) + ') sonrakı prompt-dur. Sonrakı əmrlər rejimi dəyişib: sonuncu əmrə qədər izləməlisən.';
            const f = info[s];
            if (renamed && f.h === startHost && f.md === mode) return 'Rejim düzgündür, ad köhnədir: <span class="m">hostname</span> prompt-u dərhal dəyişir, indi ' + m(host) + ' görünür.';
            return 'Sonuncu əmrdən sonra rejim ' + MODE_N[mode] + ' olur (işarə ' + m(SUF[mode]) + '). ' + m(s) + ' isə ' + MODE_N[f.md] + ' rejiminin prompt-udur.';
          };
          return { id: 'p1t9-g-trace', concept: 'modes', obj: 'Prompt-u izləmək', _meta: { startHost, startMode, steps, final, set },
            stem: '<p>Cihazın adı <b>' + startHost + '</b>-dir, prompt ' + m(promptOf(startHost, startMode)) + '. Aşağıdakı əmrləri ardıcıl yazırsan (hamısı uğurla işləyir):</p><pre class="pre">' + steps.map((s, i) => (i + 1) + '.  ' + e(s)).join('\n') + '</pre><p>Sonuncu əmrdən sonra prompt necə görünür?</p>',
            options: set.map(s => ({ t: m(s), ok: s === final, why: why(s) })) };
        },
        /* 3) reload-dan sonra hostname */
        () => {
          const names = shuffle(HOSTS.filter(h => h !== 'Switch'));
          const hasBase = R(2) === 0; const base = hasBase ? names[0] : null;
          let run = base || 'Switch', start = base; let nameIx = hasBase ? 1 : 0; let reloads = 0;
          const evs = []; const startHist = base ? [base] : []; const used = base ? [base] : [];
          const total = rnd(4, 6); const un = () => run !== (start || 'Switch');
          for (let i = 0; i < total; i++) {
            let kind;
            if (i === total - 1) kind = 'reload';
            else if (i === 0) kind = 'rename';
            else { const r = R(10); kind = r < 5 ? 'rename' : r < 8 ? 'save' : (reloads < 1 ? 'reload' : 'rename'); }
            if (kind === 'rename') { const nn = names[nameIx++]; run = nn; used.push(nn); evs.push({ k: 'rename', n: nn, run, start }); }
            else if (kind === 'save') { start = run; startHist.push(run); evs.push({ k: 'save', how: pick(['copy running-config startup-config', 'write memory']), run, start }); }
            else { let ans = null; if (un()) { ans = pick(['yes', 'no']); if (ans === 'yes') { start = run; startHist.push(run); } } const before = run; run = start || 'Switch'; reloads++; evs.push({ k: 'reload', ans, before, run, start }); }
          }
          const ans = run; const fin = evs[evs.length - 1]; const finalStart = fin.start;
          const cand = [];
          [...new Set(['Switch'].concat(used))].filter(x => x !== ans).forEach(x => cand.push(x));
          const set = shuffle([ans].concat(shuffle(cand).slice(0, 3)));
          for (const x of names) { if (set.length >= 4) break; if (!set.includes(x)) set.push(x); }
          const fin2 = shuffle(set);
          const lines = evs.map(v => v.k === 'rename' ? 'hostname ' + v.n : v.k === 'save' ? v.how : 'reload' + (v.ans ? '    (Save? [yes/no] sualına: ' + v.ans + ')' : '')).map((s, i) => (i + 1) + '.  ' + e(s)).join('\n');
          const trace = evs.map((v, i) => (i + 1) + '. ' + m(v.k === 'rename' ? 'hostname ' + v.n : v.k === 'save' ? v.how : 'reload' + (v.ans ? ' (' + v.ans + ')' : '')) + ' → ' + (v.k === 'reload' ? 'açılış: running-config = startup-config = ' + (v.start ? m(v.start) : 'boş, fabrika adı ' + m('Switch')) : 'running ' + m(v.run) + ', startup ' + (v.start ? m(v.start) : 'yoxdur'))).join('<br>');
          const why = x => {
            if (x === ans) return 'Reload running-config-i (RAM) silir və startup-config-i (NVRAM) yükləyir. Yalnız saxlanmış konfiqurasiya söndürülmədən sağ çıxır. Burada addım-addım:<br>' + trace;
            if (x === 'Switch') return 'Fabrika adı yalnız startup-config-də heç nə olmayanda çıxır. Son reload zamanı startup-config-də ' + m('hostname ' + finalStart) + ' var idi.';
            if (x === fin.before) return 'Bu, reload-dan əvvəl running-config-də (RAM) olan addır. startup-config-də isə ' + (finalStart ? m(finalStart) : 'heç nə') + ' idi: saxlanmayan ad reload-da itir.';
            if (startHist.includes(x)) return m(x) + ' bir vaxt startup-config-də idi, amma sonradan başqa ad saxlanıb. Reload yalnız son saxlanmış halı qaytarır.';
            return m(x) + ' bu ardıcıllıqda heç vaxt startup-config-ə yazılmayıb, ona görə reload bu adı qaytara bilməz.';
          };
          return { id: 'p1t9-g-reload', concept: 'save', obj: 'Reload-dan sonra konfiqurasiya', _meta: { base, evs: evs.map(v => ({ k: v.k, n: v.n, ans: v.ans })), ans, set: fin2 },
            stem: '<p>' + (hasBase ? 'Switch-in saxlanmış konfiqurasiyasında ' + m('hostname ' + base) + ' var və cihaz bu adla işləyir.' : 'Switch təzədir: heç nə saxlanmayıb, hostname ' + m('Switch') + '.') + ' Əmrlərin hamısını düzgün rejimdə yazırsan:</p><pre class="pre">' + lines + '</pre><p>Son reload-dan sonra switch hansı prompt ilə açılır?</p>',
            options: fin2.map(x => ({ t: m(x + '>'), ok: x === ans, why: why(x) })) };
        },
      ],
      pool: [
        { id: 'p1t9-q1', concept: 'modes', obj: 'exit və end fərqi',
          stem: '<p>Prompt ' + m('Switch(config-if)#') + '. Ardıcıl iki əmr yazırsan: əvvəl ' + m('end') + ', sonra ' + m('exit') + '. Nə baş verir?</p>',
          options: [
            { t: 'end səni Switch#-ə qaytarır, sonra exit konsol sessiyasını bağlayır.', ok: true, why: 'End config rejimindən birbaşa Privileged EXEC-ə qayıdır, exit isə bir pillə geri gedir. Niyə: Privileged EXEC-də geri pillə yoxdur, ona görə exit sessiyanı bitirir. İkinci əmrdən sonra cihazın əmr xəttindən çıxırsan.' },
            { t: 'Prompt Switch> olur: end Privileged EXEC-ə, exit isə User EXEC-ə düşürür.', why: 'User EXEC-ə qayıtmaq üçün ' + m('disable') + ' lazımdır. Privileged EXEC-də exit rejim dəyişmir, sessiyanı bağlayır.' },
            { t: 'Prompt Switch(config)# olur: end də, exit də yalnız bir pillə geri gedir.', why: 'end bir pillə yox, birbaşa Privileged EXEC-ə qaytarır. Bir pillə geri getmək yalnız exit-in config rejimlərindəki davranışıdır.' },
            { t: 'Heç nə olmur: exit Privileged EXEC-də tanınmır və xəta verir.', why: 'exit hər rejimdə tanınır. Privileged EXEC-də isə onun işi sessiyanı bağlamaqdır.' },
          ] },
        { id: 'p1t9-q2', concept: 'modes', obj: 'do ilə exec əmri',
          stem: '<p>Prompt ' + m('Switch(config-if)#') + '. Yazdığın interface ayarını rejimdən çıxmadan, bir sətirdə yoxlamaq istəyirsən. Hansı sətir bunu edir?</p>',
          options: [
            { t: m('show running-config'), why: m('show running-config') + ' Privileged EXEC əmridir. Interface config rejimində çox vaxt tanınmır: ya end ilə çıx, ya da qabağına do əlavə et.' },
            { t: m('do show running-config'), ok: true, why: 'Do sətrin qalanını EXEC əmri kimi icra edir. Show Privileged EXEC-ə aiddir, do isə cari config rejimini dəyişmədən onu işlədir. Nəticəni görürsən və prompt ' + m('(config-if)#') + ' olaraq qalır.' },
            { t: m('enable show running-config'), why: m('enable') + ' tək əmrdir: arxasınca başqa əmr yazmaq olmur. Üstəlik config rejiminə girmisənsə, artıq Privileged EXEC-dən keçmisən.' },
            { t: m('exit show running-config'), why: m('exit') + ' arqument qəbul etmir: bir pillə geri gedir və sətrin qalanını icra etmir. Sətir xəta verər.' },
          ] },
        { id: 'p1t9-q3', concept: 'help', obj: '? işarəsinin yeri',
          stem: '<p>' + m('show ip') + ' yazdın, amma ondan sonra hansı sözlərin gələ biləcəyini bilmirsən. Seçimlərin siyahısını görmək üçün nə yazırsan?</p>',
          options: [
            { t: m('show ip ?') + ' (? əvvəl boşluqla)', ok: true, why: 'Qayda: ? soruşmaq istədiyin yerdə, əvvəlki sözdən boşluqla ayrılaraq yazılır. Boşluq IOS-a "ip tamamlandı, indi növbəti söz nədir" deyir. İp-dən sonra gələ bilən alt-əmrlərin siyahısı çıxır.' },
            { t: m('show ip?') + ' yazmaq (boşluq qoymadan)', why: 'Boşluq olmadığı üçün IOS bunu "ip ilə başlayan sözlər hansılardır" kimi oxuyur. Alt-əmrləri yox, yalnız həmin hərflərlə başlayan sözləri göstərir.' },
            { t: m('show ip') + ' yazıb sonra Tab düyməsini basmaq', why: 'Tab siyahı vermir, yalnız yazını tamamlayır. Birdən çox seçim varsa heç nə etmir.' },
            { t: m('show ip help') + ' yazıb Enter basmaq', why: 'help burada alt-əmr kimi tanınmır, ona görə xəta alarsan. Siyahını yalnız ? verir.' },
          ] },
        { id: 'p1t9-q4', concept: 'help', obj: 'Tab və qısaltma',
          stem: '<p>Privileged EXEC-də (' + m('Switch#') + ') ' + m('co') + ' yazıb Tab basırsan, heç nə tamamlanmır. Ən ehtimal səbəb və növbəti addım hansıdır?</p>',
          options: [
            { t: 'Tab düyməsi bu konsolda söndürülüb və Cisco cihazlarında hər əmri sona qədər özün yazmalısan, qısaltma da işləmir.', why: 'Tab Cisco əmr xəttində həmişə işləyir. Yazı unikal olanda tamamlayır, deyilsə heç nə etmir: səbəb düymədə deyil.' },
            { t: 'co ilə başlayan bir neçə əmr var (configure, copy), Tab birini seçə bilmir: co? yaz, sonra hərf əlavə et.', ok: true, why: 'Qayda: Tab və qısaltma yalnız yazılan hissə unikal olanda işləyir. Niyə: IOS hansını nəzərdə tutduğunu bilmir. Burada: ' + m('co?') + ' seçimləri göstərir, ' + m('conf') + ' isə unikaldır.' },
            { t: 'co bu rejimdə mövcud deyil, çünki əmrlər yalnız enable yazandan sonra açılır və tamamlanır.', why: 'Prompt ' + m('#') + ' deyir ki, artıq Privileged EXEC-dəsən: enable keçidi edilib. Əmrlər bu rejimdə var, problem birdən çox uyğunluqdadır.' },
            { t: 'Tab yalnız Global configuration rejimində işləyir, Privileged EXEC-də tamamlama söndürülür.', why: 'Tab bütün rejimlərdə işləyir. Fərq yalnız rejimə görə mövcud əmrlərin siyahısındadır.' },
          ] },
        { id: 'p1t9-q5', concept: 'errors', obj: 'Invalid input və ^ işarəsi',
          stem: '<p>Aşağıdakı çıxışı alırsan:</p><pre class="pre"><span class="p">Switch&gt;</span>show running-config\n            ^\n% Invalid input detected at \'^\' marker.</pre><p>Bunu necə oxuyursan?</p>',
          options: [
            { t: '^ running-config-i göstərir: show tanınıb, amma bu alt-əmr User EXEC-də yoxdur.', ok: true, why: 'Qayda: ^ IOS-un qəbul edə bilmədiyi sözün yerini göstərir. Show User EXEC-də var, running-config isə yalnız Privileged EXEC-dədir. Burada: ' + m('enable') + ' yaz və əmri təkrarla.' },
            { t: '^ yazı səhvini göstərir: running-config hərfləri düzgün yazılmayıb, onları yoxla.', why: 'Söz düzgün yazılıb. Eyni mesaj həm yazı səhvində, həm səhv rejimdə çıxır: səbəbi prompt-a baxıb tapırsan.' },
            { t: '^ əmrin sonunu göstərir: əmr yarımçıqdır, sona argument əlavə etmək lazımdır.', why: 'Yarımçıq əmrə IOS ' + m('% Incomplete command.') + ' deyir və ^ göstərmir. ^ olan mesaj Invalid input-dur.' },
            { t: 'Qısaltma bir neçə əmrə uyğun gəlir, ^ uyğun gələnlərin başladığı yeri göstərir və siyahı verir.', why: m('% Ambiguous command') + ' ayrı mesajdır və ^ göstərmir. Burada isə söz tam yazılıb.' },
          ] },
        { id: 'p1t9-q6', concept: 'errors', obj: 'Əmr və xəta cütü',
          stem: '<p>Hansı cütlükdə (prompt + yazılan → mesaj) mesaj <b>düzgün</b> uyğunlaşdırılıb?</p>',
          options: [
            { t: m('Switch(config)#hostname') + ' → Incomplete command: əmr tanınıb, amma ad (argument) çatışmır.', ok: true, why: 'Əmr tanınıb, amma tələb olunan söz yoxdursa, mesaj Incomplete olur. Niyə: ' + m('hostname') + ' arxasınca ad gözləyir. Burada: ' + m('hostname SW1') + ' yazsan işləyir.' },
            { t: m('Switch#co') + ' → Invalid input: co heç bir əmrə uyğun gəlmir.', why: 'Privileged EXEC-də co ilə başlayan bir neçə əmr var (configure, copy). Bu Ambiguous halıdır, Invalid deyil.' },
            { t: m('Switch>show running-config') + ' → Incomplete command: show-dan sonra söz çatışmır.', why: 'Söz var, amma rejimdə tanınmır: bu Invalid input-dur. Incomplete yalnız əmr gözlənilən sözü almayanda çıxır.' },
            { t: m('Switch#shw run') + ' → Ambiguous: shw bir neçə əmrə uyğundur.', why: 'shw heç bir əmrlə başlamır. IOS onu çox vaxt hostname sayıb DNS-ə baxır və Unknown command mesajı verir. Ambiguous deyil.' },
          ] },
        { id: 'p1t9-q9', concept: 'show', obj: 'down/down və Vlan1',
          stem: '<p><span class="m">show ip interface brief</span> çıxışı:</p><pre class="pre">Interface         IP-Address     Status                 Protocol\nFastEthernet0/1   unassigned     up                     up\nFastEthernet0/2   unassigned     administratively down  down\nFastEthernet0/3   unassigned     down                   down\nVlan1             192.168.1.2    up                     up</pre><p>PC-C Fa0/3-ə qoşulmalıdır, amma şəbəkəyə çıxa bilmir. Çıxışa əsasən ilk nəyi yoxlayırsan?</p>',
          options: [
            { t: 'Fa0/3 down/down-dur: fiziki link yoxdur, kabelə və qarşı tərəfə bax.', ok: true, why: 'Down/down link yoxdur deməkdir, administratively down isə shutdown yazıldığını göstərir. Niyə: Fa0/3 shutdown olsaydı Fa0/2 kimi görünərdi. Switch port-u normaldır, kabel və ya qarşı tərəf problemlidir.' },
            { t: 'Fa0/3-də shutdown yazılıb: interface-ə girib no shutdown yaz ki, port açılsın.', why: 'shutdown olsaydı Status administratively down olardı (Fa0/2 kimi). Fa0/3 sadəcə down-dur, ona görə no shutdown kömək etməz.' },
            { t: 'Fa0/3-ün IP-si unassigned-dir: interface-ə girib porta ip address ver.', why: 'Switch portu Layer 2-dir və IP almır. Fa0/1 də unassigned-dir, amma up/up işləyir.' },
            { t: 'Vlan1 up/up-dır, deməli switch işləyir və yoxlamaq lazım olan yalnız PC-dir.', why: 'Vlan1 up/up yalnız ən azı bir portun (burada Fa0/1) işlədiyini göstərir. Fa0/3 haqqında heç nə demir.' },
          ] },
        { id: 'p1t9-q10', concept: 'switch-ip', obj: 'ip default-gateway',
          stem: '<p>PC (192.168.2.10/24) → Router → SW1. SW1-in Vlan1-i <span class="m">192.168.1.2/24</span>, router-in SW1 tərəfindəki IP-si <span class="m">192.168.1.1</span>-dir. PC <b>192.168.1.2</b> ünvanına (SW1-in idarəetmə IP-si) ping atır və cavab gəlmir. SW1-də <span class="m">ip default-gateway</span> yazılmayıb, sorğu isə SW1-ə çatır. Səbəb nədir?</p>',
          options: [
            { t: 'SW1 sorğunu alır, amma cavabı 192.168.2.0/24-ə göndərməyi bilmir: default gateway yoxdur.', ok: true, why: 'Hədəf başqa şəbəkədədirsə, cihaz paketi gateway-ə verir. Niyə: Vlan1-in yalnız 192.168.1.0/24 şəbəkəsi var, 192.168.2.10-un hara getməli olduğu bəlli deyil. Burada: ' + m('ip default-gateway 192.168.1.1') + ' (Global config) problemi həll edir.' },
            { t: 'Switch IP ünvanı olan cihaz kadr ötürə bilmir, ona görə Vlan1 IP-sini silmək lazımdır, sonra ping işləyəcək.', why: 'İdarəetmə IP-si kadr ötürməyə təsir etmir. Silsən yalnız switch-ə uzaqdan çatmaq imkanını itirərsən.' },
            { t: 'Switch-in IP-si PC-nin şəbəkəsində (192.168.2.x) olmalıdır, yoxsa ping heç vaxt işləməz.', why: 'Switch öz şəbəkəsində IP alır və router vasitəsilə başqa şəbəkədən də əlçatan ola bilər. Çatışmayan hissə cavabın marşrutudur.' },
            { t: 'Switch ICMP echo cavabı vermir, çünki bu funksiya yalnız router-lərdə mövcuddur.', why: 'Switch-in Vlan1 interface-i ICMP echo-ya cavab verir: eyni şəbəkədən ping işləyir. Problem başqa şəbəkədən gələn sorğunun cavabındadır.' },
          ] },
        { id: 'p1t9-q11', concept: 'switch-ip', obj: 'Switch-in IP-si və kadr ötürmə',
          stem: '<p>SW1-in Vlan1-ində heç bir IP yoxdur (<span class="m">show ip interface brief</span>-də <b>unassigned</b>). PC-A (192.168.1.10) və PC-B (192.168.1.11) eyni switch-ə qoşulub. PC-A PC-B-yə ping atır. Nə olur?</p>',
          options: [
            { t: 'İşləyir: switch kadrları MAC ünvanına görə ötürür, öz IP-si olmasa da fərqi yoxdur.', ok: true, why: 'Switch Layer 2 cihazıdır və qərarı MAC cədvəlinə görə verir. Niyə: IP başlığına baxmır. Burada: ARP və ICMP kadrları IP-siz switch-dən keçir.' },
            { t: 'İşləmir: hər switch kadr ötürmək üçün idarəetmə IP-sinə ehtiyac duyur.', why: 'İdarəetmə IP-si yalnız switch-ə özünə qoşulmaq üçündür. Kadr ötürmə ondan asılı deyil.' },
            { t: 'İşləyir, amma yalnız switch-ə ip default-gateway yazılıbsa.', why: 'default-gateway switch-in öz trafiki üçündür. PC-lərin arasındakı trafik switch-in nəzərindən keçən kadrlardır.' },
            { t: 'ARP işləyir, amma ICMP işləmir, çünki ICMP Layer 3-dür və switch onu ötürmür.', why: 'Switch ICMP-ni görmür: o, kadrın içindəki paketdir və switch yalnız Ethernet başlığına baxır. Kadr ötürülür.' },
          ] },
        { id: 'p1t9-q12', concept: 'save', obj: 'Təcrübəni geri qaytarmaq',
          stem: '<p>Dünən saxladığın konfiqurasiyada <span class="m">hostname SW1</span> var. Bu gün running-config-də təcrübə etdin (bir neçə interface söndürdün, hostname-i dəyişdin) və hamısını geri qaytarmaq istəyirsən. Heç nə saxlamamısan. Ən təmiz yol hansıdır?</p>',
          options: [
            { t: m('reload') + ' yaz və Save? sualına ' + m('no') + ' cavab ver: cihaz saxlanmış konfiqurasiya ilə açılır.', ok: true, why: 'Reload running-config-i silir və startup-config-i yükləyir. Təcrübə yalnız RAM-da idi. No cavabı dəyişiklikləri saxlamır, cihaz dünənki vəziyyətə qayıdır.' },
            { t: m('copy startup-config running-config') + ': saxlanmış konfiqurasiya running-config-in yerinə yazılır.', why: 'Bu əmr əvəz etmir, qarışdırır: startup-config-dəki sətirlər tətbiq olunur, amma yeni yazdığın əmrlər (məsələn shutdown) silinmir. Nəticə qarışıq konfiqurasiyadır.' },
            { t: m('copy running-config startup-config') + ' yaz, sonra reload et.', why: 'Bu təcrübəni saxlayır və dünənki konfiqurasiyanı üstünə yazır. İtirdiyin məhz qaytarmaq istədiyin versiyadır.' },
            { t: m('erase startup-config') + ' yaz, sonra reload et.', why: 'Bu saxlanmış konfiqurasiyanı da silir, cihaz boş konfiqurasiya ilə açılır. Qaytarmaq istədiyin hər şeyi itirirsən.' },
          ] },
        { id: 'p1t9-q13', concept: 'save', obj: 'erase startup-config',
          stem: '<p>Switch-də <span class="m">hostname SW1</span> var və konfiqurasiya saxlanıb. <span class="m">erase startup-config</span> yazıb təsdiq verdin, reload etmədin. Prompt hələ də <span class="m">SW1#</span> göstərir. Niyə, və cihaz yenidən açılanda nə olacaq?</p>',
          options: [
            { t: 'erase hələ tamamlanmayıb, ona görə reload-dan sonra SW1 adı yenidən geri qayıdacaq.', why: 'Erase dərhal tamamlanır ([OK] yazılır). Reload-dan sonra qayıtmaq üçün startup-config-də ad qalmayıb.' },
            { t: 'running-config RAM-dadır və qalır, erase isə yalnız startup-config-i silir: reload-dan sonra konfiqurasiya boş olacaq.', ok: true, why: 'Erase startup-config yalnız saxlanmış nüsxəni silir. Running-config RAM-dadır və cihaz işlədiyi müddətcə qalır. Burada: SW1 reload-a qədər qalır, reload-dan sonra ad ' + m('Switch') + ' olur.' },
            { t: 'erase running-config-i də silir, prompt isə köhnə yaddaşdan göstərilir, reload-dan sonra yenilənir.', why: 'Prompt cari running-config-dən qurulur, köhnə yaddaşdan yox. Erase running-config-ə toxunmur.' },
            { t: 'erase-dən sonra cihaz özü dərhal restart olur, prompt isə bir qədər gecikir.', why: 'Cihaz özü restart olmur: reload əmri ayrıca yazılmalıdır.' },
          ] },
        { id: 'p1t9-q14', concept: 'save', obj: '%SYS-5-CONFIG_I logu',
          stem: '<p>SIEM-də switch-dən gələn log, saat 03:12: <span class="m">%SYS-5-CONFIG_I: Configured from console by console</span>. Bu logdan nəyi əminliklə bilirsən?</p>',
          options: [
            { t: 'Konfiqurasiya dəyişib və dəyişiklik startup-config-ə də saxlanıb, yəni reload-dan sonra qalacaq.', why: 'Bu log config rejimindən çıxanda yaranır və saxlamanı göstərmir. Saxlanıb-saxlanmadığını running-config ilə startup-config-i müqayisə edib görürsən.' },
            { t: 'Kimsə console-dan config rejimindən çıxıb: running-config dəyişmiş ola bilər, nəyi isə log demir.', ok: true, why: 'Log config rejimindən çıxışı qeyd edir. Niyə: IOS dəyişikliyin məzmununu bu mesajda yazmır. Növbəti addım running-config-i startup-config ilə və dəyişiklik qeydləri (ticket) ilə müqayisə etməkdir.' },
            { t: 'Switch yenidən yüklənib və konfiqurasiya sıfırdan oxunub, yəni əvvəlki running-config silinib.', why: 'Reload ayrı log mesajı yaradır. Bu mesaj yalnız config rejimindən çıxışı bildirir.' },
            { t: 'İcazəsiz dəyişiklik edilib: bu log hücumun birbaşa sübutudur və dərhal eskalasiya lazımdır.', why: 'Log yalnız çıxışı göstərir, kimin və niyə etdiyini yox. Planlı iş də eyni mesajı yaradır, ona görə dəyişiklik qeydləri ilə yoxlamaq lazımdır.' },
          ] },
        { id: 'p1t9-q15', concept: 'show', obj: 'Status adlarının uyğunluğu',
          stem: '<p><span class="m">show interfaces status</span> çıxışında üç port belədir: Fa0/4 <b>connected</b>, Fa0/5 <b>notconnect</b>, Fa0/6 <b>disabled</b>. <span class="m">show ip interface brief</span>-də bunlar necə görünür?</p>',
          options: [
            { t: 'Fa0/4: up/up. Fa0/5: down/down. Fa0/6: administratively down/down.', ok: true, why: 'Connected = işləyir, notconnect = link yoxdur, disabled = shutdown. İki show eyni vəziyyəti fərqli sözlərlə yazır. Burada hər status öz qarşılığına çevrilir.' },
            { t: 'Fa0/4: up/up. Fa0/5: administratively down/down. Fa0/6: down/down.', why: 'Burada notconnect ilə disabled yerini dəyişib. Link olmaması down/down, shutdown isə administratively down verir.' },
            { t: 'Üçü də up/up görünür, çünki fərq yalnız show interfaces status çıxışının yazılışındadır.', why: 'Hər iki show eyni interface vəziyyətindən oxuyur. Link olmayan və ya söndürülən port heç vaxt up/up olmur.' },
            { t: 'Fa0/4: up/down. Fa0/5: down/down. Fa0/6: down/down. Protocol sütunu hər yerdə fərqlənir.', why: 'connected olan port həm Status, həm Protocol sütununda up olur. Disabled port isə Status-da administratively down göstərir, sadəcə down yox.' },
          ] },
        { id: 'p1t9-q17', concept: 'switch-ip', obj: 'Vlan1 və no shutdown',
          stem: '<p>SW1-də <span class="m">interface vlan 1</span> və <span class="m">ip address 192.168.1.2 255.255.255.0</span> yazıb <span class="m">end</span> etdin. PC-A (192.168.1.10) switch-ə ping atır, cavab yoxdur. <span class="m">show ip interface brief</span>-də Vlan1 sətrində IP <b>192.168.1.2</b> görünür, Status <b>administratively down</b>-dur. Səbəb nədir?</p>',
          options: [
            { t: 'Vlan1 default shutdown-dur: IP vermək onu açmır, no shutdown yazmaq lazımdır.', ok: true, why: 'Switch-in Vlan1 interface-i ilkin olaraq söndürülüdür. İp address yalnız ünvan verir, vəziyyəti dəyişmir. Burada: ' + m('no shutdown') + ' yazdıqdan sonra Status up olur (ən azı bir port işləyirsə).' },
            { t: 'Mask yanlış verilib: 255.255.255.0 PC-nin şəbəkəsinə uyğun gəlmir, mask dəyişdirilməlidir.', why: 'Mask 192.168.1.0/24 ilə uyğundur və IP düzgün göstərilir. Status isə mask-dan asılı olmayaraq administratively down-dur: bu shutdown-un izidir.' },
            { t: 'Switch-in IP-si PC-A-nın qoşulduğu Fa0/1 portunda olmalıdır, Vlan1-də yox.', why: 'Switch portları Layer 2-dir və IP almır. İdarəetmə IP-si Vlan1 interface-ində verilir, burada düzgün yerdədir.' },
            { t: 'end konfiqurasiyanı saxlamır: copy running-config startup-config yazmaq lazımdır.', why: 'Running-config yazılan kimi tətbiq olunur, saxlamaq onu aktiv etmir. Saxlamaq yalnız reload-dan sonra itməməsi üçündür.' },
          ] },
      ],
    },
  });
})();
