(function () {
  const A = PT.addr; const pick = PT.pick; const R = PT.randInt; const shuffle = PT.shuffle;
  const macNorm = s => String(s).toLowerCase().replace(/[^0-9a-f]/g, '');
  const hx = n => n.toString(16).padStart(2, '0');
  const rmac = () => ['00', '01', '43', hx(R(256)), hx(R(256)), hx(R(256))].join('-');

  PT.topic({
    id: 'p1t5',
    objectives: [
      'ARP-ın nə üçün lazım olduğunu və request/reply addımlarını izah etmək',
      'Eyni və fərqli network üçün ARP-ın kimin MAC-ini soruşduğunu müəyyən etmək',
      'ARP cache-i oxumaq, ARP request və reply sahələrini tanımaq',
      'ARP cache ilə MAC address table-ı fərqləndirmək',
      'ARP spoofing əlamətlərini tapmaq və müdafiə üsulunu demək',
    ],
    explain: PT.frag['p1/t05/explain'], cheat: PT.frag['p1/t05/cheat'],

    lab: {
      title: 'Lab 5: ARP-ı izlə, oxu və yoxla',
      goal: 'ARP mübadiləsinin sırasını qurmaq, PC-də ARP cache-in necə dolduğunu görmək, ARP sahələrini oxumaq və şübhəli ARP-ı aşkar etmək.',
      why: 'ARP hər ping-in görünməyən birinci addımıdır. "Yerli şəbəkə işləyir, internet işləmir" və ARP spoofing kimi problemlərin yarısı ARP cache-ə baxanda tapılır.',
      minutes: 40,
      finish: 'ARP-ı sıra ilə izah edir, cache-i oxuyur və şübhəli cavabı tanıyırsan. Növbəti mövzuda (ICMP və ping) bu bilik hər ping-in nəticəsini izah etməyə kömək edəcək.',
      steps: [
        { id: 's1', title: 'Plan', type: 'info', button: 'Başlayaq',
          body: '<p>Bu labda Packet Tracer lazım deyil.</p><ol><li>ARP mübadiləsinin sırasını qur.</li><li>Fərqli network üçün ARP-ın kimi soruşduğunu proqnozlaşdır.</li><li>PC praktikasında yoxla.</li><li>ARP request və reply sahələrini doldur.</li><li>İki ticket və bir capture tapşırığı: səbəbi tap.</li></ol>' },
        { id: 's2', title: 'ARP mübadiləsinin sırası', type: 'order',
          body: '<p>PC1 ilk dəfə eyni network-dəki PC2-yə ping göndərir. Hadisələri baş vermə sırası ilə düz (ilk hadisə yuxarıda).</p>',
          items: [
            { t: 'PC1 ARP cache-də 192.168.1.20 axtarır, tapmır', why: 'ARP başlamazdan əvvəl host həmişə cache-ə baxır.' },
            { t: 'PC1 ARP request göndərir (broadcast)', why: 'MAC bilinmir, ona görə Destination MAC FF:FF:FF:FF:FF:FF olur.' },
            { t: 'PC2 ARP reply göndərir (unicast)', why: 'PC2 sorğudan PC1-in MAC-ini bilir, ona görə cavab unicast olur.' },
            { t: 'PC1 cavabı ARP cache-ə yazır', why: 'İndi IP → MAC cütü cache-dədir.' },
            { t: 'PC1 ICMP echo request göndərir', why: 'Gözləyən ping paketi nəhayət düzgün Destination MAC ilə göndərilir.' },
          ],
          hints: ['Ping paketi MAC bilinməyənə qədər gözləyir. MAC-i tapmaq üçün hansı mesaj göndərilməlidir?'],
          after: '<p>İlk ping-də cavab müddəti uzun olur, çünki ping paketi ARP-ı gözləyir. Növbəti ping-lərdə ARP olmur.</p>' },
        { id: 's3', title: 'Proqnozlaş: fərqli network', type: 'form',
          body: '<p>PC1: <span class="m">192.168.1.10/24</span>, gateway <span class="m">192.168.1.1</span>. Aşağıdakı praktikada <span class="m">ping 10.0.0.5</span> yazacaqsan. Əvvəlcədən cavab ver:</p>',
          fields: [
            { label: 'ARP hansı IP-nin MAC-ini soruşacaq?', placeholder: 'a.b.c.d', check: r => r.trim() === '192.168.1.1', wrong: '10.0.0.5 fərqli network-dədir və ARP broadcast router-dən keçmir. Kadr hara çatmalıdır?' },
            { label: 'ICMP kadrında Destination IP', placeholder: 'a.b.c.d', check: r => r.trim() === '10.0.0.5', wrong: 'IP ünvanı son hədəfi göstərir.' },
          ],
          hints: ['Kadr link-də kimə çatmalıdır? Router paketi sonra yönləndirir.'],
          solution: 'ARP gateway-in IP-sini (192.168.1.1) soruşur. Kadrın Destination MAC-i gateway-in MAC-i, Destination IP isə 10.0.0.5 olur.' },
        { id: 's4', title: 'PC praktikası: cache necə dolur', type: 'terminal',
          body: '<p>Sağdakı vəziyyət panelində PC1-in ARP cache-i görünür. Əmrləri yaz və cache-in necə dəyişdiyinə bax.</p><ol><li><span class="m">arp -a</span> (hələlik yalnız static sətirlər olmalıdır)</li><li><span class="m">ping 192.168.1.20</span></li><li><span class="m">ping 10.0.0.5</span></li><li><span class="m">arp -a</span></li></ol>',
          term: { kind: 'host', host: { name: 'PC1', ip: '192.168.1.10', mask: '255.255.255.0', gw: '192.168.1.1', mac: '0001.4321.AAAA' },
            peers: [{ name: 'PC2', ip: '192.168.1.20', mac: '0001.4321.BBBB' }, { name: 'R1', ip: '192.168.1.1', mac: '0001.4321.DDDD' }], remote: [{ ip: '10.0.0.5', ttl: 126 }], quick: ['arp -a', 'ping 192.168.1.20', 'ping 10.0.0.5', 'arp -d'],
            goals: [
              { text: '<span class="m">ping 192.168.1.20</span> işlət (PC2-yə)', test: d => d.pings.some(p => p.ip === '192.168.1.20') },
              { text: '<span class="m">ping 10.0.0.5</span> işlət (başqa network)', test: d => d.pings.some(p => p.ip === '10.0.0.5') },
              { text: 'Sonda <span class="m">arp -a</span> ilə cache-ə bax', test: d => d.history.filter(l => /^arp\s+-a$/i.test(l)).length >= 1 && d.arp.length >= 2 },
            ] },
          hints: ['Əmri yaz və Enter bas. Ping-dən sonra sağdakı panelə bax: yeni sətir işıq verir.'],
          after: '<p>Müşahidə: 192.168.1.20 üçün giriş yarandı, 10.0.0.5 üçün isə <b>yox</b>. Gateway-in (192.168.1.1) girişi isə yarandı.</p>' },
        { id: 's5', title: 'Çıxışdan oxu', type: 'form',
          body: '<p>Əvvəlki praktikanın ARP cache-inə bax.</p>',
          fields: [
            { label: '192.168.1.1 sətrinin MAC-i (Windows formatında)', placeholder: 'xx-xx-xx-xx-xx-xx', check: r => macNorm(r) === '00014321dddd', wrong: 'Cache-də 192.168.1.1 sətrinə bax. Yalnız hex rəqəmləri müqayisə olunur.' },
            { label: '10.0.0.5 üçün cache-də giriş var? (bəli / xeyr)', placeholder: 'bəli / xeyr', answers: ['xeyr', 'yox', 'no'], wrong: '10.0.0.5 başqa network-dədir: PC onun MAC-ini heç vaxt öyrənmir.' },
            { label: 'Yeni yaranan girişlərin Type sütunu', placeholder: 'type', answers: ['dynamic', 'dinamik'], wrong: 'ARP ilə öyrənilən girişlər hansı tipdədir?' },
          ],
          hints: ['Cache hələ boşdursa, əvvəlki praktikaya qayıdıb ping əmrlərini yenidən işlət.'],
          solution: '192.168.1.1 → 00-01-43-21-dd-dd. 10.0.0.5 üçün giriş yoxdur. Yeni girişlər dynamic-dir.' },
        { id: 's6', title: 'ARP sahələrini doldur', type: 'form',
          body: '<p>PC1 (IP <span class="m">192.168.1.10</span>, MAC <span class="m">0001.4321.AAAA</span>) PC2-nin (IP <span class="m">192.168.1.20</span>, MAC <span class="m">0001.4321.BBBB</span>) MAC-ini soruşur. İki kadrı doldur. MAC-i istədiyin formatda yaza bilərsən.</p><p><b>ARP request:</b></p>',
          fields: [
            { label: 'Ethernet Destination MAC', placeholder: 'MAC', check: r => macNorm(r) === 'ffffffffffff', wrong: 'Cavab verənin MAC-i bilinmir.' },
            { label: 'EtherType (hex)', placeholder: '0x....', check: r => /^(0x)?0806$/i.test(r.trim()), wrong: 'ARP üçün EtherType: 0x0806.' },
            { label: 'Opcode', placeholder: 'rəqəm', check: r => r.trim() === '1', wrong: '1 = request, 2 = reply.' },
            { label: 'Target MAC', placeholder: 'MAC', check: r => macNorm(r) === '000000000000', wrong: 'Məhz bunu soruşur, ona görə sıfırlarla doldurulur.' },
            { label: 'Target IP', placeholder: 'a.b.c.d', check: r => r.trim() === '192.168.1.20', wrong: 'MAC-i axtarılan IP.' },
            { label: '<b>ARP reply:</b> Ethernet Destination MAC', placeholder: 'MAC', check: r => macNorm(r) === '00014321aaaa', wrong: 'Cavab unicast gedir: kimə?' },
            { label: 'Reply Sender MAC', placeholder: 'MAC', check: r => macNorm(r) === '00014321bbbb', wrong: 'Sender MAC axtarılan cavabdır. Kimin MAC-i axtarılırdı?' },
          ],
          hints: ['Request-də hədəf MAC bilinmir. Reply-da isə cavab verən öz MAC-ini deyir və soruşana unicast göndərir.'],
          solution: 'Request: Dst MAC FF:FF:FF:FF:FF:FF, EtherType 0x0806, Opcode 1, Target MAC 00:00:00:00:00:00, Target IP 192.168.1.20. Reply: Dst MAC 0001.4321.AAAA (PC1), Sender MAC 0001.4321.BBBB (PC2).' },
        { id: 's6b', title: 'ARP cache-də səhvi tap', type: 'spot',
          body: '<p>Kolleqa PC1-in ARP cache-ini şərh edib. Cache: <span class="m">192.168.1.1 → 00-01-43-21-dd-dd (dynamic)</span>, <span class="m">192.168.1.20 → 00-01-43-21-bb-bb (dynamic)</span>. <b>Bir şərh səhvdir.</b> Onu tap.</p>',
          lines: [
            { t: '1.  PC1 192.168.1.20 üçün ARP request göndərib və PC2 cavab verib.' },
            { t: '2.  192.168.1.1 gateway-dir, ona görə PC1 hədəf 10.0.0.5-ə ping atanda ARP 10.0.0.5-in MAC-ini soruşur.', bad: true, why: 'Başqa network-dəki hədəfin MAC-i soruşulmur. ARP gateway-in MAC-ini soruşur, çünki frame bu link-də gateway-ə çatmalıdır.' },
            { t: '3.  Girişlərin tipi dynamic-dir, yəni vaxt keçəndə silinəcək.' },
            { t: '4.  İlk ping-dən sonra növbəti ping-lər ARP-sız qurulur, çünki cache-də giriş var.' },
          ],
          fix: { label: 'ARP başqa network-dəki hədəf üçün kimin IP-sini soruşur?', placeholder: 'məs. gateway', answers: ['gateway', 'gateway-in', 'gateway-in ip-si', '192.168.1.1', 'default gateway'], wrong: 'Frame bu link-də hara çatmalıdır?' },
          hints: ['ARP həmişə eyni link-dəki cihazın MAC-ini soruşur.'] },
        { id: 's7', title: 'Ticket: yerli işləyir, internet yox', type: 'choice',
          body: '<p>İstifadəçi deyir ki, şirkət daxilində fayl server-ə (eyni subnet) giriş var, amma internet işləmir. Sən yoxlayırsan: PC-nin IP-si <span class="m">192.168.1.77/24</span>, gateway <span class="m">192.168.1.10</span> yazılıb. Real gateway <span class="m">192.168.1.1</span>-dir. ARP cache-də gateway üçün giriş yoxdur. Səbəb nədir?</p>',
          options: [
            { t: 'Gateway səhv IP ilə yazılıb: orada (192.168.1.10) router yoxdur.', ok: true, why: 'Fərqli network üçün PC gateway-in MAC-ini soruşur. 192.168.1.10 ünvanında router yoxdur (başqa host və ya boş), ona görə MAC alınmır və kadr qurulmur. Eyni network-dəki server üçün isə ARP uğurludur, ona görə yerli şəbəkə işləyir.' },
            { t: 'Switch ARP kadrlarını bloklayır, ona görə heç bir ARP işləmir və paketlər çıxmır.', why: 'Əgər switch ARP-ı bloklasaydı, yerli server üçün də ARP işləməzdi. Ancaq yerli şəbəkə işləyir, deməli ARP ümumilikdə uğurludur.' },
            { t: 'Mask səhvdir və PC internet ünvanlarını eyni network sayıb birbaşa göndərir.', why: 'Mask /24 düzgündür: 192.168.1.77/24 şəbəkəsi 192.168.1.0-dır. Əgər mask səhv olsaydı, PC internet ünvanları üçün birbaşa ARP göndərərdi, simptom isə fərqli olardı.' },
            { t: 'DNS server ünvanı yoxdur, ona görə internet səhifələri açılmır və ping gedir.', why: 'DNS adı IP-yə çevirir. Problem DNS olsaydı, IP ilə (məsələn 8.8.8.8) ping işləyərdi. Burada isə gateway-ə ARP uğursuzdur və heç bir paket kənara çıxmır.' },
          ],
          hints: ['Fərqli network-ə paket göndərəndə ARP kimin MAC-ini soruşur? Həmin IP-də router varmı?'],
          after: '<p>Metod: əvvəl gateway-ə ping at, sonra <span class="m">arp -a</span> ilə gateway-in MAC-inin öyrənilib-öyrənilmədiyinə bax.</p>' },
        { id: 's8', title: 'Capture oxu: şübhəli ARP', type: 'choice',
          body: '<p>Capture-də gateway-in IP-sini soruşan sorğu və iki cavab görürsən:</p><pre class="pre">1  ARP  192.168.1.50 → hamı     Who has 192.168.1.1? Tell 192.168.1.50\n2  ARP  00:11:22:33:44:55 → ...   192.168.1.1 is at 00:11:22:33:44:55\n3  ARP  00:aa:bb:cc:dd:ee → ...   192.168.1.1 is at 00:aa:bb:cc:dd:ee</pre><p>Sən bunu necə qiymətləndirirsən?</p>',
          options: [
            { t: 'Şübhəlidir: eyni IP-yə iki fərqli MAC cavab verir, biri saxta ola bilər.', ok: true, why: 'Bir IP ünvanı yalnız bir cihazda olmalıdır, ona görə yalnız bir cavab gəlməlidir. İki fərqli MAC cavabı ya ARP spoofing (biri hücumçudur), ya da duplicate IP deməkdir. Hər iki halda araşdırma lazımdır.' },
            { t: 'Normaldır: iki cavab ARP-ın etibarlılığını artırır və təsdiq rolunu oynayır.', why: 'ARP-da etibarlılıq üçün ikinci cavab mexanizmi yoxdur. Eyni IP üçün fərqli MAC-lərdən cavab normal şəbəkədə baş vermir.' },
            { t: 'Normaldır: router və switch ARP-a birlikdə cavab verir ki, etibarlı olsun.', why: 'Switch ARP-a cavab vermir, o Layer 2 cihazıdır və kadrı ötürür. Cavabı IP-nin sahibi verir.' },
            { t: 'Yalnız 1-ci cavab düzgündür, çünki ilk gəlir və cache onu saxlayır.', why: 'Çox sistem sonrakı cavabla cache-i yeniləyir. Ən son gələn cavab qalır, yəni hücumçu gec göndərərək qalib gələ bilər. "İlk gəlir" qaydası yoxdur.' },
          ],
          hints: ['Bir IP ünvanı neçə fərqli cihazda ola bilər? Hansı iki hal bu vəziyyəti yaradır?'],
          after: '<p>Növbəti addım: router-dən (<span class="m">show interfaces</span>) real gateway MAC-ini öyrən. Digər MAC-in hansı switch portunda olduğunu <span class="m">show mac address-table</span> ilə tap. Bunlardan sonra verdikt verə bilərsən.</p>' },
        { id: 's9', title: 'Qərar: ən təsirli müdafiə', type: 'choice',
          body: '<p>Qonaq Wi-Fi və ofis şəbəkəsi eyni switch-lərdədir və ARP spoofing hücumundan narahatsan. Switch səviyyəsində <b>ən birbaşa</b> müdafiə hansıdır?</p>',
          options: [
            { t: 'Dynamic ARP Inspection: ARP paketlərini switch-in bildiyi IP-MAC-port uyğunluğu ilə yoxlamaq.', ok: true, why: 'DAI hər ARP paketindəki IP-MAC cütünü switch-in bildiyi uyğunluqla müqayisə edir və uyğun gəlməyəni atır. Saxta ARP reply switch-dən keçmir.' },
            { t: 'ARP cache timeout-unu artırmaq ki, girişlər daha uzun saxlanılsın.', why: 'Timeout-u artırmaq saxta girişin də uzun qalmasına səbəb ola bilər və hücumu əngəlləmir. Problem girişin ömrü deyil, onun doğrulanmamasıdır.' },
            { t: 'Switch-də MAC address table-ı müntəzəm silmək.', why: 'MAC address table switch-in öyrənməsidir və ARP cache ilə əlaqəsi yoxdur. Silmək hücumu dayandırmır, yalnız flooding yaradır.' },
            { t: 'Firewall-da ICMP trafikini bloklamaq.', why: 'ARP ICMP deyil və IP-nin içində getmir, ona görə firewall onu görmür. ICMP-ni bloklamaq ARP spoofing-ə təsir etmir.' },
          ],
          hints: ['ARP kadrları IP-nin içində getmir. Onları yoxlaya bilən cihaz hansıdır?'],
          after: '<p>DAI bütün ARP frame-lərini yoxlaya bildiyi üçün effektivdir: ARP frame-ləri switch-dən keçir.</p>' },
        { id: 's10', title: 'Öz kompüterində: ARP cache', type: 'form',
          body: '<p>Öz kompüterində əvvəl default gateway-ə ping at, sonra <span class="m">arp -a</span> yaz (Windows, Linux və ya macOS). Gateway sətrinə bax. Type (Windows) sütununda nə yazılıb?</p><pre class="pre"><span class="p">C:\\&gt;</span>ping &lt;gateway ip&gt;\n<span class="p">C:\\&gt;</span>arp -a</pre>',
          fields: [{ label: 'Gateway sətrinin tipi', placeholder: 'dynamic / static', answers: ['dynamic', 'dinamik'], wrong: 'ARP ilə öyrənilən giriş adətən dynamic olur. Gateway sətrini tapdığına əmin ol (ipconfig ilə gateway IP-sini yoxla).' }],
          hints: ['Gateway IP-sini ipconfig ilə tap. arp -a çıxışında həmin IP-yə uyğun sətri axtar.'],
          solution: 'Gateway girişi ARP ilə öyrənildiyi üçün dynamic olur.',
          after: '<p>Əgər ping-dən əvvəl cache-də gateway yox idisə, ping onu yaratdı. Bu, bu mövzunun əsas müşahidəsidir.</p>' },
      ],
    },

    quiz: {
      draw: 8,
      gens: [
        // which IP does the PC ARP for?
        () => {
          const p = pick([24, 25, 26, 27, 28]); const b = pick(['192.168.1', '10.0.5', '172.16.9']); const block = Math.pow(2, 32 - p); const base = block * R(256 / block);
          const h1 = base + 2 + R(block - 3); const gw = base + 1; const same = R(2) === 0;
          let tgt; if (same) { do { tgt = base + 1 + R(block - 2); } while (tgt === h1); } else { const o = pick(['8.8.8.8', '10.200.3.7', '172.31.4.4', '203.0.113.20']); tgt = null; var tip = o; }
          const hostIp = b + '.' + h1, gwIp = b + '.' + gw; const tIp = same ? b + '.' + tgt : tip;
          // for "same" with gateway as target: avoid (tgt may equal gw -> fine, it's still ARP for that IP)
          const eq = A.info(hostIp, p).net === A.info(tIp, p).net; const ans = eq ? tIp : gwIp;
          const why = 'PC öz mask-ı (' + A.maskS(p) + ') ilə hesablayır: ' + hostIp + ' → network ' + A.info(hostIp, p).net + ', ' + tIp + ' → network ' + A.info(tIp, p).net + '. ' + (eq ? 'Eynidir, ona görə hədəfin özünün MAC-i lazımdır.' : 'Fərqlidir, ona görə kadr gateway-ə gedir və gateway-in MAC-i lazımdır.');
          return { id: 'p1t5-g-arpfor', concept: eq ? 'arp-flow' : 'arp-other-net', obj: 'ARP hansı IP-ni soruşur', type: 'num', _meta: { hostIp, p, gwIp, tIp, ans },
            stem: '<p>PC: IP <span class="m">' + hostIp + '</span>, mask <span class="m">' + A.maskS(p) + '</span>, gateway <span class="m">' + gwIp + '</span>. PC <span class="m">' + tIp + '</span> ünvanına ping göndərir və ARP cache boşdur. PC <b>hansı IP ünvanının</b> MAC-ini ARP ilə soruşacaq?</p>', placeholder: 'a.b.c.d',
            check: r => r.trim() === ans, solution: why + ' Cavab: <b>' + ans + '</b>.' };
        },
        // duplicate MAC in an ARP cache
        () => {
          const b = pick(['192.168.1', '10.1.1', '172.16.8']); const hosts = shuffle([1, 5, 12, 20, 33, 47, 60, 77, 90, 101, 130]).slice(0, 4).sort((x, y) => x - y);
          const macs = hosts.map(() => rmac()); const i = R(4); let j; do { j = R(4); } while (j === i); macs[j] = macs[i];
          const lines = hosts.map((h, k) => '  ' + (b + '.' + h).padEnd(18) + macs[k] + '     dynamic').join('\n');
          const pairs = []; for (let x = 0; x < 4; x++) for (let y = x + 1; y < 4; y++) pairs.push([x, y]);
          const correct = [Math.min(i, j), Math.max(i, j)]; const chosen = shuffle(pairs.filter(p => !(p[0] === correct[0] && p[1] === correct[1]))).slice(0, 3); chosen.push(correct);
          const ipOf = k => b + '.' + hosts[k];
          return { id: 'p1t5-g-dupmac', concept: 'arp-attack', obj: 'ARP cache-də təkrarlanan MAC', _meta: { macs, ans: correct },
            stem: '<p><span class="m">arp -a</span> çıxışı:</p><pre class="pre">  Internet Address  Physical Address      Type\n' + lines + '</pre><p>Hansı iki IP ünvanı <b>eyni MAC</b> ünvanına bağlıdır? Bu ARP spoofing əlaməti ola bilər (həm də bir cihazın iki IP ünvanı ola bilər).</p>',
            options: shuffle(chosen).map(p => ({ t: ipOf(p[0]) + ' və ' + ipOf(p[1]), ok: p[0] === correct[0] && p[1] === correct[1],
              why: (p[0] === correct[0] && p[1] === correct[1]) ? 'Hər ikisinin MAC-i ' + macs[correct[0]] + 'dir. Bir MAC-in iki IP-yə bağlı olması hücumçunun gateway və ya başqa host əvəzinə cavab verməsi əlaməti ola bilər; yoxlamaq lazımdır. Zərərsiz izah: bir cihazda iki IP (məsələn virtual IP).' : 'Bu iki IP-nin MAC-ləri fərqlidir (' + macs[p[0]] + ' və ' + macs[p[1]] + '). Təkrarlanan MAC başqa cütdədir.' })) };
        },
      ],
      pool: [
        { id: 'p1t5-q1', concept: 'arp-why', obj: 'ARP-ın lazım olma səbəbi',
          stem: '<p>PC hədəfin IP ünvanını bilir. Niyə yenə də ARP lazımdır?</p>',
          options: [
            { t: 'Kadrın Destination MAC-i lazımdır və IP-dən MAC hesablanmır, soruşulmalıdır.', ok: true, why: 'Switch və NIC yalnız MAC-ə baxır. Niyə: IP ilə MAC arasında riyazi əlaqə yoxdur, MAC kartın içinə yazılıb. Burada: ARP həmin MAC-i tapır, sonra kadr qurula bilir.' },
            { t: 'IP ünvanı yalnız bir dəfə doğrulanmalıdır və ARP bu doğrulamanı edir.', why: 'ARP IP-ni doğrulamır. Onun işi IP-yə uyğun MAC-i tapmaqdır. Doğrulama olmaması ARP spoofing-in səbəbidir.' },
            { t: 'IP paketi ARP olmadan şəbəkə kartına verilə bilməz, standart belə tələb edir.', why: 'Kartın tələbi MAC-dir, ARP deyil. MAC statik cədvəldən də bilinə bilərdi; ARP sadəcə bunu avtomatik edir.' },
            { t: 'ARP şəbəkənin hansı subnet-də olduğunu hesablayır.', why: 'Subnet hesabını mask edir (ikinci mövzu). ARP bu qərardan sonra gəlir və yalnız MAC-i tapır.' },
          ] },
        { id: 'p1t5-q2', concept: 'arp-flow', obj: 'Request broadcast, reply unicast',
          stem: '<p>ARP request broadcast, ARP reply isə unicast gedir. Niyə?</p>',
          options: [
            { t: 'Request-də hədəf MAC bilinmir. Reply-da cavab verən soruşanın MAC-ini artıq bilir.', ok: true, why: 'Soruşan hədəfin MAC-ini bilmir, ona görə hamıya göndərir. Cavab verən isə request-in Sender MAC sahəsindən soruşanın MAC-ini öyrənib və unicast cavab göndərə bilir.' },
            { t: 'Broadcast yalnız birinci kadrlar üçündür, qalan bütün kadrlar həmişə unicast olur.', why: 'Qayda "ilk kadr broadcast" deyil. Hər kadrın növü Destination MAC-in məlum olub-olmamasından asılıdır.' },
            { t: 'Reply də broadcast olmalıdır, amma switch onu unicast edir.', why: 'Switch kadrın başlığını dəyişmir. Reply göndərənin özü unicast kimi qurur.' },
            { t: 'Request kiçik, reply böyük paketdir, ona görə növləri fərqlidir.', why: 'İkisi də eyni ölçüdədir (28 bayt). Növ fərqi ölçüdən yox, ünvanın bilinib-bilinməməsindən gəlir.' },
          ] },
        { id: 'p1t5-q3', concept: 'arp-flow', obj: 'Switch ARP request-ə necə baxır',
          stem: '<p>Switch ARP request kadrını alır. Switch <b>nə edir</b>?</p>',
          options: [
            { t: 'Source MAC-i öyrənir və kadrı digər bütün portlara göndərir.', ok: true, why: 'Switch hər kadrda Source MAC-i cədvəlinə yazır (hansı portdan gəldi). Destination broadcast olduğu üçün kadr bütün digər portlara flood olunur. İkisi də eyni kadrda baş verir.' },
            { t: 'Yalnız hədəf IP-nin sahibinə göndərir, çünki ARP paketi IP-ni daşıyır.', why: 'Switch IP-yə baxmır. Üstəlik request broadcast olduğu üçün hədəfi tanıya bilməz; hamıya göndərir.' },
            { t: 'Kadrı yalnız router-ə verir ki, router ARP-a cavab versin və yönləndirsin.', why: 'Router yalnız öz IP-si soruşulanda cavab verir. Switch kadrı hamıya göndərir, router da ona daxil olan bir cihazdır.' },
            { t: 'ARP kadrını atır, çünki ARP IP protokolu deyil və switch onu tanımır.', why: 'Switch Layer 2 cihazıdır və ARP Layer 2 kadrında gəlir. Atmaq üçün heç bir səbəb yoxdur.' },
          ] },
        { id: 'p1t5-q4', concept: 'arp-flow', obj: 'ARP cache-in təsiri',
          stem: '<p>PC1 192.168.1.20-yə ilk ping-i atdı, ARP uğurlu oldu. Bir dəqiqə sonra yenidən ping atır. <b>ARP yenidən göndərilirmi?</b></p>',
          options: [
            { t: 'Yox, cache-də giriş var, PC1 kadrı birbaşa qurur (vaxt bitməyibsə).', ok: true, why: 'Cache məhz təkrar ARP-ın qarşısını almaq üçündür. Giriş silinənə qədər host MAC-i cache-dən götürür. Bu səbəbdən ilk ping adətən sonrakılardan yavaş olur.' },
            { t: 'Bəli, hər ping üçün yeni ARP sorğusu göndərilməlidir, cache kömək etmir.', why: 'Hər paketdə ARP göndərilsəydi şəbəkədə çoxlu broadcast olardı. Cache bunun qarşısını alır.' },
            { t: 'Bəli, çünki ping ICMP-dir və ICMP üçün cache işləmir.', why: 'Cache Layer 2 ünvan həllini saxlayır və protokoldan asılı deyil. ICMP də, TCP də eyni cache-dən istifadə edir.' },
            { t: 'Yox, çünki ARP nəticəsi yalnız switch-in MAC address table-ında saxlanır.', why: 'ARP cache host-dadır. Switch-in cədvəli isə ayrıdır (MAC → port) və host ondan istifadə etmir.' },
          ] },
        { id: 'p1t5-q5', concept: 'arp-other-net', obj: 'Fərqli network üçün ARP',
          stem: '<p>PC 192.168.1.10/24 ünvanından 10.0.0.5-ə paket göndərir (gateway 192.168.1.1). ARP request-də <b>Target IP</b> nədir?</p>',
          options: [
            { t: '192.168.1.1, yəni gateway-in IP-si.', ok: true, why: 'Hədəf fərqli network-dədir, kadr link-də gateway-ə çatmalıdır, buna görə gateway-in MAC-i lazımdır. 10.0.0.5-in MAC-i PC-yə lazım deyil və ARP onu tapa bilməz (router-dən keçmir).' },
            { t: '10.0.0.5, yəni son hədəfin IP-si, router onu tapacaq.', why: 'ARP broadcast-dır və router-dən keçmir. 10.0.0.5 başqa broadcast domain-dədir və sorğunu görmür.' },
            { t: '255.255.255.255, çünki hədəf bilinmir.', why: '255.255.255.255 ARP-ın Target IP sahəsində olmur. Broadcast ünvanı Ethernet Destination MAC-dədir, Target IP isə konkret IP-dir.' },
            { t: '192.168.1.255, yəni subnet-in broadcast ünvanı.', why: 'Subnet broadcast ARP-ın hədəfi deyil. ARP konkret IP-nin MAC-ini soruşur, broadcast ünvanının yox.' },
          ] },
        { id: 'p1t5-q6', concept: 'arp-other-net', obj: 'Səhv gateway simptomu',
          stem: '<p>PC-də gateway IP-si səhv yazılıb (orada router yoxdur). Hansı simptom <b>gözlənilir</b>?</p>',
          options: [
            { t: 'Eyni network-dəki cihazlara ping işləyir, başqalarına işləmir.', ok: true, why: 'Eyni network üçün ARP birbaşa hədəfi soruşur və uğurlu olur. Başqa network üçün gateway-in MAC-i lazımdır; orada heç kim cavab vermir, ona görə heç bir paket kənara çıxmır.' },
            { t: 'Heç bir ping işləmir, eyni network-də də.', why: 'Eyni network-də gateway lazım deyil. Orada ARP hədəfin özünə göndərilir və uğurlu olur.' },
            { t: 'Hər şey normal işləyir, gateway yalnız DNS üçün lazımdır.', why: 'Gateway DNS üçün deyil, fərqli network-lərə çıxış üçündür. Onsuz fərqli network-lərə paket çıxmır.' },
            { t: 'Yalnız veb səhifələr açılmır, ping isə başqa network-lərə də işləyir.', why: 'Ping də başqa network-ə gateway vasitəsilə gedir. Gateway işləmirsə, ping də keçmir.' },
          ] },
        { id: 'p1t5-q7', concept: 'arp-packet', obj: 'Request-də Target MAC',
          stem: '<p>ARP request-də <b>Target MAC</b> sahəsi niyə 00:00:00:00:00:00-dır?</p>',
          options: [
            { t: 'Məhz bu MAC axtarılır, ona görə hələ bilinmir, sıfırlarla doldurulur.', ok: true, why: 'Request-in məqsədi "bu IP-nin MAC-i nədir?" sualının cavabını tapmaqdır. Cavab bilinmədiyi üçün sahə sıfırdır. Reply-da isə bu sahə soruşanın MAC-i olur.' },
            { t: 'Sıfır MAC həmişə broadcast ünvanı mənasındadır, switch onu belə oxuyur.', why: 'Broadcast MAC FF:FF:FF:FF:FF:FF-dir (hamısı 1). Sıfırlar "bilinmir" mənasındadır, broadcast deyil.' },
            { t: 'Switch bu sahəni doldurur, host isə boş göndərir.', why: 'Switch kadrın içini dəyişmir. Sahə göndərən tərəfindən sıfırla yazılır.' },
            { t: 'Hədəf cihazın MAC-i cache-də var, amma təhlükəsizlik üçün gizlədilir.', why: 'Cache-də giriş olsaydı, ARP göndərilməzdi. Sıfır gizlətmə deyil, bilinməməsinin göstəricisidir.' },
          ] },
        { id: 'p1t5-q8', concept: 'arp-packet', obj: 'ARP IP-nin içində deyil',
          stem: '<p>ARP kadrı IP başlığı olmadan, birbaşa Ethernet-in içində gedir (EtherType 0x0806). Bunun nəticəsi nədir?</p>',
          options: [
            { t: 'ARP router-dən keçmir, çünki router IP başlığına görə yönləndirir.', ok: true, why: 'Router yönləndirməni IP başlığı ilə edir. ARP-da IP başlığı və TTL yoxdur, ona görə router onu yönləndirə bilməz. ARP yalnız bir link-də işləyir.' },
            { t: 'ARP kadrının TTL-i var və o, router-dən keçərək digər network-lərə çatır.', why: 'ARP-da IP başlığı yoxdur, deməli TTL də yoxdur. Router ARP-ı yönləndirmir.' },
            { t: 'ARP yalnız IPv6 şəbəkələrində işləyə bilər, çünki IPv4 başlığı tələb edir.', why: 'ARP IPv4 üçündür. IPv6-da onun əvəzinə Neighbor Discovery istifadə olunur.' },
            { t: 'ARP başlığı şifrələnmir, ona görə router onu oxuyub ötürə bilmir.', why: 'Bu doğrudur, amma verilən faktın nəticəsi deyil. IP başlığının olmaması router-dən keçməməyə aparır, şifrələnmə isə ayrı məsələdir.' },
          ] },
        { id: 'p1t5-q9', concept: 'arp-cache', obj: 'ARP cache və MAC address table',
          stem: '<p>Hansı ifadə <b>düzgündür</b>?</p>',
          options: [
            { t: 'ARP cache IP → MAC (host, router), MAC address table MAC → port (switch).', ok: true, why: 'Bunlar iki fərqli cədvəldir: biri Layer 3-dən Layer 2-yə ünvan həllidir, digəri Layer 2-də kadrın hansı porta gedəcəyini bildirir.' },
            { t: 'ARP cache switch-də olur, MAC address table isə host və router-də saxlanır.', why: 'Tərsinədir: ARP cache host və router-dədir, MAC address table switch-dədir.' },
            { t: 'İkisi eyni cədvəldir, sadəcə müxtəlif cihazlarda adı fərqli çağırılır.', why: 'Bunlar fərqli məzmundadır: biri IP → MAC, digəri MAC → port. Qarışdırmaq çox yayılmış səhvdir.' },
            { t: 'ARP cache MAC → port, MAC address table isə IP → MAC saxlayır.', why: 'Məzmunlar tərsinə yazılıb. IP → MAC cütü ARP cache-dədir, MAC → port isə switch cədvəlindədir.' },
          ] },
        { id: 'p1t5-q10', concept: 'arp-cache', obj: 'Static ARP girişi',
          stem: '<p>ARP cache-də <b>static</b> tipli giriş nə deməkdir?</p>',
          options: [
            { t: 'Giriş ARP ilə öyrənilməyib, əllə və ya sistem yaradıb, silinmir.', ok: true, why: 'Dynamic girişlər ARP ilə öyrənilir və timeout ilə silinir. Static girişlər isə əllə (arp -s) və ya sistem tərəfindən (multicast, broadcast) yaradılır və silinmir.' },
            { t: 'Giriş yalnız statik IP ünvanı olan cihazlar üçün yaradılır və saxlanılır.', why: 'Tip IP-nin necə təyin olunmasından asılı deyil. Statik IP-li cihazın girişi də ARP ilə öyrənilərsə dynamic olur.' },
            { t: 'Giriş cihaz söndüləndə silinir, yenidən yüklənəndə avtomatik qayıdır.', why: 'Bu dynamic girişin xüsusiyyəti deyil, hər iki tip üçün qaydalar fərqlidir. Static giriş ömrü boyu qalır (əməliyyat sistemi qaydasına görə).' },
            { t: 'Giriş yalnız gateway üçündür və ilk ping-də avtomatik yaranır.', why: 'Gateway girişi ARP ilə öyrənilir və dynamic olur. Static tip gateway ilə məhdud deyil.' },
          ] },
        { id: 'p1t5-q12', concept: 'arp-attack', obj: 'ARP spoofing niyə işləyir',
          stem: '<p>ARP spoofing niyə mümkündür?</p>',
          options: [
            { t: 'ARP cavabı yoxlanmır, cihazlar soruşulmamış reply-ı da qəbul edir.', ok: true, why: 'ARP-ın autentifikasiyası yoxdur. Cihaz reply alanda cavab verənin həqiqətən həmin IP-nin sahibi olub-olmadığını yoxlamır. Hücumçu saxta reply göndərir və cache dəyişir.' },
            { t: 'ARP şifrələnir və hücumçu şifrəni sındırır.', why: 'ARP şifrələnmir. Hücum şifrə sındırmaq deyil, yoxlamanın olmamasından istifadə etməkdir.' },
            { t: 'Router ARP-ı bütün network-lərə ötürür, ona görə hücumçu uzaqdan işləyir.', why: 'Router ARP-ı ötürmür. ARP spoofing yalnız eyni link-dəki hücumçu tərəfindən edilir.' },
            { t: 'Switch ARP cache-i saxlayır və hücumçu onu dəyişir.', why: 'Hücumun hədəfi hostların ARP cache-idir, switch-in cədvəli yox. Switch ARP cache saxlamır.' },
          ] },
        { id: 'p1t5-q13', concept: 'arp-attack', obj: 'DAI nəyə əsaslanır',
          stem: '<p>Dynamic ARP Inspection (DAI) ARP paketlərini <b>nəyə qarşı</b> yoxlayır?</p>',
          options: [
            { t: 'Switch-in bildiyi IP, MAC və port uyğunluğuna.', ok: true, why: 'DAI ARP paketindəki IP-MAC cütünü switch-in bildiyi uyğunluqla müqayisə edir və uyğun gəlməyəni atır.' },
            { t: 'Router-in routing table-ındakı network-lərin siyahısına.', why: 'Routing table Layer 3 yönləndirməsi üçündür və ARP-ın IP-MAC uyğunluğunu yoxlamaq üçün istifadə olunmur.' },
            { t: 'Hostun öz ARP cache-indəki girişlərə qarşı.', why: 'Switch hostların cache-ini görmür. DAI öz binding cədvəli ilə işləyir.' },
            { t: 'Firewall-un ACL qaydalarında yazılmış ünvanlara.', why: 'DAI firewall deyil, switch funksiyasıdır və switch-in bildiyi IP-MAC-port uyğunluğuna əsaslanır.' },
          ] },
        { id: 'p1t5-q14', concept: 'arp-attack', obj: 'Gateway MAC dəyişməsi',
          stem: '<p>Dünən gateway IP-sinin MAC-i <span class="m">00-01-43-21-dd-dd</span> idi. Bu gün istifadəçinin <span class="m">arp -a</span> çıxışında həmin IP üçün başqa MAC var. Ən doğru ilk addım hansıdır?</p>',
          options: [
            { t: 'Router-in real MAC-ini yoxlayıb, yeni MAC-in switch portunu tapmaq.', ok: true, why: 'MAC dəyişməsi iki hal ola bilər: router dəyişdirilib (zərərsiz) və ya ARP spoofing. Sübut üçün real MAC-i və yeni MAC-in porta (show mac address-table) bağlanmasını yoxlayırsan.' },
            { t: 'ARP cache-i silib problemi həll olunmuş hesab etmək və davam etmək.', why: 'Cache-i silmək simptomu müvəqqəti aradan qaldırar, səbəbi aşkar etməz. Hücum davam edərsə, cache yenidən zəhərlənəcək.' },
            { t: 'Dərhal şirkətin bütün switch portlarını söndürmək və şəbəkəni dayandırmaq.', why: 'Bu həddən artıq sərt və sübutsuzdur. Əvvəl hadisənin hücum olub-olmadığını təsdiq etmək lazımdır.' },
            { t: 'Heç nə etməmək, çünki MAC ünvanları adətən tez-tez dəyişir.', why: 'Gateway MAC-i adətən dəyişmir. Dəyişibsə, bu araşdırılmalı hadisədir, ya texniki dəyişiklik, ya da hücum.' },
          ] },
      ],
    },
  });
})();
