(function () {
  const pick = PT.pick; const R = PT.randInt; const shuffle = PT.shuffle;
  const norm = s => String(s).trim().toLowerCase().replace(/\s+/g, ' ');

  PT.topic({
    id: 'p3t1',
    objectives: [
      'VLAN-ın nə üçün lazım olduğunu və hansı problemləri həll etdiyini demək',
      'Access port və VLAN ID anlayışlarını izah etmək',
      'VLAN yaratmaq və portları VLAN-a təyin etmək, show vlan brief ilə yoxlamaq',
      'Fərqli VLAN-ların niyə router olmadan danışa bilmədiyini izah etmək',
      'VLAN səhvlərini simptomdan tapmaq',
    ],
    explain: PT.frag['p3/t01/explain'], cheat: PT.frag['p3/t01/cheat'],

    lab: {
      title: 'Lab 1: VLAN-ları planla, qur və yoxla',
      goal: 'VLAN planını hazırlamaq, konfiqurasiyada və show çıxışında səhv tapmaq, ticket həll etmək və Packet Tracer-də VLAN qurmaq.',
      why: 'Şirkət şəbəkələrində cihazlar VLAN-lara bölünür. Port yanlış VLAN-dadırsa cihaz heç kimi görmür, bu isə tez-tez rast gəlinən səbəbdir.',
      minutes: 45,
      finish: 'VLAN-ı planlaya, qura və səhvini tapa bilirsən. İndi quizə keç.',
      steps: [
        { id: 's1', title: 'Hazırlıq', type: 'info', button: 'Başladım',
          body: '<p>Ssenari: bir switch-də üç şöbə var: SALES (VLAN 10), ACCOUNTING (VLAN 20) və IT (VLAN 30). Subnet-lər <span class="m">192.168.10.0/24</span>, <span class="m">192.168.20.0/24</span>, <span class="m">192.168.30.0/24</span>.</p>' },
        { id: 's2', title: 'Anlayışı mənası ilə birləşdir', type: 'match',
          body: '<p>Hər anlayış nə deməkdir?</p>',
          pairs: [
            { l: 'VLAN', r: 'Switch-in virtual hissəsi, ayrı broadcast domain', why: 'Bir fiziki switch-i bölür.' },
            { l: 'Access port', r: 'Bir VLAN-a aid olan, son cihaz üçün port', why: 'PC, printer qoşulur.' },
            { l: 'VLAN 1', r: 'Default VLAN, bütün portlar əvvəlcə orada', why: 'Silinmir.' },
            { l: 'Fərqli VLAN-lar arası trafik', r: 'Router və ya Layer 3 cihazı lazımdır', why: 'VLAN-lar ayrı broadcast domain-dir.' },
          ],
          hints: ['VLAN ayrı broadcast domain deməkdir.'] },
        { id: 's3', title: 'VLAN planını hazırla', type: 'form',
          body: '<p>Switch portları: Fa0/1–Fa0/8 SALES, Fa0/9–Fa0/16 ACCOUNTING, Fa0/17–Fa0/24 IT. SALES PC-sinə (Fa0/3) ünvan verirsən.</p>',
          fields: [
            { label: 'Fa0/3 portu hansı VLAN-dadır?', placeholder: 'rəqəm', check: r => String(r).trim() === '10', show: '10', wrong: 'Fa0/1–Fa0/8 SALES-dir.' },
            { label: 'Fa0/3-ə qoşulan PC-nin subnet-i', placeholder: 'a.b.c.d/n', check: r => norm(r) === '192.168.10.0/24', show: '192.168.10.0/24', wrong: 'VLAN 10-un subnet-i.' },
            { label: 'Fa0/20-nin VLAN-ı', placeholder: 'rəqəm', check: r => String(r).trim() === '30', show: '30', wrong: 'Fa0/17–Fa0/24 IT-dir.' },
            { label: 'Fa0/9 üçün VLAN təyin edən əmr', placeholder: 'əmr', check: r => norm(r) === 'switchport access vlan 20', show: 'switchport access vlan 20', wrong: 'switchport access vlan <nömrə>' },
          ],
          hints: ['Portun hansı aralıqda olduğuna bax.'],
          solution: 'Fa0/3 → VLAN 10 (192.168.10.0/24). Fa0/20 → VLAN 30. Fa0/9 üçün: switchport access vlan 20.' },
        { id: 's4', title: 'Konfiqurasiyada səhvi tap', type: 'spot',
          body: '<p>Kolleqa SALES VLAN-ını quraşdırıb. Fa0/1 SALES PC-sinə qoşulub. SALES PC-si ACCOUNTING PC-si ilə eyni switch-də olmasına baxmayaraq danışa bilmir (bu normal), amma öz VLAN-ının PC-si ilə də danışa bilmir. <b>Bir sətir səhvdir.</b></p>',
          lines: [
            { t: 'vlan 10' },
            { t: ' name SALES' },
            { t: 'interface FastEthernet0/1' },
            { t: ' switchport mode access' },
            { t: ' switchport access vlan 20', bad: true, why: 'Port VLAN 20-ə təyin olunub (ACCOUNTING). SALES PC-si VLAN 10-da olmalıdır.' },
          ],
          fix: { label: 'Düzgün VLAN nömrəsi', placeholder: 'rəqəm', answers: ['10'], wrong: 'SALES VLAN 10-dur.' },
          hints: ['Portun hansı VLAN-a təyin olduğuna bax.'] },
        { id: 's5', title: 'show vlan brief oxu', type: 'spot',
          body: '<p>Bir istifadəçi şikayət edir: Fa0/5 portundakı PC heç bir şeyə qoşula bilmir. Cədvələ bax. <b>Problemi izah edən sətri tap.</b></p>',
          lines: [
            { t: 'VLAN Name                             Status    Ports' },
            { t: '1    default                          active    Fa0/6, Fa0/7, Fa0/8' },
            { t: '10   SALES                            active    Fa0/1, Fa0/2, Fa0/3' },
            { t: '20   ACCOUNTING                       active    Fa0/4', bad: true, why: 'Fa0/5 heç bir VLAN-ın siyahısında yoxdur. Çox ehtimalla port aid olduğu VLAN silinib: port heç bir VLAN-a aid deyil.' },
          ],
          fix: { label: 'Fa0/5 üçün nə etməlisən?', placeholder: 'məs. portu VLAN-a təyin et', answers: ['portu vlana teyin et', 'portu vlan-a təyin et', 'portu vlana təyin et', 'switchport access vlan', 'vlan yarat'], wrong: 'Portu mövcud bir VLAN-a təyin et və ya VLAN-ı yenidən yarat.' },
          hints: ['Port siyahıda yoxdursa, VLAN-a aid deyil.'] },
        { id: 's6', title: 'Ticket: "Mühasibat PC-si printeri görmür"', type: 'ticket',
          body: '<p><b>İstifadəçi deyir:</b> "Mühasibat PC-si eyni switch-də olan printeri görmür." Printer VLAN 20-dədir (192.168.20.50). PC Fa0/4-ə qoşulub, ipconfig: <span class="m">192.168.20.15/24</span>.</p>',
          stages: [
            { q: '<p>İlk yoxlama?</p>', options: [
              { t: 'PC-nin portunun VLAN-ı: show vlan brief və ya show interfaces fa0/4 switchport.', ok: true, why: 'PC düzgün subnet-dədir, VLAN ayarı şübhəlidir.' },
              { t: 'DNS server ayarı, çünki printer ad ilə axtarılır.', why: 'IP ilə ping edəndə də görmürsə, DNS səbəb deyil.' },
              { t: 'PC-nin MAC ünvanının unikal olması.', why: 'Eyni VLAN-da MAC problemi nadir haldır.' },
              { t: 'Router-in routing table-ı, çünki iki cihaz danışmır.', why: 'Eyni VLAN-dakı cihazlar router olmadan danışır.' },
            ] },
            { q: '<p>show vlan brief göstərir ki, Fa0/4 VLAN 10-dadır. Bu nə deməkdir?</p>', options: [
              { t: 'PC VLAN 10-dadır, printer VLAN 20-dədir: fərqli VLAN-lardır, danışa bilməzlər.', ok: true, why: 'IP ünvanı VLAN 20-nin subnet-indədir, port isə VLAN 10-dadır. Uyğunsuzluq var.' },
              { t: 'Hər iki cihaz eyni VLAN-dadır, problem başqa yerdədir.', why: 'Printer VLAN 20-dədir, PC-nin portu VLAN 10-dadır.' },
              { t: 'Switch VLAN-ları yanlış göstərir.', why: 'Switch çıxışı portun real ayarını göstərir.' },
              { t: 'VLAN 10 və 20 eyni subnet-dədir.', why: 'Hər VLAN ayrı subnet-dədir.' },
            ] },
            { q: '<p>Həll?</p>', options: [
              { t: 'Fa0/4 portunu VLAN 20-yə təyin etmək: switchport access vlan 20.', ok: true, why: 'PC-nin portu cihazın VLAN-ı ilə üst-üstə düşməlidir.' },
              { t: 'PC-nin IP-sini 192.168.10.15 etmək, VLAN 10-da qalmaq.', why: 'Printer VLAN 20-dədir. PC həmin VLAN-da olmalıdır.' },
              { t: 'Printer-in IP-sini dəyişmək.', why: 'Problem printer-də deyil, PC-nin portundadır.' },
              { t: 'VLAN 20-ni silmək.', why: 'VLAN 20-ni silmək yeni problemlər yaradar.' },
            ] },
          ],
          after: '<p>Metod: port VLAN-ı ilə cihazın IP subnet-i üst-üstə düşməlidir.</p>' },
        { id: 's7', title: 'Packet Tracer-də qur', type: 'ptsteps',
          body: '<p>Bir switch və dörd PC qoş.</p>',
          checks: [
            { t: 'PC1, PC2 → Fa0/1, Fa0/2. PC3, PC4 → Fa0/3, Fa0/4. IP-lər: PC1 <span class="m">192.168.10.11</span>, PC2 <span class="m">192.168.10.12</span>, PC3 <span class="m">192.168.20.13</span>, PC4 <span class="m">192.168.20.14</span> (mask 255.255.255.0).' },
            { t: 'Əvvəl ping et: PC1 → PC2 (işləməlidir) və PC1 → PC3 (bütün cihazlar bir VLAN-dadır, amma fərqli subnet-lər, ping işləmir).' },
            { t: 'Switch CLI-da VLAN-ları yarat: <span class="m">vlan 10</span>, <span class="m">name SALES</span>, <span class="m">vlan 20</span>, <span class="m">name ACCOUNTING</span>.', cmd: ['vlan 10', 'name SALES', 'vlan 20', 'name ACCOUNTING'] },
            { t: 'Portları təyin et: Fa0/1–2 <span class="m">switchport mode access</span> və <span class="m">switchport access vlan 10</span>; Fa0/3–4 VLAN 20.', cmd: ['interface range fa0/1 - 2', 'switchport mode access', 'switchport access vlan 10'] },
            { t: '<span class="m">show vlan brief</span> yaz. Sonra PC1 → PC2 ping et (işləməlidir) və PC1 → PC3 (işləməməlidir).', cmd: ['show vlan brief'] },
          ] },
        { id: 's8', title: 'Gördüyünü yaz', type: 'form',
          body: '<p>VLAN-lar qurulandan sonra PC1 → PC3 ping nə etdi?</p>',
          fields: [
            { label: 'PC1 → PC2 ping (işləyir / işləmir)', placeholder: 'seç', answers: ['işləyir', 'isleyir', 'ok', 'uğurlu'], wrong: 'Eyni VLAN-dadırlar.' },
            { label: 'PC1 → PC3 ping (işləyir / işləmir)', placeholder: 'seç', answers: ['işləmir', 'islemir', 'timeout'], wrong: 'Fərqli VLAN-lardır.' },
          ],
          solution: 'PC1 → PC2 işləyir, PC1 → PC3 işləmir (router olmadan).' },
      ],
    },

    quiz: {
      draw: 8,
      gens: [
        () => {
          const ports = shuffle([['Fa0/1', 10], ['Fa0/2', 10], ['Fa0/3', 20], ['Fa0/4', 20], ['Fa0/5', 30]]).slice(0, 2);
          const a = ports[0], b = ports[1]; const same = a[1] === b[1];
          const ipA = '192.168.' + a[1] + '.' + (10 + R(20)), ipB = '192.168.' + b[1] + '.' + (40 + R(20));
          return { id: 'p3t1-g-talk', concept: 'vlan-basics', obj: 'Eyni switch, danışırlarmı', _meta: { a, b, same },
            stem: '<p>Eyni switch-də iki PC var. PC-A <span class="m">' + a[0] + '</span> portunda (VLAN ' + a[1] + ', IP ' + ipA + '/24), PC-B <span class="m">' + b[0] + '</span> portundadır (VLAN ' + b[1] + ', IP ' + ipB + '/24). Router yoxdur. PC-A PC-B-yə ping edə bilərmi?</p>',
            options: [
              { t: 'Bəli, eyni VLAN-dadırlar və eyni subnet-dədirlər.', ok: same, why: same ? 'Eyni VLAN və eyni subnet: switch frame-i ötürür, ping işləyir.' : 'VLAN-lar fərqlidir (' + a[1] + ' və ' + b[1] + '), ping işləmir.' },
              { t: 'Xeyr, fərqli VLAN-lardadır və aralarında router lazımdır.', ok: !same, why: !same ? 'Fərqli VLAN-lar ayrı broadcast domain-dir və router olmadan danışmır.' : 'Eyni VLAN-dadırlar, ping işləyir.' },
            ] };
        },
      ],
      pool: [
        { id: 'p3t1-q1', concept: 'vlan-why', obj: 'VLAN nəyi həll edir',
          stem: '<p>VLAN-ın əsas faydası hansıdır?</p>',
          options: [
            { t: 'Switch-i ayrı broadcast domain-lərə bölür və şöbələri ayırır.', ok: true, why: 'Bir fiziki switch bir neçə virtual switch kimi işləyir.' },
            { t: 'Switch-in portlarının sürətini yüksəldir və kabel sayını azaldır.', why: 'VLAN sürəti artırmır, məntiqi bölgü yaradır.' },
            { t: 'Paketləri şifrələyir və hücumçulardan qoruyur.', why: 'VLAN şifrələmir, trafiki yalnız qruplara ayırır.' },
            { t: 'IP ünvanlarını avtomatik paylayır və DHCP-ni əvəz edir.', why: 'IP ünvanı verən DHCP-dir.' },
          ] },
        { id: 'p3t1-q2', concept: 'vlan-why', obj: 'Broadcast domain',
          stem: '<p>Switch-də üç VLAN qurulub. Neçə broadcast domain var?</p>',
          options: [
            { t: 'Üç, hər VLAN ayrı broadcast domain-dir.', ok: true, why: 'Bir VLAN-dakı broadcast başqa VLAN-a çatmır.' },
            { t: 'Bir, çünki hamısı eyni fiziki switch-dədir.', why: 'Fiziki switch önəmli deyil, VLAN-lar məntiqi bölür.' },
            { t: 'Altı, hər VLAN iki domain yaradır.', why: 'Hər VLAN bir broadcast domain-dir.' },
            { t: 'Sıfır, VLAN broadcast-ı bloklayır.', why: 'Broadcast öz VLAN-ında işləməyə davam edir.' },
          ] },
        { id: 'p3t1-q3', concept: 'vlan-basics', obj: 'Default VLAN',
          stem: '<p>Yeni switch-də bütün portlar hansı VLAN-dadır?</p>',
          options: [
            { t: 'VLAN 1.', ok: true, why: 'VLAN 1 default VLAN-dır.' },
            { t: 'VLAN 0, hələ heç bir VLAN-a aid deyillər.', why: 'VLAN 0 yoxdur. Portlar VLAN 1-dədir.' },
            { t: 'VLAN 10, ilk yaradılan VLAN-dır.', why: 'VLAN-ı administrator yaradır, default 1-dir.' },
            { t: 'VLAN 1002, xüsusi VLAN-dır.', why: '1002 ayrılmış köhnə VLAN-dır, default deyil.' },
          ] },
        { id: 'p3t1-q4', concept: 'vlan-basics', obj: 'Fərqli VLAN danışması',
          stem: '<p>İki PC eyni switch-də fərqli VLAN-lardadır. Aralarında trafik üçün nə lazımdır?</p>',
          options: [
            { t: 'Router və ya Layer 3 switch.', ok: true, why: 'Fərqli VLAN-lar arasında yol yalnız Layer 3 cihazından keçir.' },
            { t: 'Switch-də daha çox port.', why: 'Port sayı VLAN-lar arasında əlaqə yaratmır.' },
            { t: 'Daha sürətli kabel.', why: 'Kabel növü VLAN sərhədini aşmır.' },
            { t: 'Hər iki PC-yə eyni MAC ünvanı vermək.', why: 'MAC ünvanı unikal olmalıdır və problemi həll etmir.' },
          ] },
        { id: 'p3t1-q5', concept: 'vlan-config', obj: 'Port təyini',
          stem: '<p>Fa0/5 portunu VLAN 30-a təyin etmək üçün hansı əmrlər lazımdır?</p>',
          options: [
            { t: 'interface fa0/5, switchport mode access, switchport access vlan 30.', ok: true, why: 'Əvvəl interface-ə girirsən, port rejimini və VLAN-ı yazırsan.' },
            { t: 'vlan 30, interface fa0/5, shutdown, no switchport və bu normal sayılır.', why: 'shutdown portu söndürür, VLAN təyin etmir.' },
            { t: 'interface vlan 30, ip address 192.168.30.1, no shutdown.', why: 'Bu virtual interface üçündür, port təyini deyil.' },
            { t: 'interface fa0/5, switchport trunk allowed vlan 30.', why: 'Bu trunk portu üçündür, access port təyini deyil.' },
          ] },
        { id: 'p3t1-q6', concept: 'vlan-config', obj: 'show vlan brief',
          stem: '<p><span class="m">show vlan brief</span> nəyi göstərir?</p>',
          options: [
            { t: 'Mövcud VLAN-ların adlarını və onlara aid portları.', ok: true, why: 'Bu əmr VLAN-ı və port üzvlüyünü göstərir.' },
            { t: 'Switch-in MAC address table-ını və port statuslarını.', why: 'MAC cədvəli üçün show mac address-table var.' },
            { t: 'Router-in routing table-ını və bütün marşrutlarını.', why: 'Routing table show ip route ilə baxılır.' },
            { t: 'Hər VLAN-ın IP ünvanını və DHCP pool-unu.', why: 'IP ünvanı show ip interface brief-də görünür.' },
          ] },
        { id: 'p3t1-q7', concept: 'vlan-subnet', obj: 'VLAN və subnet',
          stem: '<p>Eyni VLAN-da olan iki PC-nin IP ünvanı fərqli subnet-lərdədir (192.168.10.5/24 və 192.168.20.5/24). Nə baş verir?</p>',
          options: [
            { t: 'PC-lər bir-birini eyni network-də saymır, ping işləmir.', ok: true, why: 'Hər PC hədəfi öz mask-ı ilə yoxlayır və başqa network sayır, gateway-ə verir.' },
            { t: 'Ping normal işləyir, çünki VLAN eynidir.', why: 'VLAN eyni olsa belə, IP subnet-lər fərqlidirsə PC-lər birbaşa danışmır.' },
            { t: 'Switch VLAN-ı avtomatik ikiyə bölür.', why: 'Switch VLAN-ı özü bölmür.' },
            { t: 'DHCP ünvanları avtomatik düzəldir və ping işləyir.', why: 'Statik ünvanlar DHCP ilə dəyişmir.' },
          ] },
        { id: 'p3t1-q8', concept: 'vlan-trouble', obj: 'Silinmiş VLAN',
          stem: '<p>Administrator VLAN 20-ni sildi. Ona aid portlara nə olur?</p>',
          options: [
            { t: 'Portlar heç bir VLAN-a aid olmur və işləmir.', ok: true, why: 'Port silinmiş VLAN-a təyin edilmiş qalır, amma VLAN yoxdur.' },
            { t: 'Portlar avtomatik olaraq VLAN 1-ə keçir və işləyir.', why: 'Portlar avtomatik keçmir, administrator onları yenidən təyin etməlidir.' },
            { t: 'Portlar avtomatik olaraq silinir.', why: 'Fiziki port silinmir.' },
            { t: 'Portlar avtomatik olaraq trunk rejiminə keçir.', why: 'Port rejimi VLAN silinməsi ilə dəyişmir.' },
          ] },
        { id: 'p3t1-q9', concept: 'vlan-trouble', obj: 'Diaqnoz',
          stem: '<p>Eyni switch-dəki iki PC ping etmir. İlk yoxlamalarda nə baxırsan?</p>',
          options: [
            { t: 'Portların VLAN-ına və PC-lərin IP subnet-lərinə.', ok: true, why: 'İki səbəb ən çox rast gəlinəndir: fərqli VLAN və ya fərqli subnet.' },
            { t: 'Router-in OSPF ayarlarına və qonşularına.', why: 'Eyni switch-də router iştirak etmir.' },
            { t: 'DNS server-in record-larına və cache-inə.', why: 'IP ilə ping DNS-dən asılı deyil.' },
            { t: 'Switch-in hostname-inə və banner-inə.', why: 'Hostname ping-ə təsir etmir.' },
          ] },
      ],
    },
  });
})();
