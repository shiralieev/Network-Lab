(function () {
  const pick = PT.pick; const R = PT.randInt; const shuffle = PT.shuffle;
  const norm = s => String(s).trim().toLowerCase().replace(/\s+/g, ' ');

  PT.topic({
    id: 'p3t4',
    objectives: [
      'Layer 3 switch-in nə etdiyini və router-dən fərqini demək',
      'SVI yaratmaq və ip routing əmrini yazmaq',
      'Routed port ilə SVI arasındakı fərqi izah etmək',
      'SVI və routing problemlərini simptomdan tapmaq',
    ],
    explain: PT.frag['p3/t04/explain'], cheat: PT.frag['p3/t04/cheat'],

    lab: {
      title: 'Lab 4: Layer 3 switch ilə VLAN yönləndirməsi',
      goal: 'SVI və ip routing konfiqurasiyasını yazmaq, SVI vəziyyətini oxumaq, ticket həll etmək və Packet Tracer-də Layer 3 switch qurmaq.',
      why: 'Böyük şirkətlərdə VLAN-lar arası trafik Layer 3 switch-də həll olunur. SVI və ip routing əsas bacarıqdır.',
      minutes: 40,
      finish: 'Layer 3 switch-i qura və səhvini tapa bilirsən. İndi quizə keç.',
      steps: [
        { id: 's1', title: 'Hazırlıq', type: 'info', button: 'Başladım',
          body: '<p>Ssenari: Layer 3 switch-də VLAN 10 (<span class="m">192.168.10.0/24</span>), VLAN 20 (<span class="m">192.168.20.0/24</span>). Hər VLAN-ın gateway-i switch-in SVI-sidir (<span class="m">.1</span>).</p>' },
        { id: 's2', title: 'Anlayışı mənası ilə birləşdir', type: 'match',
          body: '<p>Hər anlayış nə deməkdir?</p>',
          pairs: [
            { l: 'SVI', r: 'VLAN üçün virtual interface, VLAN-ın gateway-i', why: 'interface vlan 10 ilə yaradılır.' },
            { l: 'Routed port', r: 'no switchport yazılmış, IP-li port', why: 'Router interface-i kimi işləyir.' },
            { l: '<span class="m">ip routing</span>', r: 'Switch-də Layer 3 yönləndirməni açır', why: 'Olmasa VLAN-lar arası yönləndirmə yoxdur.' },
            { l: 'Layer 3 switch', r: 'Eyni VLAN-da switch, VLAN-lar arasında router', why: 'Yönləndirmə aparat səviyyəsindədir.' },
          ],
          hints: ['SVI VLAN ilə, routed port fiziki porta bağlıdır.'] },
        { id: 's3', title: 'SVI planını yaz', type: 'form',
          body: '<p>VLAN 30 (<span class="m">192.168.30.0/24</span>) əlavə edirsən, gateway <span class="m">.1</span>.</p>',
          fields: [
            { label: 'SVI yaradan əmr', placeholder: 'əmr', check: r => norm(r) === 'interface vlan 30', show: 'interface vlan 30', wrong: 'interface vlan <nömrə>' },
            { label: 'IP ünvan əmri', placeholder: 'əmr', check: r => norm(r) === 'ip address 192.168.30.1 255.255.255.0', show: 'ip address 192.168.30.1 255.255.255.0', wrong: 'ip address <ip> <mask>' },
            { label: 'Routing-i açan global əmr', placeholder: 'əmr', check: r => norm(r) === 'ip routing', show: 'ip routing', wrong: 'Layer 3 funksiya üçün global əmr.' },
          ],
          hints: ['Əmrləri cheat sheet-də yoxla.'],
          solution: 'interface vlan 30 / ip address 192.168.30.1 255.255.255.0 / ip routing (global).' },
        { id: 's4', title: 'Konfiqurasiyada səhvi tap', type: 'spot',
          body: '<p>SVI-lər up/up görünür, amma VLAN 10 və 20 bir-birini görmür. <b>Çatışmazlığı izah edən sətri tap.</b></p>',
          lines: [
            { t: 'hostname L3SW' },
            { t: 'interface Vlan10' },
            { t: ' ip address 192.168.10.1 255.255.255.0' },
            { t: 'interface Vlan20' },
            { t: ' ip address 192.168.20.1 255.255.255.0' },
            { t: '! ip routing əmri yoxdur', bad: true, why: 'ip routing olmadan switch Layer 3 funksiyanı yerinə yetirmir. SVI-lər yalnız ünvan daşıyır.' },
          ],
          fix: { label: 'Əlavə edəcəyin əmr', placeholder: 'əmr', answers: ['ip routing'], wrong: 'Global config-də routing-i açan əmr.' },
          hints: ['SVI var, amma routing açıq deyil.'] },
        { id: 's5', title: 'show ip interface brief oxu', type: 'spot',
          body: '<p>VLAN 30 PC-ləri gateway-ə çatmır. Çıxışa bax. <b>Problemi göstərən sətri tap.</b></p>',
          lines: [
            { t: 'Interface              IP-Address      OK? Method Status                Protocol' },
            { t: 'Vlan10                 192.168.10.1    YES manual up                    up' },
            { t: 'Vlan20                 192.168.20.1    YES manual up                    up' },
            { t: 'Vlan30                 192.168.30.1    YES manual down                  down', bad: true, why: 'Vlan30 down/down: VLAN 30 yaradılmayıb və ya onda aktiv port yoxdur.' },
          ],
          fix: { label: 'İlk yoxlayacağın əmr', placeholder: 'əmr', answers: ['show vlan brief', 'show vlan'], wrong: 'VLAN 30 mövcuddurmu və portları var?' },
          hints: ['SVI up olmaq üçün VLAN mövcud olmalıdır.'] },
        { id: 's6', title: 'Ticket: "VLAN 20 PC-ləri heç bir yerə çıxa bilmir"', type: 'ticket',
          body: '<p><b>İstifadəçi deyir:</b> "VLAN 20 PC-ləri gateway-ə (192.168.20.1) ping edə bilmir. VLAN 10 normal işləyir." Layer 3 switch-də <span class="m">show ip interface brief</span>: <span class="m">Vlan20 192.168.20.1 YES manual administratively down down</span>.</p>',
          stages: [
            { q: '<p>Status administratively down nə deməkdir?</p>', options: [
              { t: 'SVI-də shutdown yazılıb və ya no shutdown yazılmayıb.', ok: true, why: 'Administratively down əl ilə söndürülməni göstərir.' },
              { t: 'VLAN 20 yaradılmayıb.', why: 'Bu halda status down/down olardı, administratively down yox.' },
              { t: 'Kabel qırıqdır.', why: 'Kabel problemi down/down verir.' },
              { t: 'Switch ip routing istəyir.', why: 'ip routing SVI statusuna təsir etmir.' },
            ] },
            { q: '<p>Həll?</p>', options: [
              { t: 'interface vlan 20 daxilində no shutdown yazmaq.', ok: true, why: 'SVI-ni aktiv edir.' },
              { t: 'Router-i yenidən başlatmaq.', why: 'Burada router yoxdur və yenidən başlatma konfiqurasiyanı dəyişmir.' },
              { t: 'PC-lərin kabellərini dəyişmək.', why: 'SVI virtualdır, kabel təsir etmir.' },
              { t: 'VLAN 20-ni silmək.', why: 'VLAN-ı silmək problemi həll etməz.' },
            ] },
            { q: '<p>no shutdown-dan sonra yenə də status down/down qalır. İkinci şübhə?</p>', options: [
              { t: 'VLAN 20 yaradılmayıb və ya onda aktiv port yoxdur.', ok: true, why: 'SVI üçün VLAN mövcud və aktiv olmalıdır.' },
              { t: 'ip routing əmri yazılıb.', why: 'ip routing problemi yaratmır.' },
              { t: 'SVI-nin ünvanı çox kiçikdir.', why: 'Ünvanın böyüklüyü statusa təsir etmir.' },
              { t: 'Hostname uzundur.', why: 'Hostname təsir etmir.' },
            ] },
          ],
          after: '<p>SVI üçün üç şərt: VLAN var, no shutdown var, VLAN-da aktiv port var.</p>' },
        { id: 's7', title: 'Seçim: router, yoxsa Layer 3 switch?', type: 'choice',
          body: '<p>Şirkətin 12 VLAN-ı var, 400 PC. VLAN-lar arası trafik çox yüksəkdir. İnternet çıxışı bir router-dən gedir. VLAN-lar arası yönləndirməni haradan etmək daha yaxşıdır?</p>',
          options: [
            { t: 'Layer 3 switch-də SVI-lərlə: sürətli aparat yönləndirməsi və tək link darboğazı yoxdur.', ok: true, why: 'Böyük daxili trafik üçün Layer 3 switch uyğundur. Router yalnız xarici çıxış üçün qalır.' },
            { t: 'Router-on-a-stick ilə: tək trunk link bütün 12 VLAN-ı daşıyır.', why: 'Yüksək trafikdə həmin link darboğaz olur.' },
            { t: 'Hər VLAN üçün ayrı router almaq.', why: 'Bu həddindən artıq bahalıdır və lazım deyil.' },
            { t: 'Heç bir yönləndirmə etməmək: VLAN-lar özləri danışır.', why: 'VLAN-lar arası trafik üçün Layer 3 cihazı şərtdir.' },
          ],
          hints: ['Trafik həcmi və darboğaz haqqında düşün.'] },
        { id: 's8', title: 'Packet Tracer-də qur', type: 'ptsteps',
          body: '<p>Bir Layer 3 switch (məsələn 3560) və dörd PC qoş.</p>',
          checks: [
            { t: 'Layer 3 switch-də VLAN 10 və 20 yarat. Fa0/1–2 VLAN 10, Fa0/3–4 VLAN 20 (access).' },
            { t: 'Routing-i aç və SVI-lər yaz: <span class="m">ip routing</span>, <span class="m">interface vlan 10</span> / <span class="m">192.168.10.1</span>, <span class="m">interface vlan 20</span> / <span class="m">192.168.20.1</span>, hər ikisində <span class="m">no shutdown</span>.', cmd: ['ip routing', 'interface vlan 10', 'ip address 192.168.10.1 255.255.255.0', 'no shutdown'] },
            { t: 'PC-lərin IP-ləri öz VLAN subnet-indən, gateway-lər SVI ünvanları olsun.' },
            { t: 'VLAN 10 PC-sindən VLAN 20 PC-sinə ping et. İşləməlidir.' },
            { t: '<span class="m">ip routing</span> əmrini silib (<span class="m">no ip routing</span>) ping-i təkrarla: işləməməlidir.', cmd: ['no ip routing'] },
          ] },
        { id: 's9', title: 'Gördüyünü yaz', type: 'form',
          body: '<p><span class="m">no ip routing</span> yazandan sonra VLAN-lar arası ping nə etdi?</p>',
          fields: [{ label: 'Nəticə (işləyir / işləmir)', placeholder: 'seç', answers: ['işləmir', 'islemir'], wrong: 'ip routing olmadan switch yönləndirmir.' }],
          solution: 'İşləmir: ip routing olmadan Layer 3 yönləndirmə yoxdur.' },
      ],
    },

    quiz: {
      draw: 8,
      gens: [
        () => {
          const v = pick([10, 20, 30, 40, 50, 99]); const net = pick(['192.168', '10.1', '172.16']);
          const ip = net + '.' + v + '.1';
          const right = 'interface vlan ' + v;
          const opts = [right, 'interface gi0/' + v, 'vlan ' + v + ' interface', 'interface svi ' + v];
          return { id: 'p3t4-g-svi', concept: 'svi', obj: 'SVI əmri', _meta: { v },
            stem: '<p>Layer 3 switch-də VLAN <b>' + v + '</b> üçün SVI yaratmaq istəyirsən (gateway <span class="m">' + ip + '</span>). Hansı əmr düzgündür?</p>',
            options: shuffle(opts.map((t, i) => ({ t, ok: i === 0, why: i === 0 ? 'SVI interface vlan <VLAN ID> əmri ilə yaradılır.' : 'Cisco IOS-da SVI yaratmaq üçün belə əmr yoxdur.' }))) };
        },
      ],
      pool: [
        { id: 'p3t4-q1', concept: 'l3-what', obj: 'Layer 3 switch',
          stem: '<p>Layer 3 switch eyni VLAN-dakı iki cihaz arasında frame-i necə ötürür?</p>',
          options: [
            { t: 'Adi switch kimi, Destination MAC-ə görə.', ok: true, why: 'Eyni VLAN-da routing lazım deyil.' },
            { t: 'Router kimi, Destination IP-yə görə.', why: 'IP-yə görə yönləndirmə fərqli VLAN-lar arasında olur.' },
            { t: 'Hər frame-i router-ə göndərir.', why: 'Layer 3 switch özü yönləndirir, ayrıca router lazım deyil.' },
            { t: 'Frame-i atır, çünki VLAN-lar eyni olmalıdır.', why: 'Eyni VLAN-dakı cihazlar normal danışır.' },
          ] },
        { id: 'p3t4-q2', concept: 'l3-what', obj: 'Router-on-a-stick ilə müqayisə',
          stem: '<p>Layer 3 switch router-on-a-stick-dən nə ilə üstündür?</p>',
          options: [
            { t: 'Gateway switch-in daxilindədir, trunk link-dən iki dəfə keçmir.', ok: true, why: 'Tək link darboğazı yoxdur və yönləndirmə aparat səviyyəsindədir.' },
            { t: 'Daha ucuzdur, çünki router lazım deyil və ayrıca cihaz almırsan.', why: 'Layer 3 switch adətən daha bahalı olur. Üstünlük sürət və tutumdadır.' },
            { t: 'Switch VLAN-ları birləşdirir, ona görə SVI lazım olmur.', why: 'Hər VLAN üçün SVI lazımdır.' },
            { t: 'İnternetə çıxışı avtomatik verir və NAT edir.', why: 'İnternet çıxışı üçün router və marşrut lazımdır.' },
          ] },
        { id: 'p3t4-q3', concept: 'svi', obj: 'SVI nədir',
          stem: '<p>SVI nədir?</p>',
          options: [
            { t: 'VLAN üçün virtual interface, VLAN-ın gateway-i.', ok: true, why: 'PC-lər SVI ünvanına paket göndərir.' },
            { t: 'Switch-in fiziki portunun adı və bu normal sayılır.', why: 'SVI fiziki port deyil, virtual interface-dir.' },
            { t: 'Switch-dən keçən bir tag növü.', why: 'Tag trunk üçün 802.1Q-dur.' },
            { t: 'Router subinterface-nin başqa adı və bu normal sayılır.', why: 'Subinterface router-dədir, SVI isə Layer 3 switch-dədir.' },
          ] },
        { id: 'p3t4-q4', concept: 'svi', obj: 'ip routing',
          stem: '<p>Layer 3 switch-də SVI-lər up/up-dır, amma VLAN-lar arası ping işləmir. Ən ehtimal olunan çatışmazlıq?</p>',
          options: [
            { t: 'ip routing əmri yazılmayıb.', ok: true, why: 'Bu əmr olmadan switch routing etmir.' },
            { t: 'SVI-lərin IP ünvanı çox uzundur.', why: 'Ünvan uzunluğu sabitdir.' },
            { t: 'PC-lərin MAC ünvanları fərqlidir.', why: 'MAC ünvanları həmişə fərqlidir.' },
            { t: 'Switch hostname-i yoxdur.', why: 'Hostname routing-ə təsir etmir.' },
          ] },
        { id: 'p3t4-q5', concept: 'svi', obj: 'SVI down',
          stem: '<p>Vlan30 SVI-si down/down-dur və no shutdown yazılıb. Səbəb nə ola bilər?</p>',
          options: [
            { t: 'VLAN 30 yaradılmayıb və ya onda aktiv port yoxdur.', ok: true, why: 'SVI-nin up olması üçün VLAN mövcud və aktiv olmalıdır.' },
            { t: 'ip routing əmri switch-də yazılıb.', why: 'ip routing SVI-nin statusuna təsir etmir.' },
            { t: 'Switch-ə qoşulan PC-lər çox sürətlidir.', why: 'PC sürəti status yaratmır.' },
            { t: 'Gateway PC-də düzgün yazılıb.', why: 'PC-nin gateway ayarı SVI statusuna təsir etmir.' },
          ] },
        { id: 'p3t4-q6', concept: 'routed-port', obj: 'Routed port',
          stem: '<p>Layer 3 switch portunu router interface-i kimi işlətmək üçün hansı əmr lazımdır?</p>',
          options: [
            { t: 'no switchport', ok: true, why: 'Port switch portu olmaqdan çıxır və IP ala bilir.' },
            { t: 'switchport mode routed', why: 'Belə əmr yoxdur.' },
            { t: 'switchport access vlan 1', why: 'Bu portu VLAN 1 access portu edir.' },
            { t: 'ip routing', why: 'Bu global əmrdir, portu çevirmir.' },
          ] },
        { id: 'p3t4-q7', concept: 'l3-vs-router', obj: 'Router və Layer 3 switch',
          stem: '<p>Hansı iş router üçün daha uyğundur?</p>',
          options: [
            { t: 'Şirkəti internet provayderinə qoşmaq və NAT etmək.', ok: true, why: 'WAN çıxışı, NAT kimi funksiyalar router-in işidir.' },
            { t: '48 portlu mərtəbə switch-i kimi çox cihaz qoşmaq.', why: 'Çox sayda port Layer 3 switch və ya adi switch üçündür.' },
            { t: 'Daxili 20 VLAN arasında yüksək sürətli yönləndirmə.', why: 'Bu Layer 3 switch üçün daha uyğundur.' },
            { t: 'PC-lərə portlar vasitəsilə birbaşa qoşulmaq.', why: 'Router-də çox port yoxdur.' },
          ] },
        { id: 'p3t4-q8', concept: 'l3-verify', obj: 'Routing table',
          stem: '<p>Layer 3 switch-də iki SVI qurulub. <span class="m">show ip route</span>-da nə görünməlidir?</p>',
          options: [
            { t: 'İki connected (C) network, hər biri öz SVI-si ilə.', ok: true, why: 'SVI-lər connected network yaradır.' },
            { t: 'İki S (static) marşrut, əllə yazılmış.', why: 'Static marşrutu administrator əllə yazır.' },
            { t: 'Heç nə, çünki routing yalnız router-də olur.', why: 'Layer 3 switch-in də routing table-ı var.' },
            { t: 'Bir C network, yalnız fiziki interface ilə.', why: 'SVI-lər VLAN-lar üçün ayrı network yaradır.' },
          ] },
        { id: 'p3t4-q9', concept: 'l3-trouble', obj: 'SVI administratively down',
          stem: '<p>Vlan20 administratively down göstərir. Nə etməlisən?</p>',
          options: [
            { t: 'interface vlan 20 daxilində no shutdown yazmaq.', ok: true, why: 'Administratively down əl ilə söndürülmə deməkdir.' },
            { t: 'Switch portlarının kabellərini dəyişmək.', why: 'SVI virtualdır, kabel təsir etmir.' },
            { t: 'VLAN 20-ni silib yenidən yaratmaq.', why: 'VLAN problemi down/down verərdi.' },
            { t: 'ip routing əmrini switch-dən silmək.', why: 'Bu SVI statusuna təsir etmir.' },
          ] },
      ],
    },
  });
})();
