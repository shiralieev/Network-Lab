(function () {
  const A = PT.addr; const pick = PT.pick; const R = PT.randInt; const shuffle = PT.shuffle;
  const norm = s => String(s).trim().toLowerCase().replace(/\s+/g, ' ');
  const inNet = (ip, net, p) => A.net(ip, p) === net;

  PT.topic({
    id: 'p3t6',
    objectives: [
      'Default route-un nə üçün lazım olduğunu və yazılışını demək',
      'Routing table-da S* və Gateway of last resort sətirlərini oxumaq',
      'Longest-prefix match qaydası ilə seçilən marşrutu müəyyən etmək',
      'Default route və qayıdış marşrutu səhvlərini tapmaq',
    ],
    explain: PT.frag['p3/t06/explain'], cheat: PT.frag['p3/t06/cheat'],

    lab: {
      title: 'Lab 6: Default route və marşrut seçimi',
      goal: 'Default route yazmaq, routing table-da hansı marşrutun seçildiyini müəyyən etmək, konfiqurasiya səhvlərini tapmaq və Packet Tracer-də internet simulyasiyası qurmaq.',
      why: 'Hər filial router-i default route ilə provayderə çıxır. Longest-prefix match isə router-in niyə gözlənilməz yol seçdiyini izah edir.',
      minutes: 45,
      finish: 'Default route və marşrut seçimini bilirsən. İndi quizə keç.',
      steps: [
        { id: 's1', title: 'Hazırlıq', type: 'info', button: 'Başladım',
          body: '<p>Ssenari: filial router-i R1 LAN-ı <span class="m">192.168.1.0/24</span> ilə provayder router-inə (<span class="m">203.0.113.1</span>) <span class="m">203.0.113.0/30</span> link-i ilə bağlıdır. R1-in internetə çıxışı default route ilə olacaq.</p>' },
        { id: 's2', title: 'Anlayışı mənası ilə birləşdir', type: 'match',
          body: '<p>Hər anlayış nə deməkdir?</p>',
          pairs: [
            { l: '<span class="m">0.0.0.0/0</span>', r: 'Default route: hər ünvanı əhatə edir', why: 'Prefiks uzunluğu 0-dır.' },
            { l: '<span class="m">S*</span>', r: 'Default olaraq istifadə olunan static marşrut', why: 'Ulduz candidate default işarəsidir.' },
            { l: 'Gateway of last resort', r: 'Heç bir marşrut uyğun gəlməyəndə istifadə edilən next hop', why: 'Default route-un next hop-udur.' },
            { l: 'Longest-prefix match', r: 'Uyğun marşrutlardan prefiksi ən uzunu seçilir', why: 'Daha dəqiq marşrut üstün tutulur.' },
          ],
          hints: ['0.0.0.0/0 hamıya uyğundur, amma ən qısadır.'] },
        { id: 's3', title: 'Default route yaz', type: 'form',
          body: '<p>R1-də provayder router-inə (<span class="m">203.0.113.1</span>) default route yaz.</p>',
          fields: [
            { label: 'Əmr', placeholder: 'əmr', check: r => norm(r) === 'ip route 0.0.0.0 0.0.0.0 203.0.113.1', show: 'ip route 0.0.0.0 0.0.0.0 203.0.113.1', wrong: 'ip route 0.0.0.0 0.0.0.0 <next hop>' },
            { label: 'Routing table-da bu marşrutun kodu', placeholder: 'məs. C', check: r => /^s\*?$/i.test(String(r).trim()), show: 'S*', wrong: 'Static marşrut, default işarəsi ilə.' },
          ],
          hints: ['Hədəf və mask hamısı sıfır olur.'],
          solution: 'ip route 0.0.0.0 0.0.0.0 203.0.113.1; kodu S*.' },
        { id: 's4', title: 'Hansı marşrut seçilir?', type: 'form',
          pre: 'R1#show ip route\nS*   0.0.0.0/0 [1/0] via 10.0.0.2\nS    172.16.0.0/16 [1/0] via 10.0.1.2\nS    172.16.40.0/24 [1/0] via 10.0.2.2\nS    172.16.40.128/25 [1/0] via 10.0.3.2',
          body: '<p>R1-ə gələn paketlər üçün hansı next hop seçilir?</p>',
          fields: [
            { label: '172.16.40.200', placeholder: 'a.b.c.d', check: r => String(r).trim() === '10.0.3.2', show: '10.0.3.2', wrong: '172.16.40.200 /25 aralığındadır (128–255).' },
            { label: '172.16.40.50', placeholder: 'a.b.c.d', check: r => String(r).trim() === '10.0.2.2', show: '10.0.2.2', wrong: '50 /25 (128–255) aralığında deyil, amma /24-dədir.' },
            { label: '172.16.99.1', placeholder: 'a.b.c.d', check: r => String(r).trim() === '10.0.1.2', show: '10.0.1.2', wrong: 'Yalnız /16 və default uyğundur.' },
            { label: '8.8.8.8', placeholder: 'a.b.c.d', check: r => String(r).trim() === '10.0.0.2', show: '10.0.0.2', wrong: 'Yalnız default route uyğundur.' },
          ],
          hints: ['Hər hədəf üçün uyğun marşrutların siyahısını çıxar, ən uzun prefiksi seç.'],
          solution: '172.16.40.200 → /25 → 10.0.3.2; 172.16.40.50 → /24 → 10.0.2.2; 172.16.99.1 → /16 → 10.0.1.2; 8.8.8.8 → default → 10.0.0.2.' },
        { id: 's5', title: 'Default route əmrində səhvi tap', type: 'spot',
          body: '<p>R1 internetə çıxmır. <span class="m">show ip route</span> "Gateway of last resort is not set" göstərir. Konfiqurasiyaya bax. <b>Problemi izah edən sətri tap.</b></p>',
          lines: [
            { t: 'interface GigabitEthernet0/1' },
            { t: ' ip address 203.0.113.2 255.255.255.252' },
            { t: ' no shutdown' },
            { t: 'ip route 0.0.0.0 0.0.0.0 203.0.113.5', bad: true, why: 'Next hop 203.0.113.5 interface-in /30 network-ündə deyil (203.0.113.0/30). Provayder router-i 203.0.113.1-dir. Next hop əlçatan deyilsə marşrut yazılmır.' },
          ],
          fix: { label: 'Düzgün next hop', placeholder: 'a.b.c.d', answers: ['203.0.113.1'], wrong: '203.0.113.0/30 network-ündəki digər host.' },
          hints: ['Next hop interface ilə eyni network-də olmalıdır.'] },
        { id: 's6', title: 'Mask səhvini tap', type: 'spot',
          body: '<p>Kolleqa default route yazıb, amma R1 yalnız bir network-ə çıxır. <b>Səhv sətri tap.</b></p>',
          lines: [
            { t: 'ip route 0.0.0.0 255.255.255.0 203.0.113.1', bad: true, why: '0.0.0.0 255.255.255.0 default route deyil, 0.0.0.0/24 marşrutudur (yalnız 0.0.0.x ünvanları). Default üçün mask 0.0.0.0 olmalıdır.' },
          ],
          fix: { label: 'Düzgün mask', placeholder: 'a.b.c.d', answers: ['0.0.0.0'], wrong: 'Default route hər ünvanı əhatə edir, mask 0-dır.' },
          hints: ['Default route-un prefiksi /0-dır.'] },
        { id: 's7', title: 'Ticket: "İnternetə çıxış yoxdur"', type: 'ticket',
          body: '<p><b>İstifadəçilər deyir:</b> "Filialda daxili şəbəkə işləyir, internet işləmir." R1-də <span class="m">show ip route</span>: yalnız iki C sətri. <span class="m">Gateway of last resort is not set</span>.</p>',
          stages: [
            { q: '<p>Gateway of last resort is not set nə deməkdir?</p>', options: [
              { t: 'R1-də default route yoxdur: LAN-dan kənar ünvanlar üçün marşrut yoxdur.', ok: true, why: 'Router yerli network-ləri bilir, qalanı üçün yol yoxdur.' },
              { t: 'R1 söndürülüb.', why: 'R1 işləyir, yerli network-lər onun routing table-ındadır.' },
              { t: 'DNS server cavab vermir.', why: 'DNS adlar üçündür, burada marşrut yoxdur.' },
              { t: 'PC-lərin gateway-i yoxdur.', why: 'Daxili şəbəkə işləyir, deməli PC-lərdə gateway var.' },
            ] },
            { q: '<p>Provayder router-i <span class="m">203.0.113.1</span>-dir. R1-də nə yazırsan?</p>', options: [
              { t: 'ip route 0.0.0.0 0.0.0.0 203.0.113.1', ok: true, why: 'Bütün ünvanları provayderə yönləndirir.' },
              { t: 'ip route 203.0.113.1 255.255.255.0 0.0.0.0', why: 'Hədəf və next hop yerləri dəyişib.' },
              { t: 'ip route 192.168.1.0 255.255.255.0 203.0.113.1', why: 'Bu yerli LAN-ı provayderə yönləndirir, internet üçün deyil.' },
              { t: 'ip default-gateway 203.0.113.1', why: 'Bu əmr switch üçündür, router-də marşrut əmri lazımdır.' },
            ] },
            { q: '<p>Marşrut yazıldı, amma internet hələ də işləmir. Növbəti yoxlama?</p>', options: [
              { t: 'Next hop-a ping, və provayderdə qayıdış marşrutunun mövcudluğu.', ok: true, why: 'Əlaqə yoxdursa, default route işləməz. Provayder də LAN-ı bilməlidir.' },
              { t: 'PC-lərin MAC ünvanlarını dəyişmək.', why: 'MAC problem deyil.' },
              { t: 'DHCP lease müddətini artırmaq.', why: 'Lease marşrutla əlaqəli deyil.' },
              { t: 'Switch-in hostname-ini dəyişmək.', why: 'Hostname təsir etmir.' },
            ] },
          ],
          after: '<p>Default route yalnız bir tərəfdir: provayder də sənin LAN-ına qayıdış marşrutuna malik olmalıdır.</p>' },
        { id: 's8', title: 'Marşrut seçimi və kiçik tələ', type: 'choice',
          body: '<p>R1-də iki marşrut var: <span class="m">S* 0.0.0.0/0 via 10.0.0.2</span> (internet) və <span class="m">S 172.16.0.0/16 via 10.0.1.2</span> (şirkət datacenter-i). Datacenter-də yeni server <span class="m">172.16.5.10</span> əlavə edildi. PC bu serverə qoşulmaq istəyir. Paket hara gedir?</p>',
          options: [
            { t: 'Datacenter-ə (10.0.1.2), çünki /16 prefiksi /0-dan uzundur.', ok: true, why: 'Longest-prefix match: /16 default-dan daha dəqiqdir.' },
            { t: 'İnternetə (10.0.0.2), çünki default route həmişə üstündür.', why: 'Default route ən qısa prefiksdir və ən son seçilir.' },
            { t: 'Hər iki yola eyni zamanda.', why: 'Router bir paketi bir yola göndərir.' },
            { t: 'Heç hara, paket atılır.', why: 'Hədəfə uyğun marşrut var.' },
          ],
          hints: ['Hansı marşrut ünvanı daha dəqiq əhatə edir?'] },
        { id: 's9', title: 'Packet Tracer-də qur', type: 'ptsteps',
          body: '<p>İki router: R1 (filial) və R2 (provayder simulyasiyası). R2-də <span class="m">Loopback0 8.8.8.8/32</span> yarat ki, internetdəki server kimi olsun.</p>',
          checks: [
            { t: 'R1 LAN <span class="m">192.168.1.1/24</span> və R1–R2 link-i <span class="m">203.0.113.0/30</span> (R1 <span class="m">.2</span>, R2 <span class="m">.1</span>). PC1 <span class="m">192.168.1.10</span>.' },
            { t: 'R2-də: <span class="m">interface loopback0</span>, <span class="m">ip address 8.8.8.8 255.255.255.255</span>.', cmd: ['interface loopback0', 'ip address 8.8.8.8 255.255.255.255'] },
            { t: 'PC1-dən 8.8.8.8-ə ping at: işləməməlidir (R1-də default route yoxdur).' },
            { t: 'R1-də default route yaz, R2-də isə qayıdış marşrutu: <span class="m">ip route 192.168.1.0 255.255.255.0 203.0.113.2</span>.', cmd: ['ip route 0.0.0.0 0.0.0.0 203.0.113.1'] },
            { t: 'Ping-i təkrarla. <span class="m">show ip route</span> yaz və Gateway of last resort sətrini tap.', cmd: ['show ip route'] },
          ] },
        { id: 's10', title: 'Gördüyünü yaz', type: 'form',
          body: '<p>R1-də <span class="m">show ip route</span> yazdın.</p>',
          fields: [
            { label: 'Gateway of last resort hansı ünvandır?', placeholder: 'a.b.c.d', check: r => String(r).trim() === '203.0.113.1', show: '203.0.113.1', wrong: 'Default route-un next hop-u.' },
            { label: 'Default marşrutun kodu', placeholder: 'kod', check: r => /^s\*?$/i.test(String(r).trim()), show: 'S*', wrong: 'Static, default işarəsi ilə.' },
          ],
          solution: '203.0.113.1; S*.' },
      ],
    },

    quiz: {
      draw: 8,
      gens: [
        () => {
          const base = pick(['172.16', '10.20', '192.168']); const c = R(200) + 1;
          const routes = [{ net: '0.0.0.0', p: 0, nh: '10.0.0.2' }, { net: base + '.0.0', p: 16, nh: '10.0.1.2' }, { net: base + '.' + c + '.0', p: 24, nh: '10.0.2.2' }];
          const kind = pick(['inside24', 'inside16', 'default']);
          let dst, ans;
          if (kind === 'inside24') { dst = base + '.' + c + '.' + (1 + R(200)); ans = routes[2]; }
          else if (kind === 'inside16') { dst = base + '.' + ((c + 5) % 250 + 1) + '.' + (1 + R(200)); ans = routes[1]; }
          else { dst = pick(['8.8.8.8', '1.1.1.1', '203.0.113.9']); ans = routes[0]; }
          const lbl = r => r.net + '/' + r.p + ' → ' + r.nh;
          const why = r => r === ans ? 'Uyğun marşrutlar arasında ən uzun prefiksi ' + lbl(r) + ' olan seçilir.' : 'Bu marşrut ya hədəfi əhatə etmir, ya da daha qısa prefiksdir.';
          return { id: 'p3t6-g-lpm', concept: 'lpm', obj: 'Longest-prefix match', _meta: { dst, ans: ans.nh },
            stem: '<p>Routing table:</p><pre class="pre">S*   0.0.0.0/0 via 10.0.0.2\nS    ' + base + '.0.0/16 via 10.0.1.2\nS    ' + base + '.' + c + '.0/24 via 10.0.2.2</pre><p>Hədəf <span class="m">' + dst + '</span> üçün router paketi hansı next hop-a göndərir?</p>',
            options: shuffle(routes.map(r => ({ t: r.nh + '  (' + r.net + '/' + r.p + ')', ok: r === ans, why: why(r) }))) };
        },
      ],
      pool: [
        { id: 'p3t6-q1', concept: 'default-route', obj: 'Default route nədir',
          stem: '<p>Default route (0.0.0.0/0) nə vaxt istifadə olunur?</p>',
          options: [
            { t: 'Hədəfə heç bir başqa marşrut uyğun gəlməyəndə.', ok: true, why: 'Default route ən qısa prefiksdir və yalnız başqa seçim olmayanda seçilir.' },
            { t: 'Həmişə, bütün başqa marşrutlardan üstündür.', why: 'Default route /0-dır, ən az dəqiq marşrutdur.' },
            { t: 'Yalnız connected network-lər üçün istifadə olunur.', why: 'Connected network-lərin öz marşrutu var.' },
            { t: 'Yalnız broadcast paketləri üçün yazılır.', why: 'Default route broadcast ilə əlaqəli deyil.' },
          ] },
        { id: 'p3t6-q2', concept: 'default-route', obj: 'Əmr',
          stem: '<p>Provayder router-inin ünvanı 203.0.113.1-dir. Default route hansı əmrlə yazılır?</p>',
          options: [
            { t: 'ip route 0.0.0.0 0.0.0.0 203.0.113.1', ok: true, why: 'Hədəf 0.0.0.0/0, next hop provayderin ünvanı.' },
            { t: 'ip route 203.0.113.1 0.0.0.0 0.0.0.0', why: 'Hədəf və next hop yerləri dəyişib.' },
            { t: 'ip default-route 203.0.113.1', why: 'Belə əmr yoxdur.' },
            { t: 'ip route 0.0.0.0 255.255.255.255 203.0.113.1', why: '255.255.255.255 mask yalnız 0.0.0.0 host ünvanını göstərir, default route deyil.' },
          ] },
        { id: 'p3t6-q3', concept: 'default-route', obj: 'S*',
          stem: '<p>Routing table-da <span class="m">S* 0.0.0.0/0 [1/0] via 203.0.113.1</span> görürsən. <span class="m">*</span> nəyi göstərir?</p>',
          options: [
            { t: 'Marşrutun default kimi istifadə olunduğunu.', ok: true, why: 'Gateway of last resort bu marşrutdan götürülür.' },
            { t: 'Marşrutun söndürülmüş olduğunu və işləmədiyini.', why: 'Söndürülmüş marşrut routing table-da görünmür.' },
            { t: 'Marşrutun dinamik öyrənildiyini göstərir.', why: 'Dinamik marşrutların başqa kodu var.' },
            { t: 'Marşrutun xəta ilə yazıldığını bildirir.', why: 'Ulduz xəta deyil.' },
          ] },
        { id: 'p3t6-q4', concept: 'default-route', obj: 'Gateway of last resort',
          stem: '<p>Gateway of last resort nədir?</p>',
          options: [
            { t: 'Heç bir marşrut uyğun gəlməyəndə istifadə olunan next hop.', ok: true, why: 'Bu, default route-un next hop-udur.' },
            { t: 'PC-nin default gateway-i, yəni tamamilə eyni anlayış.', why: 'Bu router-in anlayışıdır, PC-nin gateway-i başqadır.' },
            { t: 'Router-in ən yaxın qonşu router-inin ünvanı.', why: 'Qonşu router default olmaya da bilər.' },
            { t: 'İnternet provayderinin domain adı və ya saytı.', why: 'Bu IP ünvanıdır, domain deyil.' },
          ] },
        { id: 'p3t6-q5', concept: 'lpm', obj: 'Prefiks uzunluğu',
          stem: '<p>Hədəfə /16 və /24 marşrutları uyğundur. Hansı seçilir?</p>',
          options: [
            { t: '/24, çünki prefiksi daha uzun və dəqiqdir.', ok: true, why: 'Longest-prefix match daha dəqiq marşrutu seçir.' },
            { t: '/16, çünki daha çox ünvanı əhatə edir.', why: 'Əhatə sahəsi böyük olan daha az dəqiqdir.' },
            { t: 'Hər ikisi, yük bərabər bölünür.', why: 'Prefiks uzunluğu fərqli olanda biri seçilir.' },
            { t: 'Hansı əvvəl yazılıbsa, həmin marşrut seçilir.', why: 'Yazılma sırası seçimə təsir etmir.' },
          ] },
        { id: 'p3t6-q6', concept: 'lpm', obj: 'Marşrut əhatə edirmi',
          stem: '<p>Routing table-da 10.1.0.0/16 var. Hansı hədəf bu marşruta <b>uyğundur</b>?</p>',
          options: [
            { t: '10.1.200.5', ok: true, why: 'İlk iki oktet 10.1-dir, /16-ya uyğundur.' },
            { t: '10.2.0.5', why: 'İkinci oktet 2-dir, /16-ya uyğun deyil.' },
            { t: '11.1.0.5', why: 'Birinci oktet 11-dir.' },
            { t: '192.168.1.5', why: 'Tamamilə fərqli network-dür.' },
          ] },
        { id: 'p3t6-q7', concept: 'lpm-vs-ad', obj: 'LPM və AD',
          stem: '<p>Longest-prefix match ilə AD (administrative distance) necə bir-birini tamamlayır?</p>',
          options: [
            { t: 'Əvvəl ən uzun prefiks, eyni prefiksdə AD kiçik olan.', ok: true, why: 'LPM hədəfi dəqiq əhatə edən marşrutu seçir, AD isə eyni prefiksdə seçim edir.' },
            { t: 'AD həmişə LPM-dən əvvəl işləyir və seçimi müəyyən edir.', why: 'Əvvəl hədəfə uyğun və ən uzun prefikslər seçilir.' },
            { t: 'Onlar eyni qaydadır və fərqi yoxdur.', why: 'LPM prefiksə, AD mənbəyə görə seçir.' },
            { t: 'AD yalnız IPv6 üçün tətbiq olunur.', why: 'AD IPv4-də də işləyir.' },
          ] },
        { id: 'p3t6-q8', concept: 'default-verify', obj: 'Gateway not set',
          stem: '<p><span class="m">show ip route</span> "Gateway of last resort is not set" göstərir. Nə deməkdir?</p>',
          options: [
            { t: 'Default route yoxdur və ya next hop əlçatan deyil.', ok: true, why: 'Əlçatan olmayan next hop ilə marşrut tətbiq olunmur.' },
            { t: 'Router-də connected network heç yoxdur.', why: 'Connected network-lər ayrıca göstərilir.' },
            { t: 'Router yenidən başlamalıdır ki, marşrut görünsün.', why: 'Marşrut yazıldıqca tətbiq olunur.' },
            { t: 'DNS server tapılmayıb və ad çevrilmir.', why: 'DNS bu sətirlə əlaqəli deyil.' },
          ] },
        { id: 'p3t6-q9', concept: 'default-verify', obj: 'Qayıdış',
          stem: '<p>R1-də default route var, amma internetdəki hədəfə ping timeout verir. Əlavə şübhə?</p>',
          options: [
            { t: 'Provayder tərəfdə LAN üçün qayıdış marşrutu yoxdur.', ok: true, why: 'Cavab geri qayıda bilmir.' },
            { t: 'R1-in hostname-i səhv yazılıb və ya uzundur.', why: 'Hostname təsir etmir.' },
            { t: 'PC-nin MAC ünvanı qısa və ya yanlışdır.', why: 'MAC ünvanı sabit uzunluqdadır.' },
            { t: 'Switch portu VLAN 1-dədir və trafik keçmir.', why: 'VLAN 1 ping-ə mane olmur.' },
          ] },
        { id: 'p3t6-q10', concept: 'default-verify', obj: 'Yerli işləyir, internet yox',
          stem: '<p>Filial PC-ləri daxili network-lərə çıxır, internetə yox. R1-də connected network-lər var. Ən ehtimal olunan səbəb?</p>',
          options: [
            { t: 'R1-də default route yoxdur və ya next hop əlçatan deyil.', ok: true, why: 'Daxili network-lər connected-dir, internet üçün default route lazımdır.' },
            { t: 'PC-lərdə DNS server ünvanı yazılmayıb və bu normal sayılır.', why: 'DNS olmasa IP ilə ping yenə işləyərdi.' },
            { t: 'Daxili şəbəkənin kabeli qırıqdır.', why: 'Daxili şəbəkə işləyir, kabel qırıq deyil.' },
            { t: 'DHCP lease müddəti bitib və ünvan yoxdur və bu normal sayılır.', why: 'Lease bitsə PC-lər ünvansız qalardı.' },
          ] },
      ],
    },
  });
})();
