(function () {
  const A = PT.addr; const pick = PT.pick; const R = PT.randInt; const shuffle = PT.shuffle;
  const norm = s => String(s).trim().toLowerCase().replace(/\s+/g, ' ');

  PT.topic({
    id: 'p3t5',
    objectives: [
      'Connected və static marşrut fərqini demək',
      'ip route əmrini düzgün yazmaq',
      'Routing table sətrini oxumaq (kod, prefix, AD/metric, next hop)',
      'Qayıdış marşrutunun niyə lazım olduğunu izah etmək',
      'Static routing səhvlərini simptomdan tapmaq',
    ],
    explain: PT.frag['p3/t05/explain'], cheat: PT.frag['p3/t05/cheat'],

    lab: {
      title: 'Lab 5: Static marşrutları planla, yaz və yoxla',
      goal: 'Marşrut əmrlərini yazmaq, routing table oxumaq, qayıdış marşrutu səhvini tapmaq, ticket həll etmək və Packet Tracer-də iki router arasında marşrut qurmaq.',
      why: 'Router-lər arasında əlaqə marşrutlarla qurulur. Yarımçıq marşrut ping timeout verir və tapmaq çətin olur.',
      minutes: 50,
      finish: 'Static marşrutları yaza və səhvini tapa bilirsən. İndi quizə keç.',
      steps: [
        { id: 's1', title: 'Hazırlıq', type: 'info', button: 'Başladım',
          body: '<p>Topologiya: PC1 (<span class="m">192.168.1.10</span>) – R1 (<span class="m">Gi0/0 192.168.1.1</span>, <span class="m">Gi0/1 10.0.12.1</span>) – R2 (<span class="m">Gi0/1 10.0.12.2</span>, <span class="m">Gi0/0 192.168.3.1</span>) – PC3 (<span class="m">192.168.3.10</span>). Router-lərdə yalnız connected network-lər var.</p>' },
        { id: 's2', title: 'Routing table sətrini oxu', type: 'match',
          body: '<p><span class="m">S 192.168.3.0/24 [1/0] via 10.0.12.2</span> sətrinin hissələri nə deməkdir?</p>',
          pairs: [
            { l: '<span class="m">S</span>', r: 'Static marşrut', why: 'Marşrutu administrator yazıb.' },
            { l: '<span class="m">192.168.3.0/24</span>', r: 'Hədəf network', why: 'Bu network-ə gedən paketlər üçündür.' },
            { l: '<span class="m">[1/0]</span>', r: 'Administrative distance 1, metric 0', why: 'Static marşrutun AD-si 1-dir.' },
            { l: '<span class="m">via 10.0.12.2</span>', r: 'Next hop: paket buraya ötürülür', why: 'Qonşu router-in ünvanı.' },
          ],
          hints: ['S static deməkdir, via isə next hop.'] },
        { id: 's3', title: 'Marşrutları yaz', type: 'form',
          body: '<p>Yuxarıdakı topologiyada hər iki router üçün lazım olan marşrutları yaz. Boşluqlar önəmli deyil.</p>',
          fields: [
            { label: 'R1-də: PC3-ün network-üçün marşrut', placeholder: 'əmr', check: r => norm(r) === 'ip route 192.168.3.0 255.255.255.0 10.0.12.2', show: 'ip route 192.168.3.0 255.255.255.0 10.0.12.2', wrong: 'ip route <network> <mask> <next hop>. Next hop R2-nin R1 tərəfindəki ünvanıdır.' },
            { label: 'R2-də: PC1-in network-ü üçün marşrut (qayıdış)', placeholder: 'əmr', check: r => norm(r) === 'ip route 192.168.1.0 255.255.255.0 10.0.12.1', show: 'ip route 192.168.1.0 255.255.255.0 10.0.12.1', wrong: 'Next hop R1-in R2 tərəfindəki ünvanıdır.' },
          ],
          hints: ['Next hop həmişə qonşu router-in ünvanıdır.'],
          solution: 'R1: ip route 192.168.3.0 255.255.255.0 10.0.12.2. R2: ip route 192.168.1.0 255.255.255.0 10.0.12.1.' },
        { id: 's4', title: 'Əmrdə səhvi tap', type: 'spot',
          body: '<p>Kolleqa R1-də marşrutu yazıb. Əmr qəbul olunub, amma PC1 PC3-ə çata bilmir. <b>Səhv sətri tap.</b></p>',
          lines: [
            { t: 'hostname R1' },
            { t: 'interface GigabitEthernet0/1' },
            { t: ' ip address 10.0.12.1 255.255.255.252' },
            { t: 'ip route 192.168.3.0 255.255.255.0 10.0.12.1', bad: true, why: 'Next hop 10.0.12.1 R1-in öz ünvanıdır. Next hop qonşu router-in (R2) ünvanı olmalıdır: 10.0.12.2.' },
          ],
          fix: { label: 'Düzgün next hop', placeholder: 'a.b.c.d', answers: ['10.0.12.2'], wrong: 'Qonşu router-in R1 tərəfindəki ünvanı.' },
          hints: ['Next hop öz ünvanın ola bilməz.'] },
        { id: 's5', title: 'Mask səhvini tap', type: 'spot',
          body: '<p>R2-də qayıdış marşrutu yazılıb, amma yenə də ping timeout verir. <b>Səhv sətri tap.</b></p>',
          lines: [
            { t: 'ip route 192.168.1.0 0.0.0.255 10.0.12.1', bad: true, why: 'Bu wildcard mask-dır. ip route əmrində adi subnet mask yazılır: 255.255.255.0.' },
          ],
          fix: { label: 'Düzgün mask', placeholder: 'a.b.c.d', answers: ['255.255.255.0'], wrong: '/24 adi mask-ı necədir?' },
          hints: ['ip route əmri wildcard yox, subnet mask istəyir.'] },
        { id: 's6', title: 'Ticket: "Ping timeout verir"', type: 'ticket',
          body: '<p><b>Mühəndis deyir:</b> "PC1-dən PC3-ə ping timeout verir. R1-də <span class="m">show ip route</span> 192.168.3.0/24 üçün S marşrutu göstərir. R2-də marşrutlar belədir: <span class="m">C 192.168.3.0/24</span>, <span class="m">C 10.0.12.0/30</span>."</p>',
          stages: [
            { q: '<p>Hansı marşrut çatışmır?</p>', options: [
              { t: 'R2-də 192.168.1.0/24 üçün qayıdış marşrutu.', ok: true, why: 'PC3-ün cavabı R2-yə gəlir və R2 PC1-in network-ünü bilmir.' },
              { t: 'R1-də 10.0.12.0/30 üçün marşrut.', why: 'Bu network R1-də connected-dir.' },
              { t: 'PC3-də ikinci gateway.', why: 'Bir gateway kifayətdir.' },
              { t: 'R2-də 192.168.3.0/24 üçün marşrut.', why: 'Bu network R2-də connected-dir.' },
            ] },
            { q: '<p>Niyə ping "Destination unreachable" yox, timeout verir?</p>', options: [
              { t: 'Sorğu PC3-ə çatır, amma cavab R2-də atılır və PC1-ə heç nə qayıtmır.', ok: true, why: 'PC1 cavab almır, xəta mesajı alınmır.' },
              { t: 'Sorğu R1-də atılır və xəta mesajı göndərilir.', why: 'R1-də marşrut var, o ötürür.' },
              { t: 'PC3 ping-ə cavab vermir.', why: 'PC3 cavab verir, cavab geri qayıda bilmir.' },
              { t: 'Kabel qırıqdır.', why: 'Kabel qırıq olsaydı, sorğu da çatmazdı və connected network-lər görünməzdi.' },
            ] },
            { q: '<p>Həll?</p>', options: [
              { t: 'R2-də ip route 192.168.1.0 255.255.255.0 10.0.12.1 yazmaq.', ok: true, why: 'Next hop R1-in R2 tərəfindəki ünvanıdır.' },
              { t: 'R1-də ikinci marşrut yazmaq.', why: 'R1 artıq düzgündür.' },
              { t: 'PC1-in gateway-ini dəyişmək.', why: 'PC1 gateway-i düzgündür.' },
              { t: 'Router-ləri yenidən başlatmaq.', why: 'Yenidən başlatma marşrut yaratmır.' },
            ] },
          ],
          after: '<p>İki router arasında hər iki istiqamətə marşrut yaz.</p>' },
        { id: 's7', title: 'show ip route oxu', type: 'form',
          pre: 'R1#show ip route\nC    192.168.1.0/24 is directly connected, GigabitEthernet0/0\nC    10.0.12.0/30 is directly connected, GigabitEthernet0/1\nS    192.168.3.0/24 [1/0] via 10.0.12.2\nS    172.16.0.0/16 [1/0] via 10.0.12.2',
          body: '<p>R1-in routing table-ına bax.</p>',
          fields: [
            { label: '192.168.3.77 ünvanı üçün next hop', placeholder: 'a.b.c.d', check: r => String(r).trim() === '10.0.12.2', show: '10.0.12.2', wrong: '192.168.3.0/24 sətrinə bax.' },
            { label: '172.16.40.5 üçün marşrut var? (bəli / xeyr)', placeholder: 'bəli / xeyr', answers: ['bəli', 'beli', 'yes'], wrong: '172.16.0.0/16 aralığı 172.16.40.5-i əhatə edir.' },
            { label: '10.5.5.5 üçün marşrut var? (bəli / xeyr)', placeholder: 'bəli / xeyr', answers: ['xeyr', 'yox', 'no'], wrong: 'Bu ünvana uyğun heç bir sətir yoxdur.' },
          ],
          hints: ['Hədəf ünvanı hansı prefiksə düşür?'],
          solution: '192.168.3.77 → 10.0.12.2; 172.16.40.5 → bəli (172.16.0.0/16); 10.5.5.5 → marşrut yoxdur.' },
        { id: 's8', title: 'Packet Tracer-də qur', type: 'ptsteps',
          body: '<p>İki router, iki switch və iki PC.</p>',
          checks: [
            { t: 'Router-ləri bir-birinə birləşdir (Gi0/1–Gi0/1, cross-over). R1 Gi0/1 <span class="m">10.0.12.1/30</span>, R2 Gi0/1 <span class="m">10.0.12.2/30</span>. LAN-lara <span class="m">192.168.1.1/24</span> və <span class="m">192.168.3.1/24</span> ver. Hər interface-də <span class="m">no shutdown</span>.' },
            { t: 'PC-lərə IP və gateway ver. Əvvəl PC1-dən PC3-ə ping at: işləməməlidir.' },
            { t: 'Yalnız R1-də marşrutu yaz. Ping yenə timeout verməlidir (R2-də qayıdış yoxdur).', cmd: ['ip route 192.168.3.0 255.255.255.0 10.0.12.2'] },
            { t: 'R2-də qayıdış marşrutunu yaz. İndi ping işləməlidir.', cmd: ['ip route 192.168.1.0 255.255.255.0 10.0.12.1'] },
            { t: 'Hər router-də <span class="m">show ip route</span> yaz və S sətrini tap. PC-dən <span class="m">tracert 192.168.3.10</span> yaz.', cmd: ['show ip route'] },
          ] },
        { id: 's9', title: 'Gördüyünü yaz', type: 'form',
          body: '<p>Yalnız R1-də marşrut yazılanda ping nə etdi?</p>',
          fields: [
            { label: 'Nəticə (işlədi / timeout)', placeholder: 'seç', answers: ['timeout', 'işləmədi', 'islemedi'], wrong: 'R2-də qayıdış marşrutu yoxdur.' },
            { label: 'Hər iki marşrutdan sonra tracert neçə hop göstərdi?', placeholder: 'rəqəm', check: r => ['2', '3'].includes(String(r).trim()), show: '2 və ya 3 (versiyadan asılı)', wrong: 'Yoldakı router-ləri say (R1, R2, hədəf).' },
          ],
          solution: 'Timeout; tracert iki router və hədəfi göstərir.' },
      ],
    },

    quiz: {
      draw: 8,
      gens: [
        () => {
          const p = pick([24, 25, 26, 27]); const block = Math.pow(2, 32 - p);
          const net = pick(['172.16.', '10.5.', '192.168.']) + R(200); const base = block * R(256 / block);
          const dst = net + '.' + base; const mask = A.maskS(p); const nh = pick(['10.0.12.2', '10.1.1.2', '172.20.0.2']);
          const wildcard = A.maskS(p).split('.').map(o => 255 - +o).join('.');
          const host = net + '.' + (base + 1 + R(Math.max(1, block - 3)));
          const opts = [
            { t: 'ip route ' + dst + ' ' + mask + ' ' + nh, ok: true, why: 'Hədəf network, adi mask və next hop düzgün sıradadır.' },
            { t: 'ip route ' + dst + ' ' + wildcard + ' ' + nh, why: 'Burada wildcard mask yazılıb. ip route adi subnet mask istəyir.' },
            { t: 'ip route ' + nh + ' ' + mask + ' ' + dst, why: 'Hədəf network və next hop yerləri dəyişib.' },
            { t: 'ip route ' + host + ' ' + mask + ' ' + nh, why: 'Hədəf yerində network ünvanı olmalıdır, host ünvanı yox.' },
          ];
          return { id: 'p3t5-g-cmd', concept: 'static-config', obj: 'ip route sintaksisi', _meta: { dst, mask, nh },
            stem: '<p><span class="m">' + dst + '/' + p + '</span> network-ünə R-in qonşusu <span class="m">' + nh + '</span> vasitəsilə getmək üçün hansı əmr düzgündür?</p>',
            options: shuffle(opts) };
        },
      ],
      pool: [
        { id: 'p3t5-q1', concept: 'route-why', obj: 'Router nəyi bilir',
          stem: '<p>Yeni router-ə iki interface IP ilə verilib. Router hansı network-ləri bilir?</p>',
          options: [
            { t: 'Yalnız interface-lərinin qoşulu olduğu connected network-ləri.', ok: true, why: 'Qalan network-lər üçün marşrut əlavə edilməlidir.' },
            { t: 'Şirkətin bütün network-lərini avtomatik öyrənib saxlayır.', why: 'Router uzaq network-ləri avtomatik öyrənmir.' },
            { t: 'İnternetdəki bütün ünvanları əvvəldən bilir.', why: 'Bunun üçün default route və ya protocol lazımdır.' },
            { t: 'Heç bir network-ü bilmir, hamısını əllə yazmaq lazımdır.', why: 'Connected network-lər avtomatik yazılır.' },
          ] },
        { id: 'p3t5-q2', concept: 'route-why', obj: 'Static və dynamic',
          stem: '<p>Static və dynamic routing arasındakı əsas fərq?</p>',
          options: [
            { t: 'Static-i administrator yazır, dynamic-də router-lər öyrənir.', ok: true, why: 'Static sadə və proqnozlaşdırılandır, dynamic dəyişikliklərə uyğunlaşır.' },
            { t: 'Static marşrut daha sürətli yönləndirir, yük az olur.', why: 'Yönləndirmə sürəti marşrutun növündən asılı deyil.' },
            { t: 'Dynamic marşrutu yalnız switch yaza bilər.', why: 'Dynamic marşrutu router-lər protocol ilə öyrənir.' },
            { t: 'Static marşrut yalnız IPv6 şəbəkələri üçün yazılır.', why: 'Static marşrut IPv4 üçün də var.' },
          ] },
        { id: 'p3t5-q3', concept: 'route-entry', obj: 'AD',
          stem: '<p>Eyni network-ü həm static marşrut (AD 1), həm OSPF (AD 110) öyrədir. Router hansını seçir?</p>',
          options: [
            { t: 'Static marşrutu, çünki AD-si kiçikdir.', ok: true, why: 'Kiçik AD daha etibarlıdır.' },
            { t: 'OSPF marşrutunu, çünki AD-si böyükdür.', why: 'Böyük AD daha az etibarlıdır.' },
            { t: 'Hər ikisini bərabər istifadə edir.', why: 'Fərqli AD-lərdə kiçik olan seçilir.' },
            { t: 'Heç birini, çünki toqquşma var.', why: 'AD məhz belə hallarda seçim edir.' },
          ] },
        { id: 'p3t5-q4', concept: 'route-entry', obj: 'S sətri',
          stem: '<p>Routing table-da <span class="m">S 10.20.0.0/16 [1/0] via 10.0.12.2</span> sətrində <span class="m">10.0.12.2</span> nədir?</p>',
          options: [
            { t: 'Next hop: paketin ötürüləcəyi qonşu router.', ok: true, why: 'via sözündən sonra next hop yazılır.' },
            { t: 'Hədəf network-ün özünün şəbəkə ünvanı.', why: 'Hədəf 10.20.0.0/16-dır.' },
            { t: 'Router-in öz loopback interface ünvanı.', why: 'Next hop qonşu router-in ünvanıdır.' },
            { t: 'DHCP server-in IP ünvanı.', why: 'Marşrutlar DHCP ilə əlaqəli deyil.' },
          ] },
        { id: 'p3t5-q5', concept: 'static-config', obj: 'ip route sintaksisi',
          stem: '<p>192.168.3.0/24 network-ünə next hop 10.0.12.2 ilə marşrut hansı əmrlə yazılır?</p>',
          options: [
            { t: 'ip route 192.168.3.0 255.255.255.0 10.0.12.2', ok: true, why: 'Hədəf network, mask, next hop.' },
            { t: 'ip route 192.168.3.0 0.0.0.255 10.0.12.2', why: 'Wildcard mask burada işlənmir.' },
            { t: 'route 10.0.12.2 192.168.3.0 /24', why: 'Cisco IOS-da belə sintaksis yoxdur.' },
            { t: 'ip route 10.0.12.2 255.255.255.0 192.168.3.0', why: 'Hədəf və next hop yerləri dəyişib.' },
          ] },
        { id: 'p3t5-q6', concept: 'static-config', obj: 'Next hop',
          stem: '<p>Next hop kimin ünvanı olmalıdır?</p>',
          options: [
            { t: 'Birbaşa qoşulu network-dəki qonşu router-in ünvanı.', ok: true, why: 'Router yalnız birbaşa əlçatan olan ünvana paket göndərə bilir.' },
            { t: 'Hədəf PC-nin özünün IP ünvanı və nəticə həmişə eynidir.', why: 'Next hop router-dir, hədəf cihaz deyil.' },
            { t: 'Router-in öz interface ünvanı.', why: 'Öz ünvanın next hop ola bilməz.' },
            { t: 'İnternet provayderinin domain adı və ya saytı.', why: 'Next hop IP ünvanıdır.' },
          ] },
        { id: 'p3t5-q7', concept: 'return-route', obj: 'Qayıdış marşrutu',
          stem: '<p>R1-də hədəf network üçün marşrut var, R2-də qayıdış marşrutu yoxdur. Ping nə göstərir?</p>',
          options: [
            { t: 'Timeout: sorğu çatır, cavab qayıda bilmir.', ok: true, why: 'R2 cavabın hədəf network-ünü bilmir və atır.' },
            { t: 'Cavab uğurla gəlir və ping tam tamamlanır.', why: 'Cavab qayıtmadan ping uğurlu olmaz.' },
            { t: 'Destination unreachable mesajı R1-dən gəlir.', why: 'R1-də marşrut var, o paketi ötürür.' },
            { t: 'Switch frame-i atır və xəta mesajı qaytarır.', why: 'Switch IP marşrutlarına baxmır.' },
          ] },
        { id: 'p3t5-q8', concept: 'return-route', obj: 'İki istiqamət',
          stem: '<p>İki LAN iki router ilə bağlıdır. Neçə static marşrut lazımdır?</p>',
          options: [
            { t: 'İki: hər router-də digər LAN üçün bir marşrut.', ok: true, why: 'Hər router uzaq LAN-ı bilməlidir.' },
            { t: 'Bir: yalnız bir router-də marşrut yazmaq kifayətdir.', why: 'Qayıdış marşrutu da lazımdır.' },
            { t: 'Dörd: hər LAN üçün iki marşrut lazımdır.', why: 'Hər router üçün yalnız bir uzaq LAN var.' },
            { t: 'Sıfır: connected network-lər kifayətdir.', why: 'Connected network-lər uzaq LAN-ı əhatə etmir.' },
          ] },
        { id: 'p3t5-q9', concept: 'route-verify', obj: 'Marşrut görünmür',
          stem: '<p>ip route əmri qəbul edildi, amma <span class="m">show ip route</span>-da S sətri yoxdur. Səbəb?</p>',
          options: [
            { t: 'Next hop əlçatan deyil: ünvan səhvdir və ya interface down.', ok: true, why: 'Əlçatan olmayan next hop ilə marşrut routing table-a düşmür.' },
            { t: 'Static marşrutlar show ip route-da heç vaxt göstərilmir.', why: 'Static marşrutlar S ilə göstərilir.' },
            { t: 'Router marşrutun görünməsi üçün yenidən başlamalıdır.', why: 'Marşrut yenidən başlama olmadan tətbiq olunur.' },
            { t: 'Mask 255.255.255.0 olduğu üçün marşrut yazılmır.', why: 'Mask marşrutun görünməsinə mane olmur.' },
          ] },
        { id: 'p3t5-q10', concept: 'route-trouble', obj: 'Unreachable mənbəyi',
          stem: '<p>PC1 ping edəndə <span class="m">Reply from 192.168.1.1: Destination host unreachable</span> görür (192.168.1.1 R1-dir). Bu nə deməkdir?</p>',
          options: [
            { t: 'R1-də hədəf network üçün marşrut yoxdur.', ok: true, why: 'Mesajı R1 göndərir: paketi aldı, amma yol tapa bilmədi.' },
            { t: 'PC1-in kabeli çıxıb və link yoxdur.', why: 'Kabel çıxsa, R1-dən cavab gəlməzdi.' },
            { t: 'Hədəf PC söndürülüb və cavab vermir.', why: 'Bu halda timeout gəlirdi.' },
            { t: 'DNS server mövcud deyil və ad çevrilmir.', why: 'IP ilə ping DNS tələb etmir.' },
          ] },
      ],
    },
  });
})();
