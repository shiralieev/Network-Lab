(function () {
  const pick = PT.pick; const R = PT.randInt; const shuffle = PT.shuffle;
  const norm = s => String(s).trim().toLowerCase().replace(/\s+/g, ' ');

  const NAMES = [['www.example.com', 'CNAME', 'www adı başqa adın ləqəbidir.'], ['example.com', 'A', 'Adın IPv4 ünvanı A record-dadır.'], ['mail.example.com', 'A', 'Server adının IPv4 ünvanı A record-dadır.']];
  const REC = [
    ['IPv4 ünvanı', 'A', 'A record adın IPv4 ünvanını saxlayır.'],
    ['IPv6 ünvanı', 'AAAA', 'AAAA record adın IPv6 ünvanını saxlayır.'],
    ['Bir adın başqa addan ləqəbi', 'CNAME', 'CNAME bir adı başqa adla əlaqələndirir.'],
    ['Domain-in mail serveri', 'MX', 'MX record mail serveri göstərir.'],
  ];

  PT.topic({
    id: 'p2t5',
    objectives: [
      'DNS-in nə üçün lazım olduğunu və cihazın adı necə çevirdiyini sıra ilə demək',
      'Recursive resolver, authoritative server, cache və TTL anlayışlarını izah etmək',
      'A, AAAA, CNAME və MX record-larını tanımaq',
      'nslookup çıxışını oxumaq və DNS problemini IP ping ilə ayırmaq',
    ],
    explain: PT.frag['p2/t05/explain'], cheat: PT.frag['p2/t05/cheat'],

    lab: {
      title: 'Lab 5: DNS-i izlə və problemi tap',
      goal: 'Ad çevrilməsinin sırasını bilmək, record növlərini ayırmaq, nslookup çıxışını oxumaq və DNS şikayətini həll etmək.',
      why: '"Sayt açılmır" şikayətlərinin çoxu DNS-lə bağlıdır. Burada əvvəl IP ilə yoxlamaq, sonra ad ilə yoxlamaq sürətli diaqnoz verir.',
      minutes: 35,
      finish: 'DNS-in yolunu və problemini tapmağı bilirsən. İndi quizə keç.',
      steps: [
        { id: 's1', title: 'Hazırlıq', type: 'info', button: 'Başladım',
          body: '<p>Əvvəlcə ad çevrilməsinin sırasını və record növlərini yoxlayacaq, sonra nslookup çıxışını oxuyacaq və bir ticket həll edəcəksən. Packet Tracer addımı yoxlama üçündür.</p>' },
        { id: 's2', title: 'Ad necə tapılır', type: 'order',
          body: '<p>PC <span class="m">example.com</span> adını açır. Cache-lər boşdur. Addımları sıra ilə düz.</p>',
          items: [
            { t: 'PC öz DNS cache-ində adı axtarır və tapmır', why: 'Cihaz əvvəl cache-ə baxır.' },
            { t: 'PC öz DNS server-inə (resolver) sorğu göndərir', why: 'Cihaz yalnız bu server ilə danışır.' },
            { t: 'Resolver root, sonra .com, sonra authoritative server-i soruşur', why: 'Zəncir kökdən aşağı gedir.' },
            { t: 'Authoritative server adın IP ünvanını verir', why: 'Domain-in sahibi cavabı bilir.' },
            { t: 'Resolver cavabı cache-ə yazır və PC-yə qaytarır', why: 'Cavab TTL qədər saxlanır.' },
          ],
          hints: ['PC resolver-ə, resolver isə zəncirə müraciət edir.'] },
        { id: 's3', title: 'Record növünü seç', type: 'match',
          body: '<p>Hər məlumat hansı record növündədir?</p>',
          pairs: REC.map(r => ({ l: r[0], r: r[1], why: r[2] })),
          hints: ['A IPv4 üçündür, AAAA IPv6 üçün.'] },
        { id: 's4', title: 'nslookup çıxışını oxu', type: 'form',
          pre: 'C:\\>nslookup shop.example.com\nServer:  dns.corp.local\nAddress:  10.0.0.53\n\nNon-authoritative answer:\nName:    shop.example.com\nAddress:  203.0.113.80\n\nC:\\>nslookup nosuchname.example.com\nServer:  dns.corp.local\nAddress:  10.0.0.53\n\n*** dns.corp.local can\'t find nosuchname.example.com: Non-existent domain',
          body: '<p>İki əmrin nəticəsinə bax.</p>',
          fields: [
            { label: 'PC hansı DNS server-dən istifadə edir?', placeholder: 'a.b.c.d', check: r => String(r).trim() === '10.0.0.53', show: '10.0.0.53', wrong: 'Server/Address sətrinə bax.' },
            { label: 'shop.example.com hansı IP-yə çevrildi?', placeholder: 'a.b.c.d', check: r => String(r).trim() === '203.0.113.80', show: '203.0.113.80', wrong: 'Name sətrindən sonrakı Address.' },
            { label: 'İkinci sorğunun xətası nə deməkdir? (ad yoxdur / server cavab vermir)', placeholder: 'seç', answers: ['ad yoxdur', 'ad yoxdu', 'yoxdur', 'nxdomain'], wrong: 'Non-existent domain: server cavab verdi, amma belə ad yoxdur.' },
          ],
          hints: ['Server cavab verirsə, timeout yoxdur.'],
          solution: '10.0.0.53; 203.0.113.80; ad yoxdur (NXDOMAIN).' },
        { id: 's5', title: 'Konfiqurasiyada səhvi tap', type: 'spot',
          body: '<p>Router DHCP ilə PC-lərə ünvan verir. PC-lər IP ilə ping edir, amma ad ilə yox. <b>Bir sətir problemi izah edir.</b></p>',
          lines: [
            { t: 'ip dhcp pool LAN1' },
            { t: ' network 192.168.1.0 255.255.255.0' },
            { t: ' default-router 192.168.1.1' },
            { t: '! dns-server sətri yoxdur', bad: true, why: 'Pool DNS server ünvanı vermir. PC-lərin DNS ayarı boş qalır və ad çevrilmir.' },
          ],
          fix: { label: 'Əlavə edəcəyin əmrin başlanğıcı', placeholder: 'əmr', answers: ['dns-server 8.8.8.8', 'dns-server'], wrong: 'DNS server ünvanı verən pool əmri.' },
          hints: ['DHCP DNS ünvanını da verir.'] },
        { id: 's6', title: 'Ticket: "Sayt açılmır"', type: 'ticket',
          body: '<p><b>İstifadəçi deyir:</b> "Brauzerdə heç bir sayt açılmır." <span class="m">ping 8.8.8.8</span> cavab verir. <span class="m">ping example.com</span> "could not find host" yazır.</p>',
          stages: [
            { q: '<p>İki ping nəyi göstərir?</p>', options: [
              { t: 'Yol işləyir, ad çevrilmir: DNS problemidir.', ok: true, why: 'IP ilə ping işləyirsə, Layer 1-3 qaydasındadır.' },
              { t: 'Kabel xarabdır.', why: 'Kabel xarab olsaydı, IP ilə ping də işləməzdi.' },
              { t: 'Gateway yoxdur.', why: 'Gateway yoxdursa, 8.8.8.8 də cavab verməzdi.' },
              { t: 'Server söndürülüb.', why: 'Ad heç çevrilmir, serverə çatmaq mərhələsinə gəlməyib.' },
            ] },
            { q: '<p>Növbəti addım?</p>', options: [
              { t: 'ipconfig /all ilə DNS Servers sətrinə baxmaq və nslookup yazmaq.', ok: true, why: 'PC hansı DNS-i işlədir və o cavab verirmi.' },
              { t: 'Browser-i yenidən quraşdırmaq.', why: 'Problem ad çevrilməsindədir.' },
              { t: 'Kabeli dəyişmək.', why: 'Fiziki yol işləyir.' },
              { t: 'Router-in IP-sini dəyişmək.', why: 'IP ilə ping işləyir, router ünvanı problem deyil.' },
            ] },
            { q: '<p>DNS Servers sətri boşdur. Həll?</p>', options: [
              { t: 'DHCP pool-a dns-server əlavə etmək və ya PC-də DNS ünvanını yazmaq.', ok: true, why: 'PC-yə işləyən DNS server ünvanı verilməlidir.' },
              { t: 'PC-nin MAC ünvanını dəyişmək.', why: 'MAC DNS-ə təsir etmir.' },
              { t: 'Gateway-i dəyişmək.', why: 'Gateway artıq işləyir.' },
              { t: 'TTL dəyərini artırmaq.', why: 'TTL DNS record müddətidir, ayara aid deyil.' },
            ] },
          ],
          after: '<p>Metod: əvvəl IP ilə, sonra ad ilə yoxla. Fərq DNS-i göstərir.</p>' },
        { id: 's7', title: 'Packet Tracer-də DNS qur (istəyə bağlı)', type: 'ptsteps',
          body: '<p>Bir PC, bir switch və bir server qoş. Server <span class="m">10.0.0.10/24</span>, PC <span class="m">10.0.0.20/24</span>.</p>',
          checks: [
            { t: 'Server → Services → DNS: DNS xidmətini aç, Name = <span class="m">test.local</span>, Address = <span class="m">10.0.0.10</span> yaz və Add bas.' },
            { t: 'PC-də Desktop → IP Configuration: DNS Server = <span class="m">10.0.0.10</span>.' },
            { t: 'PC Command Prompt-da <span class="m">ping test.local</span> yaz. Adın çevrildiyini cavabdakı IP-dən gör.' },
            { t: 'DNS Server-i sil və ya yanlış yaz, ping-i təkrarla: ad artıq çevrilmir.' },
          ] },
        { id: 's8', title: 'Gördüyünü yaz', type: 'form',
          body: '<p>DNS Server sahəsi boş olanda <span class="m">ping test.local</span> nə dedi?</p>',
          fields: [{ label: 'Nəticə (ad çevrildi / çevrilmədi)', placeholder: 'seç', answers: ['çevrilmədi', 'cevrilmedi', 'çevrilmir', 'cevrilmir', 'could not find host'], wrong: 'DNS ünvanı olmasa ad IP-yə çevrilmir.' }],
          solution: 'Ad çevrilmir: "could not find host" kimi bir mesaj.' },
      ],
    },

    quiz: {
      draw: 8,
      gens: [
        () => {
          const it = pick(REC); const all = ['A', 'AAAA', 'CNAME', 'MX'];
          return { id: 'p2t5-g-rec', concept: 'dns-records', obj: 'Record növü', _meta: { ans: it[1], what: it[0] },
            stem: '<p><b>' + it[0] + '</b> hansı DNS record-unda saxlanır?</p>',
            options: all.map(r => ({ t: r + ' record', ok: r === it[1], why: r === it[1] ? it[2] : r + ' başqa məlumat saxlayır. ' + it[2] })) };
        },
      ],
      pool: [
        { id: 'p2t5-q1', concept: 'dns-why', obj: 'DNS nə edir',
          stem: '<p>DNS-in əsas vəzifəsi nədir?</p>',
          options: [
            { t: 'Sayt adını IP ünvanına çevirmək.', ok: true, why: 'Şəbəkə IP ilə işləyir, insanlar adlarla.' },
            { t: 'IP ünvanını MAC ünvanına çevirmək.', why: 'Bunu ARP edir.' },
            { t: 'Cihazlara IP ünvanı vermək.', why: 'Bunu DHCP edir.' },
            { t: 'Paketləri şifrələmək.', why: 'DNS şifrələmə protocol-u deyil.' },
          ] },
        { id: 'p2t5-q2', concept: 'dns-why', obj: 'DNS portu',
          stem: '<p>DNS sorğusu adətən hansı protocol və portla gedir?</p>',
          options: [
            { t: 'UDP 53.', ok: true, why: 'DNS sorğusu kiçikdir və UDP ilə gedir.' },
            { t: 'TCP 80.', why: '80 HTTP üçündür.' },
            { t: 'UDP 67.', why: '67 DHCP server portudur.' },
            { t: 'TCP 443.', why: '443 HTTPS üçündür.' },
          ] },
        { id: 'p2t5-q3', concept: 'dns-resolve', obj: 'Cihaz kimə müraciət edir',
          stem: '<p>PC <span class="m">example.com</span> adını açanda sorğunu ilk hara göndərir (cache boşdur)?</p>',
          options: [
            { t: 'Öz konfiqurasiyasındakı DNS server-ə.', ok: true, why: 'PC yalnız bu server ilə danışır, qalan işi o görür.' },
            { t: 'Birbaşa root server-ə müraciət edir.', why: 'Root server-ləri resolver soruşur, PC yox.' },
            { t: 'Default gateway-in MAC ünvanına göndərir.', why: 'Gateway DNS sorğusunu cavablandırmır, o IP üzrə ötürür.' },
            { t: 'example.com-un authoritative server-inə.', why: 'PC onun ünvanını bilmir, resolver tapır.' },
          ] },
        { id: 'p2t5-q4', concept: 'dns-resolve', obj: 'Authoritative',
          stem: '<p>Authoritative DNS server nədir?</p>',
          options: [
            { t: 'Domain-in record-larına cavabdeh olan server.', ok: true, why: 'Adın IP ünvanını rəsmi olaraq o verir.' },
            { t: 'PC-nin öz yaddaşındakı müvəqqəti DNS cache-i, cavabları saxlayan yer.', why: 'Cache müvəqqəti saxlanan cavablardır.' },
            { t: 'Router-in daxilindəki DHCP server hissəsi, ünvan paylayan xidmət.', why: 'DHCP başqa xidmətdir.' },
            { t: 'Yalnız root server-lərin siyahısı, başqa heç bir server deyil.', why: 'Hər domain-in öz authoritative server-i var.' },
          ] },
        { id: 'p2t5-q5', concept: 'dns-resolve', obj: 'TTL',
          stem: '<p>DNS cavabındakı TTL nəyi göstərir?</p>',
          options: [
            { t: 'Cavabın cache-də nə qədər qalacağını.', ok: true, why: 'TTL bitəndən sonra cavab yenilənməlidir.' },
            { t: 'Paketin yolda neçə router-dən keçə biləcəyini göstərir.', why: 'Bu IP header-indəki TTL-dir. DNS record TTL-i vaxtdır.' },
            { t: 'Serverin cavab vermə sürətini millisaniyə ilə göstərir.', why: 'Cavab müddəti ayrıca ölçülür.' },
            { t: 'Domain-in qeydiyyatdan keçdiyi müddəti göstərir.', why: 'TTL qeydiyyatla əlaqəli deyil.' },
          ] },
        { id: 'p2t5-q6', concept: 'dns-records', obj: 'CNAME',
          stem: '<p><span class="m">www.example.com</span> <span class="m">example.com</span>-un ləqəbi kimi yazılıb. Bu hansı record-dur?</p>',
          options: [
            { t: 'CNAME record', ok: true, why: 'CNAME bir adı başqa adla əlaqələndirir.' },
            { t: 'A record', why: 'A record adı IPv4 ünvanına bağlayır.' },
            { t: 'MX record', why: 'MX mail serveri göstərir.' },
            { t: 'AAAA record', why: 'AAAA IPv6 ünvanı saxlayır.' },
          ] },
        { id: 'p2t5-q7', concept: 'dns-cmds', obj: 'nslookup Server sətri',
          stem: '<p>nslookup çıxışında <b>Server</b> sətri nəyi göstərir?</p>',
          options: [
            { t: 'Sorğuya cavab verən DNS server-i.', ok: true, why: 'Bu, PC-nin istifadə etdiyi DNS server-dir.' },
            { t: 'Saytın hazırda işlədiyi veb server-in IP ünvanını.', why: 'Saytın IP ünvanı Address (Name altında) sətrindədir.' },
            { t: 'PC-nin istifadə etdiyi default gateway ünvanını.', why: 'Gateway ipconfig-də göstərilir.' },
            { t: 'Şəbəkədəki DHCP server-in ünvanını və lease-ini.', why: 'DHCP server ipconfig /all-da göstərilir.' },
          ] },
        { id: 'p2t5-q8', concept: 'dns-cmds', obj: 'NXDOMAIN və timeout',
          stem: '<p>nslookup "Non-existent domain" deyir. Bu nə deməkdir?</p>',
          options: [
            { t: 'DNS server cavab verdi, belə ad yoxdur.', ok: true, why: 'Server işləyir, ad yanlışdır və ya record yoxdur.' },
            { t: 'DNS server-ə heç çatmaq olmur və sorğu cavabsız qalır.', why: 'Bu timeout olardı.' },
            { t: 'PC-nin IP ünvanı yoxdur və sorğu göndərilmir.', why: 'IP olmasa sorğu göndərilməzdi.' },
            { t: 'Default gateway ayarı səhvdir, ona görə cavab gəlmir.', why: 'Gateway səhv olsa, server cavab vermezdi.' },
          ] },
        { id: 'p2t5-q9', concept: 'dns-trouble', obj: 'IP işləyir, ad işləmir',
          stem: '<p><span class="m">ping 8.8.8.8</span> işləyir, <span class="m">ping google.com</span> işləmir. Ən ehtimal olunan səbəb?</p>',
          options: [
            { t: 'DNS server ayarı yoxdur və ya yanlışdır.', ok: true, why: 'Yol işləyir, ad çevrilmir.' },
            { t: 'Kabel qırıqdır və heç bir paket keçmir.', why: 'Kabel qırıq olsaydı, IP ilə ping də işləməzdi.' },
            { t: 'Default gateway yazılmayıb və PC kənara çıxa bilmir.', why: 'Gateway olmasaydı, 8.8.8.8 cavab verməzdi.' },
            { t: 'Switch portu shutdown vəziyyətindədir.', why: 'Port bağlı olsaydı heç bir ping işləməzdi.' },
          ] },
        { id: 'p2t5-q10', concept: 'dns-trouble', obj: 'Köhnə cavab',
          stem: '<p>Saytın IP ünvanı dəyişib, amma bir PC hələ köhnə ünvana qoşulur. Nə edirsən?</p>',
          options: [
            { t: 'ipconfig /flushdns ilə cache-i silirəm.', ok: true, why: 'Cache köhnə cavabı saxlayır.' },
            { t: 'ipconfig /release yazıb ünvanı buraxıram.', why: 'Bu DHCP ünvanını buraxır, DNS cache-ə aid deyil.' },
            { t: 'PC-nin MAC ünvanını dəyişirəm.', why: 'MAC DNS cavabına təsir etmir.' },
            { t: 'Router-in TTL dəyərini dəyişirəm.', why: 'Router TTL-i paket sayğacıdır, DNS cache deyil.' },
          ] },
      ],
    },
  });
})();
