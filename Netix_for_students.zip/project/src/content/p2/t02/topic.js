(function () {
  const pick = PT.pick; const R = PT.randInt; const shuffle = PT.shuffle;
  const macNorm = s => String(s).toLowerCase().replace(/[^0-9a-f]/g, '');

  /* devices on a PC1 - R1 - R2 - PC2 path; each link has a Src and Dst interface */
  const DEV = { pc1: 'PC1', r1a: 'R1-in PC1 tərəfindəki interface-i', r1b: 'R1-in R2 tərəfindəki interface-i', r2a: 'R2-nin R1 tərəfindəki interface-i', r2b: 'R2-nin PC2 tərəfindəki interface-i', pc2: 'PC2' };
  const LINKS = [{ n: 1, src: 'pc1', dst: 'r1a' }, { n: 2, src: 'r1b', dst: 'r2a' }, { n: 3, src: 'r2b', dst: 'pc2' }];

  PT.topic({
    id: 'p2t2',
    objectives: [
      'İki network arasında bir ping-in bütün addımlarını sıra ilə demək',
      'Hər link-də Src/Dst MAC, Src/Dst IP və TTL dəyərlərini yazmaq',
      'Hər ARP mübadiləsinin hansı link-də olduğunu və kimin MAC-ini soruşduğunu müəyyən etmək',
      'Ping və tracert nəticəsinə görə yolun hansı hissəsində problem olduğunu tapmaq',
    ],
    explain: PT.frag['p2/t02/explain'], cheat: PT.frag['p2/t02/cheat'],

    lab: {
      title: 'Lab 2: Paketi yol boyu izlə',
      goal: 'Bir ping-in addımlarını sıralamaq, hər link-in header-lərini yazmaq, ARP cache-dən nəticə çıxarmaq və qırıq yolu simptomdan tapmaq.',
      why: 'Şəbəkə problemlərinin çoxu paketin yolun hansı hissəsində dayandığını tapmaqla həll olunur. Bunun üçün yolun normal işini addım-addım bilmək lazımdır.',
      minutes: 40,
      finish: 'Paketin yolunu və hər link-də nə dəyişdiyini bilirsən. İndi quizə keç.',
      steps: [
        { id: 's1', title: 'Hazırlıq', type: 'info', button: 'Başladım',
          body: '<p>Topologiya: PC1 (<span class="m">192.168.1.10</span>) – Switch – R1 (<span class="m">192.168.1.1</span> | <span class="m">192.168.2.1</span>) – Switch – PC2 (<span class="m">192.168.2.20</span>). Bütün cədvəllər boşdur. PC1 PC2-yə ilk ping atır.</p>' },
        { id: 's2', title: 'İlk ping-in sırası', type: 'order',
          body: '<p>Hadisələri baş vermə sırası ilə düz.</p>',
          items: [
            { t: 'PC1 hədəfin başqa network-də olduğunu mask ilə müəyyən edir', why: 'Hər paketdən əvvəl PC "eyni network-dürmü" sualını verir.' },
            { t: 'PC1 ARP ilə gateway-in MAC ünvanını soruşur və öyrənir', why: 'Frame-in Dst MAC-i gateway olacaq, ona görə onun MAC-i lazımdır.' },
            { t: 'PC1 ping paketini gateway-in MAC-i ilə göndərir', why: 'Dst MAC gateway, Dst IP isə PC2-dir.' },
            { t: 'R1 routing table-dan çıxış interface-ini seçir və PC2 üçün ARP edir', why: 'Router PC2-nin MAC-ini öz ARP cache-ində tapmır.' },
            { t: 'R1 paketi yeni Ethernet header-i və azaldılmış TTL ilə PC2-yə göndərir', why: 'Link 2 üçün yeni header yazılır.' },
            { t: 'PC2 ping cavabını öz gateway-inə göndərir', why: 'PC1 başqa network-dədir, cavab də gateway-ə verilir.' },
          ],
          hints: ['PC əvvəl qərar verir, sonra ARP, sonra paket.'],
          after: '<p>İki ARP mübadiləsi var: biri PC1-in link-ində, biri PC2-nin link-ində.</p>' },
        { id: 's3', title: 'Link 2-nin header-lərini yaz', type: 'form',
          body: '<div class="tbl-wrap"><table class="tbl"><tr><th>Interface</th><th>IP</th><th>MAC</th></tr><tr><td>PC1</td><td class="m">192.168.1.10</td><td class="m">0001.4321.AAAA</td></tr><tr><td>R1 Gi0/0</td><td class="m">192.168.1.1</td><td class="m">0001.4321.B001</td></tr><tr><td>R1 Gi0/1</td><td class="m">192.168.2.1</td><td class="m">0001.4321.B002</td></tr><tr><td>PC2</td><td class="m">192.168.2.20</td><td class="m">0001.4321.CCCC</td></tr></table></div><p>İlkin TTL 128. R1-dən PC2-yə gedən frame üçün header-ləri yaz.</p>',
          fields: [
            { label: 'Src MAC', placeholder: 'MAC', check: r => macNorm(r) === '00014321b002', show: '0001.4321.B002', wrong: 'Frame-i bu link-ə kim göndərir: R1-in hansı interface-i?' },
            { label: 'Dst MAC', placeholder: 'MAC', check: r => macNorm(r) === '00014321cccc', show: '0001.4321.CCCC', wrong: 'Frame-i bu link-də kim qəbul edir?' },
            { label: 'Src IP', placeholder: 'a.b.c.d', check: r => String(r).trim() === '192.168.1.10', show: '192.168.1.10', wrong: 'IP ünvanlar dəyişmir.' },
            { label: 'Dst IP', placeholder: 'a.b.c.d', check: r => String(r).trim() === '192.168.2.20', show: '192.168.2.20', wrong: 'Paket əvvəldən kimə ünvanlanıb?' },
            { label: 'TTL', placeholder: 'rəqəm', check: r => String(r).trim() === '127', show: '127', wrong: 'Router TTL-i 1 azaldır.' },
          ],
          hints: ['MAC link üçündür, IP son hədəf üçün.'],
          solution: 'Src MAC 0001.4321.B002, Dst MAC 0001.4321.CCCC, Src IP 192.168.1.10, Dst IP 192.168.2.20, TTL 127.' },
        { id: 's4', title: 'PC1-də ping və ARP cache', type: 'terminal',
          body: '<p>PC1-dən PC2-yə ping at, sonra ARP cache-ə bax.</p><ol><li><span class="m">ping 192.168.2.20</span></li><li><span class="m">arp -a</span></li><li><span class="m">tracert 192.168.2.20</span></li></ol>',
          term: { kind: 'host', host: { name: 'PC1', ip: '192.168.1.10', mask: '255.255.255.0', gw: '192.168.1.1', mac: '0001.4321.AAAA' },
            peers: [{ name: 'R1', ip: '192.168.1.1', mac: '0001.4321.B001' }], remote: [{ ip: '192.168.2.20', ttl: 127 }], quick: ['ping 192.168.2.20', 'arp -a', 'tracert 192.168.2.20'],
            goals: [
              { text: '<span class="m">ping 192.168.2.20</span> işlət', test: d => d.pings.some(p => p.ip === '192.168.2.20') },
              { text: '<span class="m">arp -a</span> yaz', test: d => d.history.some(l => /^arp\s+-a$/i.test(l)) },
            ] },
          hints: ['Əmri yaz və Enter bas.'],
          after: '<p>Ping cavabında TTL=127: PC2-nin ilkin TTL-i 128, bir router keçdi. ARP cache-də yalnız gateway görünür.</p>' },
        { id: 's5', title: 'Çıxışdan oxu', type: 'form',
          body: '<p>Əvvəlki praktikanın nəticəsinə əsasən cavab ver.</p>',
          fields: [
            { label: 'PC1-in ARP cache-ində 192.168.2.20 üçün giriş var? (bəli / xeyr)', placeholder: 'bəli / xeyr', answers: ['xeyr', 'yox', 'no'], wrong: 'PC2 başqa network-dədir. PC1 onun MAC-ini öyrənmir.' },
            { label: 'Ping cavabındakı TTL neçə idi?', placeholder: 'rəqəm', check: r => String(r).trim() === '127', show: '127', wrong: 'PC2-nin ilkin TTL-i 128, bir router keçdi.' },
            { label: 'Neçə router keçdi?', placeholder: 'rəqəm', check: r => String(r).trim() === '1', show: '1', wrong: '128 − 127 = ?' },
          ],
          solution: 'Giriş yoxdur (yalnız gateway). TTL 127, bir router.' },
        { id: 's6', title: 'Log şərhində səhvi tap', type: 'spot',
          body: '<p>Analitik ilk ping-in capture-ini şərh edib. <b>Bir şərh səhvdir.</b> Onu tap.</p>',
          lines: [
            { t: '1.  PC1 192.168.1.1 üçün ARP request göndərir (broadcast).' },
            { t: '2.  PC1 192.168.2.20 üçün ARP request göndərir və PC2 cavab verir.', bad: true, why: 'PC1 başqa network-dəki PC2 üçün ARP göndərmir. ARP broadcast router-dən keçmir, PC1 gateway-in MAC-ini soruşur.' },
            { t: '3.  R1 Gi0/1 interface-ində 192.168.2.20 üçün ARP request göndərir.' },
            { t: '4.  Ping paketinin IP ünvanları R1-dən keçəndə dəyişmir, TTL 1 azalır.' },
          ],
          fix: { label: 'PC1 kimin MAC-ini soruşur?', placeholder: 'məs. gateway', answers: ['gateway', 'gateway-in', 'router', 'routerin', 'router-in', '192.168.1.1'], wrong: 'Frame bu link-də kimə çatmalıdır?' },
          hints: ['ARP yalnız eyni link-də işləyir.'] },
        { id: 's7', title: 'Simptom və səbəbi birləşdir', type: 'match',
          body: '<p>Hər simptomun ən ehtimal olunan səbəbini seç.</p>',
          pairs: [
            { l: 'Gateway-ə ping işləmir', r: 'PC-nin gateway ayarı və ya kabel', why: 'Problem PC ilə router arasındadır.' },
            { l: '<span class="m">Reply from gateway: Destination host unreachable</span>', r: 'Router hədəf network-ə yol tapmır', why: 'Paket router-ə çatdı, router ötürə bilmir.' },
            { l: 'Sorğu çatır, amma ping həmişə timeout', r: 'Hədəfdə gateway yoxdur və ya cavab yolu qırıqdır', why: 'Cavab geri qayıda bilmir.' },
            { l: 'Eyni network-də ping işləyir, başqasında yox', r: 'Gateway ayarı və ya router interface-i', why: 'Başqa network üçün paket gateway-ə gedir.' },
          ],
          hints: ['Problemi yolun hansı hissəsində olduğuna görə seç.'] },
        { id: 's8', title: 'Ticket: yalnız bir istiqamət', type: 'ticket',
          body: '<p><b>Mühəndis deyir:</b> "PC1-dən PC2-yə ping həmişə timeout verir, amma PC1-dən router-in hər iki interface-inə ping işləyir. Router-də <span class="m">show ip route</span> hər iki network-ü göstərir."</p>',
          stages: [
            { q: '<p>PC1-dən hər iki router interface-inə ping işləyir. Bu nəyi sübut edir?</p>', options: [
              { t: 'PC1 ilə router arasında link, gateway ayarı və router interface-ləri işləyir.', ok: true, why: 'PC1 gateway-ə çatır və router öz interface-lərini görür.' },
              { t: 'PC2-yə yol da işləyir.', why: 'Router interface-inə ping PC2-yə yolu sübut etmir.' },
              { t: 'PC2 işləyir.', why: 'PC2 hələ yoxlanmayıb.' },
              { t: 'Router-də marşrut yoxdur.', why: 'Verilənə görə routing table hər iki network-ü göstərir.' },
            ] },
            { q: '<p>Sorğu PC2-yə çatsa belə cavab niyə qayıtmaya bilər?</p>', options: [
              { t: 'PC2-nin default gateway-i yoxdur və ya yanlışdır, cavabı PC1-in network-ünə göndərə bilmir.', ok: true, why: 'PC1 başqa network-dədir. PC2 cavabı gateway-ə verməlidir.' },
              { t: 'PC2-nin MAC ünvanı çox uzundur.', why: 'MAC ünvanının uzunluğu sabitdir.' },
              { t: 'Router TTL-i artırır.', why: 'Router TTL-i azaldır.' },
              { t: 'Switch ICMP-ni bloklayır.', why: 'Switch Layer 2 cihazıdır, ICMP-yə baxmır.' },
            ] },
            { q: '<p>Növbəti addım?</p>', options: [
              { t: 'PC2-də ipconfig ilə gateway-ə və mask-a baxmaq.', ok: true, why: 'Qarşı tərəfin ayarları da düzgün olmalıdır.' },
              { t: 'PC1-in IP ünvanını dəyişmək.', why: 'PC1-in ayarları işləyir (gateway-ə çatır).' },
              { t: 'Router-i yenidən başlatmaq.', why: 'Router-in routing table-ı düzgündür, səbəb orada deyil.' },
              { t: 'Kabeli dəyişmək.', why: 'PC1-dən router-ə yol işləyir, kabel problemi olsaydı o da işləməzdi.' },
            ] },
          ],
          after: '<p>Ping iki istiqamətlidir: hər iki tərəfdə gateway doğru olmalıdır.</p>' },
        { id: 's9', title: 'Packet Tracer-də izlə (istəyə bağlı)', type: 'ptsteps',
          body: '<p>Əvvəlki mövzudakı qurğu ilə (iki PC, iki switch, bir router) yoxla.</p>',
          checks: [
            { t: 'Simulation Mode-a keç. Edit Filters-də yalnız ARP və ICMP saxla.' },
            { t: 'PC1-dən PC2-yə Add Simple PDU göndər və Capture / Forward ilə irəlilə.' },
            { t: 'İki ARP request-i tap: biri PC1-dən (gateway üçün), biri R1-dən (PC2 üçün). Hər ikisi broadcast-dır.' },
            { t: 'ICMP paketinə klik et və PDU Information-da Src/Dst MAC-in router-dən əvvəl və sonra necə dəyişdiyini yoxla. IP-lərin dəyişmədiyini gör.' },
          ] },
      ],
    },

    quiz: {
      draw: 8,
      gens: [
        () => {
          const link = pick(LINKS); const field = pick(['srcmac', 'dstmac', 'srcip', 'dstip']);
          const dev = { srcmac: link.src, dstmac: link.dst, srcip: 'pc1', dstip: 'pc2' }[field];
          const lbl = { srcmac: 'Source MAC', dstmac: 'Destination MAC', srcip: 'Source IP', dstip: 'Destination IP' }[field];
          const all = Object.keys(DEV);
          const wrong = shuffle(all.filter(k => k !== dev)).slice(0, 3);
          const opts = shuffle([dev].concat(wrong));
          const why = (k) => k === dev ? (field.endsWith('ip') ? 'IP ünvanları yol boyu dəyişmir: Source IP həmişə PC1, Destination IP həmişə PC2-dir.' : 'MAC ünvanları yalnız bir link üçündür. Link ' + link.n + '-də frame-i ' + DEV[link.src] + ' göndərir, ' + DEV[link.dst] + ' qəbul edir.') : (field.endsWith('ip') ? 'IP ünvanı dəyişmir, bu cihaz Source/Destination IP deyil.' : 'Bu cihaz link ' + link.n + '-in uclarında deyil.');
          return { id: 'p2t2-g-hdr', concept: 'path-two', obj: 'Link-də header sahəsi', _meta: { link: link.n, field, ans: dev },
            stem: '<p>PC1 → R1 → R2 → PC2 yolunda <b>link ' + link.n + '</b>-dəki frame-də <b>' + lbl + '</b> kimin ünvanıdır?</p>',
            options: opts.map(k => ({ t: DEV[k], ok: k === dev, why: why(k) })) };
        },
      ],
      pool: [
        { id: 'p2t2-q1', concept: 'path-steps', obj: 'PC1 PC2-nin MAC-ini öyrənirmi',
          stem: '<p>PC1 başqa network-dəki PC2-yə ping atır. PC1-in ARP cache-ində ping-dən sonra nə olur?</p>',
          options: [
            { t: 'Yalnız default gateway-in girişi.', ok: true, why: 'PC1 frame-i gateway-ə göndərir və yalnız onun MAC-ini öyrənir.' },
            { t: 'PC2-nin girişi, çünki ping PC2-yə gedir.', why: 'ARP broadcast router-dən keçmir, PC1 PC2-nin MAC-ini öyrənə bilməz.' },
            { t: 'Həm gateway, həm PC2 girişi.', why: 'PC2 üçün giriş yaranmır.' },
            { t: 'Heç nə, çünki başqa network üçün ARP işləmir.', why: 'Gateway üçün ARP işləyir, çünki gateway eyni network-dədir.' },
          ] },
        { id: 'p2t2-q2', concept: 'path-steps', obj: 'R1 ARP',
          stem: '<p>Paket R1-ə gəlir. Router-in PC2 üçün ARP cache-i boşdur. Router nə edir?</p>',
          options: [
            { t: 'Gi0/1 ilə PC2 üçün ARP request göndərir.', ok: true, why: 'Router PC2-yə birbaşa qoşuludur və onun MAC-ini ARP ilə öyrənir.' },
            { t: 'Paketi atır və PC1-ə dərhal xəta mesajı qaytarır.', why: 'Router əvvəl ARP ilə MAC-i öyrənməyə çalışır.' },
            { t: 'PC1-dən PC2-nin MAC ünvanını soruşur.', why: 'PC1 PC2-nin MAC-ini bilmir.' },
            { t: 'Paketi Gi0/0 ilə PC1 tərəfə geri göndərir.', why: 'Hədəf Gi0/1 tərəfindədir.' },
          ] },
        { id: 'p2t2-q3', concept: 'path-steps', obj: 'ARP sayı',
          stem: '<p>Cache-lər boşdur. Bir PC1 → PC2 ping üçün neçə ARP mübadiləsi lazımdır (switch-lər də cədvəlləri öyrənir)?</p>',
          options: [
            { t: 'İki: PC1 gateway üçün, R1 PC2 üçün.', ok: true, why: 'Hər link-də öz ARP-ı var. Cavab zamanı PC2 üçün də gateway ARP-ı lazım ola bilər.' },
            { t: 'Biri: yalnız PC1 birbaşa PC2-ni soruşur.', why: 'ARP router-dən keçmir.' },
            { t: 'Heç biri, çünki router bütün MAC-ləri əvvəldən bilir.', why: 'Router da cache boş olanda ARP edir.' },
            { t: 'Dörd: hər cihaz hər cihazı ayrıca soruşur.', why: 'ARP yalnız lazım olan ünvan üçün göndərilir.' },
          ] },
        { id: 'p2t2-q4', concept: 'path-steps', obj: 'İlk ping itkisi',
          stem: '<p>İki network arasında ilk ping-də ilk paket timeout verir, sonrakılar uğurludur. Ən ehtimal olunan səbəb?</p>',
          options: [
            { t: 'İlk paket ARP-ları gözləyir.', ok: true, why: 'ARP başa çatana qədər paket göndərilə bilmir.' },
            { t: 'Kabel qırıqdır və sonra özünü bərpa edir.', why: 'Qırıq kabel bütün paketləri itirərdi.' },
            { t: 'Router ilk paketin TTL-ini sıfırlayır.', why: 'TTL sıfır olsa, bütün paketlər atılardı.' },
            { t: 'DNS ilk sorğuya cavab vermir.', why: 'IP ilə ping DNS-dən asılı deyil.' },
          ] },
        { id: 'p2t2-q5', concept: 'path-overview', obj: 'Hansı sahə dəyişmir',
          stem: '<p>PC1-dən PC2-yə gedən paket router-dən keçir. Hansı sahə <b>dəyişmir</b>?</p>',
          options: [
            { t: 'Source IP və Destination IP.', ok: true, why: 'IP ünvanları əvvəldən sona eyni qalır.' },
            { t: 'Frame-in Source MAC ünvanı.', why: 'Source MAC hər link-də başqa cihazın MAC-idir.' },
            { t: 'Frame-in Destination MAC ünvanı.', why: 'Destination MAC hər link üçün yenidən yazılır.' },
            { t: 'IP header-indəki TTL sahəsi.', why: 'TTL hər router-də 1 azalır.' },
          ] },
        { id: 'p2t2-q6', concept: 'path-two', obj: 'Üç link TTL',
          stem: '<p>PC1 TTL=128 ilə paket göndərir. Yolda R1 və R2 var. PC2-yə çatanda TTL neçə olur?</p>',
          options: [
            { t: '126', ok: true, why: 'Hər router 1 azaldır: 128 − 2 = 126.' },
            { t: '128', why: 'Router-lərdən keçəndə TTL azalır.' },
            { t: '127', why: 'Bu yalnız bir router keçəndə olardı.' },
            { t: '125', why: 'Yolda yalnız iki router var.' },
          ] },
        { id: 'p2t2-q7', concept: 'path-fail', obj: 'Timeout səbəbi',
          stem: '<p>PC1 gateway-ə ping edə bilir. PC2-yə ping timeout verir. Routing table düzgündür. Nəyi yoxlayırsan?</p>',
          options: [
            { t: 'PC2-nin gateway və mask ayarlarını.', ok: true, why: 'PC2 cavabı öz gateway-i vasitəsilə geri göndərməlidir.' },
            { t: 'PC1-in kabelini və switch portunu.', why: 'PC1 gateway-ə çatır, kabel işləyir.' },
            { t: 'PC1-in MAC ünvanının unikallığını.', why: 'MAC unikal olarsa problem deyil.' },
            { t: 'Switch-in portunu başqa porta dəyişmək.', why: 'Əvvəl PC2-nin ayarlarına baxmaq lazımdır.' },
          ] },
        { id: 'p2t2-q8', concept: 'path-fail', obj: 'Gateway unreachable',
          stem: '<p>Ping-də <span class="m">Reply from 192.168.1.1: Destination host unreachable</span> görünür. 192.168.1.1 router-in ünvanıdır. Bu nəyi göstərir?</p>',
          options: [
            { t: 'Paket router-ə çatdı, router hədəfə çatdıra bilmir.', ok: true, why: 'Mesajı router göndərib: router paketi aldı, amma hədəf üçün yol yoxdur.' },
            { t: 'PC1-in kabeli çıxıb və link yoxdur.', why: 'Kabel çıxsa, router-dən cavab gəlməzdi.' },
            { t: 'PC1-in default gateway-i yazılmayıb və bu normal sayılır.', why: 'Mesaj gateway-dən gəlir, deməli PC1 ona çata bilir.' },
            { t: 'Hədəf cihaz ping-ə cavab vermir.', why: 'Hədəf cavab versə, Reply from hədəf görünərdi.' },
          ] },
        { id: 'p2t2-q9', concept: 'path-fail', obj: 'Ping iki istiqamətli',
          stem: '<p>Niyə "ping gedir, amma cavab gəlmir" mümkündür?</p>',
          options: [
            { t: 'Sorğu hədəfə çata bilər, qayıdış yolu isə qırıq ola bilər.', ok: true, why: 'Ping hər iki istiqamətdə yol tələb edir.' },
            { t: 'Ping yalnız bir istiqamətli protocol-dur və cavab gözləmir.', why: 'Ping iki istiqamətlidir: Echo Request və Echo Reply.' },
            { t: 'Cavab həmişə başqa portdan gəlir və PC onu görmür.', why: 'ICMP-də port yoxdur.' },
            { t: 'Hədəf cavabı göndərməyi unudur.', why: 'Cavab avtomatikdir, səbəb yolda və ya ayarlardadır.' },
          ] },
      ],
    },
  });
})();
