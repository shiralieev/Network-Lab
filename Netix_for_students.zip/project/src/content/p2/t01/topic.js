(function () {
  const A = PT.addr; const pick = PT.pick; const R = PT.randInt; const shuffle = PT.shuffle;
  const ipOK = (raw, want) => String(raw).trim() === want;

  PT.topic({
    id: 'p2t1',
    objectives: [
      'Router-in nə etdiyini və switch-dən fərqini izah etmək',
      'PC üçün düzgün IP, mask və default gateway seçmək',
      'Router interface-ini qurmaq və show ip interface brief ilə yoxlamaq',
      'show ip route çıxışında connected network-ləri oxumaq',
      'Gateway ilə bağlı səhvləri simptomdan tapmaq',
    ],
    explain: PT.frag['p2/t01/explain'], cheat: PT.frag['p2/t01/cheat'],

    lab: {
      title: 'Lab 1: Router, gateway və interface-lər',
      goal: 'PC ayarlarını hesablamaq, router konfiqurasiyasında və show çıxışında səhv tapmaq, gateway şikayətini həll etmək və Packet Tracer-də iki network-i router ilə qoşmaq.',
      why: 'Helpdesk-də "internetə çıxa bilmirəm" şikayətlərinin böyük hissəsi gateway və ya router interface-i ilə bağlıdır. Bu laba bu problemləri tez tapmağı öyrədir.',
      minutes: 40,
      finish: 'Gateway və router interface problemlərini tanıyırsan. İndi quizə keç.',
      steps: [
        { id: 's1', title: 'Hazırlıq', type: 'info', button: 'Başladım',
          body: '<p>Əvvəlcə kağız üzərində işləyəcəksən: ayarları hesablayacaq, konfiqurasiyada və çıxışda səhv tapacaq, bir ticket həll edəcəksən. Sonda Packet Tracer-də qurğunu real yoxlayacaqsan.</p>' },
        { id: 's2', title: 'Cihazın işini seç', type: 'match',
          body: '<p>Hər cihaz paketlə nə edir?</p>',
          pairs: [
            { l: '<b>Switch</b>', r: 'Destination MAC-ə baxıb frame-i porta göndərir', why: 'Layer 2 cihazıdır, IP-yə baxmır.' },
            { l: '<b>Router</b>', r: 'Destination IP-yə baxıb network-ə yol seçir', why: 'Layer 3 cihazıdır, routing table işlədir.' },
            { l: '<b>PC</b>', r: 'Paketi yaradır və hədəf başqa network-dədirsə gateway-ə verir', why: 'End device-dir.' },
            { l: '<b>Default gateway</b>', r: 'PC-nin network-ündən çıxış üçün işlətdiyi router ünvanı', why: 'Router interface-inin IP-sidir.' },
          ],
          hints: ['Əvvəl switch və router-i ayır: biri MAC-ə, digəri IP-yə baxır.'] },
        { id: 's3', title: 'PC ayarlarını hesabla', type: 'form',
          body: '<p>R1-in <span class="m">Gi0/0</span> interface-i <span class="m">10.10.5.1/24</span> ünvanındadır və LAN-a qoşulub. PC4-ə həmin LAN-dan ünvan verirsən.</p>',
          fields: [
            { label: 'PC4 üçün default gateway', placeholder: 'a.b.c.d', check: r => ipOK(r, '10.10.5.1'), show: '10.10.5.1', wrong: 'Gateway PC-nin network-ündəki router interface-inin IP ünvanıdır.' },
            { label: 'PC4 üçün subnet mask', placeholder: 'a.b.c.d', check: r => ipOK(r, '255.255.255.0'), show: '255.255.255.0', wrong: '/24 mask-ı necədir?' },
            { label: 'PC4 üçün icazə verilən IP-lərdən biri (məs. .20)', placeholder: 'a.b.c.d', check: r => { const m = String(r).trim().match(/^10\.10\.5\.(\d+)$/); return !!m && +m[1] >= 2 && +m[1] <= 254; }, show: '10.10.5.2 – 10.10.5.254 aralığından biri', wrong: 'PC4 router ilə eyni network-də olmalıdır (10.10.5.x), router-in ünvanı və .0 / .255 olmaz.' },
          ],
          hints: ['PC router ilə eyni /24 network-ündə olmalıdır.'],
          solution: 'Gateway 10.10.5.1, mask 255.255.255.0, IP 10.10.5.2 – 10.10.5.254 aralığından (router-in .1 ünvanından başqa).' },
        { id: 's4', title: 'Router konfiqurasiyasında səhvi tap', type: 'spot',
          body: '<p>Kolleqa R1-i quraşdırıb. Gi0/0 LAN 1-ə (192.168.1.0/24), Gi0/1 LAN 2-yə (192.168.2.0/24) qoşulub. <b>Bir sətir səhvdir.</b> Onu tap, sonra düzgün ünvanı yaz.</p>',
          lines: [
            { t: 'interface GigabitEthernet0/0' },
            { t: ' ip address 192.168.1.1 255.255.255.0' },
            { t: ' no shutdown' },
            { t: 'interface GigabitEthernet0/1' },
            { t: ' ip address 192.168.1.1 255.255.255.0', bad: true, why: 'Gi0/1 LAN 2-dədir, ünvanı 192.168.2.x olmalıdır. Eyni ünvanı iki interface-ə vermək olmaz.' },
            { t: ' no shutdown' },
          ],
          fix: { label: 'Gi0/1 üçün düzgün IP', placeholder: 'a.b.c.d', answers: ['192.168.2.1', '192.168.2.254'], wrong: 'Gi0/1 192.168.2.0/24 network-ündədir. İlk host ünvanını seç.' },
          hints: ['Router-in iki interface-i eyni network-də ola bilməz.'] },
        { id: 's5', title: 'show çıxışında səhvi tap', type: 'spot',
          body: '<p>Bütün PC-lər LAN 2-yə çıxa bilmir. Router-də <span class="m">show ip interface brief</span> yazdın. <b>Problemi göstərən sətri</b> tap.</p>',
          lines: [
            { t: 'Interface              IP-Address      OK? Method Status                Protocol' },
            { t: 'GigabitEthernet0/0     192.168.1.1     YES manual up                    up' },
            { t: 'GigabitEthernet0/1     192.168.2.1     YES manual administratively down down', bad: true, why: 'Gi0/1 administratively down: interface-də shutdown yazılıb və ya hələ no shutdown yazılmayıb.' },
          ],
          fix: { label: 'Interface-də hansı əmri yazırsan?', placeholder: 'əmr', answers: ['no shutdown', 'no shut'], wrong: 'Administratively down interface-i açan əmr hansıdır?' },
          hints: ['Status sütununa bax: administratively down nə deməkdir?'] },
        { id: 's6', title: 'Ticket: "Başqa şəbəkəyə çıxa bilmirəm"', type: 'ticket',
          body: '<p><b>İstifadəçi deyir:</b> "Kolleqalara və printerə çatıram, amma server şəbəkəsinə çıxa bilmirəm." PC-nin <span class="m">ipconfig</span> nəticəsi: IP <span class="m">192.168.1.30</span>, mask <span class="m">255.255.255.0</span>, gateway <span class="m">192.168.1.254</span>. Router-in LAN interface-i <span class="m">192.168.1.1</span> ünvanındadır.</p>',
          stages: [
            { q: '<p>Simptom nəyi göstərir?</p>', options: [
              { t: 'Eyni network işləyir, başqa network işləmir: gateway ilə bağlı problem şübhəlidir.', ok: true, why: 'Eyni network-də gateway lazım deyil. Başqa network üçün paket gateway-ə verilir, ona görə simptom gateway-ə işarə edir.' },
              { t: 'Kabel xarabdır, çünki heç nə işləmir.', why: 'Kolleqalara və printerə çatır, deməli kabel işləyir.' },
              { t: 'Switch MAC cədvəlini silib.', why: 'MAC cədvəli problemi eyni network-ü də pozardı.' },
              { t: 'Server söndürülüb.', why: 'Problem yalnız bir server deyil, bütün server şəbəkəsidir.' },
            ] },
            { q: '<p>Nəyi yoxlayırsan?</p>', options: [
              { t: 'PC-də yazılan gateway ünvanı router interface-inin ünvanı ilə üst-üstə düşürmü?', ok: true, why: 'PC gateway-ə (192.168.1.254) ARP göndərir. Router isə 192.168.1.1-dədir, orada kimsə cavab vermir.' },
              { t: 'DNS ayarı düzgündürmü?', why: 'DNS ad üçündür. Burada eyni IP-lərlə də server şəbəkəsinə çıxış yoxdur.' },
              { t: 'Browser-in keş-i təmizlənibmi?', why: 'Browser Layer 7-dir, problem isə daha aşağıdadır.' },
              { t: 'PC-nin MAC ünvanı unikaldırmı?', why: 'Eyni network-də ünvan işləyir, deməli MAC problemi yoxdur.' },
            ] },
            { q: '<p>Həll nədir?</p>', options: [
              { t: 'Gateway-i 192.168.1.1 etmək.', ok: true, why: 'Gateway router-in LAN interface-inin ünvanı olmalıdır.' },
              { t: 'Mask-ı 255.255.0.0 etmək.', why: 'Mask-ı dəyişmək gateway-in olmayan ünvanda olması problemini həll etmir.' },
              { t: 'Router interface-inin ünvanını .254 etmək, çünki PC-də belə yazılıb.', why: 'Əvvəl planı yoxlamaq lazımdır. Router interface-i dəyişsə, bütün digər PC-lər də pozular.' },
              { t: 'PC-ni yenidən başlatmaq.', why: 'Ayar səhv olduğu üçün yenidən başlatma onu dəyişmir.' },
            ] },
          ],
          after: '<p>Metod: gateway-i yoxla, ona ping at. Ping işləmirsə, ya gateway ayarı yanlışdır, ya router interface-i işləmir.</p>' },
        { id: 's7', title: 'show ip route oxu', type: 'form',
          pre: 'R1#show ip route\nC    192.168.1.0/24 is directly connected, GigabitEthernet0/0\nL    192.168.1.1/32 is directly connected, GigabitEthernet0/0\nC    172.16.40.0/26 is directly connected, GigabitEthernet0/1\nL    172.16.40.1/32 is directly connected, GigabitEthernet0/1',
          body: '<p>Yuxarıdakı routing table-a bax.</p>',
          fields: [
            { label: '172.16.40.20 ünvanına paket üçün çıxış interface-i', placeholder: 'məs. Gi0/0', check: r => /(gi|gigabitethernet)\s*0\/1$/i.test(String(r).trim()), show: 'GigabitEthernet0/1', wrong: '172.16.40.20 hansı network-dədir? 172.16.40.0/26 (0 – 63).' },
            { label: '192.168.1.99 ünvanı üçün çıxış interface-i', placeholder: 'məs. Gi0/0', check: r => /(gi|gigabitethernet)\s*0\/0$/i.test(String(r).trim()), show: 'GigabitEthernet0/0', wrong: '192.168.1.0/24 network-ü hansı interface-dədir?' },
            { label: '10.5.5.5 ünvanı üçün marşrut varmı? (bəli / xeyr)', placeholder: 'bəli / xeyr', answers: ['xeyr', 'yox', 'no'], wrong: 'Routing table-da yalnız iki connected network var.' },
          ],
          hints: ['Hər sətirdə C network-ü və interface-i göstərir.'],
          solution: '172.16.40.20 → Gi0/1, 192.168.1.99 → Gi0/0, 10.5.5.5 üçün marşrut yoxdur (router paketi atır).' },
        { id: 's8', title: 'Packet Tracer-də qur və yoxla', type: 'ptsteps',
          body: '<p>Bu addım yoxlamadır. Packet Tracer-də iki LAN-ı router ilə birləşdir.</p>',
          checks: [
            { t: 'Bir router (məs. 2911 və ya 4331 modeli), iki switch və hər switch-də bir PC qoy. PC1–Switch1–Router Gi0/0 və PC2–Switch2–Router Gi0/1 kabellərini çək (straight-through).' },
            { t: 'Router CLI-da: <span class="m">interface gi0/0</span>, <span class="m">ip address 192.168.1.1 255.255.255.0</span>, <span class="m">no shutdown</span>. Eyni qaydada Gi0/1 üçün <span class="m">192.168.2.1</span>.', cmd: ['interface gi0/0', 'ip address 192.168.1.1 255.255.255.0', 'no shutdown'] },
            { t: 'PC1: IP <span class="m">192.168.1.10</span>, mask <span class="m">255.255.255.0</span>, gateway <span class="m">192.168.1.1</span>. PC2: IP <span class="m">192.168.2.10</span>, gateway <span class="m">192.168.2.1</span> (Desktop → IP Configuration).' },
            { t: 'Router-də <span class="m">show ip route</span> və <span class="m">show ip interface brief</span> yaz. Sonra PC1-dən PC2-yə ping at. İlk paket itə bilər (ARP), qalanları uğurlu olmalıdır.', cmd: ['show ip route', 'show ip interface brief'] },
          ] },
        { id: 's9', title: 'Gördüyünü yaz', type: 'form',
          body: '<p>Router-də <span class="m">show ip route</span> yazanda neçə <b>C</b> (connected) sətri gördün?</p>',
          fields: [{ label: 'C sətirlərinin sayı', placeholder: 'rəqəm', check: r => String(r).trim() === '2', show: '2', wrong: 'Router-in neçə aktiv interface-i var?' }],
          solution: '2: hər aktiv interface üçün bir C sətri. Versiyada L sətirləri də ola bilər, onları sayma.' },
      ],
    },

    quiz: {
      draw: 8,
      gens: [
        /* which gateway is valid for this host */
        () => {
          const p = pick([24, 25, 26, 27]); const block = Math.pow(2, 32 - p); const base = block * R(256 / block);
          const b = pick(['192.168.10', '10.1.5', '172.16.3']); const hostN = base + 2 + R(block - 4);
          const hostIp = b + '.' + hostN; const info = A.info(hostIp, p);
          const good = info.first; const other = (base + block) % 256;
          const opts = [
            { t: info.first, ok: true, why: 'Bu ünvan ' + hostIp + '/' + p + ' ilə eyni subnet-dədir (' + info.net + ' – ' + info.bc + ') və host ünvanıdır.' },
            { t: info.bc, why: 'Bu subnet-in broadcast ünvanıdır, cihaza verilmir.' },
            { t: info.net, why: 'Bu subnet-in network ünvanıdır, cihaza verilmir.' },
            { t: b + '.' + (other + 1), why: 'Bu ünvan başqa subnet-dədir. Gateway host ilə eyni subnet-də olmalıdır.' },
          ];
          return { id: 'p2t1-g-gw', concept: 'gateway', obj: 'Düzgün gateway seçmək', _meta: { host: hostIp, p, ans: good },
            stem: '<p>PC: IP <span class="m">' + hostIp + '</span>, mask <span class="m">' + A.maskS(p) + '</span>. Router interface-i bu network-dədir. Hansı ünvan <b>default gateway</b> ola bilər?</p>',
            options: shuffle(opts) };
        },
      ],
      pool: [
        { id: 'p2t1-q1', concept: 'router-what', obj: 'Router və Layer',
          stem: '<p>Router paketi yönləndirəndə hansı məlumata görə qərar verir?</p>',
          options: [
            { t: 'Paketin Destination IP ünvanına və routing table-a.', ok: true, why: 'Router Layer 3 cihazıdır: Destination IP ilə routing table-da yol axtarır.' },
            { t: 'Frame-in Destination MAC ünvanına və MAC address table-a.', why: 'Bu switch-in işidir. Router MAC-i yalnız frame-i qəbul edəndə yoxlayır.' },
            { t: 'Paketin içindəki HTTP sorğusunun məzmununa.', why: 'Router Layer 3-ə qədər oxuyur, HTTP Layer 7-dədir.' },
            { t: 'Source port nömrəsinə.', why: 'Port nömrəsi Layer 4-dədir, adi router yönləndirmədə ona baxmır.' },
          ] },
        { id: 'p2t1-q2', concept: 'router-what', obj: 'Router paketi ötürəndə nə dəyişir',
          stem: '<p>Paket router-dən keçir. Router nəyi dəyişir?</p>',
          options: [
            { t: 'Yeni Ethernet header-i yazır və TTL-i 1 azaldır.', ok: true, why: 'MAC ünvanları hər link üçündür və dəyişir. Source və Destination IP əvvəldən sona eyni qalır.' },
            { t: 'Source və Destination IP-ni öz ünvanı ilə əvəz edir.', why: 'Adi routing zamanı IP ünvanları dəyişmir.' },
            { t: 'Heç nəyi dəyişmir, frame olduğu kimi keçir.', why: 'Bu switch-in davranışıdır. Router yeni header qurur və TTL azaldır.' },
            { t: 'Yalnız TTL-i dəyişir, MAC ünvanlarına toxunmur.', why: 'Frame yeni link-ə çıxır, ona görə yeni MAC ünvanları lazımdır.' },
          ] },
        { id: 'p2t1-q3', concept: 'router-what', obj: 'Router broadcast',
          stem: '<p>Router-in hər interface-i niyə ayrı network-də olur?</p>',
          options: [
            { t: 'Router network-ləri ayırır, hər interface bir broadcast domain sərhədidir.', ok: true, why: 'Router broadcast-ı ötürmür, hər interface ayrı broadcast domain yaradır.' },
            { t: 'İki interface eyni network-də olsa router işləmir, çünki IP ünvanı bitir.', why: 'Səbəb ünvan çatışmazlığı deyil, router-in iki ayrı network arasında yol seçməsidir.' },
            { t: 'Router yalnız bir network-ü tanıya bilir və ikincini qəbul etmir.', why: 'Router çox sayda network-ü tanıyır və onlar arasında paket ötürür.' },
            { t: 'Bu, DHCP server-in tələbidir və router-ə aid deyil.', why: 'DHCP burada iştirak etmir, network ayrılığı router-in məntiqidir.' },
          ] },
        { id: 'p2t1-q4', concept: 'gateway', obj: 'Gateway nə vaxt işlənir',
          stem: '<p>PC1 (192.168.1.10/24) hansı hədəfə paketi <b>gateway-ə</b> göndərir?</p>',
          options: [
            { t: '192.168.2.20', ok: true, why: 'Bu ünvan başqa network-dədir (192.168.2.0/24). PC1 paketi gateway-ə verir.' },
            { t: '192.168.1.200', why: 'Bu ünvan eyni network-dədir. Paket birbaşa göndərilir.' },
            { t: '192.168.1.1, router-in özü', why: 'Router PC1-in network-ündədir, birbaşa göndərilir (bu, gateway-in özüdür).' },
            { t: '192.168.1.255', why: 'Bu eyni network-ün broadcast ünvanıdır, gateway lazım deyil.' },
          ] },
        { id: 'p2t1-q5', concept: 'gateway', obj: 'Gateway frame-i',
          stem: '<p>PC1 192.168.2.20-yə paket göndərir. Gateway-ə gedən frame-də <b>Destination MAC</b> və <b>Destination IP</b> kimin ünvanıdır?</p>',
          options: [
            { t: 'MAC gateway-in, IP isə 192.168.2.20-nin ünvanıdır.', ok: true, why: 'MAC bu link-in hədəfini (gateway), IP isə son hədəfi göstərir.' },
            { t: 'Hər ikisi gateway-in ünvanıdır.', why: 'Destination IP son hədəfi göstərməlidir, yoxsa router paketi hara aparacağını bilməzdi.' },
            { t: 'Hər ikisi 192.168.2.20-nin ünvanıdır.', why: 'PC1 192.168.2.20-nin MAC-ini öyrənə bilməz, çünki o başqa network-dədir.' },
            { t: 'MAC 192.168.2.20-nin, IP isə gateway-in ünvanıdır.', why: 'Tərsinədir: MAC link üçün (gateway), IP son hədəf üçündür.' },
          ] },
        { id: 'p2t1-q6', concept: 'router-ifs', obj: 'Router interface default',
          stem: '<p>Router interface-inə IP verdin, amma <span class="m">show ip interface brief</span> <b>administratively down</b> göstərir. Səbəb nədir?</p>',
          options: [
            { t: 'Router interface-i default olaraq söndürülüdür.', ok: true, why: 'Router interface-ləri default shutdown vəziyyətindədir. no shutdown yazılana qədər aktiv olmur.' },
            { t: 'Kabel qırıqdır və link qurulmayıb.', why: 'Kabel problemi down/down verir, administratively down yox.' },
            { t: 'IP ünvanı mask-a uyğun deyil və interface rədd edilib.', why: 'Mask problemi interface statusuna təsir etmir.' },
            { t: 'Qarşı tərəfdəki switch söndürülüb.', why: 'Bu da down/down verərdi. Administratively down yalnız inzibati söndürmədir.' },
          ] },
        { id: 'p2t1-q7', concept: 'router-ifs', obj: 'Eyni network-də iki interface',
          stem: '<p>R1-in Gi0/0 interface-inə 192.168.1.1/24, Gi0/1-ə də 192.168.1.2/24 verdin. Nə baş verir?</p>',
          options: [
            { t: 'IOS ikinci ünvanı rədd edir, eyni network qəbul olunmur.', ok: true, why: 'Router hər interface üçün ayrı network gözləyir. Overlap xətası verir.' },
            { t: 'Hər ikisi işləyir və router yükü onlar arasında bölür.', why: 'Router bu şəkildə yük bölmür, eyni network iki interface-də qəbul olunmur.' },
            { t: 'İkinci interface avtomatik olaraq yenidən ad alır.', why: 'IOS ünvanı dəyişmir, xəta mesajı verir.' },
            { t: 'Yalnız Gi0/0 işləyir, Gi0/1 ping alır amma cavab vermir.', why: 'Konfiqurasiya qəbul edilmir, cavab verən interface yaranmır.' },
          ] },
        { id: 'p2t1-q8', concept: 'routing-table', obj: 'Connected network',
          stem: '<p>Routing table-da <b>C 192.168.2.0/24 is directly connected, Gi0/1</b> sətri nə deməkdir?</p>',
          options: [
            { t: 'Router bu network-ə Gi0/1 ilə birbaşa qoşuludur.', ok: true, why: 'C connected deməkdir. Interface aktivləşəndə bu sətir avtomatik yaranır.' },
            { t: 'Bu marşrutu administrator əllə yazıb və ya köçürüb.', why: 'Əllə yazılan marşrut S ilə göstərilir.' },
            { t: 'Router bu network-ü başqa router-dən öyrənib.', why: 'Dinamik protokol marşrutları başqa hərflə (məs. O) göstərilir.' },
            { t: 'Gi0/1 interface-i bu şəbəkənin gateway-idir.', why: 'Gateway PC-nin ayarıdır, routing table sətirinin mənası bu deyil.' },
          ] },
        { id: 'p2t1-q9', concept: 'routing-table', obj: 'Marşrutu olmayan network',
          stem: '<p>R1-də yalnız iki connected network var (192.168.1.0/24 və 192.168.2.0/24). PC 10.5.5.5-ə paket göndərir. Router nə edir?</p>',
          options: [
            { t: 'Marşrut tapa bilmir və paketi atır.', ok: true, why: 'Routing table-da 10.5.5.5 üçün yol yoxdur. Router paketi atır və adətən ICMP unreachable göndərir.' },
            { t: 'Paketi broadcast kimi bütün interface-lərə göndərir.', why: 'Router bilinməyən hədəf üçün broadcast etmir.' },
            { t: 'Paketi PC-yə geri qaytarır.', why: 'Router paketi geri qaytarmır.' },
            { t: 'Avtomatik olaraq internetə yol tapır.', why: 'Router yalnız routing table-da olan yollardan istifadə edir.' },
          ] },
        { id: 'p2t1-q10', concept: 'gw-mistakes', obj: 'Gateway simptomu',
          stem: '<p>PC kolleqalara və printerə çatır, amma başqa network-lərə çıxa bilmir. Hansı səbəb <b>uyğun gəlmir</b>?</p>',
          options: [
            { t: 'PC-nin IP ünvanı səhv yazılıb.', ok: true, why: 'Eyni network-ə çatması IP ünvanının işlədiyini göstərir. Switch IP-yə baxmır.' },
            { t: 'Gateway ünvanı səhv yazılıb və ya mövcud deyil.', why: 'Gateway səhvi məhz bu simptomu verir.' },
            { t: 'Router interface-i shutdown vəziyyətindədir.', why: 'Router interface-i işləməsə, gateway cavab vermir və başqa network-ə çıxış olmur.' },
            { t: 'Gateway PC-nin öz subnet-indən kənardadır.', why: 'PC gateway-ə çata bilmir, başqa network-ə çıxış olmur.' },
          ] },
        { id: 'p2t1-q11', concept: 'gw-mistakes', obj: 'Gateway diaqnozu',
          stem: '<p>"Internetə çıxa bilmirəm" şikayətində ilk iki yoxlama hansıdır?</p>',
          options: [
            { t: 'ipconfig ilə gateway-ə baxıb ona ping atmaq.', ok: true, why: 'Gateway-ə ping işləyirsə, PC ilə router arasındakı hissə qaydasındadır.' },
            { t: 'Browser-i silib yenidən quraşdırmaq.', why: 'Browser Layer 7-dir, problem çox vaxt daha aşağıdadır.' },
            { t: 'DNS server ünvanını başqa ilə dəyişmək.', why: 'DNS adlar üçündür, əvvəl IP ilə yolu yoxlamaq lazımdır.' },
            { t: 'Router-i heç nəyə baxmadan yenidən başlatmaq.', why: 'Səbəbi bilmədən yenidən başlatma başqa istifadəçiləri də kəsir.' },
          ] },
      ],
    },
  });
})();
