(function () {
  const pick = PT.pick; const R = PT.randInt; const shuffle = PT.shuffle;

  PT.topic({
    id: 'p2t4',
    objectives: [
      'DHCP relay-ə niyə ehtiyac olduğunu izah etmək',
      'Relay-in addımlarını və giaddr-in rolunu demək',
      'ip helper-address əmrini düzgün interface-də yazmaq',
      'Remote LAN-da ünvan alınmama səbəblərini simptomdan tapmaq',
    ],
    explain: PT.frag['p2/t04/explain'], cheat: PT.frag['p2/t04/cheat'],

    lab: {
      title: 'Lab 4: DHCP relay-i qur və problemi tap',
      goal: 'Relay prosesini sıralamaq, helper-address səhvini tapmaq, remote LAN-ın ünvan problemini həll etmək və Packet Tracer-də relay qurmaq.',
      why: 'Çox network-lü şirkətlərdə DHCP server mərkəzdədir. Remote şöbədə cihaz ünvan ala bilmirsə, ilk yoxlama relay-dir.',
      minutes: 35,
      finish: 'Relay-in necə işlədiyini və səhvini tapmağı bilirsən. İndi quizə keç.',
      steps: [
        { id: 's1', title: 'Hazırlıq', type: 'info', button: 'Başladım',
          body: '<p>Topologiya: client LAN <span class="m">192.168.10.0/24</span> – R1 (<span class="m">Gi0/0 = 192.168.10.1</span>, <span class="m">Gi0/1 = 10.0.0.1</span>) – server şəbəkəsi <span class="m">10.0.0.0/24</span>. DHCP server <span class="m">10.0.0.10</span> ünvanındadır.</p>' },
        { id: 's2', title: 'Relay sırası', type: 'order',
          body: '<p>Client ünvan alanda hadisələri sıra ilə düz.</p>',
          items: [
            { t: 'Client Discover broadcast göndərir', why: 'Client ünvansızdır və serveri axtarır.' },
            { t: 'R1 broadcast-ı alır və unicast edib 10.0.0.10-a ötürür, giaddr yazır', why: 'Relay client tərəfindəki interface-də işləyir.' },
            { t: 'Server giaddr-ə uyğun pool-dan ünvan seçir və Offer göndərir', why: 'giaddr client-in network-ünü göstərir.' },
            { t: 'R1 cavabı client-ə çatdırır', why: 'Client Offer-i alır, sonra Request və ACK keçir.' },
          ],
          hints: ['Relay broadcast-ı tutur, unicast edir, server isə pool seçir.'] },
        { id: 's3', title: 'Anlayışı rolu ilə birləşdir', type: 'match',
          body: '<p>Hər anlayış relay-də nə edir?</p>',
          pairs: [
            { l: '<span class="m">ip helper-address 10.0.0.10</span>', r: 'Broadcast-ı unicast edib serverə ötürür', why: 'Relay əmridir.' },
            { l: 'giaddr', r: 'Client tərəfindəki interface-in IP-si, serverə pool seçməyə kömək edir', why: 'Server hansı network-ə ünvan verdiyini bilir.' },
            { l: 'Remote pool', r: 'Server-də remote network üçün ayrılmış ünvan aralığı', why: 'Hər network üçün ayrı pool lazımdır.' },
            { l: 'Client tərəfindəki interface', r: 'helper-address yazılan interface', why: 'Broadcast ora gəlir.' },
          ],
          hints: ['Relay client broadcast-ını tutan yerdə işləyir.'] },
        { id: 's4', title: 'Konfiqurasiyada səhvi tap', type: 'spot',
          body: '<p>Remote LAN-dakı PC-lər ünvan almır. R1 konfiqurasiyasına bax. <b>Bir sətir səhvdir.</b></p>',
          lines: [
            { t: 'interface GigabitEthernet0/0' },
            { t: ' description Client LAN' },
            { t: ' ip address 192.168.10.1 255.255.255.0' },
            { t: 'interface GigabitEthernet0/1' },
            { t: ' description Server network' },
            { t: ' ip address 10.0.0.1 255.255.255.0' },
            { t: ' ip helper-address 10.0.0.10', bad: true, why: 'helper-address client tərəfindəki interface-ə (Gi0/0) yazılmalıdır, server tərəfindəki Gi0/1-ə yox. Client broadcast-ı Gi0/0-a gəlir.' },
          ],
          fix: { label: 'Hansı interface-də olmalıdır?', placeholder: 'məs. Gi0/1', answers: ['gi0/0', 'gigabitethernet0/0', 'g0/0'], wrong: 'Client broadcast-ı hansı interface-ə gəlir?' },
          hints: ['Broadcast client LAN-dan gəlir.'] },
        { id: 's5', title: 'Server tərəfində səhvi tap', type: 'spot',
          body: '<p>Relay düzgündür. Server-də (10.0.0.10) pool belədir. <b>Problemi tap.</b></p>',
          lines: [
            { t: 'ip dhcp pool SERVERNET' },
            { t: ' network 10.0.0.0 255.255.255.0' },
            { t: ' default-router 10.0.0.1' },
            { t: '! 192.168.10.0/24 üçün pool yoxdur', bad: true, why: 'Server giaddr-dən client-in 192.168.10.0/24 network-ündə olduğunu bilir, amma bu network üçün pool yoxdur. Ona görə ünvan verə bilmir.' },
          ],
          fix: { label: 'Hansı network üçün pool əlavə edirsən?', placeholder: 'a.b.c.d', answers: ['192.168.10.0', '192.168.10.0/24'], wrong: 'Remote LAN-ın network-ü.' },
          hints: ['Server yalnız öz network-ü üçün pool-a malikdir.'] },
        { id: 's6', title: 'Ticket: "Filial PC-ləri ünvan almır"', type: 'ticket',
          body: '<p><b>İstifadəçilər deyir:</b> "Filialdakı yeni PC-lər <span class="m">169.254.x.x</span> ünvanı alır. Mərkəzdəki PC-lər normal işləyir." Mərkəzi DHCP server 10.0.0.10-dadır, filial router-i R1-dir.</p>',
          stages: [
            { q: '<p>Mərkəz PC-ləri normal, filial PC-ləri APIPA alır. Bu nəyə işarədir?</p>', options: [
              { t: 'Server işləyir, problem filial LAN-ının serverə çatmasındadır (relay).', ok: true, why: 'Mərkəz PC-ləri ünvan alırsa server işləyir. Filialın broadcast-ı serverə çatmır.' },
              { t: 'DHCP server tamam sönüb.', why: 'Mərkəz PC-ləri ünvan alır.' },
              { t: 'Filial PC-lərinin MAC ünvanı səhvdir.', why: 'MAC DHCP-yə mane olmur.' },
              { t: 'DNS server yanlışdır.', why: 'DNS ünvan almağa təsir etmir.' },
            ] },
            { q: '<p>R1-də nəyi yoxlayırsan?</p>', options: [
              { t: 'Filial tərəfindəki interface-də ip helper-address 10.0.0.10 yazılıb?', ok: true, why: 'Relay olmadan broadcast router-dən keçmir.' },
              { t: 'Server tərəfindəki interface-də helper-address var?', why: 'Relay client tərəfində olmalıdır.' },
              { t: 'Router-də excluded-address var?', why: 'Excluded server-də yazılır.' },
              { t: 'Router-in hostname-i düzgündür?', why: 'Hostname DHCP-yə təsir etmir.' },
            ] },
            { q: '<p>helper-address var. Server-də hələ nəyi yoxlayırsan?</p>', options: [
              { t: 'Filial network-ü üçün pool və default-router var?', ok: true, why: 'Server giaddr-ə uyğun pool axtarır.' },
              { t: 'Server-in MAC ünvanı unikaldır?', why: 'Bu problem deyil.' },
              { t: 'Pool-un lease müddəti 1 gündür?', why: 'Lease müddəti ünvan almağa mane olmur.' },
              { t: 'Server-də web server işləyir?', why: 'Web xidməti DHCP ilə əlaqəli deyil.' },
            ] },
          ],
          after: '<p>Sıra: relay var mı → server pool-u var mı → server ilə router arasında yol var mı.</p>' },
        { id: 's7', title: 'Qərar: neçə pool?', type: 'form',
          body: '<p>Mərkəzi DHCP server 4 LAN-a xidmət edir: serverin öz LAN-ı və 3 remote LAN. Hər remote LAN-da relay var.</p>',
          fields: [
            { label: 'Server-də neçə pool lazımdır?', placeholder: 'rəqəm', check: r => String(r).trim() === '4', show: '4', wrong: 'Hər network üçün ayrı pool lazımdır, o cümlədən öz LAN-ı üçün.' },
            { label: 'Neçə router interface-ində ip helper-address yazılır?', placeholder: 'rəqəm', check: r => String(r).trim() === '3', show: '3', wrong: 'Yalnız remote LAN-lara baxan interface-lərdə.' },
          ],
          solution: '4 pool; 3 helper-address (hər remote LAN interface-ində).' },
        { id: 's8', title: 'Packet Tracer-də qur', type: 'ptsteps',
          body: '<p>Bu addım yoxlamadır. Bir router, iki switch, bir server və bir PC istifadə et.</p>',
          checks: [
            { t: 'Topologiya: PC – Switch1 – R1 Gi0/0 və R1 Gi0/1 – Switch2 – Server. R1 Gi0/0 = <span class="m">192.168.10.1/24</span>, Gi0/1 = <span class="m">10.0.0.1/24</span>. Server <span class="m">10.0.0.10</span>, gateway <span class="m">10.0.0.1</span>.' },
            { t: 'Server-də DHCP xidmətini aç (Server → Services → DHCP). Pool: default gateway <span class="m">192.168.10.1</span>, start IP <span class="m">192.168.10.50</span>, mask 255.255.255.0.' },
            { t: 'Əvvəlcə PC-də DHCP seç. Ünvan almamalıdır: relay hələ yoxdur (169.254 ünvanı görə bilərsən).' },
            { t: 'R1 Gi0/0-da <span class="m">ip helper-address 10.0.0.10</span> yaz. PC-də DHCP-ni yenidən seç. İndi ünvan gəlməlidir.', cmd: ['interface gi0/0', 'ip helper-address 10.0.0.10'] },
          ] },
      ],
    },

    quiz: {
      draw: 8,
      gens: [
        () => {
          const nets = shuffle([['192.168.10', 'LAN10'], ['192.168.20', 'LAN20'], ['172.16.5', 'LAN5'], ['10.50.1', 'LAN50']]).slice(0, 3);
          const c = pick(nets); const lastHost = pick([1, 254]);
          const giaddr = c[0] + '.' + lastHost;
          return { id: 'p2t4-g-pool', concept: 'relay-how', obj: 'giaddr və pool', _meta: { giaddr, ans: c[1] },
            stem: '<p>Mərkəzi DHCP server-də üç pool var: ' + nets.map(n => '<span class="m">' + n[1] + ' (' + n[0] + '.0/24)</span>').join(', ') + '. Relay paketdə giaddr = <span class="m">' + giaddr + '</span> yazıb. Server hansı pool-dan ünvan verəcək?</p>',
            options: shuffle(nets.map(n => ({ t: n[1] + ' (' + n[0] + '.0/24)', ok: n[1] === c[1], why: n[1] === c[1] ? 'giaddr ' + giaddr + ' bu pool-un network-ündədir.' : 'giaddr ' + giaddr + ' bu pool-un network-ündə deyil.' }))) };
        },
      ],
      pool: [
        { id: 'p2t4-q1', concept: 'relay-why', obj: 'Relay nə üçün',
          stem: '<p>DHCP server başqa network-dədir. Client-in Discover-i niyə serverə çatmır?</p>',
          options: [
            { t: 'Discover broadcast-dır, router isə broadcast ötürmür.', ok: true, why: 'Router interface-i broadcast domain-in sərhədidir.' },
            { t: 'Server UDP 67 portunu bağlayıb və Discover-i qəbul etmir.', why: 'Bu başqa problemdir. Burada paket router-də dayanır.' },
            { t: 'Client-in MAC ünvanı serverə tanış olmadığı üçün cavab yoxdur.', why: 'MAC DHCP-nin işləməsi üçün şərt deyil.' },
            { t: 'DHCP yalnız Layer 2 protocol-dur və router-dən keçmir.', why: 'DHCP Layer 7 protocol-udur, UDP ilə işləyir. Problem broadcast-ın router-dən keçməməsidir.' },
          ] },
        { id: 'p2t4-q2', concept: 'relay-why', obj: 'Relay nə edir',
          stem: '<p>DHCP relay (ip helper-address) nə edir?</p>',
          options: [
            { t: 'Client broadcast-ını unicast edib server-ə ötürür.', ok: true, why: 'Relay broadcast-ı serverin ünvanına unicast kimi göndərir.' },
            { t: 'Router-i özü DHCP server-ə çevirir.', why: 'Router DHCP server olmur, sorğunu ötürür.' },
            { t: 'Ünvanın lease müddətini avtomatik uzadır.', why: 'Lease müddəti server pool-undadır.' },
            { t: 'Client-in MAC ünvanını dəyişir.', why: 'Relay MAC ünvanına toxunmur.' },
          ] },
        { id: 'p2t4-q3', concept: 'relay-how', obj: 'giaddr',
          stem: '<p>giaddr sahəsi nə üçündür?</p>',
          options: [
            { t: 'Server client-in network-ünü bilir, uyğun pool-u seçir.', ok: true, why: 'giaddr relay-in client tərəfindəki IP-sidir.' },
            { t: 'Client server-in ünvanını bu sahədən öyrənir.', why: 'Client serverin ünvanını Offer-dən öyrənir.' },
            { t: 'Paketi şifrələyir ki, kənar şəxs oxuya bilməsin.', why: 'giaddr şifrələmə ilə əlaqəli deyil.' },
            { t: 'Ünvanın lease müddətini bu sahə təyin edir.', why: 'Lease server pool-undadır.' },
          ] },
        { id: 'p2t4-q4', concept: 'relay-how', obj: 'Unicast və broadcast',
          stem: '<p>Relay router-i Discover-i serverə hansı formada göndərir?</p>',
          options: [
            { t: 'Unicast, serverin IP ünvanına.', ok: true, why: 'Unicast paket router-lərdən keçə bilir.' },
            { t: 'Broadcast, 255.255.255.255-ə.', why: 'Broadcast router-dən keçməzdi.' },
            { t: 'Multicast, 224.0.0.5-ə.', why: 'Bu ünvan başqa məqsəd üçündür.' },
            { t: 'Heç göndərmir, serverə ping edir.', why: 'Relay DHCP mesajını ötürür.' },
          ] },
        { id: 'p2t4-q5', concept: 'relay-config', obj: 'Hansı interface',
          stem: '<p>Client LAN-ı Gi0/0-a, DHCP server şəbəkəsi Gi0/1-ə qoşulub. <span class="m">ip helper-address</span> hansı interface-də yazılır?</p>',
          options: [
            { t: 'Gi0/0, client-ə baxan interface-də.', ok: true, why: 'Client broadcast-ı bu interface-ə gəlir.' },
            { t: 'Gi0/1, serverə baxan interface-də.', why: 'Server tərəfində client broadcast-ı yoxdur.' },
            { t: 'Hər iki interface-də.', why: 'Server tərəfində lazım deyil.' },
            { t: 'Global config-də, interface-ə aid deyil.', why: 'Əmr interface rejimində yazılır.' },
          ] },
        { id: 'p2t4-q6', concept: 'relay-config', obj: 'Server tərəfi',
          stem: '<p>Relay işləyir, amma filial PC-lər yenə ünvan almır. Server-də hansı çatışmazlıq ola bilər?</p>',
          options: [
            { t: 'Filial network-ü üçün pool yoxdur.', ok: true, why: 'Server giaddr-ə uyğun pool tapmasa, ünvan verə bilmir.' },
            { t: 'Pool-da lease müddəti çox qısadır.', why: 'Qısa lease ünvan almağa mane olmur.' },
            { t: 'Server hostname-i həddindən artıq uzundur.', why: 'Hostname uzunluğu DHCP-yə təsir etmir.' },
            { t: 'Server UDP 68 portunu dinləmir.', why: 'Server 67-ni dinləyir, 68 client portudur.' },
          ] },
        { id: 'p2t4-q7', concept: 'relay-config', obj: 'Server ilə bağlantı',
          stem: '<p>Relay router-dən DHCP server-ə ping işləmir. Nə olacaq?</p>',
          options: [
            { t: 'Relay işləməyə bilər: unicast serverə çatmır və ya cavab qayıda bilmir.', ok: true, why: 'Relay serverə IP bağlantısı tələb edir.' },
            { t: 'Heç nə dəyişmir, relay serverin əlçatanlığından asılı deyil.', why: 'Server ilə yol olmasa relay işləməz.' },
            { t: 'Client avtomatik olaraq statik ünvan alır.', why: 'Statik ünvan əllə yazılır.' },
            { t: 'Router özü DHCP server rolunu üzərinə götürür və nəticə həmişə eynidir.', why: 'Router avtomatik server olmur.' },
          ] },
        { id: 'p2t4-q8', concept: 'relay-trouble', obj: 'Tək LAN-da problem',
          stem: '<p>Yalnız filial LAN-ında ünvan alınmır, mərkəz LAN-ında alınır. İlk yoxlama?</p>',
          options: [
            { t: 'Filial router interface-ində ip helper-address.', ok: true, why: 'Mərkəz işləyirsə server işləyir. Filial üçün relay lazımdır.' },
            { t: 'Mərkəzdəki PC-lərin kabelləri və bu normal sayılır.', why: 'Mərkəz normal işləyir.' },
            { t: 'Mərkəzdəki DNS server ünvanı.', why: 'DNS ünvan almağa təsir etmir.' },
            { t: 'Mərkəz server-in kabeli və portu və bu normal sayılır.', why: 'Server mərkəzdə ünvan verir, deməli işləyir.' },
          ] },
        { id: 'p2t4-q9', concept: 'relay-trouble', obj: 'Pool sayı',
          stem: '<p>Bir DHCP server 5 fərqli network-ə (öz network-ü + 4 remote) xidmət edir. Neçə pool lazımdır?</p>',
          options: [
            { t: '5, hər network üçün bir pool.', ok: true, why: 'Server hər network üçün ayrı ünvan aralığı paylayır.' },
            { t: '1, pool-lar avtomatik yaranır.', why: 'Pool-ları administrator yaratmalıdır.' },
            { t: '4, öz network-ü pool tələb etmir.', why: 'Öz network-ündəki clients üçün də pool lazımdır.' },
            { t: '10, hər network üçün iki.', why: 'İkiqat pool tələb olunmur.' },
          ] },
      ],
    },
  });
})();
