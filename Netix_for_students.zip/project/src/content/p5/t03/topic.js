(function () {
  const A = PT.addr; const pick = PT.pick; const R = PT.randInt; const shuffle = PT.shuffle;
  const norm = s => String(s).trim().toLowerCase().replace(/\s+/g, ' ');
  const wc = mask => mask.split('.').map(o => 255 - +o).join('.');
  const ipN = s => s.split('.').reduce((a, o) => a * 256 + +o, 0);

  PT.topic({
    id: 'p5t3',
    objectives: [
      'OSPF-in link-state prinsipini və LSDB/SPF anlayışlarını izah etmək',
      'Interface və yol cost-unu hesablamaq',
      'Qonşuluq şərtlərini, hallarını və DR/BDR seçimini demək',
      'Router ID-nin seçilmə qaydasını bilmək',
      'OSPF konfiqurasiyasını yazmaq və show əmrləri ilə yoxlamaq',
      'OSPF qonşuluq problemlərini simptomdan tapmaq',
    ],
    explain: PT.frag['p5/t03/explain'], cheat: PT.frag['p5/t03/cheat'],

    lab: {
      title: 'Lab 3: OSPF qur, qonşuluğu və cost-u oxu',
      goal: 'OSPF anlayışlarını bilmək, cost hesablamaq, DR seçimini müəyyən etmək, konfiqurasiya və show çıxışında səhv tapmaq, ticket həll etmək və Packet Tracer-də OSPF qurmaq.',
      why: 'Orta və böyük şəbəkələrdə marşrutlar OSPF kimi protocol-larla idarə olunur. Qonşuluq problemləri həll etmək əsas bacarıqdır.',
      minutes: 70,
      finish: 'OSPF-i qura və qonşuluq problemini tapa bilirsən. İndi quizə keç.',
      steps: [
        { id: 's1', title: 'Hazırlıq', type: 'info', button: 'Başladım',
          body: '<p>Ssenari: üç router xətt şəklində: R1 – R2 – R3. R1–R2 link-i <span class="m">10.0.12.0/30</span>, R2–R3 link-i <span class="m">10.0.23.0/30</span>. R1-in LAN-ı <span class="m">192.168.1.0/24</span>, R3-ün LAN-ı <span class="m">192.168.3.0/24</span>. Bütün link-lər FastEthernet (cost 1).</p>' },
        { id: 's2', title: 'Anlayışı mənası ilə birləşdir', type: 'match',
          body: '<p>Hər anlayış nə deməkdir?</p>',
          pairs: [
            { l: 'LSA', r: 'Router-in link məlumatını bildirən mesaj', why: 'Link-State Advertisement.' },
            { l: 'LSDB', r: 'Router-in topladığı LSA-lar bazası: şəbəkənin xəritəsi', why: 'Eyni area-dakı router-lərdə eynidir.' },
            { l: 'SPF', r: 'LSDB üzərində ən qısa yolu hesablayan alqoritm', why: 'Hər router öz yolunu hesablayır.' },
            { l: 'Hello', r: 'Qonşu tapan və əlaqəni yoxlayan mesaj', why: '10 saniyədən bir.' },
            { l: 'Router ID', r: 'OSPF router-ini unikal tanıyan IP formatlı nömrə', why: 'Əl ilə, loopback və ya interface IP-dən seçilir.' },
            { l: 'DR', r: 'Multi-access şəbəkədə update-ləri toplayan router', why: 'Priority, sonra router ID ilə seçilir.' },
          ],
          hints: ['LSDB xəritədir, SPF isə yol hesablayır.'] },
        { id: 's3', title: 'Cost hesabla', type: 'form',
          body: '<p>Default reference bandwidth 100 Mbps-dır. Cost = 100 Mbps / interface bandwidth (minimum 1).</p>',
          fields: [
            { label: '10 Mbps interface-in cost-u', placeholder: 'rəqəm', check: r => String(r).trim() === '10', show: '10', wrong: '100 / 10 = 10.' },
            { label: '100 Mbps interface-in cost-u', placeholder: 'rəqəm', check: r => String(r).trim() === '1', show: '1', wrong: '100 / 100 = 1.' },
            { label: '1 Gbps interface-in cost-u (default reference ilə)', placeholder: 'rəqəm', check: r => String(r).trim() === '1', show: '1', wrong: '100 / 1000 = 0,1 → minimum 1.' },
            { label: 'R1 → R2 → R3 yolunda iki FastEthernet link-in ümumi cost-u (hər link cost 1)', placeholder: 'rəqəm', check: r => String(r).trim() === '2', show: '2', wrong: '1 + 1 = 2.' },
          ],
          hints: ['Cost-lar toplanır.'],
          solution: '10; 1; 1; 2.' },
        { id: 's4', title: 'DR seçimi', type: 'form',
          body: '<p>Bir switch-ə üç router qoşulub. Priority (default 1) və router ID-lər belədir: R1 priority 1, ID 3.3.3.3; R2 priority 1, ID 2.2.2.2; R3 priority 1, ID 1.1.1.1. Hamısı eyni anda açılıb.</p>',
          fields: [
            { label: 'DR kim olur?', placeholder: 'R1 / R2 / R3', answers: ['r1'], wrong: 'Priority bərabərdir. Router ID-si ən yüksək olan DR olur.' },
            { label: 'BDR kim olur?', placeholder: 'R1 / R2 / R3', answers: ['r2'], wrong: 'İkinci ən yüksək router ID.' },
            { label: 'R3-ün R2 ilə qonşuluq vəziyyəti', placeholder: 'FULL / 2-WAY', answers: ['2-way', '2way', 'two-way'], wrong: 'DROTHER-lər bir-biri ilə 2-Way qalır.' },
          ],
          hints: ['Əvvəl priority, bərabər olsa ən yüksək router ID.'],
          solution: 'DR R1 (3.3.3.3); BDR R2; R3–R2 qonşuluğu 2-Way.' },
        { id: 's5', title: 'Router ID-ni müəyyən et', type: 'form',
          body: '<p>Router-də interface-lər: Gi0/0 <span class="m">192.168.1.1</span>, Gi0/1 <span class="m">10.0.12.1</span>, Loopback0 <span class="m">172.16.0.1</span>. Router-id əmri yazılmayıb.</p>',
          fields: [
            { label: 'Router ID nə olur?', placeholder: 'a.b.c.d', check: r => String(r).trim() === '172.16.0.1', show: '172.16.0.1', wrong: 'Loopback varsa onun ünvanı seçilir.' },
            { label: 'Loopback silinsə (router yenidən başlasa) router ID nə olar?', placeholder: 'a.b.c.d', check: r => String(r).trim() === '192.168.1.1', show: '192.168.1.1', wrong: 'Ən yüksək aktiv interface ünvanı: 192.168.1.1 > 10.0.12.1.' },
          ],
          hints: ['Loopback → ən yüksək aktiv interface ünvanı.'],
          solution: '172.16.0.1; 192.168.1.1.' },
        { id: 's6', title: 'Konfiqurasiyada səhvi tap', type: 'spot',
          body: '<p>R2 R3 ilə qonşu ola bilmir. R2 və R3-ün konfiqurasiyası belədir. <b>Problemi göstərən sətri tap.</b></p>',
          lines: [
            { t: 'R2: network 10.0.23.0 0.0.0.3 area 0' },
            { t: 'R3: network 10.0.23.0 0.0.0.3 area 1', bad: true, why: 'R3 bu link-i area 1-də elan edir, R2 isə area 0-da. Qonşuluq üçün area nömrəsi eyni olmalıdır.' },
          ],
          fix: { label: 'R3-də area nə olmalıdır?', placeholder: 'rəqəm', answers: ['0'], wrong: 'İki ucda area eyni olmalıdır.' },
          hints: ['Area uyğunsuzluğu qonşuluğu bloklayır.'] },
        { id: 's7', title: 'Wildcard səhvini tap', type: 'spot',
          body: '<p>R1-in LAN-ı <span class="m">192.168.1.0/24</span> OSPF-də elan olunmur, uzaq router-lər onu görmür. <b>Problemi tap.</b></p>',
          lines: [
            { t: 'router ospf 1' },
            { t: ' network 10.0.12.0 0.0.0.3 area 0' },
            { t: ' network 192.168.1.0 255.255.255.0 area 0', bad: true, why: 'network əmrində subnet mask yox, wildcard mask yazılır: /24 üçün 0.0.0.255.' },
          ],
          fix: { label: 'Düzgün wildcard', placeholder: 'a.b.c.d', answers: ['0.0.0.255'], wrong: '/24 üçün wildcard 0.0.0.255.' },
          hints: ['OSPF network əmri ACL kimi wildcard istəyir.'] },
        { id: 's8', title: 'show ip ospf neighbor oxu', type: 'form',
          pre: 'R2#show ip ospf neighbor\nNeighbor ID     Pri   State     Dead Time   Address        Interface\n1.1.1.1           0   FULL/-    00:00:33    10.0.12.1      Gi0/0\n3.3.3.3           0   INIT/-    00:00:38    10.0.23.2      Gi0/1',
          body: '<p>Çıxışa bax.</p>',
          fields: [
            { label: 'R1 ilə qonşuluq düzgündür? (bəli / xeyr)', placeholder: 'bəli / xeyr', answers: ['bəli', 'beli', 'yes'], wrong: 'FULL son vəziyyətdir.' },
            { label: 'R3 ilə qonşuluğun problemi? (INIT nə deməkdir)', placeholder: 'qısa cavab', check: r => /hello|bir istiqamət|qarşı|görmür/i.test(String(r)), show: 'R2 R3-ün Hello-sunu alır, R3 isə R2-ni görmür (bir istiqamətli əlaqə)', wrong: 'Init: Hello alındı, amma qarşı tərəf bizi qonşu kimi görmür.' },
            { label: 'R2 hansı interface-dən R3-ü görür?', placeholder: 'interface', answers: ['gi0/1', 'gigabitethernet0/1'], wrong: 'Interface sütununa bax.' },
          ],
          hints: ['INIT bir istiqamətli Hello deməkdir.'],
          solution: 'Bəli; Init: bir istiqamətli Hello (qarşı tərəf R2-ni görmür); Gi0/1.' },
        { id: 's9', title: 'Ticket: "Qonşuluq qurulmur"', type: 'ticket',
          body: '<p><b>Mühəndis deyir:</b> "R1 və R2 arasında OSPF qonşuluğu qurulmur. <span class="m">show ip ospf neighbor</span> boşdur. İki router birbaşa bağlıdır, ping işləyir."</p>',
          stages: [
            { q: '<p>İlk addım?</p>', options: [
              { t: 'İki router-də show ip ospf interface ilə area, hello/dead timer və mask-ı müqayisə etmək.', ok: true, why: 'Qonşuluq üçün bu parametrlər eyni olmalıdır.' },
              { t: 'Router-ləri yenidən başlatmaq.', why: 'Konfiqurasiya səhvini yenidən başlatma düzəltmir.' },
              { t: 'PC-lərin DNS ayarını yoxlamaq.', why: 'DNS bu problemə aid deyil.' },
              { t: 'Switch VLAN-larına baxmaq.', why: 'Burada router-lər birbaşa bağlıdır.' },
            ] },
            { q: '<p>Müqayisə göstərir: R1 hello 10, dead 40; R2 hello 5, dead 20. Nəticə?</p>', options: [
              { t: 'Timer-lər uyğun deyil, qonşuluq qurulmur.', ok: true, why: 'Hello və dead interval iki ucda eyni olmalıdır.' },
              { t: 'Timer fərqi OSPF üçün problem deyil.', why: 'Fərqli timer qonşuluğu bloklayır.' },
              { t: 'Qonşuluq qurulur, amma yavaş.', why: 'Uyğunsuzluq qonşuluq qurulmasına imkan vermir.' },
              { t: 'Router ID fərqlidir deyə problem var.', why: 'Router ID fərqli olmalıdır.' },
            ] },
            { q: '<p>Düzəliş?</p>', options: [
              { t: 'R2 interface-ində ip ospf hello-interval 10 və dead-interval 40 yazmaq (və ya default qaytarmaq).', ok: true, why: 'Timer-lər uyğunlaşdırılır.' },
              { t: 'Hər iki router-də router-id-ni silmək.', why: 'Router ID problem deyil.' },
              { t: 'R1-də area-nı dəyişmək.', why: 'Area problem deyil, timer fərqlidir.' },
              { t: 'Link-i kəsmək.', why: 'Link işləyir, kəsmək yardım etmir.' },
            ] },
          ],
          after: '<p>Qonşuluq problemi: area, subnet/mask, timer-lər, router ID və autentifikasiya.</p>' },
        { id: 's10', title: 'OSPF-i özün yaz', type: 'form',
          body: '<p>R3: Gi0/0 <span class="m">192.168.3.1/24</span> (LAN), Gi0/1 <span class="m">10.0.23.2/30</span>. Router ID 3.3.3.3, hər şey area 0.</p>',
          fields: [
            { label: 'Router ID əmri', placeholder: 'əmr', check: r => norm(r) === 'router-id 3.3.3.3', show: 'router-id 3.3.3.3', wrong: 'router-id <ip>' },
            { label: 'LAN-ı OSPF-ə daxil edən əmr', placeholder: 'əmr', check: r => norm(r) === 'network 192.168.3.0 0.0.0.255 area 0', show: 'network 192.168.3.0 0.0.0.255 area 0', wrong: 'network <ünvan> <wildcard> area 0' },
            { label: 'R2 ilə link-i daxil edən əmr', placeholder: 'əmr', check: r => norm(r) === 'network 10.0.23.0 0.0.0.3 area 0', show: 'network 10.0.23.0 0.0.0.3 area 0', wrong: '/30 üçün wildcard 0.0.0.3.' },
            { label: 'LAN interface-ində Hello-nu dayandıran əmr', placeholder: 'əmr', check: r => norm(r) === 'passive-interface gi0/0' || norm(r) === 'passive-interface gigabitethernet0/0', show: 'passive-interface gi0/0', wrong: 'passive-interface <interface>' },
          ],
          solution: 'router-id 3.3.3.3; network 192.168.3.0 0.0.0.255 area 0; network 10.0.23.0 0.0.0.3 area 0; passive-interface gi0/0.' },
        { id: 's11', title: 'Packet Tracer-də qur', type: 'ptsteps',
          body: '<p>Üç router, hər LAN-da bir PC. R1–R2–R3 xətti.</p>',
          checks: [
            { t: 'Ünvanları ver: R1 LAN <span class="m">192.168.1.1/24</span>, R1–R2 <span class="m">10.0.12.1/30</span> və <span class="m">10.0.12.2/30</span>, R2–R3 <span class="m">10.0.23.1/30</span> və <span class="m">10.0.23.2/30</span>, R3 LAN <span class="m">192.168.3.1/24</span>. PC gateway-lərini yaz. Hər interface-də <span class="m">no shutdown</span>.' },
            { t: 'Hələ marşrut yoxdur: PC1-dən PC3-ə ping et. İşləməməlidir.' },
            { t: 'Hər router-də OSPF qur: <span class="m">router ospf 1</span>, <span class="m">router-id</span>, <span class="m">network</span> əmrləri (qoşulu olduğu bütün network-lər), LAN interface-lərində <span class="m">passive-interface</span>.', cmd: ['router ospf 1', 'router-id 1.1.1.1', 'network 192.168.1.0 0.0.0.255 area 0', 'network 10.0.12.0 0.0.0.3 area 0', 'passive-interface gi0/0'] },
            { t: '<span class="m">show ip ospf neighbor</span> yaz: FULL qonşular görünməlidir. <span class="m">show ip route ospf</span> yaz: O marşrutları.', cmd: ['show ip ospf neighbor', 'show ip route ospf'] },
            { t: 'PC1 → PC3 ping et: işləməlidir. R1-də <span class="m">show ip route</span> yaz və cost-u (<span class="m">[110/..]</span>) yaz.', cmd: ['show ip route'] },
            { t: 'R2–R3 link-ini çıxar (və ya shutdown et). OSPF marşrutunun itdiyini və geri qoşanda bərpa olunduğunu izlə.' },
          ] },
        { id: 's12', title: 'Gördüyünü yaz', type: 'form',
          body: '<p>R1-də <span class="m">show ip route ospf</span> yazdın.</p>',
          fields: [
            { label: 'R3-ün LAN-ı (192.168.3.0/24) üçün marşrutun AD/cost göstəricisi', placeholder: '[110/..]', check: r => /110\s*\/\s*\d+/.test(String(r)), show: '[110/3] (versiyadan asılı olaraq fərqli ola bilər)', wrong: 'AD 110, cost-u isə yolun cəmidir.' },
            { label: 'Marşrut kodu', placeholder: 'kod', answers: ['o'], wrong: 'OSPF marşrutları O ilə göstərilir.' },
          ],
          solution: '[110/3] və ya buna bənzər; kod O.' },
      ],
    },

    quiz: {
      draw: 8,
      gens: [
        () => {
          const refs = [100, 1000]; const ref = pick(refs); const bws = [10, 100, 1000, 10000]; const bw = pick(bws);
          const cost = Math.max(1, Math.floor(ref / bw));
          return { id: 'p5t3-g-cost', concept: 'ospf-cost', obj: 'Interface cost', type: 'num', _meta: { ref, bw, cost },
            stem: '<p>OSPF reference bandwidth <b>' + ref + ' Mbps</b>-dir. <b>' + bw + ' Mbps</b> interface-in cost-u neçədir? (cost = reference / bandwidth, minimum 1)</p>', placeholder: 'rəqəm',
            check: r => String(r).trim() === String(cost),
            solution: ref + ' / ' + bw + ' = ' + (ref / bw) + (ref / bw < 1 ? ', minimum 1-ə yuvarlanır' : '') + '. Cavab: <b>' + cost + '</b>.' };
        },
        () => {
          const p = pick([24, 25, 26, 27, 28, 29, 30]); const net = pick(['192.168.1', '10.0.12', '172.16.5']);
          const mask = A.maskS(p); const ans = wc(mask); const base = Math.floor(R(256) / Math.pow(2, 32 - p)) * Math.pow(2, 32 - p);
          const ip = net + '.' + (p === 24 ? 0 : base);
          const opts = [ans, mask, wc(A.maskS(p === 30 ? 24 : p + 1)), wc(A.maskS(p === 24 ? 25 : p - 1))].filter((v, i, a) => a.indexOf(v) === i);
          while (opts.length < 4) opts.push('0.0.0.' + (R(250) + 1));
          return { id: 'p5t3-g-net', concept: 'ospf-config', obj: 'network wildcard', _meta: { p, ans },
            stem: '<p>OSPF-də <span class="m">' + ip + '/' + p + '</span> network-ünü elan etmək üçün <span class="m">network ' + ip + ' ??? area 0</span> əmrində hansı wildcard mask yazılır?</p>',
            options: shuffle(opts.slice(0, 4).map(o => ({ t: o, ok: o === ans, why: o === ans ? '/' + p + ' üçün wildcard = 255.255.255.255 − ' + mask + ' = ' + ans + '.' : (o === mask ? 'Bu subnet mask-dır. OSPF network əmri wildcard istəyir.' : 'Bu wildcard /' + p + ' ilə uyğun gəlmir.') }))) };
        },
        () => {
          const ids = ['1.1.1.1', '2.2.2.2', '3.3.3.3', '10.0.0.5', '192.168.1.1'];
          const rs = shuffle(ids).slice(0, 3).map((id, i) => ({ n: 'R' + (i + 1), id, pr: pick([1, 1, 1, 100]) }));
          const best = rs.slice().sort((a, b) => (b.pr - a.pr) || (ipN(b.id) - ipN(a.id)))[0];
          return { id: 'p5t3-g-dr', concept: 'dr-bdr', obj: 'DR seçimi', _meta: { ans: best.n },
            stem: '<p>Eyni switch-ə qoşulan üç OSPF router-i eyni anda açılır:<br>' + rs.map(r => r.n + ': priority ' + r.pr + ', router ID ' + r.id).join('<br>') + '</p><p>DR kim olur?</p>',
            options: rs.map(r => ({ t: r.n, ok: r === best, why: r === best ? 'Ən yüksək priority, bərabər olsa ən yüksək router ID qalib olur. ' + r.n + ' bu şərtə uyğundur.' : r.n + ' daha aşağı priority və ya router ID-yə malikdir.' })) };
        },
      ],
      pool: [
        { id: 'p5t3-q1', concept: 'ospf-why', obj: 'OSPF nədir',
          stem: '<p>OSPF hansı tip protocol-dur?</p>',
          options: [
            { t: 'Link-state dynamic routing protocol.', ok: true, why: 'Hər router link vəziyyətini yayır, hamı eyni xəritəni qurur.' },
            { t: 'Switch-lər üçün loop protection protocol-u.', why: 'Bu STP-dir.' },
            { t: 'IP ünvanı verən protocol.', why: 'Bu DHCP-dir.' },
            { t: 'Adı IP-yə çevirən protocol.', why: 'Bu DNS-dir.' },
          ] },
        { id: 'p5t3-q2', concept: 'ospf-why', obj: 'Static ilə fərq',
          stem: '<p>OSPF static routing-dən nə ilə üstündür?</p>',
          options: [
            { t: 'Link qırılanda marşrutlar avtomatik yenilənir.', ok: true, why: 'Router-lər dəyişiklikləri bir-birinə bildirir.' },
            { t: 'Router-ə heç bir ayar yazmaq lazım deyil.', why: 'OSPF-i də qurmaq lazımdır.' },
            { t: 'OSPF həmişə daha yavaşdır, amma daha təhlükəsizdir.', why: 'OSPF bu mənada daha təhlükəsiz deyil.' },
            { t: 'OSPF yalnız iki router arasında işləyir.', why: 'OSPF çoxlu router üçündür.' },
          ] },
        { id: 'p5t3-q3', concept: 'ospf-how', obj: 'LSDB və SPF',
          stem: '<p>OSPF-də hər router ən qısa yolu necə tapır?</p>',
          options: [
            { t: 'LSDB-dəki xəritə üzərində SPF alqoritmini işlədir.', ok: true, why: 'Hər router öz yolunu hesablayır.' },
            { t: 'Qonşusundan hazır marşrut cədvəlini kopyalayır.', why: 'OSPF cədvəl yox, link məlumatı yayır.' },
            { t: 'Ping ilə hər yolu ayrı-ayrılıqda sınayır.', why: 'OSPF ping işlətmir.' },
            { t: 'Administrator hər yolu əl ilə seçib yazır.', why: 'Bu static routing-dir.' },
          ] },
        { id: 'p5t3-q4', concept: 'ospf-how', obj: 'Marşrut kodu',
          stem: '<p>Routing table-da OSPF marşrutu hansı kodla göstərilir və AD-si nədir?</p>',
          options: [
            { t: 'O, AD 110.', ok: true, why: 'OSPF üçün default AD 110-dur.' },
            { t: 'S, AD 1 (static).', why: 'Bu static marşrutdur.' },
            { t: 'C, AD 0 (connected).', why: 'Bu connected-dir.' },
            { t: 'O, AD 1 (static kimi).', why: 'Kod doğrudur, amma OSPF-in AD-si 110-dur.' },
          ] },
        { id: 'p5t3-q5', concept: 'ospf-cost', obj: 'Gigabit cost',
          stem: '<p>Default reference bandwidth (100 Mbps) ilə FastEthernet və Gigabit interface-lərin cost-u nə olur?</p>',
          options: [
            { t: 'İkisi də 1: OSPF onları ayırd edə bilmir.', ok: true, why: '100/1000 = 0,1 → 1-ə yuvarlanır.' },
            { t: 'FastEthernet 1, Gigabit isə 0,1 olur.', why: 'Cost minimum 1-dir.' },
            { t: 'FastEthernet 10, Gigabit isə 1 olur.', why: 'Bu 100 Mbps üçün 10 olmazdı.' },
            { t: 'Hər ikisi 100 olur və fərqlənmir.', why: 'Cost reference-i bandwidth-ə bölməklə alınır.' },
          ] },
        { id: 'p5t3-q6', concept: 'ospf-cost', obj: 'Yol cost-u',
          stem: '<p>Yol iki link-dən keçir: cost-ları 1 və 64. Ümumi yol cost-u?</p>',
          options: [
            { t: '65', ok: true, why: 'Çıxış interface cost-ları toplanır.' },
            { t: '64', why: 'Birinci link də hesaba qatılır.' },
            { t: '1', why: 'Yalnız birinci link götürülüb.' },
            { t: '64 × 1', why: 'Cost-lar toplanır, vurulmur.' },
          ] },
        { id: 'p5t3-q7', concept: 'ospf-neighbors', obj: 'Qonşuluq şərti',
          stem: '<p>Hansı fərq iki OSPF router-in qonşu olmasına <b>mane olmur</b>?</p>',
          options: [
            { t: 'Fərqli router ID.', ok: true, why: 'Router ID fərqli olmalıdır, eyni olsa problem yaranır.' },
            { t: 'Fərqli area.', why: 'Area eyni olmalıdır.' },
            { t: 'Fərqli hello/dead timer.', why: 'Timer-lər uyğun olmalıdır.' },
            { t: 'Fərqli subnet.', why: 'Eyni subnet-də olmalıdırlar.' },
          ] },
        { id: 'p5t3-q8', concept: 'ospf-neighbors', obj: 'Full',
          stem: '<p>Normal və tam qonşuluğun vəziyyəti hansıdır?</p>',
          options: [
            { t: 'FULL.', ok: true, why: 'LSDB-lər sinxronlaşıb.' },
            { t: 'INIT.', why: 'Init Hello-nun bir istiqamətdə alınması deməkdir.' },
            { t: 'DOWN.', why: 'Down əlaqə yoxdur.' },
            { t: 'EXSTART.', why: 'ExStart başlanğıc mərhələdir.' },
          ] },
        { id: 'p5t3-q9', concept: 'ospf-neighbors', obj: 'Hello timer',
          stem: '<p>Broadcast link-də default Hello və dead interval?</p>',
          options: [
            { t: 'Hello 10 saniyə, dead 40 saniyə.', ok: true, why: 'Dead interval Hello-nun 4 mislidir.' },
            { t: 'Hello 40 saniyə, dead 10 saniyə.', why: 'Tərsinə yazılıb.' },
            { t: 'Hello 5 saniyə, dead 10 saniyə.', why: 'Bu default deyil.' },
            { t: 'Hello 30 saniyə, dead 120 saniyə.', why: 'Bu başqa link növlərinə aiddir.' },
          ] },
        { id: 'p5t3-q10', concept: 'dr-bdr', obj: 'DROTHER',
          stem: '<p>Multi-access şəbəkədə iki DROTHER router bir-biri ilə hansı vəziyyətdə qalır?</p>',
          options: [
            { t: '2-Way, bu normaldır.', ok: true, why: 'Onlar yalnız DR və BDR ilə FULL olur.' },
            { t: 'FULL: tam qonşuluq qurulur.', why: 'DROTHER-lər arasında FULL olmur.' },
            { t: 'DOWN: əlaqə yoxdur.', why: 'Qonşu görünürlər.' },
            { t: 'INIT: birtərəfli Hello.', why: 'Init problem hesab olunur, 2-Way normaldır.' },
          ] },
        { id: 'p5t3-q11', concept: 'router-id', obj: 'Router ID qaydası',
          stem: '<p>Router ID əl ilə yazılmayıb, router-də loopback və bir neçə fiziki interface var. Router ID necə seçilir?</p>',
          options: [
            { t: 'Ən yüksək loopback ünvanı, yoxdursa ən yüksək aktiv interface ünvanı.', ok: true, why: 'Bu OSPF-in qaydasıdır.' },
            { t: 'Ən kiçik interface ünvanı götürülür və istifadə olunur və bu normal sayılır.', why: 'Ən yüksək ünvan götürülür.' },
            { t: 'Router-in hostname-i router ID kimi istifadə olunur və bu normal sayılır.', why: 'Router ID IP formatındadır.' },
            { t: 'Qonşu router router ID-ni özü seçib təyin edir.', why: 'Router ID yerli seçilir.' },
          ] },
        { id: 'p5t3-q12', concept: 'ospf-config', obj: 'Process ID',
          stem: '<p>R1-də <span class="m">router ospf 1</span>, R2-də <span class="m">router ospf 10</span> yazılıb. OSPF qonşuluğu qurulurmu?</p>',
          options: [
            { t: 'Bəli, process ID yerlidir.', ok: true, why: 'Qonşuluq area, timer, subnet kimi parametrlərdən asılıdır.' },
            { t: 'Xeyr, process ID eyni olmalıdır.', why: 'Process ID router-lər arasında bölüşdürülmür.' },
            { t: 'Xeyr, 10 qadağan olunmuş nömrədir.', why: 'İstənilən nömrə yazıla bilər.' },
            { t: 'Yalnız area 10 olarsa.', why: 'Process ID area-dan fərqli anlayışdır.' },
          ] },
        { id: 'p5t3-q13', concept: 'ospf-config', obj: 'passive-interface',
          stem: '<p>LAN interface-ində <span class="m">passive-interface</span> yazıldıqda nə baş verir?</p>',
          options: [
            { t: 'Orada Hello göndərilmir, LAN yenə OSPF-də elan olunur.', ok: true, why: 'LAN-da router yoxdur, ona görə qonşuluq lazım deyil.' },
            { t: 'LAN OSPF-dən silinir və uzaq router-lər onu görmür.', why: 'Network elan olunmağa davam edir.' },
            { t: 'Interface inzibati olaraq söndürülür və işləmir.', why: 'Passive interface-i söndürmür.' },
            { t: 'Interface avtomatik DR olur və Hello göndərir.', why: 'DR seçimi ilə əlaqəsi yoxdur.' },
          ] },
        { id: 'p5t3-q14', concept: 'ospf-verify', obj: 'show ip ospf neighbor',
          stem: '<p><span class="m">show ip ospf neighbor</span> çıxışı boşdur. Ən ehtimal olunan səbəb?</p>',
          options: [
            { t: 'Area, subnet/mask, timer uyğunsuzluğu və ya network əmri yoxdur.', ok: true, why: 'Qonşuluq şərtlərindən biri pozulub.' },
            { t: 'DNS server yoxdur və ya cavab vermir.', why: 'DNS OSPF-ə aid deyil.' },
            { t: 'DHCP lease müddəti bitib və ünvan yoxdur və bu avtomatik baş verir.', why: 'DHCP router-lər arasındakı OSPF-ə təsir etmir.' },
            { t: 'Router-in hostname-i çox uzundur və ya yanlışdır və bu normal sayılır.', why: 'Hostname qonşuluğa təsir etmir.' },
          ] },
        { id: 'p5t3-q15', concept: 'ospf-trouble', obj: 'INIT',
          stem: '<p>Qonşu INIT vəziyyətində ilişib. Bu nə deməkdir?</p>',
          options: [
            { t: 'Hello bir istiqamətdə alınır: qarşı tərəf bizi görmür.', ok: true, why: 'Bir tərəfin Hello-su çatmır, məsələn ACL və ya bir ucda OSPF yoxdur.' },
            { t: 'Qonşuluq tam qurulub və LSDB sinxrondur və bu normal sayılır.', why: 'Tam qonşuluq FULL-dur.' },
            { t: 'Qonşu DR olub və seçim bitib.', why: 'DR başqa anlayışdır.' },
            { t: 'Router ID iki router-də eyni olub və bu normal sayılır.', why: 'Bu daha çox ExStart/Exchange ilişməsi verir.' },
          ] },
      ],
    },
  });
})();
