(function () {
  const pick = PT.pick; const R = PT.randInt; const shuffle = PT.shuffle;
  const norm = s => String(s).trim().toLowerCase().replace(/\s+/g, ' ');
  const COST = { '10 Mbps': 100, '100 Mbps': 19, '1 Gbps': 4, '10 Gbps': 2 };
  const hex4 = () => { const h = '0123456789abcdef'; let s = ''; for (let i = 0; i < 4; i++) s += h[R(16)]; return s; };

  PT.topic({
    id: 'p5t1',
    objectives: [
      'Layer 2 loop-un nəticələrini və STP-nin nə üçün lazım olduğunu demək',
      'Bridge ID-yə görə root bridge-i müəyyən etmək',
      'Path cost-ları toplayıb root port və designated portu seçmək',
      'Port rollarını və hallarını (PVST+ və RSTP) demək',
      'PortFast və BPDU Guard-ı bilmək, show spanning-tree oxumaq',
    ],
    explain: PT.frag['p5/t01/explain'], cheat: PT.frag['p5/t01/cheat'],

    lab: {
      title: 'Lab 1: STP seçimlərini hesabla və şəbəkəni qoru',
      goal: 'Root bridge-i və port rollarını hesablamaq, show spanning-tree oxumaq, konfiqurasiya səhvini tapmaq, ticket həll etmək və Packet Tracer-də STP-ni müşahidə etmək.',
      why: 'STP səhvləri bütün şəbəkəni dayandırır. Root bridge-in təsadüfi switch olması da real problemdir.',
      minutes: 60,
      finish: 'STP seçimlərini hesablaya və səhvini tapa bilirsən. İndi quizə keç.',
      steps: [
        { id: 's1', title: 'Hazırlıq', type: 'info', button: 'Başladım',
          body: '<p>Ssenari: üç switch üçbucaq şəklində birləşib: SW1–SW2, SW1–SW3, SW2–SW3. Bütün link-lər FastEthernet (cost 19). Bridge ID-lər: SW1 <span class="m">32769 · 0001.aaaa</span>, SW2 <span class="m">32769 · 0001.bbbb</span>, SW3 <span class="m">32769 · 0001.cccc</span>.</p>' },
        { id: 's2', title: 'Anlayışı mənası ilə birləşdir', type: 'match',
          body: '<p>Hər anlayış nə deməkdir?</p>',
          pairs: [
            { l: 'Root bridge', r: 'Ən kiçik Bridge ID olan switch', why: 'Priority, sonra MAC.' },
            { l: 'Root port', r: 'Qeyri-root switch-in root-a ən ucuz yolu', why: 'Hər qeyri-root switch-də bir dənə.' },
            { l: 'Designated port', r: 'Seqmentdə trafiki ötürən port', why: 'Root-a ən yaxın tərəf.' },
            { l: 'Alternate / blocked port', r: 'Loop-un qarşısı üçün bloklanan port', why: 'Ehtiyat link.' },
            { l: 'PortFast', r: 'İstifadəçi portunu dərhal forwarding-ə keçirir', why: '30 saniyə gözləmir.' },
            { l: 'BPDU Guard', r: 'PortFast portuna BPDU gəlsə portu söndürür', why: 'Switch qoşulmasının qarşısını alır.' },
          ],
          hints: ['Root bridge ən kiçik Bridge ID-dir.'] },
        { id: 's3', title: 'Root bridge və portları müəyyən et', type: 'form',
          body: '<p>Yuxarıdakı topologiya üçün cavab ver.</p>',
          fields: [
            { label: 'Hansı switch root bridge olur?', placeholder: 'SW1 / SW2 / SW3', answers: ['sw1'], wrong: 'Priority eynidir, MAC ən kiçik olan (aaaa) qalib olur.' },
            { label: 'SW2-nin root portu hansı switch-ə baxır?', placeholder: 'SW1 / SW3', answers: ['sw1'], wrong: 'SW1-ə birbaşa cost 19, SW3 üzərindən 38.' },
            { label: 'SW2–SW3 link-ində hansı port bloklanır? (SW2 / SW3)', placeholder: 'SW2 / SW3', answers: ['sw3'], wrong: 'Hər iki cost eynidir (19). Tie-breaker: kiçik Bridge ID olan designated olur (SW2), digər tərəf bloklanır.' },
            { label: 'SW1-in neçə portu bloklanır?', placeholder: 'rəqəm', check: r => String(r).trim() === '0', show: '0', wrong: 'Root bridge-in bütün portları designated-dir.' },
          ],
          hints: ['Əvvəl root-u seç, sonra hər switch-in root-a yolunu hesabla.'],
          solution: 'Root SW1; SW2 root portu SW1-ə; SW2–SW3 link-ində SW3 portu bloklanır; SW1 portlarından heç biri bloklanmır.' },
        { id: 's4', title: 'Fərqli cost-larla root port', type: 'form',
          body: '<p>SW3 topologiyasında link-lər: SW1–SW3 <b>100 Mbps</b> (cost 19), SW2–SW3 <b>1 Gbps</b> (cost 4), SW1–SW2 <b>1 Gbps</b> (cost 4). SW1 root-dur.</p>',
          fields: [
            { label: 'SW3-ün SW1-ə birbaşa yolunun cost-u', placeholder: 'rəqəm', check: r => String(r).trim() === '19', show: '19', wrong: 'SW1–SW3 100 Mbps: 19.' },
            { label: 'SW3-ün SW2 üzərindən SW1-ə yolunun cost-u', placeholder: 'rəqəm', check: r => String(r).trim() === '8', show: '8', wrong: '4 + 4 = 8.' },
            { label: 'SW3-ün root portu hansı switch-ə baxır?', placeholder: 'SW1 / SW2', answers: ['sw2'], wrong: 'Daha aşağı cost (8 < 19) olan yol seçilir.' },
          ],
          hints: ['Yol cost-ları toplanır, ən kiçik seçilir.'],
          solution: '19; 8; root port SW2-yə baxır.' },
        { id: 's5', title: 'show spanning-tree oxu', type: 'form',
          pre: 'SW3#show spanning-tree\nVLAN0001\n  Root ID    Priority    24577\n             Address     0001.4321.AAAA\n             Cost        8\n             Port        2 (FastEthernet0/2)\n  Bridge ID  Priority    32769\n             Address     0001.4321.CCCC\n\nInterface        Role Sts Cost      Prio.Nbr Type\nFa0/1            Altn BLK 19        128.1    P2p\nFa0/2            Root FWD 4         128.2    P2p',
          body: '<p>Çıxışa bax.</p>',
          fields: [
            { label: 'SW3 root bridge-dirmi? (bəli / xeyr)', placeholder: 'bəli / xeyr', answers: ['xeyr', 'yox', 'no'], wrong: 'Root ID Bridge ID-dən fərqlidir.' },
            { label: 'Root bridge-in priority-si', placeholder: 'rəqəm', check: r => String(r).trim() === '24577', show: '24577', wrong: 'Root ID bölməsində Priority.' },
            { label: 'SW3-ün bloklanmış portu', placeholder: 'port', answers: ['fa0/1', 'fastethernet0/1'], wrong: 'Role Altn / Sts BLK.' },
          ],
          hints: ['Root ID root bridge-i, Bridge ID bu switch-i göstərir.'],
          solution: 'Xeyr; 24577 (24576 + VLAN 1); Fa0/1.' },
        { id: 's6', title: 'Konfiqurasiyada səhvi tap', type: 'spot',
          body: '<p>Güclü core switch root olmalıdır, amma köhnə access switch root olub. Core switch-in konfiqurasiyasına bax. <b>Problemi izah edən sətri tap.</b></p>',
          lines: [
            { t: 'hostname CORE1' },
            { t: 'spanning-tree mode rapid-pvst' },
            { t: '! priority sətri yoxdur (default 32768)', bad: true, why: 'Priority default qalıb. Ən kiçik MAC-li switch root olur və bu köhnə access switch ola bilər.' },
          ],
          fix: { label: 'Əlavə edəcəyin əmr', placeholder: 'əmr', answers: ['spanning-tree vlan 1 root primary', 'spanning-tree vlan 1 priority 4096', 'spanning-tree vlan 1 priority 0', 'spanning-tree vlan 1 priority 8192', 'spanning-tree vlan 1 priority 24576'], wrong: 'Core switch-in priority-sini kiçilt.' },
          hints: ['Root ən kiçik Bridge ID-dir.'] },
        { id: 's7', title: 'PortFast riski', type: 'spot',
          body: '<p>Bir istifadəçi portuna kiçik switch qoşub və şəbəkə yavaşlayıb. Konfiqurasiyaya bax. <b>Çatışmazlığı tap.</b></p>',
          lines: [
            { t: 'interface FastEthernet0/5' },
            { t: ' switchport mode access' },
            { t: ' spanning-tree portfast' },
            { t: '! bpduguard yoxdur', bad: true, why: 'PortFast portunda BPDU Guard olmasa, istifadəçi switch qoşub BPDU göndərə və loop yarada bilər. BPDU Guard bu halda portu söndürür.' },
          ],
          fix: { label: 'Əlavə edəcəyin əmr', placeholder: 'əmr', answers: ['spanning-tree bpduguard enable'], wrong: 'PortFast portlarında BPDU Guard açılır.' },
          hints: ['PortFast portuna switch qoşulmamalıdır.'] },
        { id: 's8', title: 'Ticket: "Şəbəkə dayandı"', type: 'ticket',
          body: '<p><b>İstifadəçilər deyir:</b> "Birdən bütün şəbəkə yavaşladı, ping nəticələr qeyri-sabitdir." Switch-lərin işıqları sürətlə yanıb-sönür. Yarım saat əvvəl bir texnik iki switch arasında əlavə kabel çəkib.</p>',
          stages: [
            { q: '<p>Ən ehtimal olunan səbəb?</p>', options: [
              { t: 'Layer 2 loop və broadcast storm: əlavə kabel loop yaradıb və STP onu bloklamayıb.', ok: true, why: 'Qeyri-sabit ping və yanıb-sönən işıqlar broadcast storm əlamətidir.' },
              { t: 'DHCP server tükənib.', why: 'DHCP bu simptomu vermir.' },
              { t: 'DNS cache doludur.', why: 'DNS şəbəkə ümumi yavaşlığını yaratmır.' },
              { t: 'Router-in ACL-i səhvdir.', why: 'ACL bir istiqamətdə bloklayır, switch işıqlarını yandırıb-söndürmür.' },
            ] },
            { q: '<p>İlk addım?</p>', options: [
              { t: 'Son əlavə olunan kabeli çıxarıb vəziyyəti yoxlamaq.', ok: true, why: 'Loop yaradan link ayrılanda storm dayanır.' },
              { t: 'Bütün switch-ləri yenidən başlatmaq.', why: 'Kabel yerində qalsa loop təkrar yaranır.' },
              { t: 'PC-lərin IP-lərini dəyişmək.', why: 'IP-lər problem deyil.' },
              { t: 'DNS server-i dəyişmək.', why: 'DNS bu problemə aid deyil.' },
            ] },
            { q: '<p>Niyə STP onu avtomatik bloklamadı?</p>', options: [
              { t: 'STP söndürülüb və ya link BPDU almır (məsələn kiçik switch-in STP-si yoxdur).', ok: true, why: 'STP işləsəydi bir port bloklanardı.' },
              { t: 'STP yalnız router-lərdə işləyir.', why: 'STP switch protocol-udur.' },
              { t: 'Kabel çox qısadır.', why: 'Uzunluq STP-yə təsir etmir.' },
              { t: 'STP yalnız gecə işləyir.', why: 'STP daimi işləyir.' },
            ] },
          ],
          after: '<p>Şəbəkədə ani dayanma varsa, son dəyişikliyi ilk yoxla.</p>' },
        { id: 's9', title: 'Packet Tracer-də müşahidə et', type: 'ptsteps',
          body: '<p>Üç 2960 switch üçbucaq şəklində (cross-over kabellərlə) birləşsin.</p>',
          checks: [
            { t: 'Hər switch-də <span class="m">show spanning-tree</span> yaz. Root ID və Bridge ID-ləri müqayisə et. Root bridge MAC-i ən kiçik olan switch-dir.', cmd: ['show spanning-tree'] },
            { t: 'Hansı portun <span class="m">Altn BLK</span> olduğunu tap. Hansı link-in bir ucu bloklanıb?' },
            { t: 'Sonra SW2-də <span class="m">spanning-tree vlan 1 root primary</span> yaz. Yenə <span class="m">show spanning-tree</span> yaz: root dəyişməlidir.', cmd: ['spanning-tree vlan 1 root primary', 'show spanning-tree'] },
            { t: 'Root-a aparan link-i çıxar və bloklanmış portun tez bir zamanda forwarding-ə keçdiyini izlə (Packet Tracer-də vaxt saatını sürətləndirə bilərsən).' },
          ] },
        { id: 's10', title: 'Gördüyünü yaz', type: 'form',
          body: '<p>SW2-də root primary yazandan sonra:</p>',
          fields: [
            { label: 'Hansı switch artıq root-dur?', placeholder: 'SWx', answers: ['sw2'], wrong: 'root primary priority-ni mövcud root-dan kiçik edir.' },
            { label: 'SW2-nin yeni priority-si 24576 + VLAN. VLAN 1 üçün show-da nə görünür?', placeholder: 'rəqəm', check: r => String(r).trim() === '24577', show: '24577', wrong: '24576 + 1.' },
          ],
          solution: 'SW2; 24577 (versiyadan asılı olaraq fərqli ola bilər, əsas olan əvvəlkindən kiçik olmasıdır).' },
      ],
    },

    quiz: {
      draw: 8,
      gens: [
        () => {
          const sw = ['SW1', 'SW2', 'SW3'].map(n => ({ n, pr: pick([4096, 8192, 24576, 32768, 32768, 32768]), mac: hex4() }));
          const key = s => s.pr * 1e6 + parseInt(s.mac, 16);
          const root = sw.slice().sort((a, b) => key(a) - key(b))[0];
          if (sw.filter(s => key(s) === key(root)).length > 1) sw[0].mac = (parseInt(sw[0].mac, 16) + 1).toString(16).padStart(4, '0');
          const root2 = sw.slice().sort((a, b) => key(a) - key(b))[0];
          const lines = sw.map(s => s.n + ': priority ' + s.pr + ', MAC 0001.' + s.mac).join('<br>');
          const why = s => s === root2 ? 'Əvvəl priority müqayisə olunur, bərabər olsa MAC. ' + s.n + ' ən kiçik Bridge ID-yə malikdir.' : s.n + '-in Bridge ID-si daha böyükdür.';
          return { id: 'p5t1-g-root', concept: 'root-bridge', obj: 'Root bridge seçimi', _meta: { ans: root2.n },
            stem: '<p>Üç switch-in Bridge ID məlumatları:<br>' + lines + '</p><p>Hansı switch root bridge olur?</p>',
            options: sw.map(s => ({ t: s.n, ok: s === root2, why: why(s) })) };
        },
        () => {
          const speeds = Object.keys(COST); const a = pick(speeds), b = pick(speeds);
          const ans = COST[a] + COST[b];
          return { id: 'p5t1-g-cost', concept: 'root-port', obj: 'Path cost', type: 'num', _meta: { a, b, ans },
            stem: '<p>Switch root bridge-ə iki link-dən keçir: birinci link <b>' + a + '</b>, ikinci link <b>' + b + '</b>. Bu yolun path cost-u neçədir? (10 Mbps = 100, 100 Mbps = 19, 1 Gbps = 4, 10 Gbps = 2)</p>', placeholder: 'rəqəm',
            check: r => String(r).trim() === String(ans),
            solution: COST[a] + ' + ' + COST[b] + ' = <b>' + ans + '</b>.' };
        },
      ],
      pool: [
        { id: 'p5t1-q1', concept: 'stp-why', obj: 'Loop problemi',
          stem: '<p>Layer 2 loop niyə təhlükəlidir?</p>',
          options: [
            { t: 'Broadcast frame-lər dövr edib çoxalır, çünki Layer 2-də TTL yoxdur.', ok: true, why: 'Frame özü-özünə ölmür.' },
            { t: 'Loop IP ünvanlarını dəyişir və paketləri yanlış yerə aparır.', why: 'IP ünvanları loop-dan təsirlənmir.' },
            { t: 'Loop DNS cavablarını gecikdirir və ad çevrilmir.', why: 'DNS-in bu məsələyə aidiyyəti yoxdur.' },
            { t: 'Loop yalnız kabelləri qızdırır və fiziki zədə yaradır.', why: 'Fiziki qızma problem deyil.' },
          ] },
        { id: 'p5t1-q2', concept: 'stp-why', obj: 'STP nə edir',
          stem: '<p>STP nə edir?</p>',
          options: [
            { t: 'Loop yaradan yolların bir hissəsini bloklayıb loop-suz ağac qurur.', ok: true, why: 'Bloklanmış yol ehtiyat qalır.' },
            { t: 'VLAN-ları switch-lərə yayıb eyni siyahını saxlayır.', why: 'Bu VTP-nin işidir.' },
            { t: 'Portlara avtomatik IP ünvanı verib ayarları göndərir və bu normal sayılır.', why: 'IP ünvanı verən DHCP-dir.' },
            { t: 'Paketləri şifrələyib kənar şəxsdən qoruyur.', why: 'STP şifrələmə protocol-u deyil.' },
          ] },
        { id: 'p5t1-q3', concept: 'root-bridge', obj: 'Priority və MAC',
          stem: '<p>Bütün switch-lərdə priority default (32768)-dir. Hansı switch root olur?</p>',
          options: [
            { t: 'MAC ünvanı ən kiçik olan.', ok: true, why: 'Priority bərabər olsa MAC müqayisə olunur.' },
            { t: 'MAC ünvanı ən böyük olan.', why: 'Ən kiçik Bridge ID qalib olur.' },
            { t: 'Ən çox portu olan.', why: 'Port sayı seçimə təsir etmir.' },
            { t: 'Ən yeni switch.', why: 'Yeni olmaq seçimə təsir etmir.' },
          ] },
        { id: 'p5t1-q4', concept: 'root-bridge', obj: 'Priority qaydası',
          stem: '<p>Root bridge seçimində hansı Bridge ID qalib olur?</p>',
          options: [
            { t: 'Ən kiçik.', ok: true, why: 'Kiçik priority daha yaxşıdır.' },
            { t: 'Ən böyük.', why: 'Böyük priority root olmaq şansını azaldır.' },
            { t: 'Ortadakı.', why: 'Orta seçilmir.' },
            { t: 'Təsadüfi seçilir.', why: 'Qayda dəqiqdir.' },
          ] },
        { id: 'p5t1-q5', concept: 'root-port', obj: 'Root port',
          stem: '<p>Root port hansı portdur?</p>',
          options: [
            { t: 'Root-a ən ucuz yolu olan qeyri-root port.', ok: true, why: 'Hər qeyri-root switch-də bir root port olur.' },
            { t: 'Root bridge-in öz portu, həmişə forwarding-dir.', why: 'Root bridge-in portları designated-dir.' },
            { t: 'Bloklanmış port, loop-un qarşısını alan.', why: 'Bloklanmış port alternate-dir.' },
            { t: 'İstifadəçi PC-sinin qoşulduğu port.', why: 'Rol cost-a görə təyin olunur, port növünə görə yox.' },
          ] },
        { id: 'p5t1-q6', concept: 'root-port', obj: 'Cost sırası',
          stem: '<p>Hansı link cost-u ən kiçikdir?</p>',
          options: [
            { t: '10 Gbps.', ok: true, why: 'Sürət yüksək olduqca cost kiçilir.' },
            { t: '10 Mbps.', why: '10 Mbps cost-u 100-dür, ən böyükdür.' },
            { t: '100 Mbps.', why: 'Cost-u 19-dur.' },
            { t: '1 Gbps.', why: 'Cost-u 4-dür, 10 Gbps-dən böyükdür.' },
          ] },
        { id: 'p5t1-q7', concept: 'designated-port', obj: 'Root bridge portları',
          stem: '<p>Root bridge-in portları hansı roldadır?</p>',
          options: [
            { t: 'Hamısı designated və forwarding.', ok: true, why: 'Root bridge-in öz seqmentlərində ən yaxın olanı özüdür.' },
            { t: 'Yarısı root port, yarısı bloklanıb.', why: 'Root bridge-də root port olmur.' },
            { t: 'Hamısı bloklanıb.', why: 'Onda root trafiki ötürə bilməzdi.' },
            { t: 'Yalnız bir port designated-dir.', why: 'Bütün portlar designated-dir.' },
          ] },
        { id: 'p5t1-q8', concept: 'stp-states', obj: 'Klassik STP gecikməsi',
          stem: '<p>Klassik STP-də port bloklanmışdan forwarding-ə keçərkən təxminən nə qədər gözləyir?</p>',
          options: [
            { t: 'Təxminən 30 saniyə (listening 15 + learning 15).', ok: true, why: 'Max age ilə birlikdə 50 saniyəyə qədər çata bilər.' },
            { t: 'Dərhal, heç bir gözləmə olmadan keçir.', why: 'PortFast olmadan dərhal keçmir.' },
            { t: 'Təxminən 5 dəqiqə gözləyir.', why: 'Bu həddindən artıq uzundur.' },
            { t: 'Keçmir, bloklanmış qalır və yolu açmır.', why: 'Bloklanmış port aktiv yol qırılanda açılır.' },
          ] },
        { id: 'p5t1-q9', concept: 'stp-states', obj: 'RSTP',
          stem: '<p>Rapid STP (RSTP) klassik STP-dən nə ilə fərqlənir?</p>',
          options: [
            { t: 'Bərpa bir neçə saniyədə olur, halları üçdür.', ok: true, why: 'Discarding, learning, forwarding.' },
            { t: 'Loop-ları bloklamır, onları buraxır və yayır.', why: 'RSTP də loop-ları bloklayır.' },
            { t: 'Yalnız router-lər üçün yazılmış protocol-dur.', why: 'RSTP switch protocol-udur.' },
            { t: 'Daha çox switch tələb edir və bahalıdır.', why: 'Switch sayı tələb olunmur.' },
          ] },
        { id: 'p5t1-q10', concept: 'stp-config', obj: 'PortFast',
          stem: '<p>PortFast hansı portlarda işlədilməlidir?</p>',
          options: [
            { t: 'Yalnız PC, printer kimi son cihaz qoşulan portlarda.', ok: true, why: 'Switch-lərarası link-də loop riski var.' },
            { t: 'Bütün trunk portlarında, sürətli bərpa üçün.', why: 'Trunk-da loop riski var.' },
            { t: 'Yalnız root bridge-in bütün portlarında.', why: 'PortFast portun növünə aiddir.' },
            { t: 'Heç vaxt işlədilməməlidir, risklidir.', why: 'İstifadəçi portlarında işlədilir.' },
          ] },
        { id: 'p5t1-q11', concept: 'stp-config', obj: 'BPDU Guard',
          stem: '<p>BPDU Guard nə edir?</p>',
          options: [
            { t: 'PortFast portuna BPDU gəlsə portu err-disabled edir.', ok: true, why: 'İstifadəçi portuna switch qoşulmasının qarşısını alır.' },
            { t: 'Root bridge-i avtomatik başqa switch-ə dəyişdirir.', why: 'Root seçimi priority ilədir.' },
            { t: 'Portun sürətini avtomatik artırır.', why: 'Sürətə aid deyil.' },
            { t: 'VLAN-ları bloklayır və trunk-ı bağlayır.', why: 'VLAN-a aid deyil.' },
          ] },
        { id: 'p5t1-q12', concept: 'stp-verify', obj: 'show spanning-tree',
          stem: '<p>show spanning-tree-də <b>Root ID</b> ilə <b>Bridge ID</b> fərqlidir. Bu nə deməkdir?</p>',
          options: [
            { t: 'Bu switch root bridge deyil.', ok: true, why: 'Root ID-də root switch-in məlumatı, Bridge ID-də bu switch-in məlumatı var.' },
            { t: 'Bu switch root bridge-dir.', why: 'Root olsa iki bölmə eyni olardı.' },
            { t: 'STP bu switch-də söndürülüb.', why: 'STP açıq olduğu üçün çıxış göstərilir.' },
            { t: 'Switch-də loop yaranıb.', why: 'Loop çıxışdan bilinməz.' },
          ] },
      ],
    },
  });
})();
