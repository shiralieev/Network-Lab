(function () {
  const pick = PT.pick; const R = PT.randInt; const shuffle = PT.shuffle;
  const norm = s => String(s).trim().toLowerCase().replace(/\s+/g, ' ');

  PT.topic({
    id: 'p4t4',
    objectives: [
      'VTP-nin nə yaydığını və nə yaymadığını demək',
      'Server, client və transparent rejimlərini ayırmaq',
      'Configuration revision number qaydasını izah etmək',
      'VTP ilə VLAN-ların silinməsi riskini və qarşısını almağı bilmək',
      'show vtp status çıxışını oxumaq',
    ],
    explain: PT.frag['p4/t04/explain'], cheat: PT.frag['p4/t04/cheat'],

    lab: {
      title: 'Lab 4: VTP-ni qur və riskini anla',
      goal: 'VTP rejimlərini ayırmaq, revision qaydasını tətbiq etmək, show vtp status oxumaq, VLAN silinmə ssenarisini həll etmək və Packet Tracer-də VTP qurmaq.',
      why: 'Səhv switch-in qoşulması VLAN-ları silə bilər. Bunu tanımaq və qarşısını almaq real iş vərdişidir.',
      minutes: 40,
      finish: 'VTP-ni və riskini bilirsən. İndi quizə keç.',
      steps: [
        { id: 's1', title: 'Hazırlıq', type: 'info', button: 'Başladım',
          body: '<p>Ssenari: SW1 (server) və SW2, SW3 (client) trunk linklərlə birləşib. Domain <span class="m">COMPANY</span>. VLAN 10, 20, 30 mövcuddur.</p>' },
        { id: 's2', title: 'Rejimi davranışı ilə birləşdir', type: 'match',
          body: '<p>Hər rejim nə edir?</p>',
          pairs: [
            { l: '<b>Server</b>', r: 'VLAN yaradır və digərlərinə yayır', why: 'Default rejimdir.' },
            { l: '<b>Client</b>', r: 'VLAN yarada bilmir, serverdən öyrənir', why: 'Siyahı server ilə eyni qalır.' },
            { l: '<b>Transparent</b>', r: 'Öz VLAN-larını saxlayır, mesajı ötürür', why: 'VTP ilə sinxron olmur.' },
            { l: 'Revision number', r: 'Hansı siyahının yeni olduğunu göstərir', why: 'Hər dəyişiklikdə artır.' },
          ],
          hints: ['Client dəyişiklik edə bilmir.'] },
        { id: 's3', title: 'Revision qaydası', type: 'form',
          body: '<p>Domain eynidir. Qaydanı tətbiq et: daha böyük revision olan siyahı qalibdir.</p>',
          fields: [
            { label: 'Şirkət switch-ləri revision 12, yeni switch revision 30. Hansının siyahısı qalib olur?', placeholder: 'seç', answers: ['yeni', 'yeni switch', 'yeni switchin'], wrong: 'Daha böyük revision qalibdir.' },
            { label: 'Şirkət revision 40, yeni switch revision 5. Hansı qalib olur?', placeholder: 'seç', answers: ['şirkət', 'sirket', 'şirkət switchləri', 'mövcud'], wrong: '40 daha böyükdür.' },
            { label: 'Yeni switch-in domain adı fərqlidir (LAB). Mövcud şəbəkəyə təsir edirmi? (bəli / xeyr)', placeholder: 'bəli / xeyr', answers: ['xeyr', 'yox', 'no'], wrong: 'Fərqli domain-dəki mesajlar qəbul edilmir.' },
          ],
          hints: ['Eyni domain və daha böyük revision lazımdır.'],
          solution: 'Yeni switch (30 > 12); şirkət (40 > 5); xeyr, domain fərqlidir.' },
        { id: 's4', title: 'Qoşmaq üçün hazırlıq', type: 'spot',
          body: '<p>Köhnə laboratoriya switch-i şirkət şəbəkəsinə qoşulacaq. <span class="m">show vtp status</span> belədir. <b>Riskli sətri tap.</b></p>',
          lines: [
            { t: 'VTP Domain Name         : COMPANY' },
            { t: 'VTP Operating Mode      : Server' },
            { t: 'Configuration Revision  : 87', bad: true, why: 'Revision nömrəsi mövcud şəbəkədən çox böyükdür və domain eynidir. Qoşulsa, bu switch-in VLAN siyahısı mövcud olanı əvəz edər.' },
          ],
          fix: { label: 'Qoşmazdan əvvəl nə etməlisən?', placeholder: 'məs. revision sıfırla', answers: ['revision sıfırla', 'revisionu sıfırla', 'transparent et', 'domain dəyiş', 'domaini dəyiş', 'transparent rejimə keçir'], wrong: 'Rejimi transparent edib geri qaytar və ya domain adını dəyiş.' },
          hints: ['Revision 87 mövcud şəbəkəni əvəz edə bilər.'] },
        { id: 's5', title: 'Konfiqurasiyada səhvi tap', type: 'spot',
          body: '<p>SW2 client olmalıdır, amma yeni VLAN 30-u görmür. <b>Problemi tap.</b></p>',
          lines: [
            { t: 'SW1: vtp mode server' },
            { t: 'SW1: vtp domain COMPANY' },
            { t: 'SW2: vtp mode client' },
            { t: 'SW2: vtp domain COMPANY-LAB', bad: true, why: 'Domain adları fərqlidir (COMPANY və COMPANY-LAB). SW2 SW1-in mesajlarını qəbul etmir.' },
          ],
          fix: { label: 'SW2-də domain nə olmalıdır?', placeholder: 'ad', answers: ['company'], wrong: 'Domain adı iki switch-də eyni olmalıdır.' },
          hints: ['Domain adı böyük-kiçik hərfə və tireyə həssasdır.'] },
        { id: 's6', title: 'Ticket: "Bütün VLAN-lar birdən itdi"', type: 'ticket',
          body: '<p><b>İstifadəçilər deyir:</b> "Bu gün səhər bütün şöbələrin interneti kəsildi." <span class="m">show vlan brief</span> yalnız default VLAN-ı göstərir. Dünən yeni switch-i qoşmuşdular.</p>',
          stages: [
            { q: '<p>Ən ehtimal olunan səbəb?</p>', options: [
              { t: 'Yeni switch eyni VTP domain-də yüksək revision ilə boş VLAN siyahısı gətirdi.', ok: true, why: 'Mövcud switch-lər onun siyahısını qəbul edib VLAN-ları sildi.' },
              { t: 'Provayder bütün kabelləri kəsib.', why: 'Kabel problemi VLAN siyahısını silmir.' },
              { t: 'DHCP server işləmir.', why: 'DHCP VLAN siyahısına aid deyil.' },
              { t: 'DNS cache dolub.', why: 'DNS VLAN-lara təsir etmir.' },
            ] },
            { q: '<p>İlk addım?</p>', options: [
              { t: 'Yeni switch-i trunk-dan ayırıb, show vtp status ilə revision və rejimi yoxlayıram.', ok: true, why: 'Əvvəl səbəbi dayandırıb yoxlayıram.' },
              { t: 'Bütün switch-ləri yenidən başladıram.', why: 'Yenidən başlatma silinmiş VLAN-ları geri qaytarmır.' },
              { t: 'PC-lərin IP-lərini dəyişirəm.', why: 'Problem IP-də deyil.' },
              { t: 'Router-in ACL-lərini silirəm.', why: 'ACL VLAN siyahısı ilə əlaqəli deyil.' },
            ] },
            { q: '<p>VLAN-ları bərpa etmək və təkrarın qarşısını almaq üçün?</p>', options: [
              { t: 'VLAN-ları yenidən yaradıb (və ya ehtiyat konfiqurasiyadan), VTP-ni transparent edib və ya parol qoymaq.', ok: true, why: 'Bərpa və qoruma birlikdə lazımdır.' },
              { t: 'VTP rejimini bütün switch-lərdə server qoymaq.', why: 'Bu riski artırır.' },
              { t: 'Yalnız revision nömrəsini artırmaq.', why: 'Bu problemi daha da pisləşdirə bilər.' },
              { t: 'Trunk portlarını söndürmək.', why: 'Bu bütün şəbəkəni kəsər.' },
            ] },
          ],
          after: '<p>VTP-ni kritik şəbəkələrdə transparent saxlamaq və yeni switch-ləri təmizləyib qoşmaq vərdişdir.</p>' },
        { id: 's7', title: 'Packet Tracer-də qur', type: 'ptsteps',
          body: '<p>İki switch cross-over trunk ilə birləşsin (SW1 server, SW2 client).</p>',
          checks: [
            { t: 'Hər iki switch-də <span class="m">vtp domain COMPANY</span> yaz, SW1-də <span class="m">vtp mode server</span>, SW2-də <span class="m">vtp mode client</span>.', cmd: ['vtp mode server', 'vtp domain COMPANY'] },
            { t: 'Linki trunk et: iki switch-də <span class="m">interface gi0/1</span> / <span class="m">switchport mode trunk</span>.' },
            { t: 'SW1-də <span class="m">vlan 10</span> və <span class="m">name SALES</span> yarat. SW2-də <span class="m">show vlan brief</span> yaz: VLAN 10 görünməlidir.', cmd: ['vlan 10', 'name SALES', 'show vlan brief'] },
            { t: 'SW2-də <span class="m">vlan 20</span> yaratmağa çalış: xəta verməlidir (client).' },
            { t: 'SW1 və SW2-də <span class="m">show vtp status</span> yaz və Configuration Revision-ı müqayisə et.', cmd: ['show vtp status'] },
          ] },
        { id: 's8', title: 'Gördüyünü yaz', type: 'form',
          body: '<p>Client switch-də VLAN yaratmağa çalışanda nə oldu?</p>',
          fields: [
            { label: 'Client-də VLAN yaratmaq (mümkündür / mümkün deyil)', placeholder: 'seç', answers: ['mümkün deyil', 'mumkun deyil', 'olmur', 'xəta'], wrong: 'Client rejimi VLAN dəyişikliyinə icazə vermir.' },
            { label: 'Server-də VLAN əlavə edəndən sonra revision (artdı / dəyişmədi)', placeholder: 'seç', answers: ['artdı', 'artdi', 'artır'], wrong: 'Hər VLAN dəyişikliyi revision-ı artırır.' },
          ],
          solution: 'Mümkün deyil; revision artdı.' },
      ],
    },

    quiz: {
      draw: 8,
      gens: [
        () => {
          let a = 1 + R(60), b = 1 + R(60); while (a === b) b = 1 + R(60);
          const sameDomain = R(3) !== 0;
          const win = a > b ? 'A' : 'B';
          const ans = sameDomain ? win : 'none';
          const opts = [{ k: 'A', t: 'A switch-in VLAN siyahısı qalib olur' }, { k: 'B', t: 'B switch-in VLAN siyahısı qalib olur' }, { k: 'none', t: 'Heç biri: siyahılar dəyişmir' }];
          return { id: 'p4t4-g-rev', concept: 'vtp-revision', obj: 'Revision qaydası', _meta: { a, b, sameDomain, ans },
            stem: '<p>A switch-in revision nömrəsi <b>' + a + '</b>, B switch-in <b>' + b + '</b>-dir. Domain adları ' + (sameDomain ? '<b>eynidir</b>' : '<b>fərqlidir</b>') + ', parollar uyğundur, aralarında trunk var. Nə baş verir?</p>',
            options: opts.map(o => ({ t: o.t, ok: o.k === ans, why: o.k === ans ? (sameDomain ? 'Eyni domain-də daha böyük revision (' + Math.max(a, b) + ') qalib olur.' : 'Fərqli domain adlarında mesajlar qəbul edilmir.') : (sameDomain ? 'Eyni domain-də daha böyük revision qalib olur.' : 'Fərqli domain olduğu üçün heç biri dəyişmir.') })) };
        },
      ],
      pool: [
        { id: 'p4t4-q1', concept: 'vtp-what', obj: 'VTP nə yayır',
          stem: '<p>VTP nəyi yayır?</p>',
          options: [
            { t: 'VLAN nömrələrini və adlarını.', ok: true, why: 'VLAN-ı bir switch-də yaradırsan, digərləri öyrənir.' },
            { t: 'Portların hansı VLAN-a təyin olunduğunu.', why: 'Port təyini hər switch-də ayrıca edilir.' },
            { t: 'MAC address table-ı.', why: 'MAC cədvəli yayılmır.' },
            { t: 'IP marşrutlarını.', why: 'Marşrutları routing protocol-ları yayır.' },
          ] },
        { id: 'p4t4-q2', concept: 'vtp-what', obj: 'VTP linki',
          stem: '<p>VTP mesajları hansı link-dən keçir?</p>',
          options: [
            { t: 'Trunk linkdən.', ok: true, why: 'Access portdan keçmir.' },
            { t: 'Access portdan.', why: 'Access port VTP mesajlarını daşımır.' },
            { t: 'Hər link növündən.', why: 'Yalnız trunk.' },
            { t: 'Yalnız console kabelindən.', why: 'Console məlumat daşımır.' },
          ] },
        { id: 'p4t4-q3', concept: 'vtp-modes', obj: 'Client',
          stem: '<p>VTP client rejimindəki switch-də <span class="m">vlan 50</span> yazmaq nə edir?</p>',
          options: [
            { t: 'Xəta verir, client VLAN yarada bilmir.', ok: true, why: 'Client yalnız serverdən öyrənir.' },
            { t: 'VLAN yaradılır və digər switch-lərə yayılır.', why: 'Yayma server işidir.' },
            { t: 'VLAN yaradılır, amma yayılmır.', why: 'Client VLAN yarada bilmir.' },
            { t: 'Switch server rejiminə keçir.', why: 'Rejim avtomatik dəyişmir.' },
          ] },
        { id: 'p4t4-q4', concept: 'vtp-modes', obj: 'Transparent',
          stem: '<p>Transparent rejimin əsas xüsusiyyəti?</p>',
          options: [
            { t: 'VTP mesajlarını ötürür, öz siyahısını sinxronlaşdırmır.', ok: true, why: 'Öz VLAN-larını saxlayır.' },
            { t: 'Bütün VLAN-ları serverdən avtomatik öyrənir.', why: 'Bu client-in işidir.' },
            { t: 'VLAN yarada bilmir və yalnız oxuyur və bu normal sayılır.', why: 'Transparent switch öz VLAN-larını yarada bilir.' },
            { t: 'Trunk portunu avtomatik söndürür.', why: 'Transparent trunk-a toxunmur.' },
          ] },
        { id: 'p4t4-q5', concept: 'vtp-revision', obj: 'Revision artımı',
          stem: '<p>Revision number nə vaxt artır?</p>',
          options: [
            { t: 'VLAN yaradılanda, silinəndə və ya adı dəyişəndə.', ok: true, why: 'Hər dəyişiklik siyahını "daha yeni" edir.' },
            { t: 'Hər paket göndəriləndə dəyişir və bu normal sayılır.', why: 'Revision VLAN dəyişikliyinə bağlıdır.' },
            { t: 'Hər saniyə avtomatik artır.', why: 'Revision vaxtla artmır.' },
            { t: 'Switch yenidən başlayanda artır və bu normal sayılır.', why: 'Yenidən başlama revision-ı artırmır.' },
          ] },
        { id: 'p4t4-q6', concept: 'vtp-revision', obj: 'Şərtlər',
          stem: '<p>VTP-nin iki switch arasında işləməsi üçün hansı şərt <b>lazım deyil</b>?</p>',
          options: [
            { t: 'Eyni hostname.', ok: true, why: 'Hostname VTP üçün şərt deyil.' },
            { t: 'Eyni domain adı.', why: 'Domain adı eyni olmalıdır.' },
            { t: 'Aralarında trunk.', why: 'VTP yalnız trunk-dan keçir.' },
            { t: 'Eyni parol (qoyulubsa).', why: 'Parol uyğun olmalıdır.' },
          ] },
        { id: 'p4t4-q7', concept: 'vtp-danger', obj: 'Yüksək revision',
          stem: '<p>Yüksək revision nömrəli switch eyni domain-ə qoşulur. Nə baş verə bilər?</p>',
          options: [
            { t: 'Mövcud switch-lər onun siyahısını qəbul edib VLAN-larını itirə bilər.', ok: true, why: 'Daha böyük revision qalib gəlir.' },
            { t: 'Yeni switch mövcud siyahını qəbul edir, heç nə dəyişmir və bu normal sayılır.', why: 'Yeni switch-in revision-ı daha böyükdür, əksinə olur.' },
            { t: 'Switch trunk portunu avtomatik söndürür və bu hər halda belə olur.', why: 'VTP bu cür müdafiə etmir.' },
            { t: 'Hər iki siyahı avtomatik birləşir.', why: 'VTP siyahıları birləşdirmir, əvəz edir.' },
          ] },
        { id: 'p4t4-q8', concept: 'vtp-danger', obj: 'Qoşmazdan əvvəl',
          stem: '<p>İstifadə olunmuş switch-i şirkət şəbəkəsinə qoşmazdan əvvəl ən vacib addım?</p>',
          options: [
            { t: 'show vtp status ilə revision-ı yoxlayıb sıfırlamaq.', ok: true, why: 'Revision 0 olsa, mövcud şəbəkəni əvəz edə bilməz.' },
            { t: 'Switch-in hostname-ini dəyişmək.', why: 'Hostname VTP-yə təsir etmir.' },
            { t: 'Bütün portlarını access rejiminə keçirmək.', why: 'Revision problemi bununla həll olunmur.' },
            { t: 'Switch-i server rejimində qoşmaq və bu normal sayılır.', why: 'Server rejimi riski artırır.' },
          ] },
        { id: 'p4t4-q9', concept: 'vtp-verify', obj: 'show vtp status',
          stem: '<p><span class="m">show vtp status</span> hansı məlumatları göstərir?</p>',
          options: [
            { t: 'Domain adı, işləmə rejimi və revision nömrəsi.', ok: true, why: 'Bunlar VTP vəziyyətinin əsas hissələridir.' },
            { t: 'Switch portlarının MAC ünvanları və bu normal sayılır.', why: 'MAC ünvanları show mac address-table ilədir.' },
            { t: 'Router-in marşrut cədvəli və bu normal sayılır.', why: 'Marşrutlar show ip route ilədir.' },
            { t: 'Port security pozuntuları.', why: 'Bu show port-security ilədir.' },
          ] },
      ],
    },
  });
})();
