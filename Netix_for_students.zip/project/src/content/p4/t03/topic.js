(function () {
  const pick = PT.pick; const R = PT.randInt; const shuffle = PT.shuffle;
  const norm = s => String(s).trim().toLowerCase().replace(/\s+/g, ' ');

  const MODES = ['access', 'trunk', 'dynamic auto', 'dynamic desirable'];
  /* outcome of a link for two admin modes */
  function outcome(a, b) {
    const s = [a, b].sort().join('|');
    const has = m => a === m || b === m;
    if (has('trunk') && has('access')) return 'mismatch';
    if (has('access')) return 'access';
    if (has('trunk')) return 'trunk';
    if (has('dynamic desirable')) return 'trunk';
    return 'access'; // auto + auto
  }
  const OUT_TXT = { trunk: 'Trunk', access: 'Access', mismatch: 'İşləmir (mismatch)' };

  PT.topic({
    id: 'p4t3',
    objectives: [
      'DTP-nin nə etdiyini və dörd port rejimini demək',
      'İki uc rejiminə görə linkin nəticəsini müəyyən etmək',
      'Switch spoofing hücumunu və müdafiəsini izah etmək',
      'Administrative və Operational rejimi show çıxışında oxumaq',
    ],
    explain: PT.frag['p4/t03/explain'], cheat: PT.frag['p4/t03/cheat'],

    lab: {
      title: 'Lab 3: DTP nəticələrini hesabla və portları sabitlə',
      goal: 'İki uc rejiminin nəticəsini bilmək, show çıxışında Administrative və Operational rejimi oxumaq, switch spoofing riskini tapmaq və portları təhlükəsiz sabitləmək.',
      why: 'Default DTP ayarı çox vaxt unudulur və istifadəçi portlarını risk altında qoyur. Portları sabitləmək ucuz müdafiədir.',
      minutes: 40,
      finish: 'DTP davranışını və müdafiəsini bilirsən. İndi quizə keç.',
      steps: [
        { id: 's1', title: 'Hazırlıq', type: 'info', button: 'Başladım',
          body: '<p>DTP iki switch portunun rejimlərinə baxıb trunk qurub-qurmayacağına qərar verir. Əvvəlcə cədvəldəki qaydanı yadda saxla: trunk yalnız bir tərəf onu aktiv istəyəndə qurulur.</p>' },
        { id: 's2', title: 'Rejimi davranışı ilə birləşdir', type: 'match',
          body: '<p>Hər rejim nə edir?</p>',
          pairs: [
            { l: '<span class="m">dynamic auto</span>', r: 'Passiv: trunk olmağa hazırdır, özü təklif etmir', why: 'Qarşı tərəf təklif etsə trunk olur.' },
            { l: '<span class="m">dynamic desirable</span>', r: 'Aktiv: trunk olmağı təklif edir', why: 'Qarşı tərəf auto olsa da trunk qurulur.' },
            { l: '<span class="m">trunk</span>', r: 'Həmişə trunk', why: 'DTP mesajı da göndərir.' },
            { l: '<span class="m">access</span>', r: 'Həmişə access, trunk qurmur', why: 'İstifadəçi portu üçün düzgün seçimdir.' },
          ],
          hints: ['Auto passivdir, desirable aktivdir.'] },
        { id: 's3', title: 'Nəticəni hesabla', type: 'form',
          body: '<p>İki switch-in uc rejimləri verilib. Linkin nəticəsini yaz: <b>trunk</b>, <b>access</b> və ya <b>mismatch</b>.</p>',
          fields: [
            { label: 'dynamic auto + dynamic auto', placeholder: 'nəticə', answers: ['access'], wrong: 'Heç kim trunk təklif etmir.' },
            { label: 'dynamic auto + dynamic desirable', placeholder: 'nəticə', answers: ['trunk'], wrong: 'Desirable təklif edir, auto qəbul edir.' },
            { label: 'dynamic desirable + dynamic desirable', placeholder: 'nəticə', answers: ['trunk'], wrong: 'İki tərəf də təklif edir.' },
            { label: 'trunk + access', placeholder: 'nəticə', answers: ['mismatch', 'işləmir', 'islemir'], wrong: 'Bir tərəf trunk, digər access: uyğunsuzluq.' },
            { label: 'dynamic desirable + access', placeholder: 'nəticə', answers: ['access'], wrong: 'Access tərəf trunk istəmir.' },
          ],
          hints: ['Cədvəldə hər cütü tap.'],
          solution: 'auto+auto: access; auto+desirable: trunk; desirable+desirable: trunk; trunk+access: mismatch; desirable+access: access.' },
        { id: 's4', title: 'show interfaces switchport oxu', type: 'spot',
          body: '<p>Fa0/1 PC üçün nəzərdə tutulub, amma <span class="m">show interfaces trunk</span> onu trunk kimi göstərir. Çıxışa bax. <b>Riskli sətri tap.</b></p>',
          lines: [
            { t: 'Name: Fa0/1' },
            { t: 'Administrative Mode: dynamic desirable', bad: true, why: 'İstifadəçi portu dynamic desirable-dır, yəni trunk təklif edir. Hücumçu və ya səhv qurulmuş cihaz trunk qura bilər.' },
            { t: 'Operational Mode: trunk' },
            { t: 'Negotiation of Trunking: On' },
          ],
          fix: { label: 'Düzəliş əmri', placeholder: 'əmr', answers: ['switchport mode access'], wrong: 'İstifadəçi portu access olmalıdır.' },
          hints: ['PC portu hansı rejimdə olmalıdır?'] },
        { id: 's5', title: 'Hücum ssenarisi', type: 'choice',
          body: '<p>Ofisin otaq rozetkası switch-in Fa0/12 portuna gedir. Port dynamic auto rejimindədir (default). Hücumçu noutbukunu qoşur və DTP mesajı göndərir. Nə baş verir?</p>',
          options: [
            { t: 'Port trunk olur və hücumçu bütün VLAN-ların trafikinə çıxış qazanır.', ok: true, why: 'Auto rejimi trunk təklifini qəbul edir. Hücumçu switch kimi təqdim olunur.' },
            { t: 'Port access qalır, çünki auto passivdir və qarşıdan gələn təklifləri rədd edir.', why: 'Auto passiv olsa da təklif gələndə qəbul edir. Rədd etmir.' },
            { t: 'Port err-disabled olur.', why: 'DTP təklifi pozuntu sayılmır.' },
            { t: 'Switch hücumçunun MAC ünvanını qara siyahıya salır.', why: 'DTP-də belə bir mexanizm yoxdur.' },
          ],
          hints: ['Auto təklifləri qəbul edir.'] },
        { id: 's6', title: 'Ticket: "İki switch trunk deyil"', type: 'ticket',
          body: '<p><b>Mühəndis deyir:</b> "SW1 və SW2 arasında Gi0/1 linki ilə VLAN 10 və 20 keçməlidir. Linkin iki ucu da default qalıb. VLAN-lar keçmir." <span class="m">show interfaces trunk</span> boşdur.</p>',
          stages: [
            { q: '<p>İki uc default (dynamic auto) olsa nə baş verir?</p>', options: [
              { t: 'Heç biri trunk təklif etmir, link access qalır.', ok: true, why: 'auto + auto = access.' },
              { t: 'Link avtomatik trunk olur.', why: 'Trunk üçün ən azı bir tərəf aktiv olmalıdır.' },
              { t: 'Link err-disabled olur.', why: 'DTP bu halda xəta vermir.' },
              { t: 'Switch-lər bir-birini görmür.', why: 'Link işləyir, sadəcə access rejimindədir.' },
            ] },
            { q: '<p>Həll?</p>', options: [
              { t: 'Hər iki uc üçün switchport mode trunk yazmaq.', ok: true, why: 'Trunk-u açıq şəkildə qurmaq DTP-dən asılı olmur.' },
              { t: 'Yalnız bir tərəfdə dynamic auto qoymaq.', why: 'Auto yenə də qarşıdan təklif gözləyir.' },
              { t: 'Hər iki tərəfdə access qoymaq.', why: 'Access VLAN-ları daşımır.' },
              { t: 'Kabeli dəyişmək.', why: 'Kabel işləyir, problem rejimdədir.' },
            ] },
            { q: '<p>Trunk qurulandan sonra əlavə nə yazmaq təhlükəsizliyi artırır?</p>', options: [
              { t: 'switchport nonegotiate: DTP mesajlarını dayandırır.', ok: true, why: 'Trunk açıq qurulubsa, DTP lazım deyil.' },
              { t: 'switchport mode dynamic desirable.', why: 'Bu DTP-ni daha aktiv edir.' },
              { t: 'switchport port-security.', why: 'Bu trunk portda qəbul edilmir.' },
              { t: 'shutdown.', why: 'Bu linki söndürür.' },
            ] },
          ],
          after: '<p>Trunk-u açıq yaz, DTP-yə güvənmə.</p>' },
        { id: 's7', title: 'Sabitləmə planı', type: 'form',
          body: '<p>Switch-də Fa0/1–Fa0/20 PC-lər üçün, Gi0/1 digər switch-ə trunk-dur, Fa0/21–Fa0/24 istifadə olunmur.</p>',
          fields: [
            { label: 'PC portları üçün rejim əmri', placeholder: 'əmr', check: r => norm(r) === 'switchport mode access', show: 'switchport mode access', wrong: 'PC portu access olmalıdır.' },
            { label: 'Trunk portunda DTP-ni dayandıran əmr', placeholder: 'əmr', check: r => norm(r) === 'switchport nonegotiate', show: 'switchport nonegotiate', wrong: 'DTP mesajlarını dayandıran əmr.' },
            { label: 'İstifadə olunmayan portlar üçün əmr', placeholder: 'əmr', check: r => norm(r) === 'shutdown', show: 'shutdown', wrong: 'İstifadə olunmayan portu söndür.' },
          ],
          solution: 'access, nonegotiate, shutdown.' },
        { id: 's8', title: 'Packet Tracer-də yoxla', type: 'ptsteps',
          body: '<p>İki switch (2960) cross-over kabellə Gi0/1-lərdən birləşsin.</p>',
          checks: [
            { t: 'Hər iki switch-də <span class="m">show interfaces gi0/1 switchport</span> yaz və Administrative Mode-a bax.', cmd: ['show interfaces gi0/1 switchport'] },
            { t: 'Bir switch-də <span class="m">switchport mode dynamic desirable</span> yaz. Hər iki tərəfdə <span class="m">show interfaces trunk</span> yaz: trunk qurulmalıdır (modelə görə default fərqlənə bilər).', cmd: ['interface gi0/1', 'switchport mode dynamic desirable', 'show interfaces trunk'] },
            { t: 'Hər iki switch-də <span class="m">switchport mode access</span> yaz. Operational Mode-un static access olduğunu gör.', cmd: ['switchport mode access'] },
            { t: 'Bir tərəfdə trunk, digər tərəfdə access qoy. Link-in düzgün işləmədiyini göstərən nəticəni yoxla (VLAN-lar keçmir).' },
          ] },
      ],
    },

    quiz: {
      draw: 8,
      gens: [
        () => {
          const a = pick(MODES), b = pick(MODES); const res = outcome(a, b);
          const opts = ['trunk', 'access', 'mismatch'];
          return { id: 'p4t3-g-out', concept: 'dtp-result', obj: 'İki uc rejiminin nəticəsi', _meta: { a, b, ans: res },
            stem: '<p>Link-in bir ucu <span class="m">' + a + '</span>, digər ucu <span class="m">' + b + '</span> rejimindədir. Nəticə nədir?</p>',
            options: opts.map(o => ({ t: OUT_TXT[o], ok: o === res, why: o === res ? 'Bu kombinasiyanın nəticəsi: ' + OUT_TXT[o] + '.' : 'Bu kombinasiya ' + OUT_TXT[res] + ' verir.' })) };
        },
      ],
      pool: [
        { id: 'p4t3-q1', concept: 'dtp-what', obj: 'DTP nədir',
          stem: '<p>DTP nə edir?</p>',
          options: [
            { t: 'İki switch portu arasında trunk-u razılaşdırır.', ok: true, why: 'Cisco protocol-udur.' },
            { t: 'VLAN adlarını bütün switch-lərə yayır və yeniləyir.', why: 'VLAN adlarını yayan başqa protocol-dur.' },
            { t: 'Portlara avtomatik olaraq IP ünvanı verir.', why: 'IP ünvanı verən DHCP-dir.' },
            { t: 'Spanning tree-ni idarə edib loop-ları bloklayır.', why: 'Loop-ları başqa protocol idarə edir.' },
          ] },
        { id: 'p4t3-q2', concept: 'dtp-modes', obj: 'Auto və desirable',
          stem: '<p>dynamic auto ilə dynamic desirable arasındakı fərq?</p>',
          options: [
            { t: 'Auto passivdir (gözləyir), desirable aktivdir (təklif edir).', ok: true, why: 'Desirable ilk addımı atır.' },
            { t: 'Auto həmişə trunk edir, desirable isə həmişə access edir.', why: 'Tərsinə və yanlış oxunub.' },
            { t: 'Fərq yoxdur, ikisi də tam eyni davranır.', why: 'Davranış fərqlidir.' },
            { t: 'Auto yalnız VLAN 1-i daşıyır, desirable hamısını.', why: 'VLAN daşıma rejimdən asılı deyil.' },
          ] },
        { id: 'p4t3-q3', concept: 'dtp-modes', obj: 'Access rejimi',
          stem: '<p><span class="m">switchport mode access</span> DTP-yə necə təsir edir?</p>',
          options: [
            { t: 'Port həmişə access qalır və trunk qurmur.', ok: true, why: 'Qarşıdan gələn DTP təklifi qəbul edilmir.' },
            { t: 'Port trunk təklif etməyə başlayır.', why: 'Bu desirable-ın işidir.' },
            { t: 'Port söndürülür.', why: 'Access portu söndürmür.' },
            { t: 'Port trunk-dan avtomatik access-ə qayıdır.', why: 'Access rejimi sabitdir.' },
          ] },
        { id: 'p4t3-q4', concept: 'dtp-result', obj: 'trunk + auto',
          stem: '<p>Bir ucda <span class="m">trunk</span>, digər ucda <span class="m">dynamic auto</span> var. Nəticə?</p>',
          options: [
            { t: 'Trunk.', ok: true, why: 'Trunk tərəfi təklif edir, auto qəbul edir.' },
            { t: 'Access.', why: 'Trunk tərəf DTP təklifi göndərir.' },
            { t: 'İşləmir.', why: 'Mismatch yalnız trunk və access arasındadır.' },
            { t: 'Err-disabled.', why: 'DTP burada pozuntu yaratmır.' },
          ] },
        { id: 'p4t3-q5', concept: 'dtp-result', obj: 'auto + auto',
          stem: '<p>İki switch default (dynamic auto) rejimdədir. Link necə olur?</p>',
          options: [
            { t: 'Access qalır, heç kim trunk təklif etmir.', ok: true, why: 'Auto passivdir.' },
            { t: 'Trunk olur, çünki iki tərəf də hazırdır.', why: 'Hazır olmaq kifayət deyil, kimsə təklif etməlidir.' },
            { t: 'Mismatch yaranır və link tamam işləmir.', why: 'Mismatch trunk və access cütündədir.' },
            { t: 'Tərəflər təsadüfi olaraq birini seçir.', why: 'Qayda dəqiqdir.' },
          ] },
        { id: 'p4t3-q6', concept: 'dtp-attack', obj: 'Switch spoofing',
          stem: '<p>Switch spoofing nədir?</p>',
          options: [
            { t: 'Hücumçu DTP ilə portu trunk edib bütün VLAN-lara çıxır.', ok: true, why: 'Auto/desirable port təklifi qəbul edir.' },
            { t: 'Hücumçu switch-in MAC cədvəlini saxta MAC-lərlə doldurur.', why: 'Bu MAC flooding-dir.' },
            { t: 'Hücumçu DHCP server kimi cavab verib saxta ayar verir.', why: 'Bu rogue DHCP-dir.' },
            { t: 'Hücumçu IP ünvanını saxtalaşdırıb başqa cihaz kimi görünür.', why: 'Bu IP spoofing-dir.' },
          ] },
        { id: 'p4t3-q7', concept: 'dtp-attack', obj: 'Müdafiə',
          stem: '<p>Switch spoofing-ə qarşı ən sadə müdafiə?</p>',
          options: [
            { t: 'İstifadəçi portlarında switchport mode access yazmaq.', ok: true, why: 'Access port DTP təklifini qəbul etmir.' },
            { t: 'Bütün portları dynamic desirable rejimində saxlamaq.', why: 'Bu hücumu asanlaşdırır.' },
            { t: 'Daha uzun və keyfiyyətli kabel istifadə etmək.', why: 'Kabel uzunluğu təsir etmir.' },
            { t: 'DNS server ünvanını başqa ilə dəyişmək.', why: 'DNS bu problemlə əlaqəli deyil.' },
          ] },
        { id: 'p4t3-q8', concept: 'dtp-config', obj: 'nonegotiate',
          stem: '<p><span class="m">switchport nonegotiate</span> nə edir?</p>',
          options: [
            { t: 'Portun DTP mesajı göndərməsini dayandırır.', ok: true, why: 'Trunk açıq qurulubsa DTP lazım deyil.' },
            { t: 'Portu inzibati olaraq tamamilə söndürür.', why: 'Söndürmək üçün shutdown yazılır.' },
            { t: 'Trunk-da daşınan VLAN-ları məhdudlaşdırır.', why: 'VLAN siyahısı allowed vlan ilə təyin olunur.' },
            { t: 'Portun sürətini avtomatik endirir.', why: 'Sürət başqa əmrlə təyin olunur.' },
          ] },
        { id: 'p4t3-q9', concept: 'dtp-verify', obj: 'Administrative və Operational',
          stem: '<p>show interfaces switchport-da <b>Administrative Mode</b> ilə <b>Operational Mode</b> nəyi göstərir?</p>',
          options: [
            { t: 'Administrative konfiqdə yazılan, Operational real işləyən rejimdir.', ok: true, why: 'Auto rejim qarşı tərəfə görə access və ya trunk olur.' },
            { t: 'Administrative portun sürətini, Operational isə VLAN-ı göstərir.', why: 'Sürət və VLAN başqa sətirlərdədir.' },
            { t: 'İkisi eyni mənadadır və həmişə üst-üstə düşür.', why: 'Dynamic rejimlərdə fərqli ola bilər.' },
            { t: 'Administrative yalnız router portları üçün işlənir.', why: 'Bu sətirlər switch portu üçündür.' },
          ] },
      ],
    },
  });
})();
