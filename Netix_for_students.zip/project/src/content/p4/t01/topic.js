(function () {
  const A = PT.addr; const pick = PT.pick; const R = PT.randInt; const shuffle = PT.shuffle;
  const norm = s => String(s).trim().toLowerCase().replace(/\s+/g, ' ');
  const wc = mask => mask.split('.').map(o => 255 - +o).join('.');

  /* a small extended ACL and packets for the "first match" generator */
  const RULES = [
    { n: 10, act: 'deny', proto: 'tcp', net: '192.168.2.0', p: 24, dst: '10.0.0.10', port: 23, txt: 'deny tcp 192.168.2.0 0.0.0.255 host 10.0.0.10 eq 23' },
    { n: 20, act: 'permit', proto: 'tcp', net: '192.168.1.0', p: 24, dst: '10.0.0.10', port: 80, txt: 'permit tcp 192.168.1.0 0.0.0.255 host 10.0.0.10 eq 80' },
    { n: 30, act: 'permit', proto: 'tcp', net: '192.168.2.0', p: 24, dst: '10.0.0.10', port: 80, txt: 'permit tcp 192.168.2.0 0.0.0.255 host 10.0.0.10 eq 80' },
  ];
  function evalAcl(src, dst, port) {
    for (const r of RULES) { if (A.net(src, r.p) === r.net && dst === r.dst && port === r.port) return { r, act: r.act }; }
    return { r: null, act: 'deny' };
  }

  PT.topic({
    id: 'p4t1',
    objectives: [
      'ACL-in nə etdiyini, in/out istiqamətini və yuxarıdan aşağı yoxlamanı izah etmək',
      'Implicit deny qaydasını bilmək və onu nəzərə alaraq ACL yazmaq',
      'Subnet mask-dan wildcard mask hesablamaq',
      'Standard və extended ACL yazmaq, yerləşdirmə qaydasını demək',
      'ACL-i interface-ə tətbiq edib show əmrləri ilə yoxlamaq',
      'ACL səhvlərini tapmaq',
    ],
    explain: PT.frag['p4/t01/explain'], cheat: PT.frag['p4/t01/cheat'],

    lab: {
      title: 'Lab 1: ACL yaz, oxu və səhvini tap',
      goal: 'Wildcard hesablamaq, ACL yazmaq, paketin ACL-dən keçib-keçmədiyini müəyyən etmək, konfiqurasiya səhvlərini tapmaq və Packet Tracer-də ACL tətbiq etmək.',
      why: 'ACL şəbəkə təhlükəsizliyinin ən çox istifadə olunan alətidir. Həm yazmaq, həm başqasının yazdığını oxumaq lazımdır.',
      minutes: 55,
      finish: 'ACL-i yaza və səhvini tapa bilirsən. İndi quizə keç.',
      steps: [
        { id: 's1', title: 'Hazırlıq', type: 'info', button: 'Başladım',
          body: '<p>Ssenari: R1-in <span class="m">Gi0/0</span> interface-i LAN 1-ə (<span class="m">192.168.1.0/24</span>), <span class="m">Gi0/1</span> LAN 2-yə (<span class="m">192.168.2.0/24</span>), <span class="m">Gi0/2</span> server şəbəkəsinə (<span class="m">10.0.0.0/24</span>, server <span class="m">10.0.0.10</span>) baxır.</p>' },
        { id: 's2', title: 'Wildcard hesabla', type: 'form',
          body: '<p>Subnet mask-dan wildcard mask-ı hesabla: <b>255.255.255.255 − mask</b>.</p>',
          fields: [
            { label: '255.255.255.0', placeholder: 'a.b.c.d', check: r => String(r).trim() === '0.0.0.255', show: '0.0.0.255', wrong: '255 − 255 = 0, 255 − 0 = 255.' },
            { label: '255.255.255.192', placeholder: 'a.b.c.d', check: r => String(r).trim() === '0.0.0.63', show: '0.0.0.63', wrong: '255 − 192 = 63.' },
            { label: '255.255.240.0', placeholder: 'a.b.c.d', check: r => String(r).trim() === '0.0.15.255', show: '0.0.15.255', wrong: '255 − 240 = 15.' },
            { label: 'Tək host 192.168.1.10 üçün wildcard', placeholder: 'a.b.c.d', check: r => String(r).trim() === '0.0.0.0', show: '0.0.0.0', wrong: 'Hamısı uyğun gəlməlidir.' },
          ],
          hints: ['Hər oktet üçün 255-dən çıx.'],
          solution: '0.0.0.255; 0.0.0.63; 0.0.15.255; 0.0.0.0.' },
        { id: 's3', title: 'Anlayışı mənası ilə birləşdir', type: 'match',
          body: '<p>Hər anlayış nə deməkdir?</p>',
          pairs: [
            { l: 'Implicit deny', r: 'ACL-in sonundakı gizli deny any', why: 'Heç bir qayda uyğun gəlməyəndə trafik bloklanır.' },
            { l: 'Standard ACL', r: 'Yalnız Source IP-yə baxır', why: '1–99 aralığı.' },
            { l: 'Extended ACL', r: 'Protocol, Source, Destination və port yoxlayır', why: '100–199 aralığı.' },
            { l: 'ip access-group', r: 'ACL-i interface və istiqamətə tətbiq edir', why: 'ACL yazmaq kifayət deyil.' },
          ],
          hints: ['Standard sadədir, extended dəqiqdir.'] },
        { id: 's4', title: 'Paket ACL-dən keçirmi?', type: 'form',
          pre: 'R1(config)#access-list 110 deny tcp 192.168.2.0 0.0.0.255 host 10.0.0.10 eq 23\nR1(config)#access-list 110 permit tcp 192.168.1.0 0.0.0.255 host 10.0.0.10 eq 80\nR1(config)#access-list 110 permit tcp 192.168.2.0 0.0.0.255 host 10.0.0.10 eq 80\n! tətbiq: Gi0/2 out',
          body: '<p>Server şəbəkəsinə gedən paketlər üçün cavab ver (<b>permit</b> və ya <b>deny</b>).</p>',
          fields: [
            { label: '192.168.1.5 → 10.0.0.10, TCP 80', placeholder: 'permit / deny', answers: ['permit'], wrong: 'İkinci sətir bu paketə uyğun gəlir.' },
            { label: '192.168.2.7 → 10.0.0.10, TCP 23 (Telnet)', placeholder: 'permit / deny', answers: ['deny'], wrong: 'Birinci sətir Telnet-i bloklayır.' },
            { label: '192.168.2.7 → 10.0.0.10, TCP 80', placeholder: 'permit / deny', answers: ['permit'], wrong: 'Üçüncü sətir bu paketə icazə verir.' },
            { label: '192.168.1.5 → 10.0.0.10, TCP 22 (SSH)', placeholder: 'permit / deny', answers: ['deny'], wrong: 'Heç bir sətir uyğun gəlmir: implicit deny.' },
          ],
          hints: ['Paketi sətirlərlə yuxarıdan aşağı müqayisə et. İlk uyğun gələn tətbiq olunur.'],
          solution: 'permit (2-ci sətir); deny (1-ci sətir); permit (3-cü sətir); deny (implicit deny).' },
        { id: 's5', title: 'ACL-də səhvi tap', type: 'spot',
          body: '<p>Məqsəd: LAN 2 (<span class="m">192.168.2.0/24</span>) server şəbəkəsinə girməsin, qalan hər şey işləsin. Kolleqa belə yazıb, amma bütün trafik bloklanır. <b>Çatışmazlığı tap.</b></p>',
          lines: [
            { t: 'access-list 10 deny 192.168.2.0 0.0.0.255' },
            { t: '! sonra başqa sətir yoxdur', bad: true, why: 'Yalnız deny var. Gizli deny any bütün qalan trafiki də bloklayır. Sonda permit any lazımdır.' },
          ],
          fix: { label: 'Əlavə edəcəyin sətir', placeholder: 'əmr', answers: ['access-list 10 permit any'], wrong: 'Standard ACL 10-a qalan trafikə icazə verən sətir.' },
          hints: ['Implicit deny nəyi bloklayır?'] },
        { id: 's6', title: 'Sıra səhvini tap', type: 'spot',
          body: '<p>Məqsəd: 192.168.1.10 hostu serverə web ilə çıxsın, qalan 192.168.1.0/24 isə çıxmasın. Kolleqa yazıb, amma host serverə çıxa bilmir. <b>Problemli sətri tap.</b></p>',
          lines: [
            { t: '10 deny ip 192.168.1.0 0.0.0.255 host 10.0.0.10', bad: true, why: 'Bu ümumi qayda birinci gəlir və 192.168.1.10-u da bloklayır. Dəqiq permit qaydası ondan yuxarıda olmalıdır.' },
            { t: '20 permit tcp host 192.168.1.10 host 10.0.0.10 eq 80' },
          ],
          fix: { label: 'Düzgün sıra necədir? (hansı sətir birinci)', placeholder: '10 / 20', answers: ['20', 'permit', '20 permit'], wrong: 'Dəqiq qayda yuxarıda olmalıdır.' },
          hints: ['Ümumi qayda dəqiq qaydanı kölgədə qoyur.'] },
        { id: 's7', title: 'Tətbiq səhvini tap', type: 'spot',
          body: '<p>ACL 110 düzgündür (LAN 1 yalnız serverə web). Amma LAN 1 hələ də serverə SSH edə bilir. Konfiqurasiyaya bax. <b>Problemi tap.</b></p>',
          lines: [
            { t: 'access-list 110 permit tcp 192.168.1.0 0.0.0.255 host 10.0.0.10 eq 80' },
            { t: 'interface GigabitEthernet0/1', bad: true, why: 'ACL Gi0/1-ə (LAN 2 tərəfi) yazılıb. LAN 1-in trafiki Gi0/0 interface-inə gəlir. ACL həmin interface-ə tətbiq olunmalıdır.' },
            { t: ' ip access-group 110 in' },
          ],
          fix: { label: 'Düzgün interface', placeholder: 'məs. Gi0/2', answers: ['gi0/0', 'gigabitethernet0/0', 'g0/0'], wrong: 'Extended ACL mənbəyə yaxın qoyulur: LAN 1 interface-i.' },
          hints: ['Extended ACL mənbəyə yaxın tətbiq olunur.'] },
        { id: 's8', title: 'Ticket: "Serverə girə bilmirik"', type: 'ticket',
          body: '<p><b>İstifadəçi deyir:</b> "Bu gün ACL tətbiq olunandan sonra LAN 1 serverin saytına girə bilmir." ACL: <span class="m">access-list 110 deny tcp 192.168.1.0 0.0.0.255 host 10.0.0.10 eq 22</span> yazılıb, Gi0/0 in.</p>',
          stages: [
            { q: '<p>ACL-in niyyəti yalnız SSH-ı bloklamaqdır. Niyə veb də bloklanır?</p>', options: [
              { t: 'Sonda permit yoxdur: gizli deny qalan bütün trafiki bloklayır.', ok: true, why: 'Yalnız deny sətri qalanda hər şey bloklanır.' },
              { t: 'Veb port 22-dir.', why: 'Veb 80 və 443-dür, 22 SSH-dır.' },
              { t: 'Router ACL-i səhv oxuyub.', why: 'ACL düzgün oxunur, nəticə qaydalardan çıxır.' },
              { t: 'Server söndürülüb.', why: 'ACL tətbiq olunmazdan əvvəl sayt açılırdı.' },
            ] },
            { q: '<p>Həll?</p>', options: [
              { t: 'ACL-in sonuna permit ip any any əlavə etmək.', ok: true, why: 'Qalan trafikə icazə verir.' },
              { t: 'deny sətrini silib ACL-i interface-dən götürmək.', why: 'Bu SSH-ı da açar, məqsəd isə onu bloklamaqdır.' },
              { t: 'Veb portunu 22-yə dəyişmək.', why: 'Port dəyişmək məsələni həll etmir.' },
              { t: 'ACL-i out istiqamətinə keçirmək.', why: 'İstiqamət dəyişsə gizli deny yenə qalır.' },
            ] },
            { q: '<p>Yoxlamaq üçün?</p>', options: [
              { t: 'show access-lists: veb trafiki üçün permit sətrinin matches sayğacı artmalıdır.', ok: true, why: 'Sayğac trafikin hansı qaydaya düşdüyünü göstərir.' },
              { t: 'show vlan brief.', why: 'VLAN-lar ACL ilə əlaqəli deyil.' },
              { t: 'show ip arp.', why: 'ARP cache ACL nəticəsini göstərmir.' },
              { t: 'show mac address-table.', why: 'Switch cədvəli Layer 3 ACL-ə aid deyil.' },
            ] },
          ],
          after: '<p>Metod: ACL yazandan sonra sonda nə olduğunu yoxla: lazım olan trafikə permit var?</p>' },
        { id: 's9', title: 'ACL-i özün yaz', type: 'form',
          body: '<p>Server <span class="m">10.0.0.10</span>. LAN 2 (<span class="m">192.168.2.0/24</span>) yalnız HTTPS (443) ilə serverə çıxsın, başqa heç nə yox. ACL nömrəsi 120.</p>',
          fields: [
            { label: 'Permit sətri', placeholder: 'əmr', check: r => norm(r) === 'access-list 120 permit tcp 192.168.2.0 0.0.0.255 host 10.0.0.10 eq 443', show: 'access-list 120 permit tcp 192.168.2.0 0.0.0.255 host 10.0.0.10 eq 443', wrong: 'access-list 120 permit tcp <mənbə> <wildcard> host <server> eq <port>' },
            { label: 'Tətbiq əmri (Gi0/1 interface-ində)', placeholder: 'əmr', check: r => norm(r) === 'ip access-group 120 in', show: 'ip access-group 120 in', wrong: 'ip access-group <nömrə> in' },
          ],
          hints: ['Başqa trafik üçün əlavə sətir yazmaq lazım deyil, implicit deny bloklayır.'],
          solution: 'access-list 120 permit tcp 192.168.2.0 0.0.0.255 host 10.0.0.10 eq 443; Gi0/1: ip access-group 120 in.' },
        { id: 's10', title: 'Packet Tracer-də tətbiq et', type: 'ptsteps',
          body: '<p>Üç şəbəkə: LAN 1, LAN 2 və server. R1 hamısını qoşur.</p>',
          checks: [
            { t: 'R1 interface-ləri: Gi0/0 <span class="m">192.168.1.1/24</span>, Gi0/1 <span class="m">192.168.2.1/24</span>, Gi0/2 <span class="m">10.0.0.1/24</span>. PC-lərin və server-in gateway-ləri düzgün olsun. Əvvəl hər PC-dən servera ping et: işləməlidir.' },
            { t: 'Yeni ACL: <span class="m">access-list 110 deny ip 192.168.2.0 0.0.0.255 host 10.0.0.10</span> və <span class="m">access-list 110 permit ip any any</span>.', cmd: ['access-list 110 deny ip 192.168.2.0 0.0.0.255 host 10.0.0.10', 'access-list 110 permit ip any any'] },
            { t: 'Gi0/1-ə (LAN 2 tərəfi) tətbiq et: <span class="m">ip access-group 110 in</span>.', cmd: ['interface gi0/1', 'ip access-group 110 in'] },
            { t: 'LAN 2 PC-sindən servera ping: bloklanmalıdır (Destination host unreachable). LAN 1 PC-sindən ping işləməlidir.' },
            { t: '<span class="m">show access-lists</span> yaz və matches sayğacını yoxla.', cmd: ['show access-lists'] },
          ] },
        { id: 's11', title: 'Gördüyünü yaz', type: 'form',
          body: '<p>ACL tətbiq olunandan sonra:</p>',
          fields: [
            { label: 'LAN 2 PC-si → server ping nəticəsi', placeholder: 'seç', answers: ['bloklandı', 'bloklanir', 'bloklanır', 'unreachable', 'işləmir'], wrong: 'ACL LAN 2 trafikini bloklayır.' },
            { label: 'LAN 1 PC-si → server ping nəticəsi', placeholder: 'seç', answers: ['işləyir', 'işlədi', 'ok', 'uğurlu'], wrong: 'permit ip any any sətri qalan trafikə icazə verir.' },
          ],
          solution: 'LAN 2 bloklanır, LAN 1 işləyir.' },
      ],
    },

    quiz: {
      draw: 8,
      gens: [
        () => {
          const ps = [8, 16, 20, 22, 23, 24, 25, 26, 27, 28, 29, 30];
          const p = pick(ps); const mask = A.maskS(p); const ans = wc(mask);
          return { id: 'p4t1-g-wc', concept: 'wildcard', obj: 'Wildcard mask hesabı', type: 'num', _meta: { p, ans },
            stem: '<p>Subnet mask <span class="m">' + mask + '</span> (/' + p + ') üçün wildcard mask nədir?</p>', placeholder: 'a.b.c.d',
            check: r => String(r).trim() === ans,
            solution: 'Wildcard = 255.255.255.255 − ' + mask + ' = <span class="m">' + ans + '</span>.' };
        },
        () => {
          const cases = [
            ['192.168.1.5', '10.0.0.10', 80], ['192.168.2.7', '10.0.0.10', 23], ['192.168.2.7', '10.0.0.10', 80], ['192.168.1.9', '10.0.0.10', 22], ['192.168.2.40', '10.0.0.10', 443], ['192.168.1.20', '10.0.0.10', 80]];
          const [src, dst, port] = pick(cases); const res = evalAcl(src, dst, port);
          const text = RULES.map(r => r.n + ' ' + r.txt).join('\n') + '\n(sonda gizli implicit deny)';
          const expl = res.r ? 'Paket ' + res.r.n + '-ci sətrə uyğun gəlir (' + res.r.act + '). İlk uyğun gələn qayda tətbiq olunur.' : 'Heç bir sətir uyğun gəlmir. Sonda gizli implicit deny paketi bloklayır.';
          return { id: 'p4t1-g-eval', concept: 'acl-order', obj: 'ACL nəticəsi', _meta: { src, dst, port, act: res.act },
            stem: '<p>Extended ACL:</p><pre class="pre">' + text + '</pre><p>Paket: <span class="m">' + src + '</span> → <span class="m">' + dst + '</span>, TCP <span class="m">' + port + '</span>. Nə baş verir?</p>',
            options: [{ t: 'Permit: paket keçir.', ok: res.act === 'permit', why: res.act === 'permit' ? expl : 'Paket bloklanır. ' + expl }, { t: 'Deny: paket bloklanır.', ok: res.act === 'deny', why: res.act === 'deny' ? expl : 'Paket keçir. ' + expl }] };
        },
      ],
      pool: [
        { id: 'p4t1-q1', concept: 'acl-what', obj: 'ACL istiqaməti',
          stem: '<p><span class="m">ip access-group 110 in</span> nə deməkdir?</p>',
          options: [
            { t: 'ACL 110 interface-ə daxil olan trafiki yoxlayır.', ok: true, why: 'in interface-ə daxil olan paketlərə aiddir.' },
            { t: 'ACL 110 interface-dən çıxan trafiki yoxlayır.', why: 'Çıxan trafik üçün out yazılır.' },
            { t: 'ACL 110 router-in bütün interface-lərinə tətbiq olunur.', why: 'Əmr yazıldığı interface-ə aiddir.' },
            { t: 'ACL 110 router-dən silinir və qüvvədən düşür.', why: 'Silmək üçün no access-list istifadə olunur.' },
          ] },
        { id: 'p4t1-q2', concept: 'acl-order', obj: 'Implicit deny',
          stem: '<p>ACL-də yalnız bir deny sətri var, permit yoxdur. Bu interface-dən digər trafikə nə olur?</p>',
          options: [
            { t: 'Hamısı bloklanır, gizli implicit deny any var.', ok: true, why: 'Heç bir qayda uyğun gəlməyəndə sonda deny tətbiq olunur.' },
            { t: 'Hamısı keçir, çünki deny yalnız bir sətirdir.', why: 'Sonda gizli deny qalan hər şeyi bloklayır.' },
            { t: 'Router xəta verir və ACL-i avtomatik silir.', why: 'IOS bunu xəta saymır.' },
            { t: 'Yarısı keçir, yarısı bloklanır.', why: 'Qayda həmişə eyni tətbiq olunur.' },
          ] },
        { id: 'p4t1-q3', concept: 'acl-order', obj: 'Sıra',
          stem: '<p>ACL-də 192.168.1.0/24 üçün deny, aşağıda 192.168.1.10 host üçün permit yazılıb. 192.168.1.10-dan gələn paket?</p>',
          options: [
            { t: 'Bloklanır: birinci qayda ilk uyğun gəlir, yoxlama dayanır.', ok: true, why: 'Ümumi qayda dəqiq qaydanı kölgədə qoyur.' },
            { t: 'Keçir, çünki dəqiq qayda həmişə üstündür.', why: 'Sıra vacibdir, dəqiqlik deyil.' },
            { t: 'İkisi də tətbiq olunur və paket yarıya bölünür.', why: 'Bir paket üçün yalnız bir qayda tətbiq olunur.' },
            { t: 'Router paketi yenidən başqa qaydalarla yoxlayır.', why: 'İlk uyğun gələn qaydada yoxlama bitir.' },
          ] },
        { id: 'p4t1-q4', concept: 'wildcard', obj: 'Wildcard mənası',
          stem: '<p>Wildcard mask <span class="m">0.0.0.255</span> nə deməkdir?</p>',
          options: [
            { t: 'İlk üç oktet uyğun gəlməlidir, sonuncu nəzərə alınmır.', ok: true, why: '0 uyğun gəlməlidir, 1 nəzərə alınmır.' },
            { t: 'İlk üç oktet nəzərə alınmır, sonuncu uyğun gəlməlidir.', why: 'Tərsinə oxunub.' },
            { t: 'Yalnız bir host ünvanı nəzərdə tutulur.', why: 'Tək host üçün 0.0.0.0 lazımdır.' },
            { t: 'Bütün ünvanlar uyğun sayılır.', why: 'Bütün ünvanlar 255.255.255.255 və ya any ilədir.' },
          ] },
        { id: 'p4t1-q5', concept: 'wildcard', obj: 'host və any',
          stem: '<p>ACL-də <span class="m">host 10.0.0.10</span> və <span class="m">any</span> nəyə bərabərdir?</p>',
          options: [
            { t: 'host = ünvan 0.0.0.0; any = 0.0.0.0 255.255.255.255.', ok: true, why: 'host tək ünvandır, any hamısıdır.' },
            { t: 'host = 255.255.255.255; any = 0.0.0.0 və tək host.', why: 'Tərsinədir.' },
            { t: 'Hər ikisi 0.0.0.0 mənasını verir.', why: 'any bütün ünvanları əhatə edir.' },
            { t: 'host subnet mask-dır, any isə wildcard-dır.', why: 'İkisi də wildcard qısa yazılışlarıdır.' },
          ] },
        { id: 'p4t1-q6', concept: 'acl-types', obj: 'Standard və extended',
          stem: '<p>Standard ACL nəyə baxır?</p>',
          options: [
            { t: 'Yalnız paketin Source IP ünvanına.', ok: true, why: 'Protocol, port və hədəf yoxlanmır.' },
            { t: 'Source və Destination IP, protocol və port.', why: 'Bunu extended ACL edir.' },
            { t: 'Yalnız MAC ünvanına.', why: 'ACL Layer 3-4 məlumatına baxır.' },
            { t: 'Yalnız Destination port-a.', why: 'Standard ACL port yoxlamır.' },
          ] },
        { id: 'p4t1-q7', concept: 'acl-types', obj: 'Yerləşdirmə',
          stem: '<p>Standard və extended ACL hara qoyulur?</p>',
          options: [
            { t: 'Standard hədəfə yaxın, extended mənbəyə yaxın.', ok: true, why: 'Standard yalnız mənbəyə baxdığı üçün mənbəyə yaxın qoyulsa, onun başqa yerlərə trafikini də bloklayar.' },
            { t: 'Standard mənbəyə yaxın, extended hədəfə yaxın.', why: 'Tərsinədir.' },
            { t: 'Hər ikisi həmişə hədəfə yaxın.', why: 'Extended dəqiq olduğu üçün mənbəyə yaxın qoyulur.' },
            { t: 'Yerləşdirmənin əhəmiyyəti yoxdur.', why: 'Yerləşdirmə trafikin lazımsız yerə getməsinə təsir edir.' },
          ] },
        { id: 'p4t1-q8', concept: 'acl-types', obj: 'Extended sətrin quruluşu',
          stem: '<p>Hansı sətir extended ACL qaydasıdır?</p>',
          options: [
            { t: 'access-list 110 permit tcp 192.168.1.0 0.0.0.255 host 10.0.0.10 eq 80', ok: true, why: 'Protocol, mənbə, hədəf və port göstərilib.' },
            { t: 'access-list 10 permit 192.168.1.0 0.0.0.255 (yalnız mənbə)', why: 'Bu standart ACL-dir, yalnız mənbə göstərilib.' },
            { t: 'interface gi0/0 ip access-group 110 in (tətbiq əmri) və bu normal sayılır', why: 'Bu ACL-i interface-ə tətbiq edən əmrdir.' },
            { t: 'show access-lists 110 (yoxlama əmri və sayğac)', why: 'Bu yoxlama əmridir.' },
          ] },
        { id: 'p4t1-q9', concept: 'acl-config', obj: 'Tətbiq',
          stem: '<p>ACL yazıb, amma heç bir trafik filtrlənmir. Ən çox rast gəlinən səbəb?</p>',
          options: [
            { t: 'ACL interface-ə tətbiq olunmayıb (ip access-group yoxdur).', ok: true, why: 'Siyahı yazılması filtrləmə üçün kifayət etmir.' },
            { t: 'Wildcard mask çox qısa yazılıb və qayda işləmir.', why: 'Səhv wildcard səhv ünvanı əhatə edər, amma ACL tətbiq olunubsa nəsə filtrlənir.' },
            { t: 'ACL nömrəsi çox böyük olduğu üçün qüvvədə deyil.', why: 'Nömrə aralığı doğrudursa problem deyil.' },
            { t: 'Router yenidən başlamalıdır, yoxsa ACL tətbiq olunmur.', why: 'ACL dərhal tətbiq olunur.' },
          ] },
        { id: 'p4t1-q10', concept: 'acl-verify', obj: 'matches',
          stem: '<p><span class="m">show access-lists</span> çıxışında <b>(12 matches)</b> nəyi göstərir?</p>',
          options: [
            { t: 'Həmin sətrə 12 paketin uyğun gəldiyini.', ok: true, why: 'Sayğac trafikin hansı qaydaya düşdüyünü göstərir.' },
            { t: 'ACL-də 12 sətir olduğunu.', why: 'Sətir sayı sıra nömrələrindən görünür.' },
            { t: 'ACL-in 12 interface-ə tətbiq olunduğunu.', why: 'Sayğac paket sayıdır.' },
            { t: 'Qaydanın 12 saniyə əvvəl yazıldığını.', why: 'Sayğac vaxt göstərmir.' },
          ] },
        { id: 'p4t1-q11', concept: 'acl-trouble', obj: 'Yanlış interface',
          stem: '<p>Extended ACL LAN 1-i serverdən bloklamalıdır, amma LAN 2 interface-ində in tətbiq edilib. Nəticə?</p>',
          options: [
            { t: 'LAN 1 trafiki bu interface-ə gəlmir, ACL onu yoxlamır.', ok: true, why: 'ACL yalnız həmin interface-ə daxil olan trafikə baxır.' },
            { t: 'ACL LAN 1-i yenə bloklayır, interface seçimi önəmli deyil.', why: 'Interface seçimi vacibdir.' },
            { t: 'Router ACL-i avtomatik düzgün interface-ə köçürür.', why: 'Router ACL-i köçürmür.' },
            { t: 'ACL LAN 2 trafikini bloklayır, LAN 1 isə keçir.', why: 'ACL LAN 1 üçün yazılıb, LAN 2 uyğun gəlmir.' },
          ] },
      ],
    },
  });
})();
