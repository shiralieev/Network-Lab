(function () {
  const pick = PT.pick; const R = PT.randInt; const shuffle = PT.shuffle;
  const norm = s => String(s).trim().toLowerCase().replace(/\s+/g, ' ');

  const MSG = [
    ['DHCP Discover (client-dən)', 'permit', 'Client mesajları untrusted portdan keçir.'],
    ['DHCP Request (client-dən)', 'permit', 'Client mesajları untrusted portdan keçir.'],
    ['DHCP Offer (server-dən)', 'drop', 'Server cavabı untrusted portdan atılır.'],
    ['DHCP ACK (server-dən)', 'drop', 'Server cavabı untrusted portdan atılır.'],
  ];

  PT.topic({
    id: 'p4t5',
    objectives: [
      'DHCP starvation və rogue DHCP server hücumlarını izah etmək',
      'DHCP snooping-in trusted və untrusted portlarını fərqləndirmək',
      'Snooping konfiqurasiyasını yazmaq və show ilə yoxlamaq',
      'Binding cədvəlini oxumaq',
      'Snooping səhvlərini simptomdan tapmaq',
    ],
    explain: PT.frag['p4/t05/explain'], cheat: PT.frag['p4/t05/cheat'],

    lab: {
      title: 'Lab 5: DHCP snooping ilə rogue server-i dayandır',
      goal: 'Hücum növlərini fərqləndirmək, trusted portları seçmək, snooping konfiqurasiyasını yazıb səhvini tapmaq, ticket həll etmək və Packet Tracer-də rogue DHCP-ni bloklamaq.',
      why: 'Rogue DHCP server şəbəkəni ələ keçirməyin ən sadə üsullarındandır. DHCP snooping ən ucuz və təsirli müdafiədir.',
      minutes: 50,
      finish: 'DHCP hücumlarını və snooping müdafiəsini bilirsən. İndi quizə keç.',
      steps: [
        { id: 's1', title: 'Hazırlıq', type: 'info', button: 'Başladım',
          body: '<p>Ssenari: SW1-in <span class="m">Gi0/1</span> portu real DHCP server-ə gedir, <span class="m">Fa0/1–Fa0/20</span> istifadəçi portlarıdır. Hücumçu Fa0/7 rozetkasına öz noutbukunu qoşub.</p>' },
        { id: 's2', title: 'Hücumu təsviri ilə birləşdir', type: 'match',
          body: '<p>Hər təsvir hansı hücumdur?</p>',
          pairs: [
            { l: 'Çoxlu saxta MAC ilə Discover göndərilir, pool tükənir', r: 'DHCP starvation', why: 'Server artıq ünvan verə bilmir.' },
            { l: 'Saxta server Offer göndərir və öz gateway-ini verir', r: 'Rogue DHCP server', why: 'Client yanlış ayarları qəbul edir.' },
            { l: 'Switch yalnız etibarlı portdan DHCP server cavabı buraxır', r: 'DHCP snooping', why: 'Müdafiə funksiyasıdır.' },
            { l: 'Saniyədə DHCP paket limiti', r: 'Rate limit', why: 'Starvation-dan qoruyur.' },
          ],
          hints: ['Starvation pool-u tükədir, rogue saxta ayar verir.'] },
        { id: 's3', title: 'Hansı portlar trusted olmalıdır?', type: 'form',
          body: '<p>SW1: Fa0/1–Fa0/20 istifadəçi PC-ləri, Gi0/1 DHCP server tərəfi, Gi0/2 digər switch-ə uplink. Cavab ver (trusted / untrusted).</p>',
          fields: [
            { label: 'Fa0/7 (istifadəçi portu)', placeholder: 'trusted / untrusted', answers: ['untrusted'], wrong: 'İstifadəçi portundan server cavabı gəlməməlidir.' },
            { label: 'Gi0/1 (DHCP server tərəfi)', placeholder: 'trusted / untrusted', answers: ['trusted'], wrong: 'Real server buradadır.' },
            { label: 'Gi0/2 (digər switch-ə uplink)', placeholder: 'trusted / untrusted', answers: ['trusted'], wrong: 'Server cavabı bu yolla gələ bilər.' },
          ],
          hints: ['Server cavabı hansı portlardan gəlməlidir?'],
          solution: 'Fa0/7 untrusted; Gi0/1 trusted; Gi0/2 trusted.' },
        { id: 's4', title: 'Mesajı portla birləşdir', type: 'form',
          body: '<p>Mesaj untrusted istifadəçi portundan gəlir. Switch nə edir (<b>permit</b> keçir, <b>drop</b> atır)?</p>',
          fields: [
            { label: 'DHCP Discover (client-dən)', placeholder: 'permit / drop', answers: ['permit', 'keçir'], wrong: 'Client mesajları keçir.' },
            { label: 'DHCP Offer (rogue server-dən)', placeholder: 'permit / drop', answers: ['drop', 'atılır'], wrong: 'Untrusted portdan server cavabı atılır.' },
            { label: 'DHCP ACK (rogue server-dən)', placeholder: 'permit / drop', answers: ['drop', 'atılır'], wrong: 'ACK də server cavabıdır.' },
            { label: 'DHCP Request (client-dən)', placeholder: 'permit / drop', answers: ['permit', 'keçir'], wrong: 'Client mesajı keçir.' },
          ],
          hints: ['Server cavabları untrusted-dən atılır.'],
          solution: 'Discover: permit; Offer: drop; ACK: drop; Request: permit.' },
        { id: 's5', title: 'Konfiqurasiyada səhvi tap', type: 'spot',
          body: '<p>Snooping qurulub, amma heç kim ünvan almır. <b>Problemi izah edən çatışmazlığı tap.</b></p>',
          lines: [
            { t: 'ip dhcp snooping' },
            { t: 'ip dhcp snooping vlan 10' },
            { t: 'interface GigabitEthernet0/1' },
            { t: ' description DHCP server', bad: true, why: 'Server tərəfindəki Gi0/1 untrusted qalıb (ip dhcp snooping trust yoxdur). Real serverin Offer-ləri bloklanır.' },
          ],
          fix: { label: 'Əlavə edəcəyin əmr', placeholder: 'əmr', answers: ['ip dhcp snooping trust'], wrong: 'Server portunu etibarlı etmək üçün.' },
          hints: ['Server tərəfi etibarlı olmalıdır.'] },
        { id: 's6', title: 'Rate limit səhvi', type: 'spot',
          body: '<p>Fa0/7 portu tez-tez err-disabled olur. Administrator rate limit qoyub. <b>Mənasız sətri tap.</b></p>',
          lines: [
            { t: 'interface range FastEthernet0/1 - 20' },
            { t: ' ip dhcp snooping limit rate 1', bad: true, why: 'Saniyədə 1 DHCP paketi həddən artıq azdır. Normal client də DORA zamanı bir neçə paket göndərir və port err-disabled olur.' },
          ],
          fix: { label: 'Daha uyğun dəyər (məs.)', placeholder: 'rəqəm', answers: ['10', '15', '20', '5'], wrong: 'Normal istifadəçi üçün kifayət edən kiçik dəyər, məsələn 10.' },
          hints: ['Normal cihaz saniyədə bir neçə DHCP paketi göndərir.'] },
        { id: 's7', title: 'Ticket: "Gateway yadplanetlidir"', type: 'ticket',
          body: '<p><b>İstifadəçi deyir:</b> "Bir neçə PC internetə çıxa bilmir və ya qəribə saytlar açır." <span class="m">ipconfig /all</span>: <span class="m">Default Gateway 192.168.10.99</span>, <span class="m">DHCP Server 192.168.10.99</span>. Real gateway və server <span class="m">192.168.10.1</span>-dir.</p>',
          stages: [
            { q: '<p>Bu nəyə işarədir?</p>', options: [
              { t: 'Şəbəkədə rogue DHCP server var: 192.168.10.99 saxta ayarlar verir.', ok: true, why: 'Real server .1-dir, cavab isə .99-dan gəlir.' },
              { t: 'Real server ünvanını dəyişib.', why: 'Real server .1 ünvanındadır.' },
              { t: 'PC-nin kabeli qırıqdır.', why: 'PC ünvan alıb, kabel işləyir.' },
              { t: 'DNS cache köhnədir.', why: 'Problem gateway və DHCP server ünvanındadır.' },
            ] },
            { q: '<p>İlk addım?</p>', options: [
              { t: '192.168.10.99-un hansı switch portunda olduğunu MAC cədvəli ilə tapıb portu izolə etmək.', ok: true, why: 'Əvvəl mənbəni tapıb dayandırırsan.' },
              { t: 'Bütün PC-lərin IP-sini statik etmək.', why: 'Bu müvəqqətidir və mənbəni aradan qaldırmır.' },
              { t: 'DHCP server-i söndürmək.', why: 'Bu real xidməti kəsir.' },
              { t: 'DNS server ünvanını dəyişmək.', why: 'Mənbə rogue serverdir.' },
            ] },
            { q: '<p>Təkrarın qarşısını almaq üçün?</p>', options: [
              { t: 'DHCP snooping açmaq, yalnız server tərəfini trusted etmək.', ok: true, why: 'Rogue server-in Offer-i untrusted portdan atılacaq.' },
              { t: 'Bütün portları trusted etmək.', why: 'Bu rogue server-i də buraxar.' },
              { t: 'DHCP lease müddətini artırmaq.', why: 'Lease müddəti hücumu dayandırmır.' },
              { t: 'VTP domain-i dəyişmək.', why: 'VTP bu hücumla əlaqəli deyil.' },
            ] },
          ],
          after: '<p>Rogue DHCP-ni aşkar edəndə DHCP Server və Default Gateway sətirlərinə bax.</p>' },
        { id: 's8', title: 'Konfiqurasiyanı özün yaz', type: 'form',
          body: '<p>VLAN 20 üçün snooping aç, Gi0/24 server portu olsun. Əmrləri yaz.</p>',
          fields: [
            { label: 'Qlobal açan əmr', placeholder: 'əmr', check: r => norm(r) === 'ip dhcp snooping', show: 'ip dhcp snooping', wrong: 'ip dhcp snooping' },
            { label: 'VLAN 20 üçün aktiv edən əmr', placeholder: 'əmr', check: r => norm(r) === 'ip dhcp snooping vlan 20', show: 'ip dhcp snooping vlan 20', wrong: 'ip dhcp snooping vlan <nömrə>' },
            { label: 'Gi0/24 portunda etibar edən əmr', placeholder: 'əmr', check: r => norm(r) === 'ip dhcp snooping trust', show: 'ip dhcp snooping trust', wrong: 'Interface rejimində yazılan əmr.' },
          ],
          solution: 'ip dhcp snooping; ip dhcp snooping vlan 20; ip dhcp snooping trust (Gi0/24-də).' },
        { id: 's9', title: 'Packet Tracer-də yoxla', type: 'ptsteps',
          body: '<p>Bir switch, real DHCP server (Gi0/1), bir PC (Fa0/1) və bir rogue server (Fa0/2) qoş.</p>',
          checks: [
            { t: 'Real server <span class="m">192.168.1.2</span>, DHCP xidməti açıq, pool gateway <span class="m">192.168.1.1</span>. Rogue server <span class="m">192.168.1.99</span>, DHCP xidməti açıq, gateway <span class="m">192.168.1.99</span>.' },
            { t: 'Snooping olmadan PC-də DHCP seç. Alınan gateway-ə bax: rogue-un cavabı gələ bilər (<span class="m">192.168.1.99</span>). Bu, hücumun nümunəsidir.' },
            { t: 'Switch-də snooping qur: <span class="m">ip dhcp snooping</span>, <span class="m">ip dhcp snooping vlan 1</span>, real server portunda <span class="m">ip dhcp snooping trust</span>.', cmd: ['ip dhcp snooping', 'ip dhcp snooping vlan 1', 'interface gi0/1', 'ip dhcp snooping trust'] },
            { t: 'PC-də DHCP-ni yenidən seç. İndi gateway <span class="m">192.168.1.1</span> olmalıdır.' },
            { t: '<span class="m">show ip dhcp snooping binding</span> yaz və PC-nin qeydini gör.', cmd: ['show ip dhcp snooping binding'] },
          ] },
        { id: 's10', title: 'Gördüyünü yaz', type: 'form',
          body: '<p>Snooping qurulandan sonra:</p>',
          fields: [
            { label: 'PC hansı gateway-i aldı?', placeholder: 'a.b.c.d', check: r => String(r).trim() === '192.168.1.1', show: '192.168.1.1', wrong: 'Real serverin ünvanı.' },
            { label: 'Rogue server-in Offer-i nə oldu? (atıldı / çatdı)', placeholder: 'seç', answers: ['atıldı', 'atildi', 'atılır'], wrong: 'Untrusted portdan server cavabı atılır.' },
          ],
          solution: '192.168.1.1; atıldı.' },
      ],
    },

    quiz: {
      draw: 8,
      gens: [
        () => {
          const it = pick(MSG); const port = pick(['untrusted', 'untrusted', 'trusted']);
          const ans = port === 'trusted' ? 'permit' : it[1];
          const why = port === 'trusted' ? 'Trusted portdan bütün DHCP mesajları keçir.' : it[2];
          return { id: 'p4t5-g-msg', concept: 'snooping-what', obj: 'Mesaj və port', _meta: { msg: it[0], port, ans },
            stem: '<p>DHCP snooping açıqdır. <b>' + it[0] + '</b> mesajı <b>' + port + '</b> portdan gəlir. Switch nə edir?</p>',
            options: [{ t: 'Keçirir (permit)', ok: ans === 'permit', why: ans === 'permit' ? why : 'Bu mesaj atılır. ' + why }, { t: 'Atır (drop)', ok: ans === 'drop', why: ans === 'drop' ? why : 'Bu mesaj keçir. ' + why }] };
        },
      ],
      pool: [
        { id: 'p4t5-q1', concept: 'dhcp-attacks', obj: 'Starvation',
          stem: '<p>DHCP starvation hücumunda nə baş verir?</p>',
          options: [
            { t: 'Hücumçu saxta MAC-lərlə pool-u tükədir, yeni cihaz ünvan ala bilmir.', ok: true, why: 'Server hər Discover-ə ünvan ayırır.' },
            { t: 'Hücumçu öz DHCP server-ini şəbəkəyə qoşub saxta ayar verir.', why: 'Bu rogue DHCP-dir.' },
            { t: 'Hücumçu gateway-in MAC ünvanını dəyişib trafiki yönləndirir.', why: 'Bu ARP spoofing-dir.' },
            { t: 'Hücumçu VLAN siyahısını silib şəbəkəni dayandırır.', why: 'Bu VTP riskidir.' },
          ] },
        { id: 'p4t5-q2', concept: 'dhcp-attacks', obj: 'Rogue DHCP',
          stem: '<p>Rogue DHCP server nəyə nail ola bilər?</p>',
          options: [
            { t: 'Clients-ə saxta gateway və DNS verib trafiki öz üzərindən keçirə bilər.', ok: true, why: 'Client ilk cavabı qəbul edir və yoxlamır.' },
            { t: 'Switch-in portlarını uzaqdan söndürüb xidməti dayandıra bilər.', why: 'DHCP portu söndürmür.' },
            { t: 'VLAN siyahısını əvəz edib portları işləməz hala sala bilər.', why: 'Bu VTP-nin işidir.' },
            { t: 'Router-in routing table-ını silib şəbəkəni kəsə bilər.', why: 'DHCP routing table-a təsir etmir.' },
          ] },
        { id: 'p4t5-q3', concept: 'dhcp-attacks', obj: 'Aşkar etmə',
          stem: '<p>ipconfig /all-da Default Gateway və DHCP Server ünvanı gözlənilməyəndir. Ən ehtimal olunan səbəb?</p>',
          options: [
            { t: 'Rogue DHCP server cavab verib.', ok: true, why: 'Real server başqa ünvandadır.' },
            { t: 'DNS cache köhnədir və yenilənməlidir.', why: 'DNS cache gateway ünvanını dəyişmir.' },
            { t: 'PC-nin kabeli zədələnib.', why: 'PC ünvan alıb.' },
            { t: 'Switch VLAN 1-dədir.', why: 'VLAN 1 anormal deyil.' },
          ] },
        { id: 'p4t5-q4', concept: 'snooping-what', obj: 'Trusted port',
          stem: '<p>Hansı portlar <b>trusted</b> olmalıdır?</p>',
          options: [
            { t: 'Real DHCP server portu və switch-lər arası uplink-lər.', ok: true, why: 'Server cavabı bu portlardan gəlir.' },
            { t: 'Bütün istifadəçi portları, çünki cihazlar onlara qoşulur.', why: 'İstifadəçi portundan server cavabı gəlməməlidir.' },
            { t: 'Yalnız istifadə olunmayan portlar, onlar ən təhlükəsizdir.', why: 'İstifadə olunmayan portlar söndürülməlidir.' },
            { t: 'Heç bir port trusted olmamalıdır, hamısı untrusted qalmalıdır.', why: 'Server tərəfi trusted olmasa, real server bloklanar.' },
          ] },
        { id: 'p4t5-q5', concept: 'snooping-what', obj: 'Untrusted davranış',
          stem: '<p>Untrusted portdan hansı DHCP mesajları <b>atılır</b>?</p>',
          options: [
            { t: 'Server cavabları: Offer və ACK.', ok: true, why: 'İstifadəçi portundan server cavabı gəlməməlidir.' },
            { t: 'Client mesajları: Discover və Request.', why: 'Client mesajları normal keçir.' },
            { t: 'Bütün DHCP mesajları.', why: 'Client DHCP istəyə bilməlidir.' },
            { t: 'Heç biri.', why: 'Snooping məhz server cavablarını bloklayır.' },
          ] },
        { id: 'p4t5-q6', concept: 'snooping-what', obj: 'Default',
          stem: '<p>Snooping açılandan sonra portların default vəziyyəti?</p>',
          options: [
            { t: 'Hamısı untrusted.', ok: true, why: 'Administrator server tərəfini trusted edir.' },
            { t: 'Hamısı trusted.', why: 'Onda rogue server buraxılar.' },
            { t: 'Yarısı trusted, yarısı untrusted.', why: 'Belə default yoxdur.' },
            { t: 'Portlar söndürülür.', why: 'Snooping portu söndürmür.' },
          ] },
        { id: 'p4t5-q7', concept: 'snooping-binding', obj: 'Binding cədvəli',
          stem: '<p>DHCP snooping binding cədvəlində nə saxlanılır?</p>',
          options: [
            { t: 'MAC, IP, VLAN, port və lease məlumatı.', ok: true, why: 'Kimə hansı ünvan hansı portda verildi.' },
            { t: 'Yalnız VLAN adları və VLAN nömrələri.', why: 'VLAN adları show vlan brief-də görünür.' },
            { t: 'Router-in routing marşrutları və AD dəyərləri.', why: 'Marşrutlar routing table-dadır.' },
            { t: 'DNS record-ları və onların TTL dəyərləri.', why: 'DNS record-lar DNS server-dədir.' },
          ] },
        { id: 'p4t5-q8', concept: 'snooping-config', obj: 'Əmr',
          stem: '<p>Porta etibar etmək üçün interface rejimində hansı əmr yazılır?</p>',
          options: [
            { t: 'ip dhcp snooping trust', ok: true, why: 'Porta etibar edir.' },
            { t: 'ip dhcp snooping vlan 10', why: 'Bu VLAN üçün funksiyanı açır.' },
            { t: 'ip dhcp snooping limit rate 10', why: 'Bu paket limitidir.' },
            { t: 'ip helper-address 10.0.0.10', why: 'Bu DHCP relay əmridir.' },
          ] },
        { id: 'p4t5-q9', concept: 'snooping-config', obj: 'Rate limit',
          stem: '<p><span class="m">ip dhcp snooping limit rate 10</span> nəyə qarşı qoruyur?</p>',
          options: [
            { t: 'Starvation-a: port saniyədə çox DHCP paketi göndərəndə err-disabled olur.', ok: true, why: 'Çoxlu Discover gəldikdə pool tükənmədən dayandırılır.' },
            { t: 'Rogue server-ə: onun saxta Offer-lərini switch-də atır və nəticə həmişə eynidir.', why: 'Rogue-dan trusted/untrusted qoruyur.' },
            { t: 'ARP spoofing-ə: ARP frame-lərini switch yoxlayıb atır və bu normal sayılır.', why: 'ARP spoofing üçün başqa müdafiə var.' },
            { t: 'VLAN hopping-ə: DTP-ni dayandırıb portu access edir.', why: 'VLAN hopping DTP ilə əlaqəlidir.' },
          ] },
        { id: 'p4t5-q10', concept: 'snooping-verify', obj: 'Heç kim ünvan almır',
          stem: '<p>DHCP snooping açıldıqdan sonra heç bir PC ünvan almır. İlk yoxlama?</p>',
          options: [
            { t: 'Real DHCP server tərəfindəki portun trusted olması.', ok: true, why: 'Server cavabları untrusted portdan atılır.' },
            { t: 'PC-lərin DNS ayarının doğru yazılması.', why: 'DNS ünvan almağa təsir etmir.' },
            { t: 'Switch-in hostname-inin dəyişdirilməsi.', why: 'Hostname təsir etmir.' },
            { t: 'Router-in OSPF ayarının yoxlanması.', why: 'OSPF DHCP ilə əlaqəli deyil.' },
          ] },
      ],
    },
  });
})();
