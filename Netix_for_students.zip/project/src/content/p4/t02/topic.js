(function () {
  const pick = PT.pick; const R = PT.randInt; const shuffle = PT.shuffle;
  const norm = s => String(s).trim().toLowerCase().replace(/\s+/g, ' ');

  const MODES = [
    { m: 'protect', drop: 'atılır', log: 'yoxdur', port: 'işləməyə davam edir' },
    { m: 'restrict', drop: 'atılır', log: 'var', port: 'işləməyə davam edir' },
    { m: 'shutdown', drop: 'port söndürülür', log: 'var', port: 'err-disabled olur' },
  ];

  PT.topic({
    id: 'p4t2',
    objectives: [
      'Port security-nin nəyi qoruduğunu və harada işlədiyini demək',
      'maximum, sticky və violation əmrlərini yazmaq',
      'Üç violation rejimini fərqləndirmək',
      'err-disabled portu yenidən açmaq',
      'show port-security çıxışını oxumaq',
    ],
    explain: PT.frag['p4/t02/explain'], cheat: PT.frag['p4/t02/cheat'],

    lab: {
      title: 'Lab 2: Port security-ni qur və pozuntunu araşdır',
      goal: 'Port security əmrlərini yazmaq, violation rejimlərini ayırmaq, show çıxışında vəziyyəti oxumaq, err-disabled ticket-ini həll etmək və Packet Tracer-də test etmək.',
      why: 'Ofis switch-lərində boş rozetkalar və icazəsiz cihazlar real təhlükədir. Port security ən sadə müdafiə üsuludur.',
      minutes: 45,
      finish: 'Port security-ni qura və pozuntunu həll edə bilirsən. İndi quizə keç.',
      steps: [
        { id: 's1', title: 'Hazırlıq', type: 'info', button: 'Başladım',
          body: '<p>Ssenari: SW1-in <span class="m">Fa0/1</span> portuna bir PC qoşulub. Hər porta yalnız bir MAC icazəli olmalıdır. Pozuntuda port söndürülməlidir.</p>' },
        { id: 's2', title: 'Rejimi davranışı ilə birləşdir', type: 'match',
          body: '<p>Hər violation rejimi nə edir?</p>',
          pairs: [
            { l: '<span class="m">protect</span>', r: 'İcazəsiz trafiki atır, log yazmır', why: 'Sakit rejimdir.' },
            { l: '<span class="m">restrict</span>', r: 'İcazəsiz trafiki atır, log və sayğac yazır', why: 'Port işləməyə davam edir.' },
            { l: '<span class="m">shutdown</span>', r: 'Portu err-disabled edir', why: 'Default rejimdir.' },
            { l: '<span class="m">sticky</span>', r: 'MAC-i avtomatik öyrənib running-config-ə yazır', why: 'Əllə yazmaq lazım olmur.' },
          ],
          hints: ['Shutdown ən sərtdir, protect ən yumşaqdır.'] },
        { id: 's3', title: 'Konfiqurasiyanı yaz', type: 'form',
          body: '<p>Fa0/5 portu: yalnız 2 MAC, sticky öyrənmə, pozuntuda restrict. Əmrləri yaz (boşluqlar önəmli deyil).</p>',
          fields: [
            { label: 'Funksiyanı açan əmr', placeholder: 'əmr', check: r => norm(r) === 'switchport port-security', show: 'switchport port-security', wrong: 'switchport port-security' },
            { label: 'Maksimum 2 MAC', placeholder: 'əmr', check: r => norm(r) === 'switchport port-security maximum 2', show: 'switchport port-security maximum 2', wrong: 'switchport port-security maximum <say>' },
            { label: 'Sticky öyrənmə', placeholder: 'əmr', check: r => norm(r) === 'switchport port-security mac-address sticky', show: 'switchport port-security mac-address sticky', wrong: 'switchport port-security mac-address sticky' },
            { label: 'Violation restrict', placeholder: 'əmr', check: r => norm(r) === 'switchport port-security violation restrict', show: 'switchport port-security violation restrict', wrong: 'switchport port-security violation <rejim>' },
          ],
          hints: ['Əvvəl port access rejimində olmalıdır.'],
          solution: 'switchport port-security / ... maximum 2 / ... mac-address sticky / ... violation restrict.' },
        { id: 's4', title: 'Konfiqurasiyada səhvi tap', type: 'spot',
          body: '<p>Port security qurulub, amma əmr xəta verir və funksiya işləmir. <b>Problemi tap.</b></p>',
          lines: [
            { t: 'interface FastEthernet0/1' },
            { t: ' switchport mode trunk', bad: true, why: 'Port security trunk portda qəbul edilmir. Port access rejimində olmalıdır.' },
            { t: ' switchport port-security' },
            { t: ' switchport port-security maximum 1' },
          ],
          fix: { label: 'Düzgün port rejimi', placeholder: 'rejim', answers: ['access', 'switchport mode access'], wrong: 'Son istifadəçi cihazı qoşulan port hansı rejimdədir?' },
          hints: ['Port security access portu qoruyur.'] },
        { id: 's5', title: 'show port-security oxu', type: 'form',
          pre: 'SW1#show port-security interface fa0/1\nPort Security              : Enabled\nPort Status                : Secure-shutdown\nViolation Mode             : Shutdown\nMaximum MAC Addresses      : 1\nTotal MAC Addresses        : 1\nSticky MAC Addresses       : 1\nSecurity Violation Count   : 1',
          body: '<p>Çıxışa bax.</p>',
          fields: [
            { label: 'Port hazırda işləyirmi? (bəli / xeyr)', placeholder: 'bəli / xeyr', answers: ['xeyr', 'yox', 'no'], wrong: 'Secure-shutdown portun söndürüldüyünü göstərir.' },
            { label: 'Neçə pozuntu olub?', placeholder: 'rəqəm', check: r => String(r).trim() === '1', show: '1', wrong: 'Security Violation Count.' },
            { label: 'Violation rejimi', placeholder: 'rejim', answers: ['shutdown'], wrong: 'Violation Mode sətri.' },
          ],
          hints: ['Port Status Secure-shutdown deməkdir.'],
          solution: 'Xeyr (söndürülüb), 1 pozuntu, rejim shutdown.' },
        { id: 's6', title: 'Ticket: "Portum söndü"', type: 'ticket',
          body: '<p><b>İstifadəçi deyir:</b> "Dünən işləyən PC-m bu gün şəbəkəyə qoşulmur. Kabel yerindədir." Switch portu ilə problem var. <span class="m">show interfaces status</span>: <span class="m">Fa0/3 err-disabled</span>.</p>',
          stages: [
            { q: '<p>err-disabled nə deməkdir?</p>', options: [
              { t: 'Port xəta səbəbindən avtomatik söndürülüb, məsələn port security pozuntusu.', ok: true, why: 'Violation shutdown rejimi portu err-disabled edir.' },
              { t: 'Kabel qırıqdır.', why: 'Kabel problemi down/down olur, err-disabled yox.' },
              { t: 'Port əl ilə söndürülüb (administratively down).', why: 'Bu başqa haldır. err-disabled avtomatikdir.' },
              { t: 'Port trunk rejimindədir.', why: 'Trunk err-disabled yaratmır.' },
            ] },
            { q: '<p>Səbəbi necə tapırsan?</p>', options: [
              { t: 'show port-security interface fa0/3: violation sayğacına və son MAC-ə bax.', ok: true, why: 'Bu əmr pozuntunu göstərir.' },
              { t: 'show vlan brief: portun VLAN-ına bax.', why: 'VLAN err-disabled səbəbi deyil.' },
              { t: 'show ip route: marşrutlara bax.', why: 'Marşrut switch portunun söndürülməsinə aid deyil.' },
              { t: 'ipconfig /all: PC-nin DNS ayarına bax.', why: 'DNS port statusuna təsir etmir.' },
            ] },
            { q: '<p>Səbəb: işçi yeni noutbuk qoşub (limit 1). Portu necə açırsan?</p>', options: [
              { t: 'İcazəsiz cihazı çıxarıb interface-də shutdown, sonra no shutdown yazıram.', ok: true, why: 'Əvvəl səbəb aradan qaldırılır, sonra port yenidən açılır.' },
              { t: 'Yalnız no shutdown yazıram, cihaz qalsın.', why: 'Cihaz qalsa pozuntu təkrar olunar və port yenə söndürülər.' },
              { t: 'Switch-i yenidən başladıram.', why: 'Bu bütün istifadəçiləri kəsir və səbəb qalır.' },
              { t: 'Port security-ni bütün portlarda silirəm.', why: 'Bu təhlükəsizliyi azaldır və lazımsızdır.' },
            ] },
          ],
          after: '<p>Metod: err-disabled gördünsə, əvvəl səbəbi tap, sonra portu aç.</p>' },
        { id: 's7', title: 'Qərar: IP telefon və PC', type: 'choice',
          body: '<p>Bir masada IP telefon var və PC telefonun arxasındakı porta qoşulur. Hər ikisi switch portundan bir kabelle çıxır. Port security üçün maximum neçə olmalıdır?</p>',
          options: [
            { t: '2: telefon və PC iki ayrı MAC ünvanı göstərir.', ok: true, why: 'Hər cihaz öz MAC ünvanı ilə görünür.' },
            { t: '1: bir kabel var, deməli bir cihaz.', why: 'Telefonun arxasında PC də var, ikisi də MAC göstərir.' },
            { t: '0: port security lazım deyil.', why: 'Limit 0 cihazlara icazə vermir.' },
            { t: '10: ehtiyat üçün.', why: 'Böyük limit qorumanı zəiflədir.' },
          ],
          hints: ['Hər cihazın öz MAC ünvanı var.'] },
        { id: 's8', title: 'Packet Tracer-də yoxla', type: 'ptsteps',
          body: '<p>Bir switch və iki PC (PC1 və PC2) qoş.</p>',
          checks: [
            { t: 'PC1 Fa0/1-ə qoşulsun. Fa0/1: <span class="m">switchport mode access</span>, <span class="m">switchport port-security</span>, <span class="m">maximum 1</span>, <span class="m">mac-address sticky</span>, <span class="m">violation shutdown</span>.', cmd: ['interface fa0/1', 'switchport mode access', 'switchport port-security', 'switchport port-security maximum 1', 'switchport port-security mac-address sticky', 'switchport port-security violation shutdown'] },
            { t: 'PC1-dən ping at (məsələn PC2-yə) ki, MAC öyrənilsin. <span class="m">show port-security interface fa0/1</span> yaz: Secure-up.', cmd: ['show port-security interface fa0/1'] },
            { t: 'PC1-in kabelini çıxarıb PC2-ni Fa0/1-ə qoş. PC2-dən ping at.' },
            { t: 'Port link işığı qırmızı (err-disabled) olmalıdır. <span class="m">show interfaces status</span> və <span class="m">show port-security interface fa0/1</span> yaz.', cmd: ['show interfaces status'] },
            { t: 'PC1-i geri qoş, interface-də <span class="m">shutdown</span>, <span class="m">no shutdown</span> yaz. Port yenidən işləməlidir.', cmd: ['shutdown', 'no shutdown'] },
          ] },
        { id: 's9', title: 'Gördüyünü yaz', type: 'form',
          body: '<p>PC2 Fa0/1-ə qoşulandan sonra:</p>',
          fields: [
            { label: 'Port statusu', placeholder: 'status', answers: ['err-disabled', 'errdisabled', 'secure-shutdown'], wrong: 'Violation shutdown rejimi portu söndürür.' },
            { label: 'Portu açmaq üçün iki əmr', placeholder: 'əmrlər', check: r => /shutdown/.test(norm(r)) && /no shutdown/.test(norm(r)), show: 'shutdown, sonra no shutdown', wrong: 'Əvvəl shutdown, sonra no shutdown.' },
          ],
          solution: 'err-disabled; shutdown və no shutdown.' },
      ],
    },

    quiz: {
      draw: 8,
      gens: [
        () => {
          const m = pick(MODES); const aspect = pick(['log', 'port']);
          const lbl = aspect === 'log' ? 'Log mesajı və pozuntu sayğacı' : 'Port statusu';
          const val = aspect === 'log' ? (m.log === 'var' ? 'Var' : 'Yoxdur') : (m.port === 'err-disabled olur' ? 'Port err-disabled olur' : 'Port işləməyə davam edir');
          const opts = aspect === 'log' ? ['Var', 'Yoxdur'] : ['Port err-disabled olur', 'Port işləməyə davam edir'];
          return { id: 'p4t2-g-mode', concept: 'ps-violation', obj: 'Violation rejimi', _meta: { mode: m.m, aspect },
            stem: '<p>Violation rejimi <span class="m">' + m.m + '</span>-dir. İcazəsiz MAC görünəndə: <b>' + lbl + '</b>?</p>',
            options: opts.map(o => ({ t: o, ok: o === val, why: o === val ? m.m + ' rejimində: trafik ' + m.drop + ', log ' + m.log + ', port ' + m.port + '.' : m.m + ' rejimində: log ' + m.log + ', port ' + m.port + '.' })) };
        },
      ],
      pool: [
        { id: 'p4t2-q1', concept: 'ps-what', obj: 'Port security məqsədi',
          stem: '<p>Port security nəyi məhdudlaşdırır?</p>',
          options: [
            { t: 'Portda hansı MAC ünvanlarının işləyəcəyini.', ok: true, why: 'İcazəsiz cihaz və MAC flooding-dən qoruyur.' },
            { t: 'Portda hansı IP ünvanlarının işləyə biləcəyini.', why: 'Port security MAC ünvanına əsaslanır, IP-yə yox.' },
            { t: 'Portdan keçən trafikin sürətinin nə qədər olacağını.', why: 'Sürət məhdudiyyəti başqa funksiyadır.' },
            { t: 'Portun hansı VLAN-a aid olacağını və necə adlanacağını.', why: 'VLAN təyini ayrıca əmrlə edilir.' },
          ] },
        { id: 'p4t2-q2', concept: 'ps-what', obj: 'Port rejimi',
          stem: '<p>Port security hansı port rejimində işləyir?</p>',
          options: [
            { t: 'Access rejimində.', ok: true, why: 'Trunk və dinamik portlarda əmr qəbul edilmir.' },
            { t: 'Trunk rejimində.', why: 'Trunk portda port security qəbul edilmir.' },
            { t: 'Hər iki rejimdə eyni.', why: 'Yalnız access portda dəstəklənir.' },
            { t: 'Yalnız routed portlarda.', why: 'Port security switch portu üçündür.' },
          ] },
        { id: 'p4t2-q3', concept: 'ps-config', obj: 'Default',
          stem: '<p>Port security açılıb, əlavə heç nə yazılmayıb. Default maximum və violation?</p>',
          options: [
            { t: 'Maximum 1, violation shutdown.', ok: true, why: 'Bu default dəyərlərdir.' },
            { t: 'Maximum 2, violation restrict.', why: 'Default limit 1-dir.' },
            { t: 'Maximum 10, violation protect.', why: 'Bu default deyil.' },
            { t: 'Limit yoxdur, violation yoxdur.', why: 'Port security açılanda default dəyərlər tətbiq olunur.' },
          ] },
        { id: 'p4t2-q4', concept: 'ps-config', obj: 'sticky',
          stem: '<p><span class="m">mac-address sticky</span> nə edir?</p>',
          options: [
            { t: 'Portda gördüyü MAC-i öyrənir, running-config-ə yazır.', ok: true, why: 'MAC-ləri əllə yazmaq lazım olmur.' },
            { t: 'MAC ünvanını həmişəlik dəyişməz edir və qoruyur.', why: 'Sticky yalnız öyrənmə metodudur.' },
            { t: 'MAC-i startup-config-ə avtomatik saxlayır.', why: 'Saxlamaq üçün copy running-config startup-config lazımdır.' },
            { t: 'İcazəsiz MAC görünəndə portu dərhal söndürür.', why: 'Söndürmə violation rejiminin işidir.' },
          ] },
        { id: 'p4t2-q5', concept: 'ps-violation', obj: 'protect',
          stem: '<p>Hansı violation rejimi trafiki atır, amma log yazmır və portu söndürmür?</p>',
          options: [
            { t: 'protect', ok: true, why: 'Sakit atır.' },
            { t: 'restrict', why: 'restrict log və sayğac yazır.' },
            { t: 'shutdown', why: 'shutdown portu söndürür.' },
            { t: 'sticky', why: 'sticky violation rejimi deyil.' },
          ] },
        { id: 'p4t2-q6', concept: 'ps-violation', obj: 'restrict',
          stem: '<p>restrict rejimi ilə shutdown arasındakı fərq?</p>',
          options: [
            { t: 'restrict portu söndürmür, shutdown isə err-disabled edir.', ok: true, why: 'İkisi də log yazır, amma restrict port işləməyə davam edir.' },
            { t: 'restrict portu söndürür, shutdown isə söndürmür.', why: 'Tərsinədir.' },
            { t: 'Heç bir fərq yoxdur, ikisi də eyni işi görür.', why: 'Port statusu fərqlidir.' },
            { t: 'restrict yalnız trunk portda işləyir, shutdown isə access portda.', why: 'Port security access portda işləyir.' },
          ] },
        { id: 'p4t2-q7', concept: 'ps-violation', obj: 'err-disabled açmaq',
          stem: '<p>Port err-disabled oldu. İcazəsiz cihaz çıxarılıb. Portu necə açırsan?</p>',
          options: [
            { t: 'Interface-də shutdown, sonra no shutdown yazmaq.', ok: true, why: 'Port yenidən başladılır.' },
            { t: 'Switch-i bütövlükdə yenidən başladırsan.', why: 'Bu lazımsız və təsirlidir.' },
            { t: 'Portun kabelini yeni kabellə dəyişirsən.', why: 'Kabel problem deyil.' },
            { t: 'Portun VLAN-ını silib yenidən yaradırsan.', why: 'VLAN err-disabled-ə aid deyil.' },
          ] },
        { id: 'p4t2-q8', concept: 'ps-verify', obj: 'Port status',
          stem: '<p><span class="m">show port-security interface fa0/1</span>-də Port Status <span class="m">Secure-shutdown</span> yazır. Nə deməkdir?</p>',
          options: [
            { t: 'Port pozuntu səbəbindən söndürülüb.', ok: true, why: 'Violation shutdown rejimi işləyib.' },
            { t: 'Port normal işləyir və cihaz qoşulub.', why: 'Normal hal Secure-up-dur.' },
            { t: 'Port security funksiyası söndürülüb.', why: 'Funksiya açıqdır.' },
            { t: 'Port trunk rejimində işləyir.', why: 'Trunk-da port security yoxdur.' },
          ] },
        { id: 'p4t2-q9', concept: 'ps-trouble', obj: 'Telefon və PC',
          stem: '<p>IP telefon və onun arxasında PC bir porta qoşulur. Maximum 1-dir. Nə baş verir?</p>',
          options: [
            { t: 'İkinci MAC limiti aşır və port söndürülür.', ok: true, why: 'İki cihaz iki MAC göstərir.' },
            { t: 'Heç nə baş vermir, çünki yalnız bir kabel var.', why: 'MAC sayı kabelin sayına görə hesablanmır.' },
            { t: 'Telefon öz ünvanını avtomatik olaraq dəyişir.', why: 'MAC ünvanı dəyişmir.' },
            { t: 'Switch yeni VLAN yaradır və cihazları ayırır.', why: 'VLAN pozuntuya cavab deyil.' },
          ] },
      ],
    },
  });
})();
