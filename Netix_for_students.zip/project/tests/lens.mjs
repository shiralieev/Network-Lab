// prints option lengths for a topic pool + one sample of each generator; marks the correct option. usage: node tests/lens.mjs p1t6
import { createRequire } from 'node:module';
import path from 'node:path'; import fs from 'node:fs'; import { fileURLToPath } from 'node:url';
const require = createRequire('/opt/npm-tools/'); const { chromium } = require('playwright');
const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const file = 'file://' + path.join(root, 'dist', JSON.parse(fs.readFileSync(path.join(root, 'src/config.json'))).outFile);
const id = process.argv[2] || 'p1t6';
const b = await chromium.launch(); const p = await b.newPage(); await p.goto(file + '#/home'); await p.waitForTimeout(300);
const r = await p.evaluate(id => { const T = PT.topics[id]; const strip = s => String(s).replace(/<[^>]+>/g, ''); const rows = [];
  const add = q => { if (q.type && q.type !== 'mc') return; const L = q.options.map(o => strip(o.t).length); const ok = q.options.findIndex(o => o.ok); const rank = L.filter(x => x > L[ok]).length; rows.push({ id: q.id, L: L.join(','), okLen: L[ok], rankFromLongest: rank, n: L.length }); };
  T.quiz.pool.forEach(add); T.quiz.gens.forEach(g => { for (let k = 0; k < 8; k++) add(g()); }); return rows; }, id);
const agg = [0, 0, 0, 0]; r.forEach(x => { agg[x.rankFromLongest]++; console.log(x.id.padEnd(22), 'ok=' + x.okLen, 'lens=' + x.L, 'rank=' + x.rankFromLongest); });
console.log('rank histogram (0=longest):', agg.join(' '));
await b.close();
