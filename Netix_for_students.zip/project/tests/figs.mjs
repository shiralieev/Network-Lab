// screenshots every .figure / [data-sim] on a route (unlocked) for visual review. usage: node tests/figs.mjs /p1/p1t3/explain outDir [theme] [width]
import { createRequire } from 'node:module';
import path from 'node:path'; import fs from 'node:fs'; import { fileURLToPath } from 'node:url';
const require = createRequire('/opt/npm-tools/'); const { chromium } = require('playwright');
const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const file = 'file://' + path.join(root, 'dist', JSON.parse(fs.readFileSync(path.join(root, 'src/config.json'))).outFile);
const route = process.argv[2]; const out = process.argv[3]; const theme = process.argv[4] || 'light'; const width = +(process.argv[5] || 1366);
fs.mkdirSync(out, { recursive: true });
const b = await chromium.launch(); const ctx = await b.newContext({ viewport: { width, height: 900 }, colorScheme: theme }); const p = await ctx.newPage();
const errs = []; p.on('pageerror', e => errs.push(e.message)); p.on('console', m => { if (m.type() === 'error') errs.push(m.text()); });
await p.goto(file + '#/home'); await p.evaluate(() => { PT.order().forEach(id => { PT.progress.data.unlocked[id] = true; }); PT.progress.save(); });
await p.goto(file + '#' + route); await p.reload(); await p.waitForTimeout(400);
const els = await p.locator('.figure, [data-sim], .pre, details.box').all(); let n = 0;
for (const e of els) { try { await e.scrollIntoViewIfNeeded(); await e.screenshot({ path: path.join(out, `${theme}_${width}_${String(n).padStart(2, '0')}.png`) }); n++; } catch (x) { } }
console.log('shots', n, 'errors', errs.length, errs.slice(0, 5));
await b.close();
