import { createRequire } from 'node:module';
const require = createRequire('/opt/npm-tools/'); const { chromium } = require('playwright');
const f='file:///mnt/user-data/outputs/pt-platform-src/dist/Packet_Tracer_Sifirdan_Pesekara.html';
const b=await chromium.launch(); const p=await (await b.newContext()).newPage(); const errs=[]; p.on('pageerror',e=>errs.push(e.message));
await p.goto(f+'#/home'); await p.waitForTimeout(300);
const res=await p.evaluate(()=>{
  const S=id=>PT.topics.p1t9.lab.steps.find(s=>s.id===id); const out=[];
  const t=(id,k,v)=>{ const fl=S(id).fields[k]; let r; if(fl.check) r=fl.check(v); else r=fl.answers.some(a=>a.toLowerCase()===String(v).trim().toLowerCase()); out.push(id+'.f'+k+' '+JSON.stringify(v)+' -> '+(r&&r.ok===false?'note':!!(r&&r.ok!==undefined?r.ok:r))); };
  t('s6',0,'xəta yoxdur'); t('s6',0,'invalid'); t('s6',0,'ok'); t('s6',0,'book'); t('s6',1,'Ambiguous'); t('s6',2,'incomplete'); t('s6',3,'invalid'); t('s6',4,'Invalid input');
  t('s7',0,'up up'); t('s7',0,'up/up'); t('s7',1,'administratively down / down'); t('s7',1,'administratively down down'); t('s7',2,'down down'); t('s7',3,'Up Up'); t('s7',0,'down down');
  t('s10',0,'DIST-SW#'); t('s10',0,'dist-sw#'); t('s10',0,'DIST-SW>'); t('s10',1,'Printer'); t('s10',1,'printer'); t('s10',2,'administratively down/down'); t('s10',3,'no shutdown'); t('s10',3,'No  Shutdown'); t('s10',4,'xeyr'); t('s10',4,'bəli');
  t('s15',0,'up up'); t('s15',1,'4'); t('s15',1,'3'); t('s15',1,'2');
  t('s17',0,'administratively down'); t('s17',0,'down'); t('s17',1,'xeyr'); t('s17',2,'no shutdown');
  return out; });
console.log(res.join('\n')); console.log('errs',errs); await b.close();
