import { createRequire } from 'node:module';
const require = createRequire('/opt/npm-tools/'); const { chromium } = require('playwright');
const f='file:///mnt/user-data/outputs/pt-platform-src/dist/Packet_Tracer_Sifirdan_Pesekara.html';
const b=await chromium.launch(); const ctx=await b.newContext({viewport:{width:1000,height:900}}); const p=await ctx.newPage(); const errs=[]; p.on('pageerror',e=>errs.push(e.message)); p.on('console',m=>{ if(m.type()==='error') errs.push('console:'+m.text()); });
await p.goto(f+'#/home'); await p.waitForTimeout(300);
async function run(stepId, cmds){
  await p.evaluate((id)=>{ const st=PT.topics.p1t9.lab.steps.find(s=>s.id===(id==='s11b'?'s11':id)); const c=document.createElement('div'); c.style.cssText='width:900px;padding:10px'; document.body.innerHTML=''; document.body.appendChild(c); window.__st=st; window.__api=PT.mountTerminal(c, Object.assign({}, st.term, {onChange: d=>{window.__dev=d; window.__st.term.goals.forEach(g=>{try{g.test(d)}catch(e){}});}})); window.__st=st; }, stepId);
  const inp=await p.$('.term-input');
  for(const cmd of cmds){ await inp.click(); await inp.fill(''); await inp.type(cmd,{delay:5}); if(!cmd.endsWith('?')) await inp.press('Enter'); else { await inp.press('Enter'); } await p.waitForTimeout(40); }
  const info=await p.evaluate(()=>{ const goals=window.__st.term.goals.map(g=>{ try{return (g.test(window.__dev)?'OK ':'-- ')+g.text.replace(/<[^>]+>/g,'').slice(0,80);}catch(e){return 'ERR '+e.message;} }); const items=[...document.querySelectorAll('li')].filter(li=>/goal|done|ok/i.test(li.className)||li.querySelector('.goal-mark')); return {goals, out:document.querySelector('.term-body').innerText.slice(-700), keys:Object.keys(window.__api||{}), goalDom:[...document.querySelectorAll('[class*=goal]')].slice(0,12).map(e=>e.tagName+'.'+e.className+':'+e.innerText.replace(/\s+/g,' ').slice(0,70))}; });
  return info;
}
const which=process.argv[2];
const T={
 s3:['enable','configure terminal','hostname SW1','end','show running-config'],
 s4:['?','show ?','show ip ?','sh?'],
 s5:['show','show ipp','e'],
 s8:['show ip interface brief','show interfaces status'],
 s9:['enable','configure terminal','interface fa0/2','description PC-B','shutdown','end','show ip interface brief','configure terminal','interface fa0/2','no shutdown','end','show ip interface brief'],
 s11:['enable','configure terminal','hostname LAB-SW','end','reload','no','','enable','configure terminal','hostname LAB-SW','end','copy running-config startup-config','','reload',''],
 s11b:['enable','configure terminal','hostname LAB-SW','end','copy running-config startup-config','','reload','','enable','erase startup-config','','reload','no',''],
 s13:['show ip interface brief','enable','configure terminal','interface fa0/2','no shutdown','end','show ip interface brief','copy running-config startup-config',''],
};
const r=await run(which,T[which]); console.log(r.out.slice(-420)); console.log(r.goals.join('\n'));
console.log('errs',errs); await b.close();
