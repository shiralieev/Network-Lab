import { createRequire } from 'node:module';
const require = createRequire('/opt/npm-tools/'); const { chromium } = require('playwright');
const f='file:///mnt/user-data/outputs/pt-platform-src/dist/Packet_Tracer_Sifirdan_Pesekara.html';
const S=process.argv[2];
const b=await chromium.launch(); const p=await (await b.newContext({viewport:{width:1100,height:900}})).newPage(); const errs=[]; p.on('pageerror',e=>errs.push(e.message));
await p.goto(f+'#/home'); await p.evaluate(()=>{PT.order().forEach(id=>{PT.progress.data.unlocked[id]=true}); PT.progress.save();});
await p.goto(f+'#/p1/p1t9/quiz'); await p.reload(); await p.waitForTimeout(300);
await p.evaluate(()=>{ window.__prep=[]; const o=PT.quiz.prepare; PT.quiz.prepare=function(q){ const r=o.apply(this,arguments); window.__prep.push(r); return r; }; });
const start=await p.$('button.btn-primary'); console.log('start btn:', await start.innerText()); await start.click(); await p.waitForTimeout(200);
const n=await p.evaluate(()=>window.__prep.length); console.log('questions', n);
for(let i=0;i<n;i++){
  const idx=await p.evaluate(i=>{ const q=window.__prep[i]; return {type:q.type, ok:(q.options||[]).findIndex(o=>o.ok), nopt:(q.options||[]).length}; }, i);
  const btns=await p.$$('.opts button, .opts .opt, button.opt'); 
  if(i===0) console.log('qtype',idx, 'buttons', btns.length);
  await btns[idx.ok].click(); await p.waitForTimeout(100);
  await p.click('button:has-text("Yoxla")'); await p.waitForTimeout(120);
  const labels=await p.evaluate(()=>[...document.querySelectorAll('.btn-primary')].map(b=>b.innerText)); if(i===0) console.log('after check buttons',labels);
  if(i===0){ console.log(await p.evaluate(()=>[...document.querySelectorAll('.btn-primary')].map(b=>b.innerText+'|vis='+(b.offsetParent!==null)+'|cls='+b.className+'|parent='+b.parentElement.className))); await p.screenshot({path:S+'/q9dbg.png'}); }
  await p.evaluate(()=>document.querySelector('.q-actions .btn-primary:not(.hide)').click()); await p.waitForTimeout(150);
}
await p.waitForTimeout(400);
console.log((await p.evaluate(()=>{const e=document.querySelector('.q-result, .result, .res'); return e? e.innerText : document.body.innerText.slice(-900);})).slice(0,900));
await p.screenshot({path:S+'/q9pass.png', fullPage:false});
console.log('errors',errs); await b.close();
