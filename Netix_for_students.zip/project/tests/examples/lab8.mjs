import { createRequire } from 'node:module';
const require = createRequire('/opt/npm-tools/'); const { chromium } = require('playwright');
const f='file:///mnt/user-data/outputs/pt-platform-src/dist/Packet_Tracer_Sifirdan_Pesekara.html';
const b=await chromium.launch(); const p=await (await b.newContext({viewport:{width:1100,height:900}})).newPage(); const errs=[]; p.on('pageerror',e=>errs.push(e.message));
await p.goto(f+'#/home'); await p.evaluate(()=>{PT.order().forEach(id=>{PT.progress.data.unlocked[id]=true}); const t=PT.progress.topic('p1t8'); ['s1','s2','s3'].forEach(k=>t.labSteps[k]=true); PT.progress.save();});
await p.goto(f+'#/p1/p1t8/lab'); await p.reload(); await p.waitForTimeout(400);
async function openStep(){ return await p.evaluate(()=>{const s=document.querySelector('.lstep:not(.is-done):not(.is-future)'); return s? s.id+' | '+s.querySelector('.lstep-title').innerText:null}); }
console.log('open:',await openStep());
// s4, s5 ptsteps
for(const id of ['s4','s5']){ const sel='#lab-'+id; const boxes=await p.$$(sel+' input[type=checkbox]'); for(const c of boxes) await c.check(); await p.click(sel+' .btn-primary'); await p.waitForTimeout(200); console.log('after',id,'->',await openStep()); }
// s6 wrong then right
const fill=async(id,vals)=>{ for(let i=0;i<vals.length;i++){ const inp=await p.$('#'+id+'-f'+i); if(inp && !(await inp.isDisabled())) await inp.fill(vals[i]); } await p.click('#lab-'+id+' .btn-primary:has-text("Yoxla")'); await p.waitForTimeout(200); const nx=await p.$('#lab-'+id+' .hint-bar .btn-primary:not(.hide)'); if(nx && /Davam|Növbəti|Keç/.test(await nx.innerText())){ await nx.click(); await p.waitForTimeout(200);} };
await fill('s6',['hello','0001.C7A1.5D32']); console.log('s6 wrong ->',await p.evaluate(()=>[...document.querySelectorAll('#lab-s6 .fine')].map(e=>e.innerText).join(' || ')));
await fill('s6',['0001.C7A1.5D32','0001.C7A1.5D32']); console.log('s6 same ->',await p.evaluate(()=>[...document.querySelectorAll('#lab-s6 .fine')].map(e=>e.innerText).join(' || ')));
{ const i0=await p.$('#s6-f0'); await i0.fill('00-60-2F-3A-07-BC'); await p.click('#lab-s6 .btn-primary:has-text("Yoxla")'); await p.waitForTimeout(200); const nx=await p.$('#lab-s6 .hint-bar .btn-primary:not(.hide)'); if(nx){console.log('continue btn:',await nx.innerText()); await nx.click(); await p.waitForTimeout(200);} } console.log('after s6 ->',await openStep());
await fill('s7',['2','1','1','2','1']); console.log('after s7 ->',await openStep());
{ const sel='#lab-s8'; const boxes=await p.$$(sel+' input[type=checkbox]'); for(const c of boxes) await c.check(); await p.click(sel+' .btn-primary'); await p.waitForTimeout(200); console.log('after s8 ->',await openStep()); }
await fill('s9',['FFFF.FFFF.FFFF','PC-A','xeyr']); console.log('after s9 ->',await openStep());
await fill('s10',['2','1','xeyr']); console.log('after s10 ->',await openStep());
console.log('errors',errs); await b.close();
