import sys, json
f=sys.argv[1]; pairs=json.load(open(sys.argv[2]))
s=open(f,encoding='utf-8').read(); bad=0
for old,new in pairs:
    c=s.count(old)
    if c!=1: print('FAIL',c,old[:70]); bad+=1; continue
    s=s.replace(old,new)
open(f,'w',encoding='utf-8').write(s); print('applied',len(pairs)-bad,'failed',bad)
