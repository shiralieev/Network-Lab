import { createRequire } from 'node:module';
const require = createRequire('/opt/npm-tools/'); const { chromium } = require('playwright');
const f='file:///mnt/user-data/outputs/pt-platform-src/dist/Packet_Tracer_Sifirdan_Pesekara.html';
const b=await chromium.launch(); const p=await (await b.newContext({viewport:{width:1100,height:900}})).newPage(); const errs=[]; p.on('pageerror',e=>errs.push(e.message));
await p.goto(f+'#/home'); await p.evaluate(()=>{PT.order().forEach(id=>{PT.progress.data.unlocked[id]=true}); PT.progress.save();});
for(let i=1;i<=9;i++){ for(const tab of ['explain','cheat','lab']){ await p.goto(f+'#/p1/p1t'+i+'/'+tab); await p.reload(); await p.waitForTimeout(250);
  const r=await p.evaluate(()=>{ const g=[...document.querySelectorAll('.gl')]; const inMono=g.filter(x=>x.closest('.m,pre,code,.cmd-table,.term-body')).length; return {n:g.length, inMono, terms:g.map(x=>x.dataset.term).slice(0,60).join(', ')}; });
  console.log('t'+i,tab,r.n,'mono:',r.inMono, tab==='explain'&&i%4===1?r.terms:''); } }
console.log('errors',errs); await b.close();
