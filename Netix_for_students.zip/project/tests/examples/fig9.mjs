import { createRequire } from 'node:module';
const require = createRequire('/opt/npm-tools/'); const { chromium } = require('playwright');
const f='file:///mnt/user-data/outputs/pt-platform-src/dist/Packet_Tracer_Sifirdan_Pesekara.html';
const b=await chromium.launch(); const p=await (await b.newContext({viewport:{width:390,height:800}})).newPage();
await p.goto(f+'#/home'); await p.evaluate(()=>{PT.order().forEach(id=>{PT.progress.data.unlocked[id]=true}); PT.progress.save();});
await p.goto(f+'#/p1/p1t9/explain'); await p.reload(); await p.waitForTimeout(300);
const figs=await p.$$('.figure'); console.log('figures',figs.length);
for(let i=0;i<figs.length;i++){ const r=await figs[i].evaluate(e=>({sw:e.scrollWidth,cw:e.clientWidth,svg:e.querySelector('svg')?.getBoundingClientRect().width})); console.log(i,JSON.stringify(r)); }
const idx=await p.evaluate(()=>[...document.querySelectorAll('.figure')].findIndex(f=>f.querySelector('svg[viewBox="0 0 760 250"]')));
console.log('idx',idx); if(idx>=0){ await figs[idx].scrollIntoViewIfNeeded(); await figs[idx].screenshot({path:'/tmp/claude-0/-home-claude/107565f3-4b67-5291-83ec-590343f11743/scratchpad/fig9_phone.png'}); }
await b.close();
