import { createRequire } from 'node:module';
const require = createRequire('/opt/npm-tools/'); const { chromium } = require('playwright');
const f='file:///mnt/user-data/outputs/pt-platform-src/dist/Packet_Tracer_Sifirdan_Pesekara.html';
const S=process.argv[2];
const b=await chromium.launch(); const p=await (await b.newContext({viewport:{width:1100,height:900}})).newPage(); const errs=[]; p.on('pageerror',e=>errs.push(e.message));
await p.goto(f+'#/home'); await p.evaluate(()=>{PT.order().forEach(id=>{PT.progress.data.unlocked[id]=true}); const t=PT.progress.topic('p1t9'); for(let i=1;i<=13;i++) t.labSteps['s'+i]=true; PT.progress.save();});
await p.goto(f+'#/p1/p1t9/lab'); await p.reload(); await p.waitForTimeout(400);
async function openStep(){ return await p.evaluate(()=>{const s=document.querySelector('.lstep:not(.is-done):not(.is-future)'); return s? s.id+' | '+s.querySelector('.lstep-title').innerText:null}); }
console.log('open:',await openStep());
await (await p.$('#lab-s14')).screenshot({path:S+'/s14.png'});
for(const id of ['s14']){ const sel='#lab-'+id; const boxes=await p.$$(sel+' input[type=checkbox]'); for(const c of boxes) await c.check(); await p.click(sel+' .btn-primary'); await p.waitForTimeout(200); console.log('after',id,'->',await openStep()); }
const fill=async(id,vals)=>{ for(let i=0;i<vals.length;i++){ const inp=await p.$('#'+id+'-f'+i); if(inp && !(await inp.isDisabled())) await inp.fill(vals[i]); } await p.click('#lab-'+id+' .btn-primary:has-text("Yoxla")'); await p.waitForTimeout(200); const nx=await p.$('#lab-'+id+' .hint-bar .btn-primary:has-text("Davam")'); if(nx){ await nx.click(); await p.waitForTimeout(200);} };
await fill('s15',['up up','4']); console.log('after s15 ->',await openStep());
{ const sel='#lab-s16'; const boxes=await p.$$(sel+' input[type=checkbox]'); for(const c of boxes) await c.check(); await p.click(sel+' .btn-primary'); await p.waitForTimeout(200); console.log('after s16 ->',await openStep()); }
await fill('s17',['administratively down','xeyr','no shutdown']); console.log('after s17 ->',await openStep());
console.log('lab done text:', await p.evaluate(()=>document.body.innerText.includes('Hissə 1-in sonudur')));
console.log('errors',errs); await b.close();
