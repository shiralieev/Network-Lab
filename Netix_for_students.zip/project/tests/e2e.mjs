// Loads the built file in headless Chromium, collects console errors and external requests, takes screenshots.
import { createRequire } from 'node:module';
import path from 'node:path'; import fs from 'node:fs'; import { fileURLToPath } from 'node:url';
const require = createRequire('/opt/npm-tools/');
const { chromium } = require('playwright');
const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const file = 'file://' + path.join(root, 'dist', JSON.parse(fs.readFileSync(path.join(root, 'src/config.json'))).outFile);
const outDir = process.argv[2] || path.join(root, 'tests', 'shots'); fs.mkdirSync(outDir, { recursive: true });
const routes = (process.argv[3] || '/home').split(',');
const sizes = [['desk', 1366, 900], ['phone', 390, 800]];
const errors = []; const external = [];
const browser = await chromium.launch();
for (const theme of ['light', 'dark']) for (const [sn, w, hgt] of sizes) {
  const ctx = await browser.newContext({ viewport: { width: w, height: hgt }, colorScheme: theme });
  const page = await ctx.newPage();
  page.on('console', m => { if (m.type() === 'error' || m.type() === 'warning') errors.push(`[${theme}/${sn}] ${m.type()}: ${m.text()}`); });
  page.on('pageerror', e => errors.push(`[${theme}/${sn}] pageerror: ${e.message}`));
  page.on('request', r => { const u = r.url(); if (!u.startsWith('file:') && !u.startsWith('data:')) external.push(u); });
  await page.goto(file + '#/home'); await page.evaluate(() => { PT.order().forEach(id => { PT.progress.data.unlocked[id] = true; }); PT.progress.save(); });
  for (const rt of routes) {
    await page.goto(file + '#' + rt); await page.reload(); await page.waitForTimeout(250);
    const name = `${theme}_${sn}_${rt.replace(/[^\w]+/g, '_')}.png`;
    await page.screenshot({ path: path.join(outDir, name), fullPage: true });
  }
  await ctx.close();
}
await browser.close();
console.log('errors:', errors.length); errors.slice(0, 20).forEach(e => console.log(' ', e));
console.log('external requests:', external.length); external.slice(0, 5).forEach(e => console.log(' ', e));
process.exit(errors.length || external.length ? 1 : 0);
