// Mounts every simulator in a blank page, clicks around, reports JS errors, takes screenshots.
import { createRequire } from 'node:module';
import path from 'node:path'; import fs from 'node:fs'; import { fileURLToPath } from 'node:url';
const require = createRequire('/opt/npm-tools/');
const { chromium } = require('playwright');
const root = path.dirname(path.dirname(fileURLToPath(import.meta.url)));
const file = 'file://' + path.join(root, 'dist', 'Packet_Tracer_Sifirdan_Pesekara.html');
const outDir = process.argv[2] || path.join(root, 'tests', 'shots'); fs.mkdirSync(outDir, { recursive: true });
const theme = process.argv[3] || 'light';
const browser = await chromium.launch(); const ctx = await browser.newContext({ viewport: { width: 1180, height: 900 }, colorScheme: theme }); const page = await ctx.newPage();
const errs = []; page.on('pageerror', e => errs.push(String(e))); page.on('console', m => { if (m.type() === 'error') errs.push(m.text()); });
await page.goto(file + '#/home');
await page.evaluate(() => { PT.fast = true; document.body.innerHTML = '<div id="t" style="padding:16px;max-width:1000px;margin:0 auto"></div>'; });
const sims = [['bitgrid', {}], ['samenet', {}], ['splitnet', {}], ['macview', {}], ['encap', {}], ['hexdump', { frame: 'icmp' }], ['hexdump', { frame: 'arp' }], ['cast', {}], ['arpsim', {}], ['switchsim', {}], ['ptui', {}], ['pingttl', {}], ['anat', { parts: [{ t: 'interface', k: 'kw', d: 'x' }, { t: 'fa0/1', k: 'arg', d: 'y' }], mode: '(config)#', effect: 'z', proof: 'show', undo: 'no' }], ['climodes', {}]];
let i = 0;
for (const [name, opts] of sims) {
  i++;
  await page.evaluate(({ name, opts }) => { const t = document.getElementById('t'); t.innerHTML = ''; const el = document.createElement('div'); t.append(el); PT.sims[name](el, opts); }, { name, opts });
  // generic clicking: click every chip/button once (except Reset-ish) to look for runtime errors
  const n = await page.evaluate(() => document.querySelectorAll('#t button, #t select').length);
  for (let k = 0; k < Math.min(n, 40); k++) {
    await page.evaluate(k => { const els = document.querySelectorAll('#t button'); const e = els[k % els.length]; if (e && !e.disabled) e.click(); }, k);
    await page.waitForTimeout(15);
  }
  await page.screenshot({ path: path.join(outDir, `sim_${theme}_${String(i).padStart(2, '0')}_${name}.png`), fullPage: true });
}
console.log(errs.length ? 'ERRORS:\n' + errs.join('\n') : 'no errors');
await browser.close(); process.exit(errs.length ? 1 : 0);
