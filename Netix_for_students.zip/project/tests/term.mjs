// Transcript tests for the practice terminal (runs in headless Chromium against dist HTML)
import { createRequire } from 'node:module';
import path from 'node:path'; import { fileURLToPath } from 'node:url';
const require = createRequire('/opt/npm-tools/');
const { chromium } = require('playwright');
const root = path.dirname(path.dirname(fileURLToPath(import.meta.url)));
const file = 'file://' + path.join(root, 'dist', 'Packet_Tracer_Sifirdan_Pesekara.html');
const browser = await chromium.launch(); const page = await browser.newPage();
const errs = []; page.on('pageerror', e => errs.push(String(e))); page.on('console', m => { if (m.type() === 'error') errs.push(m.text()); });
await page.goto(file + '#/home');
let fails = 0;
const T = async (name, cfg, cmds, check) => {
  const r = await page.evaluate(({ cfg, cmds }) => {
    const host = document.createElement('div'); document.body.append(host);
    const c = PT.mountTerminal(host, Object.assign({}, cfg));
    const out = [];
    for (const cmd of cmds) { if (cmd.startsWith('?:')) c.help(cmd.slice(2)); else c.run(cmd); }
    const lines = Array.from(host.querySelectorAll('.term-body .ln')).map(x => x.textContent.replace(/ /g, ' '));
    const d = c.dev; const res = { lines, mode: d.mode, host: d.run.hostname, prompt: d.prompt(), unsaved: d.unsaved(), startHas: d.start ? d.cfgLines(d.start).join('|') : null, runLines: d.cfgLines(d.run).join('|'), ifs: Object.fromEntries(d.listIfs().map(n => [n, d.iface(n)])) };
    host.remove(); return res;
  }, { cfg, cmds });
  let ok = true, why = '';
  try { const x = check(r); if (x !== true) { ok = false; why = String(x); } } catch (e) { ok = false; why = e.message; }
  console.log((ok ? 'PASS ' : 'FAIL ') + name + (ok ? '' : '  -> ' + why + '\n' + r.lines.join('\n')));
  if (!ok) fails++;
};
const has = (r, s) => r.lines.some(l => l.includes(s));

await T('basic modes', {}, ['enable', 'configure terminal', 'hostname SW1', 'exit'], r => r.prompt === 'SW1#' || 'prompt=' + r.prompt);
await T('abbrev conf t', {}, ['en', 'conf t', 'int fa0/1', 'shut'], r => (r.mode === 'if' && r.ifs.FastEthernet0Slash1 === undefined && r.ifs['FastEthernet0/1'].shut) || 'mode=' + r.mode);
await T('invalid caret', {}, ['enable', 'show runn x'], r => has(r, "% Invalid input detected at '^' marker.") || 'no invalid');
await T('caret column', {}, ['enable', 'show xyz'], r => { const i = r.lines.findIndex(l => l.includes("Invalid input")); return r.lines[i - 1] === ' '.repeat('Switch#'.length + 5) + '^' || 'caret=' + JSON.stringify(r.lines[i - 1]); });
await T('incomplete', {}, ['enable', 'show'], r => has(r, '% Incomplete command.') || 'x');
await T('ambiguous', {}, ['enable', 'conf t', 'e'], r => has(r, '% Ambiguous command:  "e"') || 'x');
await T('unknown word exec', {}, ['shw'], r => has(r, 'Translating "shw"') && has(r, '% Unknown command or computer name') || 'x');
await T('no ip domain-lookup', {}, ['en', 'conf t', 'no ip domain-lookup', 'end', 'shw'], r => !has(r, 'Translating') && has(r, '% Unknown command') || 'x');
await T('user cannot show run', {}, ['show running-config'], r => has(r, "% Invalid input detected") || 'x');
await T('router if shutdown default', { kind: 'router', cables: { 'gi0/0': 'PC1' } }, ['en', 'show ip interface brief'], r => has(r, 'administratively down') || 'x');
await T('router no shut + ip', { kind: 'router', cables: { 'gi0/0': 'PC1' } }, ['en', 'conf t', 'int gi0/0', 'ip address 192.168.1.1 255.255.255.0', 'no shutdown', 'end', 'show ip int br'], r => { const i = r.ifs['GigabitEthernet0/0']; return (i.status === 'up' && i.proto === 'up' && i.ip === '192.168.1.1') || JSON.stringify(i); });
await T('no cable -> down/down', { kind: 'router' }, ['en', 'conf t', 'int gi0/1', 'no shut'], r => { const i = r.ifs['GigabitEthernet0/1']; return (i.status === 'down' && i.proto === 'down') || JSON.stringify(i); });
await T('switch port ip address invalid', {}, ['en', 'conf t', 'int fa0/1', 'ip address 1.1.1.1 255.255.255.0'], r => has(r, "Invalid input detected") || 'x');
await T('vlan1 ip', { cables: { 'fa0/1': 'PC1' } }, ['en', 'conf t', 'int vlan 1', 'ip address 10.0.0.2 255.255.255.0', 'no shut'], r => (r.ifs.Vlan1.status === 'up' && r.ifs.Vlan1.ip === '10.0.0.2') || JSON.stringify(r.ifs.Vlan1));
await T('bad mask', { kind: 'router' }, ['en', 'conf t', 'int gi0/0', 'ip address 192.168.1.1 255.0.255.0'], r => has(r, 'Invalid input') || 'x');
await T('save prompts', {}, ['en', 'conf t', 'hostname X', 'end', 'copy running-config startup-config', ''], r => r.startHas && r.startHas.includes('hostname X') && has(r, '[OK]') && !r.unsaved || 'x');
await T('write memory', {}, ['en', 'conf t', 'hostname Y', 'end', 'write memory'], r => r.startHas.includes('hostname Y') || 'x');
await T('reload without save loses config', {}, ['en', 'conf t', 'hostname LOST', 'end', 'reload', 'no', ''], r => r.host === 'Switch' && r.mode === 'user' || 'host=' + r.host + ' mode=' + r.mode);
await T('reload with save keeps config', {}, ['en', 'conf t', 'hostname KEPT', 'end', 'reload', 'yes', ''], r => r.host === 'KEPT' || 'host=' + r.host);
await T('reload asks save only if modified', {}, ['en', 'reload'], r => !has(r, 'System configuration has been modified') && r.prompt.includes('Proceed with reload?') || 'x');
await T('erase startup', {}, ['en', 'conf t', 'hostname Z', 'end', 'wr', 'erase startup-config', '', 'reload', 'no', ''], r => r.host === 'Switch' || 'host=' + r.host);
await T('do show from config', {}, ['en', 'conf t', 'do show ip int br'], r => has(r, 'Interface') && r.mode === 'config' || 'x');
await T('no description', {}, ['en', 'conf t', 'int fa0/1', 'description to PC1 office', 'no description'], r => r.ifs['FastEthernet0/1'].desc === '' || r.ifs['FastEthernet0/1'].desc);
await T('description rest text', {}, ['en', 'conf t', 'int fa0/1', 'description to PC1 office'], r => r.ifs['FastEthernet0/1'].desc === 'to PC1 office' || r.ifs['FastEthernet0/1'].desc);
await T('help ?', {}, ['?:'], r => has(r, 'enable') && has(r, 'show') || 'x');
await T('help show ?', {}, ['en', '?:show '], r => has(r, 'running-config') || 'x');
await T('help word?', {}, ['en', '?:co'], r => has(r, 'configure') && has(r, 'copy') || 'x');
await T('interface fa 0/1 with space', {}, ['en', 'conf t', 'interface fa 0/1'], r => r.mode === 'if' || 'mode=' + r.mode);
await T('interface bad', {}, ['en', 'conf t', 'interface fa9/9'], r => has(r, '% Invalid interface type and number') || 'x');
await T('ping self ip', { kind: 'router', cables: { 'gi0/0': 'PC1' } }, ['en', 'conf t', 'int gi0/0', 'ip address 10.0.0.1 255.255.255.0', 'no shut', 'end', 'ping 10.0.0.1'], r => has(r, '!!!!!') || 'x');
await T('mac table', { macs: [{ mac: '0001.4321.AAAA', port: 'Fa0/1' }] }, ['en', 'show mac address-table'], r => has(r, '0001.4321.aaaa') && has(r, 'Total Mac Addresses for this criterion: 1') || 'x');
await T('clear mac', { macs: [{ mac: '0001.4321.AAAA', port: 'Fa0/1' }] }, ['en', 'clear mac address-table dynamic', 'show mac address-table'], r => has(r, 'criterion: 0') || 'x');
await T('shutdown port shows disabled', { cables: { 'fa0/1': 'PC1' } }, ['en', 'conf t', 'int fa0/1', 'shutdown', 'end', 'show interfaces status'], r => has(r, 'disabled') || 'x');
await T('initial config copy startup', { initial: { hostname: 'SW9' } }, ['en'], r => !r.unsaved && r.prompt === 'SW9#' || 'x');
console.log(errs.length ? 'PAGE ERRORS:\n' + errs.join('\n') : 'no page errors');
console.log(fails ? fails + ' FAILED' : 'ALL PASSED');
await browser.close(); process.exit(fails ? 1 : 0);
