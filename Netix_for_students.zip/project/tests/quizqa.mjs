// Quiz/lab QA for one or more topics: structural validation + generator dump (for the Python check) + length-bias stats.
// usage: node tests/quizqa.mjs p1t2[,p1t3...] [dumpFile]
import { createRequire } from 'node:module';
import path from 'node:path'; import fs from 'node:fs'; import { fileURLToPath } from 'node:url';
const require = createRequire('/opt/npm-tools/');
const { chromium } = require('playwright');
const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const file = 'file://' + path.join(root, 'dist', JSON.parse(fs.readFileSync(path.join(root, 'src/config.json'))).outFile);
const ids = (process.argv[2] || 'p1t1').split(','); const dump = process.argv[3];
const browser = await chromium.launch(); const page = await browser.newPage();
const errs = []; page.on('pageerror', e => errs.push(e.message)); page.on('console', m => { if (m.type() === 'error') errs.push(m.text()); });
await page.goto(file + '#/home'); await page.waitForTimeout(300);
const res = await page.evaluate(ids => {
  const out = { problems: [], stats: {}, gen: [] };
  const strip = s => String(s).replace(/<[^>]+>/g, '');
  for (const id of ids) {
    const T = PT.topics[id]; if (!T) { out.problems.push(id + ': topic not registered'); continue; }
    const frag = T.explain || ''; const headIds = new Set([...String(frag).matchAll(/<h[23][^>]*id="([^"]+)"/g)].map(m => m[1]));
    const seen = new Set(); let longest = 0, shortest = 0, mcCount = 0, mcN = 0;
    const lenTell = (opts, tag) => { if (!opts || opts.length < 3) return; const L = opts.map(o => strip(o.t).length); const ok = opts.findIndex(o => o.ok); if (ok < 0) return; const others = L.filter((_, i) => i !== ok); const mx = Math.max(...others); if (L[ok] >= 1.2 * mx && L[ok] - mx >= 8) out.problems.push(`${tag}: correct option is much longer than every distractor (${L[ok]} vs max ${mx})`); const mn = Math.min(...others); if (L[ok] * 1.5 <= mn && mn - L[ok] >= 10) out.problems.push(`${tag}: correct option is much shorter than every distractor (${L[ok]} vs min ${mn})`); };
    const checkQ = (q, tag) => {
      if (!q.id) out.problems.push(`${id} ${tag}: no id`); if (seen.has(q.id) && tag === 'pool') out.problems.push(`${id}: duplicate id ${q.id}`); seen.add(q.id);
      if (!q.stem) out.problems.push(`${id} ${q.id}: no stem`);
      if (!q.concept) out.problems.push(`${id} ${q.id}: no concept`); else if (headIds.size && !headIds.has(q.concept)) out.problems.push(`${id} ${q.id}: concept '${q.concept}' not an explanation heading id`);
      if (!q.obj) out.problems.push(`${id} ${q.id}: no obj`);
      const type = q.type || 'mc';
      if (type === 'mc') {
        const ok = (q.options || []).filter(o => o.ok); if (ok.length !== 1) out.problems.push(`${id} ${q.id}: ${ok.length} correct options`);
        (q.options || []).forEach((o, i) => { if (!o.why || strip(o.why).length < 25) out.problems.push(`${id} ${q.id}: option ${i} weak/missing why`); });
        if ((q.options || []).length < 2) out.problems.push(`${id} ${q.id}: <2 options`);
        const txt = new Set((q.options || []).map(o => o.t)); if (txt.size !== (q.options || []).length) out.problems.push(`${id} ${q.id}: duplicate option text`);
        lenTell(q.options, `${id} ${q.id}`);
        if ((q.options || []).length >= 3) { mcN++; const L = q.options.map(o => strip(o.t).length); const m = Math.max(...L); if (q.options.find(o => o.ok) && strip(q.options.find(o => o.ok).t).length === m && L.filter(x => x === m).length === 1) longest++; const mnn = Math.min(...L); if (q.options.find(o => o.ok) && strip(q.options.find(o => o.ok).t).length === mnn && L.filter(x => x === mnn).length === 1) shortest++; }
      } else if (type === 'num') { if (typeof q.check !== 'function') out.problems.push(`${id} ${q.id}: num without check`); if (!q.solution) out.problems.push(`${id} ${q.id}: num without solution`); }
    };
    (T.quiz.pool || []).forEach(q => checkQ(q, 'pool'));
    for (let k = 0; k < 60; k++) (T.quiz.gens || []).forEach(g => { const q = g(); checkQ(q, 'gen'); if (q._meta) out.gen.push({ topic: id, id: q.id, meta: q._meta, ok: typeof q.check === 'function' ? (q._meta.ans !== undefined ? q.check(String(q._meta.ans)) : null) : null }); });
    out.stats[id] = { pool: (T.quiz.pool || []).length, gens: (T.quiz.gens || []).length, mc3plus: mcN, correctIsUniquelyLongest: longest, correctIsUniquelyShortest: shortest };
    // labs
    const L = T.lab; if (!L) out.problems.push(id + ': no lab'); else (L.steps || []).forEach(s => {
      if (!s.id || !s.title || !s.type) out.problems.push(`${id} lab step ${s.id}: missing id/title/type`);
      if (s.type === 'choice') { lenTell(s.options, `${id} lab ${s.id}`); const ok = s.options.filter(o => o.ok); if (ok.length !== 1) out.problems.push(`${id} lab ${s.id}: ${ok.length} correct`); s.options.forEach((o, i) => { if (!o.why) out.problems.push(`${id} lab ${s.id}: option ${i} no why`); }); }
      if (s.type === 'form') s.fields.forEach((f, i) => { if (!f.check && !f.answers) out.problems.push(`${id} lab ${s.id}: field ${i} no check`); });
    });
  }
  return out;
}, ids);
console.log('page errors:', errs.length); errs.slice(0, 10).forEach(e => console.log('  ', e));
console.log('stats:', JSON.stringify(res.stats));
console.log('problems:', res.problems.length); res.problems.slice(0, 60).forEach(p => console.log('  -', p));
const bad = res.gen.filter(g => g.ok === false); console.log('generator self-check failures (own answer rejected):', bad.length);
if (dump) fs.writeFileSync(dump, JSON.stringify(res.gen));
await browser.close(); process.exit(errs.length || res.problems.length || bad.length ? 1 : 0);
