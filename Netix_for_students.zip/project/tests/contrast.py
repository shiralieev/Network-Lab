#!/usr/bin/env python3
"""Checks WCAG contrast of the colour pairs actually used in text, for both themes."""
import re, sys, pathlib
css = pathlib.Path(__file__).resolve().parent.parent.joinpath('src/css/10_tokens.css').read_text()

def block(sel):
    m = re.search(re.escape(sel) + r'\s*\{(.*?)\}', css, re.S)
    return dict(re.findall(r'--([\w-]+)\s*:\s*(#[0-9A-Fa-f]{6})', m.group(1)))

light = block(':root'); dark = {**light, **block('[data-theme="dark"]')}

def lum(h):
    r, g, b = [int(h[i:i+2], 16) / 255 for i in (1, 3, 5)]
    f = lambda c: c / 12.92 if c <= 0.03928 else ((c + 0.055) / 1.055) ** 2.4
    return 0.2126 * f(r) + 0.7152 * f(g) + 0.0722 * f(b)
def cr(a, b):
    la, lb = lum(a), lum(b)
    if la < lb: la, lb = lb, la
    return (la + 0.05) / (lb + 0.05)

# (foreground, background, minimum ratio, what)
PAIRS = [
 ('ink','bg',4.5,'body on page'), ('ink','panel',4.5,'body on panel'), ('ink','panel-2',4.5,'body on panel-2'),
 ('ink-2','panel',4.5,'secondary on panel'), ('ink-2','bg',4.5,'secondary on page'), ('ink-2','panel-2',4.5,'secondary on panel-2'),
 ('ink-3','panel',4.5,'muted on panel'), ('ink-3','bg',4.5,'muted on page'), ('ink-3','panel-2',4.5,'muted on panel-2'),
 ('blue','panel',4.5,'link on panel'), ('blue','bg',4.5,'link on page'), ('blue','blue-soft',4.5,'link on blue-soft'),
 ('btn-ink','btn',4.5,'primary button text'), ('yel-ink','yel',4.5,'yellow chip text'),
 ('ink','blue-soft',4.5,'text on blue-soft'), ('ink','yel-soft',4.5,'text on yellow-soft'),
 ('ink','ok-soft',4.5,'text on ok-soft'), ('ink','bad-soft',4.5,'text on bad-soft'), ('ink','warn-soft',4.5,'text on warn-soft'),
 ('ok','ok-soft',4.5,'ok label on ok-soft'), ('bad','bad-soft',4.5,'bad label on bad-soft'), ('warn','warn-soft',4.5,'warn label on warn-soft'),
 ('ok','panel',4.5,'ok label on panel'), ('bad','panel',4.5,'bad label on panel'), ('warn','panel',4.5,'warn label on panel'),
 ('bad','panel-2',4.5,'bad label on panel-2'), ('ok','panel-2',4.5,'ok label on panel-2'),
 ('term-ink','term-bg',4.5,'terminal text'), ('term-dim','term-bg',4.5,'terminal dim'), ('term-prompt','term-bg',4.5,'terminal prompt'),
 ('term-ok','term-bg',4.5,'terminal ok'), ('term-bad','term-bg',4.5,'terminal err'),
 ('term-dim','term-bar',4.5,'terminal bar text'), ('term-ink','term-bar',4.5,'terminal bar ink'), ('term-ink','term-mark',4.5,'terminal hover'),
 ('jack-edge','panel',3.0,'jack outline (UI)'), ('led-off','panel',3.0,'LED off (state)'), ('line','panel',1.4,'border (decor)'),
 ('btn','panel',3.0,'primary as UI accent on panel'), ('ok','panel',3.0,'ok as UI colour'),
]
bad = 0
for name, th in (('light', light), ('dark', dark)):
    for fg, bgk, minr, what in PAIRS:
        r = cr(th[fg], th[bgk])
        flag = 'OK ' if r >= minr else 'LOW'
        if r < minr: bad += 1
        if flag == 'LOW' or '-v' in sys.argv:
            print(f'{name:5} {flag} {r:5.2f} (min {minr}) {fg} on {bgk}: {what}  [{th[fg]} / {th[bgk]}]')
print('contrast problems:', bad)
sys.exit(1 if bad else 0)
