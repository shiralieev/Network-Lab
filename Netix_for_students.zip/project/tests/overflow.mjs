import { createRequire } from 'node:module';
const require = createRequire('/opt/npm-tools/'); const { chromium } = require('playwright');
import path from 'node:path'; import fs from 'node:fs'; import { fileURLToPath } from 'node:url';
const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const f = 'file://' + path.join(root, 'dist', JSON.parse(fs.readFileSync(path.join(root, 'src/config.json'))).outFile);
// phone/tablet overflow check over Part 1. EDIT the topic loop range when new topics get content.
const b=await chromium.launch(); let bad=0, n=0;
for(const [theme,w] of [['light',390],['dark',390],['light',768],['dark',1366]]){
  const p=await (await b.newContext({viewport:{width:w,height:800},colorScheme:theme})).newPage(); const errs=[]; p.on('pageerror',e=>errs.push(e.message));
  await p.goto(f+'#/home'); await p.evaluate(()=>{PT.order().forEach(id=>{PT.progress.data.unlocked[id]=true}); PT.progress.save();});
  for(let i=1;i<=9;i++) for(const t of ['explain','cheat','lab','quiz']){ await p.goto(f+'#/p1/p1t'+i+'/'+t); await p.reload(); await p.waitForTimeout(120); n++;
    const r=await p.evaluate(()=>{ const de=document.documentElement; const wide=[...document.querySelectorAll('body *')].filter(e=>{const r=e.getBoundingClientRect(); return r.right>de.clientWidth+2 && r.width>0 && !e.closest('.rack-tabs,pre,.tbl-wrap,.term-body,.cmd-line,svg,.figure,table,.sim,[data-sim],.state-body')}).slice(0,3).map(e=>e.tagName+'.'+e.className); return {sw:de.scrollWidth, cw:de.clientWidth, wide}; });
    if(r.sw>r.cw+1 || r.wide.length){ bad++; console.log(theme,w,'p1t'+i,t,JSON.stringify(r)); } }
  if(errs.length) console.log('errs',theme,w,errs.slice(0,3));
}
console.log('checked',n,'bad',bad); await b.close();
