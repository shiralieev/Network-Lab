// TEMPLATE for src/content/<part>/<tNN>/topic.js  (folder p2/t01 -> topic id 'p2t1').
// Copy it, rename ids, write Azerbaijani content. It is NOT built while it lives in templates/.
// Model on a finished topic: src/content/p1/t05/topic.js (generators + pool), src/content/p1/t09/topic.js (terminal labs).
(function () {
  const A = PT.addr;                                    // IP/MAC math helpers (see src/js/80_simkit.js)
  const R = n => PT.randInt(n), pick = PT.pick, shuffle = PT.shuffle;
  const e = PT.esc, m = s => '<span class="m">' + e(s) + '</span>';

  PT.topic({
    id: 'p2t1',
    objectives: [
      'Birinci məqsəd: ölçülə bilən fel ilə (izah etmək, tapmaq, düzəltmək)',
      'İkinci məqsəd',
      'Üçüncü məqsəd',
    ],
    explain: PT.frag['p2/t01/explain'],
    cheat: PT.frag['p2/t01/cheat'],

    // ---------------------------------------------------------------- LAB
    lab: {
      title: 'Lab N: qısa ad',
      goal: 'Lab-ın sonunda tələbə nəyi bacaracaq.',
      why: 'Bu bacarıq işdə (helpdesk / network / SOC) harada lazım olur.',
      minutes: 40,
      finish: 'Bitirdin. İndi quizə keç.',
      steps: [
        // info: text + continue button
        { id: 's1', title: 'Hazırlıq', type: 'info', button: 'Hazıram, davam et',
          body: '<p>Nə edəcəksən və nəyi açmalısan (Packet Tracer topologiyası və s.).</p>' },

        // choice: renderer shuffles the options; exactly one ok:true
        { id: 's2', title: 'Qərar ver', type: 'choice',
          body: '<p>Vəziyyət: ... Hansı fikir düzgündür?</p>',
          options: [
            { t: 'Düzgün cavab.', ok: true, why: 'Qayda... Niyə... Burada...' },
            { t: 'Real yanlış təsəvvür 1.', why: 'Bu niyə yanlışdır.' },
            { t: 'Real yanlış təsəvvür 2.', why: 'Bu niyə yanlışdır.' },
          ],
          hints: ['Kiçik işarə.'], after: '<p>Nəyi yadda saxlamalı.</p>' },

        // form: typed answers. Use anchored regex in check; label has no trailing colon.
        { id: 's3', title: 'Hesabla və yaz', type: 'form',
          body: '<p>Tapşırıq mətni.</p>',
          fields: [
            { label: 'Cavab 1', placeholder: 'məs. 192.168.1.0', check: raw => raw.trim() === '192.168.1.0', wrong: 'Niyə düz deyil və hara baxmalı.' },
            { label: 'Bəli / xeyr', answers: ['bəli', 'beli', 'yes'], wrong: 'İpucu.' },
          ],
          hints: ['Yüngül ipucu.', 'Demək olar cavab.'],
          solution: 'Tam həll və səbəbi.', after: '<p>Metod.</p>' },

        // order: items listed in the CORRECT order; the UI shuffles them
        { id: 's4', title: 'Sıraya düz', type: 'order',
          body: '<p>Addımları düzgün sırayla düz.</p>',
          items: [{ t: 'Birinci addım', why: 'Niyə birinci.' }, { t: 'İkinci addım', why: 'Niyə ikinci.' }, { t: 'Üçüncü addım', why: 'Niyə sonuncu.' }],
          hints: ['İlk addım hansıdır?'] },

        // terminal: practice IOS-like terminal. Goals re-run on every change; one-time events need sticky flags on dev.mark.
        { id: 's5', title: 'Router-də qur', type: 'terminal',
          body: '<p>Router-də interface-i aktiv et və IP ver.</p>',
          term: { kind: 'router', hostname: 'R1', title: 'R1', quick: ['enable', 'configure terminal', 'show ip interface brief'],
            goals: [
              { text: 'Gig0/0-a <span class="m">192.168.1.1/24</span> ver', test: d => d.run.ifs['GigabitEthernet0/0'] && d.run.ifs['GigabitEthernet0/0'].ip === '192.168.1.1' },
              { text: 'Interface-i <span class="m">no shutdown</span> ilə aç', test: d => d.run.ifs['GigabitEthernet0/0'] && !d.run.ifs['GigabitEthernet0/0'].shut },
            ] },
          hints: ['Əvvəl hansı rejimə keçməlisən?'] },

        // ptsteps: checklist for building in REAL Packet Tracer (cmd may be a string or an array of copyable lines)
        { id: 's6', title: 'Packet Tracer-də qur', type: 'ptsteps',
          body: '<p>Topologiya: ...</p>',
          checks: [
            { t: 'Router-in CLI nişanına keç.' },
            { t: 'Əmrləri yaz:', cmd: ['enable', 'configure terminal', 'interface g0/0', 'ip address 192.168.1.1 255.255.255.0', 'no shutdown'] },
            { t: 'PC-dən ping at:', cmd: 'ping 192.168.1.1' },
          ] },

        // proof form after the PT build: the student types what they SAW
        { id: 's7', title: 'Gördüyünü yaz', type: 'form',
          body: '<p>Ping-in nəticəsi nə oldu? Neçə cavab gəldi?</p>',
          fields: [{ label: 'Cavab sayı', answers: ['4', '3'], wrong: 'Command Prompt-dakı "Reply from" sətirlərini say.' }],
          hints: ['Birinci ping çox vaxt ARP səbəbindən itə bilər.'] },
      ],
    },

    // ---------------------------------------------------------------- QUIZ
    quiz: {
      draw: 8,
      gens: [
        // A generator returns a question object + _meta (used by the Python re-check). Give ids a '-g-' infix.
        () => {
          const p = pick([24, 25, 26]); const net = pick(['192.168.1', '10.0.5']); const ip = net + '.' + (10 + R(100));
          const info = A.info(ip, p); const ans = info.net;
          const pool = shuffle([info.net, info.bc, info.first, info.last]);   // plausible distractors from the same calculation
          return { id: 'p2t1-g-example', concept: 'how-x-works', obj: 'Tələbə nəyi hesablaya bilir', _meta: { ip, p, ans },
            stem: '<p>' + m(ip + '/' + p) + ' ünvanının network ünvanı hansıdır?</p>',
            options: pool.map(t => ({ t, ok: t === ans, why: t === ans ? 'Qayda... Niyə... Burada...' : 'Bu ünvan başqa şeydir: ... (real səhv təsəvvür).' })) };
        },
      ],
      pool: [
        // mc question. Rule for ALL options: Rule -> Why -> Application. Balance option LENGTH (correct must not be longest/shortest too often).
        { id: 'p2t1-q1', concept: 'why-x', obj: 'X-in niyə lazım olduğunu izah etmək',
          stem: '<p>Vəziyyət / konfiqurasiya / çıxış göstər. Sual?</p>',
          options: [
            { t: 'Düzgün cavab.', ok: true, why: 'Qayda: ... Niyə: ... Burada: ...' },
            { t: 'Yanlış 1 (real səhv təsəvvür).', why: 'Niyə yanlışdır: ...' },
            { t: 'Yanlış 2.', why: 'Niyə yanlışdır: ...' },
            { t: 'Yanlış 3.', why: 'Niyə yanlışdır: ...' },
          ] },
        // num question: typed answer
        { id: 'p2t1-q2', concept: 'how-x-works', obj: 'Ədədi cavab', type: 'num',
          stem: '<p>Hesabla: ...</p>', placeholder: 'ədəd', check: r => r.trim() === '254', solution: 'Həll yolu və cavab: <b>254</b>.' },
        // order question
        { id: 'p2t1-q3', concept: 'how-x-works', obj: 'Prosesin sırası', type: 'order',
          stem: '<p>Addımları sırala.</p>',
          items: [{ t: 'Birinci', why: 'Niyə.' }, { t: 'İkinci', why: 'Niyə.' }, { t: 'Üçüncü', why: 'Niyə.' }] },
      ],
    },
  });
})();
