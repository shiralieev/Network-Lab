#!/usr/bin/env python3
"""Netix local server.

Serves the Netix page and keeps all progress in a file next to this script
(Netix_data/state.json), so nothing depends on the browser's memory.
Only the Python standard library is used. It listens on 127.0.0.1 only.

  python server.py                 student copy   (Netix.html,            port 47310)
  python server.py --instructor    instructor copy (Netix_Instructor.html, port 47311)
"""
import argparse, json, os, socket, sys, threading, time, urllib.request, webbrowser
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

HERE = os.path.dirname(os.path.abspath(__file__))
ap = argparse.ArgumentParser()
ap.add_argument('--instructor', action='store_true')
ap.add_argument('--port', type=int, default=0)
ap.add_argument('--no-browser', action='store_true')
args = ap.parse_args()

PAGE = 'Netix_Instructor.html' if args.instructor else 'Netix.html'
DATA_DIR = os.path.join(HERE, 'Netix_Instructor_data' if args.instructor else 'Netix_data')
STATE = os.path.join(DATA_DIR, 'state.json')
BASE_PORT = args.port or (47311 if args.instructor else 47310)
NAME = 'netix-instructor' if args.instructor else 'netix'
LOCK = threading.Lock()


def load_state():
    try:
        with open(STATE, encoding='utf-8') as f:
            d = json.load(f)
            return d if isinstance(d, dict) else {}
    except (OSError, ValueError):
        return {}


def save_state(d):
    os.makedirs(DATA_DIR, exist_ok=True)
    tmp = STATE + '.tmp'
    with open(tmp, 'w', encoding='utf-8') as f:
        json.dump(d, f, ensure_ascii=False)
    os.replace(tmp, STATE)          # atomic: a crash never leaves a half-written file


def search_dirs():
    folder = 'Netix_Instructor' if args.instructor else 'Netix'
    return [HERE, os.path.join(HERE, folder), os.path.join(HERE, 'dist', folder),
            os.path.join(HERE, '..', 'dist', folder), os.path.join(HERE, '..', folder)]


def find_page():
    for d in search_dirs():
        fp = os.path.join(d, PAGE)
        if os.path.isfile(fp):
            return fp
    return None


class Server(ThreadingHTTPServer):
    # On Windows the default SO_REUSEADDR lets a second program bind a port that is already in use.
    # Ask for exclusive use instead, so Netix never shares a port with another app.
    allow_reuse_address = False

    def server_bind(self):
        if os.name == 'nt' and hasattr(socket, 'SO_EXCLUSIVEADDRUSE'):
            self.socket.setsockopt(socket.SOL_SOCKET, socket.SO_EXCLUSIVEADDRUSE, 1)
        super().server_bind()


class Handler(BaseHTTPRequestHandler):
    server_version = 'Netix'

    def log_message(self, *a):      # keep the console quiet
        pass

    def _local_only(self):
        host = (self.headers.get('Host') or '').split(':')[0].lower()
        if host not in ('127.0.0.1', 'localhost', '[::1]'):
            self.send_error(403, 'local access only')
            return False
        origin = self.headers.get('Origin')
        if origin and not (origin.startswith('http://127.0.0.1') or origin.startswith('http://localhost')):
            self.send_error(403, 'bad origin')
            return False
        return True

    def _send(self, code, body, ctype):
        self.send_response(code)
        self.send_header('Content-Type', ctype)
        self.send_header('Content-Length', str(len(body)))
        self.send_header('Cache-Control', 'no-store')
        self.end_headers()
        self.wfile.write(body)

    def do_GET(self):
        if not self._local_only():
            return
        path = self.path.split('?')[0]
        if path in ('/', '/index.html'):
            page = find_page()
            if page:
                with open(page, 'rb') as f:
                    self._send(200, f.read(), 'text/html; charset=utf-8')
            else:
                msg = ('<h2>Netix: cannot find %s</h2><p>Looked in:</p><pre>%s</pre>'
                       '<p>Run the .bat file from the folder that contains %s (the ready folders are dist/Netix and dist/Netix_Instructor), '
                       'or run <code>python build.py</code> first.</p>' % (PAGE, chr(10).join(search_dirs()), PAGE))
                self._send(500, msg.encode('utf-8'), 'text/html; charset=utf-8')
        elif path == '/api/state':
            with LOCK:
                self._send(200, json.dumps(load_state(), ensure_ascii=False).encode('utf-8'), 'application/json')
        elif path == '/api/ping':
            self._send(200, NAME.encode(), 'text/plain')
        else:
            self.send_error(404)

    def do_POST(self):
        if not self._local_only():
            return
        if self.path.split('?')[0] != '/api/state':
            self.send_error(404)
            return
        try:
            n = int(self.headers.get('Content-Length') or 0)
            if n > 5_000_000:
                raise ValueError('too big')
            upd = json.loads(self.rfile.read(n).decode('utf-8'))
            if not isinstance(upd, dict):
                raise ValueError('not an object')
        except (ValueError, OSError):
            self.send_error(400)
            return
        with LOCK:
            st = load_state()
            st.update(upd)
            save_state(st)
        self._send(200, b'{"ok":true}', 'application/json')


def already_running(port):
    try:
        with urllib.request.urlopen('http://127.0.0.1:%d/api/ping' % port, timeout=1) as r:
            return r.read().decode() == NAME
    except Exception:
        return False


def main():
    for port in range(BASE_PORT, BASE_PORT + 20):
        if already_running(port):
            print('Netix is already running. Opening it in the browser...')
            if not args.no_browser:
                webbrowser.open('http://127.0.0.1:%d/' % port)
            return
        try:
            httpd = Server(('127.0.0.1', port), Handler)
            break
        except OSError:
            continue
    else:
        print('Could not find a free port.')
        sys.exit(1)
    url = 'http://127.0.0.1:%d/' % port
    if not find_page():
        print('WARNING: cannot find ' + PAGE + '. Looked in:')
        for d in search_dirs():
            print('   ' + os.path.abspath(d))
        print('Run this from the folder that contains ' + PAGE + ' (dist/Netix or dist/Netix_Instructor).')
    print('=' * 56)
    print('  Netix%s is running at %s' % (' (instructor copy)' if args.instructor else '', url))
    print('  Your progress is saved in: ' + DATA_DIR)
    print('  Keep this window open while you use Netix.')
    print('  Close this window (or press Ctrl+C) to stop it.')
    print('=' * 56)
    if not args.no_browser:
        threading.Timer(0.6, lambda: webbrowser.open(url)).start()
    try:
        httpd.serve_forever()
    except KeyboardInterrupt:
        pass


if __name__ == '__main__':
    main()
