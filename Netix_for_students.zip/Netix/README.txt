Netix - how to run
==================
1. Double-click the .bat file in this folder (Netix.bat, or Netix_Instructor.bat).
2. A black window opens and your browser opens Netix. Keep the black window open while you use it.
3. To stop: close the black window.

Your progress is saved in the "Netix_data" folder next to the .bat file (not in the browser).
Copy that folder to keep or move your progress.

You need Python 3 on the computer (https://www.python.org/downloads/, tick "Add python.exe to PATH").
Use the "English" / "Azərbaycanca" button at the top to switch the language.
